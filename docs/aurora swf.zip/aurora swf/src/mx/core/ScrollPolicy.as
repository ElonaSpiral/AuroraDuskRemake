package mx.core
{
   use namespace mx_internal;
   
   public final class ScrollPolicy
   {
      
      mx_internal static const VERSION:String = "4.6.0.23201";
      
      public static const AUTO:String = "auto";
      
      public static const OFF:String = "off";
      
      public static const ON:String = "on";
      
      public function ScrollPolicy()
      {
         super();
      }
   }
}

