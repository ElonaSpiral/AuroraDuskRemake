package aurora.commun
{
   public class SauvegardeGlobale
   {
      
      public static var sauvegardeEditeur:Boolean = false;
      
      public function SauvegardeGlobale()
      {
         super();
      }
   }
}

