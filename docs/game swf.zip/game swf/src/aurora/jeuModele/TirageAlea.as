package aurora.jeuModele
{
   public class TirageAlea
   {
      
      private var ids:Vector.<String>;
      
      private var totalChances:int;
      
      public function TirageAlea(param1:Vector.<Object>, param2:int = 2147483647)
      {
         var _loc3_:int = 0;
         var _loc4_:String = null;
         var _loc5_:Object = null;
         var _loc6_:int = 0;
         super();
         this.ids = new Vector.<String>();
         for each(_loc5_ in param1)
         {
            if(!_loc5_.secret && (!_loc5_.age || _loc5_.age <= param2))
            {
               _loc4_ = _loc5_.id;
               _loc3_ = int(_loc5_.rate);
               _loc6_ = 0;
               while(_loc6_ < _loc3_)
               {
                  this.ids.push(_loc4_);
                  _loc6_++;
               }
               this.totalChances += _loc3_;
            }
         }
      }
      
      public function tirage() : String
      {
         return this.ids[int(Math.random() * this.totalChances)];
      }
      
      public function tirage_selon_liste_ids(param1:Vector.<Object>, param2:Array, param3:int = 2147483647) : String
      {
         var _loc5_:int = 0;
         var _loc6_:int = 0;
         var _loc7_:String = null;
         var _loc8_:Object = null;
         var _loc9_:int = 0;
         var _loc4_:Vector.<String> = new Vector.<String>();
         for each(_loc8_ in param1)
         {
            if(param2.indexOf(_loc8_.id) != -1)
            {
               if(!_loc8_.age || _loc8_.age <= param3)
               {
                  _loc7_ = _loc8_.id;
                  _loc6_ = int(_loc8_.rate);
                  _loc9_ = 0;
                  while(_loc9_ < _loc6_)
                  {
                     _loc4_.push(_loc7_);
                     _loc9_++;
                  }
                  _loc5_ += _loc6_;
               }
            }
         }
         return _loc4_[int(Math.random() * _loc5_)];
      }
   }
}

