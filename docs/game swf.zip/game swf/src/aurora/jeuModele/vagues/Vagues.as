package aurora.jeuModele.vagues
{
   import aurora.jeuModele.Donnees;
   import aurora.jeuModele.Terrain;
   import aurora.jeuModele.TirageAlea;
   import flash.events.EventDispatcher;
   import flash.events.TimerEvent;
   import flash.utils.ByteArray;
   import flash.utils.Timer;
   
   public class Vagues extends EventDispatcher
   {
      
      private const ORIGINE_NORD:int = 1;
      
      private const ORIGINE_SUD:int = 2;
      
      private const ORIGINE_OUEST:int = 3;
      
      private const ORIGINE_EST:int = 4;
      
      private var premierTemps:Number = 5;
      
      public var nombreVagues:int = 5;
      
      private var tempsVagues:Number = 2;
      
      private var nombreMonstres:int = 10;
      
      private var monstresSupplementaires:int = 0;
      
      public var puissance:Number = 1;
      
      public var direction:int = 0;
      
      public var listeMonstres:Array;
      
      private var _actif:Boolean;
      
      public var noVague:int = 0;
      
      private var temps:Timer;
      
      public var origine:int;
      
      private var _nbMonstres:int;
      
      private var _nbMonstresActifs:int;
      
      private var _nbMonstresMax:int = 50;
      
      public var monstresEnAttente:Vector.<VaguesCreerPerso>;
      
      public var epoque:int;
      
      public var enCours:Boolean;
      
      public function Vagues()
      {
         super();
         this.monstresEnAttente = new Vector.<VaguesCreerPerso>();
      }
      
      public function init_data(param1:Object) : void
      {
         if(Boolean(param1) && Boolean(param1.waves))
         {
            if(param1.waves.first != undefined)
            {
               this.premierTemps = param1.waves.first;
            }
            if(param1.waves.count != undefined)
            {
               this.nombreVagues = param1.waves.count;
            }
            if(param1.waves.timer != undefined)
            {
               this.tempsVagues = param1.waves.timer;
            }
            if(param1.waves.nbMonsters != undefined)
            {
               this.nombreMonstres = param1.waves.nbMonsters;
            }
            if(param1.waves.supMonsters != undefined)
            {
               this.monstresSupplementaires = param1.waves.supMonsters;
            }
            if(param1.waves.power != undefined)
            {
               this.puissance = param1.waves.power;
            }
            if(param1.waves.direction != undefined)
            {
               this.direction = param1.waves.direction;
            }
            if(param1.waves.monsters != undefined)
            {
               this.listeMonstres = param1.waves.monsters;
            }
            if(param1.waves.monstersLimit != undefined)
            {
               this._nbMonstresMax = param1.waves.monstersLimit;
            }
         }
         if(Boolean(param1) && Boolean(param1.towns))
         {
            if(Boolean(param1.towns[0]) && Boolean(param1.towns[0].startingAge))
            {
               this.epoque = param1.towns[0].startingAge;
            }
         }
         this._actif = true;
         if(this.premierTemps < 0.02)
         {
            this.premierTemps = 0.02;
         }
         this.temps = new Timer(1000,this.premierTemps * 60);
         this.temps.addEventListener(TimerEvent.TIMER,this.actualiser_temps);
         this.temps.addEventListener(TimerEvent.TIMER_COMPLETE,this.envoyer_vague);
         this.enCours = Boolean(param1) && Boolean(param1.waves) && param1.waves.count > 0;
      }
      
      public function init() : void
      {
         if(this.enCours)
         {
            this.temps.start();
            dispatchEvent(new VaguesActualiserEvent(VaguesActualiserEvent.ACTUALISER_TEMPS,this.temps.repeatCount));
            dispatchEvent(new VaguesActualiserEvent(VaguesActualiserEvent.ACTUALISER_NO_VAGUE,0));
            dispatchEvent(new VaguesActualiserEvent(VaguesActualiserEvent.ACTUALISER_NB_VAGUES,this.nombreVagues));
         }
      }
      
      public function nombre_de_monstres_restants() : int
      {
         var _loc1_:int = 0;
         var _loc2_:int = 0;
         if(this.enCours)
         {
            _loc2_ = this.noVague;
            while(_loc2_ <= this.nombreVagues)
            {
               _loc1_ += this.nombreMonstres + (_loc2_ - 1) * this.monstresSupplementaires;
               _loc2_++;
            }
         }
         return _loc1_;
      }
      
      private function actualiser_temps(param1:TimerEvent) : void
      {
         dispatchEvent(new VaguesActualiserEvent(VaguesActualiserEvent.ACTUALISER_TEMPS,this.temps.repeatCount - this.temps.currentCount));
      }
      
      private function envoyer_vague(param1:TimerEvent = null) : void
      {
         var _loc2_:int = 0;
         ++this.noVague;
         dispatchEvent(new VaguesActualiserEvent(VaguesActualiserEvent.ACTUALISER_NO_VAGUE,this.noVague));
         if(this.noVague == this.nombreVagues)
         {
            this.enCours = false;
         }
         if(this.noVague <= this.nombreVagues)
         {
            _loc2_ = this.nombreMonstres + (this.noVague - 1) * this.monstresSupplementaires;
            this.envoyer(_loc2_);
            if(this.enCours)
            {
               this.temps.repeatCount = this.tempsVagues * 60;
               this.temps.reset();
               this.temps.start();
            }
         }
      }
      
      public function envoyer_supplementaire(param1:int = 0) : void
      {
         if(param1 == 0)
         {
            param1 = this.nombreMonstres + Math.max(this.noVague - 1,0) * this.monstresSupplementaires;
            ++this.noVague;
         }
         this.envoyer(param1);
      }
      
      private function envoyer(param1:int) : void
      {
         var _loc3_:int = 0;
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         var _loc8_:int = 0;
         var _loc9_:int = 0;
         var _loc11_:int = 0;
         var _loc12_:int = 0;
         var _loc13_:int = 0;
         var _loc14_:int = 0;
         var _loc15_:int = 0;
         var _loc16_:int = 0;
         var _loc18_:VaguesCreerPerso = null;
         var _loc2_:TirageAlea = _loc2_ = new TirageAlea(Donnees.monstres,this.epoque);
         var _loc6_:int = 32;
         var _loc7_:int = 32;
         _loc4_ = Math.min(Math.round(Math.sqrt(param1) * 1.5),Terrain.largeur / _loc6_);
         _loc5_ = Math.ceil(param1 / _loc4_);
         var _loc10_:Vector.<VaguesCreerPerso> = new Vector.<VaguesCreerPerso>();
         if(this.direction == 0)
         {
            this.origine = int(Math.random() * 4) + 1;
         }
         else
         {
            this.origine = this.direction;
         }
         switch(this.origine)
         {
            case this.ORIGINE_NORD:
               _loc3_ = _loc4_;
               _loc15_ = 1;
               _loc16_ = -1;
               if(this.direction == 0)
               {
                  _loc11_ = Math.random() * (Terrain.largeur - _loc4_ * _loc6_);
               }
               else
               {
                  _loc11_ = Terrain.largeur * 0.5 - _loc4_ * _loc6_ * 0.5;
               }
               _loc12_ = 0;
               _loc13_ = Terrain.largeur * 0.5 - _loc4_ * _loc6_ * 0.5;
               _loc14_ = Terrain.hauteur * 0.5;
               break;
            case this.ORIGINE_SUD:
               _loc3_ = _loc4_;
               _loc15_ = 1;
               _loc16_ = 1;
               if(this.direction == 0)
               {
                  _loc11_ = Math.random() * (Terrain.largeur - _loc4_ * _loc6_);
               }
               else
               {
                  _loc11_ = Terrain.largeur * 0.5 - _loc4_ * _loc6_ * 0.5;
               }
               _loc12_ = Terrain.hauteur + _loc7_;
               _loc13_ = Terrain.largeur * 0.5 - _loc4_ * _loc6_ * 0.5;
               _loc14_ = Terrain.hauteur * 0.5;
               break;
            case this.ORIGINE_OUEST:
               _loc3_ = _loc5_;
               _loc15_ = -1;
               _loc16_ = 1;
               _loc11_ = 0;
               if(this.direction == 0)
               {
                  _loc12_ = Math.random() * (Terrain.hauteur - _loc4_ * _loc7_);
               }
               else
               {
                  _loc12_ = Terrain.hauteur * 0.5 - _loc4_ * _loc7_ * 0.5;
               }
               _loc13_ = Terrain.largeur * 0.5;
               _loc14_ = Terrain.hauteur * 0.5 - _loc4_ * _loc7_ * 0.5;
               break;
            case this.ORIGINE_EST:
               _loc3_ = _loc5_;
               _loc15_ = 1;
               _loc16_ = 1;
               _loc11_ = Terrain.largeur + _loc6_;
               if(this.direction == 0)
               {
                  _loc12_ = Math.random() * (Terrain.hauteur - _loc4_ * _loc7_);
               }
               else
               {
                  _loc12_ = Terrain.hauteur * 0.5 - _loc4_ * _loc7_ * 0.5;
               }
               _loc13_ = Terrain.largeur * 0.5;
               _loc14_ = Terrain.hauteur * 0.5 - _loc4_ * _loc7_ * 0.5;
         }
         var _loc17_:int = 0;
         while(_loc17_ < param1)
         {
            _loc18_ = new VaguesCreerPerso(this.listeMonstres ? _loc2_.tirage_selon_liste_ids(Donnees.monstres,this.listeMonstres) : _loc2_.tirage(),_loc15_ * _loc8_ * _loc6_ + _loc11_,_loc16_ * _loc9_ * _loc7_ + _loc12_,_loc15_ * _loc8_ * _loc6_ + _loc13_,_loc16_ * _loc9_ * _loc7_ + _loc14_);
            if(this._nbMonstresActifs < this._nbMonstresMax)
            {
               _loc10_.push(_loc18_);
               ++this._nbMonstresActifs;
            }
            else
            {
               this.monstresEnAttente.push(_loc18_);
            }
            if(++_loc8_ >= _loc3_)
            {
               _loc8_ = 0;
               _loc9_++;
            }
            _loc17_++;
         }
         this.nbMonstres += param1;
         if(_loc10_.length)
         {
            dispatchEvent(new VaguesCreerPersoEvent(VaguesCreerPersoEvent.CREER_PERSO,_loc10_));
         }
      }
      
      public function pause() : void
      {
         if(this.temps)
         {
            this.temps.stop();
         }
      }
      
      public function reprendre() : void
      {
         if(this._actif && this.enCours)
         {
            if(this.temps)
            {
               this.temps.start();
            }
         }
      }
      
      public function get actif() : Boolean
      {
         return this._actif;
      }
      
      public function set actif(param1:Boolean) : void
      {
         this._actif = param1;
         if(this._actif)
         {
            this.reprendre();
         }
         else
         {
            this.pause();
         }
      }
      
      public function get nbMonstres() : int
      {
         return this._nbMonstres;
      }
      
      public function set nbMonstres(param1:int) : void
      {
         this._nbMonstres = param1;
         dispatchEvent(new VaguesActualiserEvent(VaguesActualiserEvent.ACTUALISER_NB_MONSTRES,this._nbMonstres));
      }
      
      public function get nbMonstresActifs() : int
      {
         return this._nbMonstresActifs;
      }
      
      public function set nbMonstresActifs(param1:int) : void
      {
         this._nbMonstresActifs = param1;
      }
      
      public function get nbMonstresMax() : int
      {
         return this._nbMonstresMax;
      }
      
      public function set nbMonstresMax(param1:int) : void
      {
         this._nbMonstresMax = param1;
      }
      
      public function charger(param1:ByteArray) : void
      {
         this.noVague = param1.readInt();
         this.epoque = param1.readInt();
         this.enCours = param1.readBoolean();
         this.temps = new Timer(1000,param1.readInt());
         this.temps.addEventListener(TimerEvent.TIMER,this.actualiser_temps);
         this.temps.addEventListener(TimerEvent.TIMER_COMPLETE,this.envoyer_vague);
      }
      
      public function sauvegarder(param1:ByteArray) : ByteArray
      {
         param1.writeInt(this.noVague);
         param1.writeInt(this.epoque);
         param1.writeBoolean(this.enCours);
         param1.writeInt(this.temps.repeatCount - this.temps.currentCount);
         return param1;
      }
      
      public function detruire() : void
      {
         this.temps.removeEventListener(TimerEvent.TIMER,this.actualiser_temps);
         this.temps.removeEventListener(TimerEvent.TIMER_COMPLETE,this.envoyer_vague);
         this.temps.stop();
      }
   }
}

