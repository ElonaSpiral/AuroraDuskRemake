package aurora.jeuModele.vagues
{
   public class VaguesCreerPerso
   {
      
      public var race:String;
      
      public var x:int;
      
      public var y:int;
      
      public var destinationX:int;
      
      public var destinationY:int;
      
      public var equipe:int;
      
      public var ville:int;
      
      public function VaguesCreerPerso(param1:String, param2:int, param3:int, param4:int, param5:int, param6:int = -1, param7:int = -1)
      {
         super();
         this.race = param1;
         this.x = param2;
         this.y = param3;
         this.destinationX = param4;
         this.destinationY = param5;
         this.equipe = param6;
         this.ville = param7;
      }
   }
}

