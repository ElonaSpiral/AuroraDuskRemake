package aurora.jeuModele.vagues
{
   import flash.events.Event;
   
   public class VaguesActualiserEvent extends Event
   {
      
      public static const ACTUALISER_TEMPS:String = "actualiserTemps";
      
      public static const ACTUALISER_NO_VAGUE:String = "actualiserNoVague";
      
      public static const ACTUALISER_NB_VAGUES:String = "actualiserNbVagues";
      
      public static const ACTUALISER_NB_VILLAGEOIS:String = "actualiserNbVillageois";
      
      public static const ACTUALISER_NB_VILLAGEOIS_MAX:String = "actualiserNbVillageoisMax";
      
      public static const ACTUALISER_NB_MONSTRES:String = "actualiserNbMonstres";
      
      public static const ACTUALISER_NB_SOLDATS:String = "actualiserNbSoldats";
      
      public static const ACTUALISER_NB_SOLDATS_MAX:String = "actualiserNbSoldatsMax";
      
      public var nombre:int;
      
      public var equipe:int;
      
      public function VaguesActualiserEvent(param1:String, param2:int = 0, param3:int = -1)
      {
         this.nombre = param2;
         this.equipe = param3;
         super(param1);
      }
   }
}

