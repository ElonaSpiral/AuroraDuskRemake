package aurora.jeuModele.vagues
{
   import flash.events.Event;
   
   public class VaguesCreerPersoEvent extends Event
   {
      
      public static const CREER_PERSO:String = "creer_perso";
      
      public var vaguesCreerPerso:Vector.<VaguesCreerPerso>;
      
      public function VaguesCreerPersoEvent(param1:String, param2:Vector.<VaguesCreerPerso>)
      {
         this.vaguesCreerPerso = param2;
         super(param1);
      }
   }
}

