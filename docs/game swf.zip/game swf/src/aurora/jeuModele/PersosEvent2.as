package aurora.jeuModele
{
   import flash.events.Event;
   
   public class PersosEvent2 extends Event
   {
      
      public static const CHOISIR_FABRICATION:String = "choisirFabrication";
      
      public var perso:*;
      
      public var noJoueur:int;
      
      public function PersosEvent2(param1:String, param2:* = null, param3:int = 0)
      {
         this.perso = param2;
         this.noJoueur = param3;
         super(param1);
      }
   }
}

