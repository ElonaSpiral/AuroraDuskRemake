package aurora.jeuModele.finPartie
{
   import aurora.jeuModele.perso.Artisan;
   import aurora.jeuModele.perso.Combattant;
   import aurora.jeuModele.perso.Joueur;
   import aurora.jeuModele.vagues.Vagues;
   import flash.utils.Dictionary;
   
   public class FinPartie
   {
      
      private var vagues:Vagues;
      
      private var combattants:Dictionary;
      
      private var batimentResurrection:Dictionary;
      
      private var donjons:Dictionary;
      
      public var nePasVerifierGagne:Boolean;
      
      public var perduSiJoueurMort:Boolean;
      
      public function FinPartie(param1:Vagues, param2:Dictionary, param3:Dictionary, param4:Dictionary)
      {
         super();
         this.vagues = param1;
         this.combattants = param2;
         this.batimentResurrection = param3;
         this.donjons = param4;
      }
      
      public function verifier_gagne(param1:Joueur) : Boolean
      {
         var _loc2_:Object = null;
         if(this.nePasVerifierGagne)
         {
            return false;
         }
         if(Boolean(this.vagues) && this.vagues.enCours)
         {
            return false;
         }
         for each(_loc2_ in this.combattants)
         {
            if(_loc2_ != param1)
            {
               if(Boolean(_loc2_.vivant) && Boolean(_loc2_.equipe != param1.equipe) && _loc2_ is Combattant)
               {
                  return false;
               }
            }
         }
         for each(_loc2_ in this.batimentResurrection)
         {
            if(Boolean(_loc2_.vivant) && _loc2_.equipe != param1.equipe)
            {
               return false;
            }
         }
         for each(_loc2_ in this.donjons)
         {
            if(Boolean(_loc2_.vivant) && _loc2_.equipe != param1.equipe)
            {
               return false;
            }
         }
         return true;
      }
      
      public function verifier_perdu(param1:Joueur) : Boolean
      {
         var _loc2_:Object = null;
         if(this.perduSiJoueurMort)
         {
            return !param1.vivant;
         }
         for each(_loc2_ in this.combattants)
         {
            if(Boolean(_loc2_.vivant) && Boolean(_loc2_.equipe == param1.equipe) && _loc2_ is Artisan)
            {
               return false;
            }
         }
         for each(_loc2_ in this.batimentResurrection)
         {
            if(Boolean(_loc2_.vivant) && _loc2_.equipe == param1.equipe)
            {
               return false;
            }
         }
         for each(_loc2_ in this.donjons)
         {
            if(Boolean(_loc2_.vivant) && _loc2_.equipe == param1.equipe)
            {
               return false;
            }
         }
         return true;
      }
      
      public function detruire() : void
      {
         this.vagues = null;
         this.combattants = null;
         this.batimentResurrection = null;
         this.donjons = null;
      }
   }
}

