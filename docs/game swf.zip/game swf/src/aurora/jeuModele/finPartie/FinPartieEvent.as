package aurora.jeuModele.finPartie
{
   import flash.events.Event;
   
   public class FinPartieEvent extends Event
   {
      
      public static const VERIFIER_FIN_PARTIE:String = "verifierFinPartie";
      
      public static const GAGNER_DIRECT:String = "gagnerDirect";
      
      public function FinPartieEvent(param1:String, param2:Boolean = false, param3:Boolean = false)
      {
         super(param1,param2,param3);
      }
      
      override public function clone() : Event
      {
         return new FinPartieEvent(type,bubbles,cancelable);
      }
      
      override public function toString() : String
      {
         return formatToString("FinPartieEvent","type","bubbles","cancelable","eventPhase");
      }
   }
}

