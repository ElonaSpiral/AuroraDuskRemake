package aurora.jeuModele
{
   import aurora.jeuModele.perso.Animal;
   import aurora.jeuModele.perso.Artisan;
   import aurora.jeuModele.perso.Aventurier;
   import aurora.jeuModele.perso.Batiment;
   import aurora.jeuModele.perso.BatimentCentreVille;
   import aurora.jeuModele.perso.BatimentDonjon;
   import aurora.jeuModele.perso.BatimentMobile;
   import aurora.jeuModele.perso.BatimentOffensif;
   import aurora.jeuModele.perso.BatimentResurrection;
   import aurora.jeuModele.perso.Combattant;
   import aurora.jeuModele.perso.Fondations;
   import aurora.jeuModele.perso.Guerisseur;
   import aurora.jeuModele.perso.Intermediaire;
   import aurora.jeuModele.perso.Joueur;
   import aurora.jeuModele.perso.Maison;
   import aurora.jeuModele.perso.Mobile;
   import aurora.jeuModele.perso.Mur;
   import aurora.jeuModele.perso.Perso;
   import aurora.jeuModele.perso.RessourceMobile;
   import aurora.jeuModele.perso.RessourceTerrain;
   import aurora.jeuModele.perso.Serviteur;
   import aurora.jeuModele.perso.Soldat;
   import aurora.jeuModele.perso.Tresor;
   import aurora.jeuModele.perso.Vivant;
   import aurora.jeuModele.perso.caracteristiquesPrimaires.CaracteristiquePrimaireArtisan;
   import aurora.jeuModele.perso.objets.ObjetEquipe;
   import aurora.jeuModele.ville.Ville;
   import flash.geom.Point;
   import flash.utils.Dictionary;
   
   public class IA
   {
      
      private static var persos:Dictionary;
      
      private static var ressourcesTerrain:Dictionary;
      
      private static var montures:Dictionary;
      
      public static var combattants:Dictionary;
      
      public static var batiments:Dictionary;
      
      public static var batimentsDefense:Dictionary;
      
      public static var batimentResurrection:Dictionary;
      
      public static var batimentCaserne:Dictionary;
      
      public static var centresVille:Dictionary;
      
      private static var terrain:Terrain;
      
      public static var villes:Vector.<Ville>;
      
      public static var tresors:Vector.<Tresor>;
      
      public static var agressif:Boolean;
      
      private static var caracteristiquesPrimaires:Vector.<String>;
      
      public static var ressourcesCarac:Dictionary;
      
      public static var ressourcesTerrainCarac:Dictionary;
      
      public static var matieresPremieres:Dictionary;
      
      public static var matieresPremieresObligatoires:Dictionary;
      
      public static var persoRessource:Dictionary;
      
      public static var atelierRessource:Dictionary;
      
      public static var objetsCarac:Dictionary;
      
      public static var nbToursDefenseEpoques:Vector.<int>;
      
      public static var toursDefenseEpoques:Vector.<Vector.<String>>;
      
      public static var nbMaisonsEpoques:Vector.<int>;
      
      public static var maisonsEpoques:Vector.<Vector.<String>>;
      
      public static var nbSoldatsEpoques:Vector.<int>;
      
      public static var soldatsEpoques:Vector.<Vector.<String>>;
      
      public static var nbObjetsArmesDistanceEpoques:Vector.<int>;
      
      public static var objetsArmesDistanceEpoques:Vector.<Vector.<String>>;
      
      public static var munitionsEpoques:Vector.<Dictionary>;
      
      public static var consommablesEpoques:Vector.<Dictionary>;
      
      public static var nbObjetsArmesContactEpoques:Vector.<int>;
      
      public static var objetsArmesContactEpoques:Vector.<Vector.<String>>;
      
      public static var nbObjetsEpoques:Vector.<int>;
      
      public static var objetsEpoques:Vector.<Vector.<String>>;
      
      public static var objetsCategories:Dictionary;
      
      public static var categoriesPriorites:Vector.<String>;
      
      public static var objetsAteliers:Dictionary;
      
      public static var soldatsAteliers:Dictionary;
      
      public static var soldatsObjets:Dictionary;
      
      public static var nbBatimentsResurrectionEpoques:Vector.<int>;
      
      public static var batimentsResurrectionEpoques:Vector.<Vector.<String>>;
      
      private static var tempCible:Vivant;
      
      public function IA()
      {
         super();
      }
      
      public static function init0() : void
      {
         var _loc1_:Object = null;
         var _loc2_:String = null;
         var _loc3_:Object = null;
         var _loc4_:String = null;
         var _loc5_:String = null;
         var _loc6_:* = 0;
         var _loc7_:int = 0;
         categoriesPriorites = new Vector.<String>();
         categoriesPriorites.splice(0,0,"body","mount","head","feet","hand","belt","back","ring","neck");
         ressourcesCarac = new Dictionary();
         for each(_loc1_ in Donnees.ressources)
         {
            if(_loc1_.gain)
            {
               for(_loc2_ in _loc1_.gain)
               {
                  if(!ressourcesCarac[_loc2_])
                  {
                     ressourcesCarac[_loc2_] = new Vector.<Object>();
                  }
                  ressourcesCarac[_loc2_].push({
                     "id":_loc1_.id,
                     "score":_loc1_.gain[_loc2_]
                  });
               }
            }
         }
         ressourcesTerrainCarac = new Dictionary();
         persoRessource = new Dictionary();
         for each(_loc1_ in Donnees.ressourcesTerrain)
         {
            if(_loc1_.produce)
            {
               _loc6_ = 0;
               for each(_loc3_ in _loc1_.produce)
               {
                  if(_loc3_.gainRessource)
                  {
                     for(_loc2_ in _loc3_.gainRessource)
                     {
                        if(Donnees.donnees[_loc2_].gain)
                        {
                           for(_loc4_ in Donnees.donnees[_loc2_].gain)
                           {
                              if(!ressourcesTerrainCarac[_loc4_])
                              {
                                 ressourcesTerrainCarac[_loc4_] = new Vector.<Object>();
                              }
                              ressourcesTerrainCarac[_loc4_].push({
                                 "id":_loc1_.id,
                                 "no":_loc6_,
                                 "age":_loc1_.age
                              });
                           }
                        }
                     }
                  }
                  _loc6_++;
               }
            }
         }
         matieresPremieres = new Dictionary();
         matieresPremieresObligatoires = new Dictionary();
         for each(_loc1_ in Donnees.donnees)
         {
            if(_loc1_.produce)
            {
               _loc6_ = 0;
               for each(_loc3_ in _loc1_.produce)
               {
                  if(_loc3_.gainRessource)
                  {
                     for(_loc2_ in _loc3_.gainRessource)
                     {
                        if(!persoRessource[_loc2_])
                        {
                           persoRessource[_loc2_] = new Vector.<Object>();
                        }
                        persoRessource[_loc2_].push({
                           "id":_loc1_.id,
                           "type":_loc1_.type,
                           "no":_loc6_,
                           "age":(_loc3_.age ? _loc3_.age : _loc1_.age)
                        });
                        if(_loc3_.costRessource)
                        {
                           for(_loc4_ in _loc3_.costRessource)
                           {
                              if(!Donnees.donnees[_loc4_].disableRawMaterial || Boolean(Donnees.donnees[_loc2_].disableRawMaterial) && Boolean(Donnees.donnees[_loc4_].disableRawMaterial))
                              {
                                 if(!matieresPremieres[_loc2_])
                                 {
                                    matieresPremieres[_loc2_] = new Vector.<Object>();
                                 }
                                 matieresPremieres[_loc2_].push({
                                    "id":_loc4_,
                                    "nb":_loc3_.costRessource[_loc4_] / _loc3_.gainRessource[_loc2_],
                                    "age":(_loc3_.age ? _loc3_.age : Donnees.donnees[_loc2_].age)
                                 });
                              }
                           }
                           if(matieresPremieresObligatoires[_loc2_] == undefined)
                           {
                              matieresPremieresObligatoires[_loc2_] = true;
                           }
                        }
                        else
                        {
                           matieresPremieresObligatoires[_loc2_] = false;
                        }
                     }
                  }
                  _loc6_++;
               }
            }
            if(Boolean(_loc1_.build) && Boolean(_loc1_.death) && Boolean(_loc1_.death.build))
            {
               if(Donnees.donnees[_loc1_.death.build.name].produce)
               {
                  _loc6_ = 0;
                  for each(_loc3_ in Donnees.donnees[_loc1_.death.build.name].produce)
                  {
                     if(_loc3_.gainRessource)
                     {
                        for(_loc2_ in _loc3_.gainRessource)
                        {
                           if(!persoRessource[_loc2_])
                           {
                              persoRessource[_loc2_] = new Vector.<Object>();
                           }
                           persoRessource[_loc2_].push({
                              "id":_loc1_.id,
                              "type":_loc1_.type,
                              "no":_loc6_,
                              "age":_loc1_.age
                           });
                        }
                     }
                     _loc6_++;
                  }
               }
            }
         }
         for each(_loc1_ in persoRessource)
         {
            if(_loc1_.length > 1)
            {
               _loc6_ = 0;
               while(_loc6_ < _loc1_.length)
               {
                  if(Boolean(Donnees.donnees[_loc1_[_loc6_].id].produce) && Boolean(Donnees.donnees[_loc1_[_loc6_].id].produce[_loc1_[_loc6_].no].costRessource))
                  {
                     for(_loc2_ in Donnees.donnees[_loc1_[_loc6_].id].produce[_loc1_[_loc6_].no].costRessource)
                     {
                        if(Donnees.donnees[_loc2_].maxQuantity == "infinity")
                        {
                           _loc1_.splice(_loc6_,1);
                           _loc6_--;
                           break;
                        }
                     }
                  }
                  _loc6_++;
               }
            }
         }
         objetsCarac = new Dictionary();
         for each(_loc1_ in Donnees.objets)
         {
            if(_loc1_["use"])
            {
               if(Boolean(_loc1_["use"].gainPrimaryCharacteristic) && !_loc1_["use"].costPrimaryCharacteristic)
               {
                  for(_loc2_ in _loc1_["use"].gainPrimaryCharacteristic)
                  {
                     if(!objetsCarac[_loc2_])
                     {
                        objetsCarac[_loc2_] = new Vector.<String>();
                     }
                     objetsCarac[_loc2_].push(_loc1_.id);
                  }
               }
            }
         }
         maisonsEpoques = new Vector.<Vector.<String>>();
         nbMaisonsEpoques = new Vector.<int>();
         toursDefenseEpoques = new Vector.<Vector.<String>>();
         nbToursDefenseEpoques = new Vector.<int>();
         soldatsEpoques = new Vector.<Vector.<String>>();
         nbSoldatsEpoques = new Vector.<int>();
         batimentsResurrectionEpoques = new Vector.<Vector.<String>>();
         nbBatimentsResurrectionEpoques = new Vector.<int>();
         nbObjetsArmesDistanceEpoques = new Vector.<int>();
         objetsArmesDistanceEpoques = new Vector.<Vector.<String>>();
         munitionsEpoques = new Vector.<Dictionary>();
         consommablesEpoques = new Vector.<Dictionary>();
         nbObjetsArmesContactEpoques = new Vector.<int>();
         objetsArmesContactEpoques = new Vector.<Vector.<String>>();
         objetsEpoques = new Vector.<Vector.<String>>();
         nbObjetsEpoques = new Vector.<int>();
         objetsCategories = new Dictionary();
         for each(_loc2_ in categoriesPriorites)
         {
            objetsCategories[_loc2_] = new Vector.<Vector.<String>>();
            while(objetsCategories[_loc2_].length < Donnees.epoques.length)
            {
               objetsCategories[_loc2_].push(new Vector.<String>());
            }
         }
         _loc6_ = 0;
         while(_loc6_ < Donnees.epoques.length)
         {
            maisonsEpoques.push(new Vector.<String>());
            for each(_loc2_ in Donnees.maisons)
            {
               if(Boolean(Donnees.donnees[_loc2_] && !Donnees.donnees[_loc2_].secret) && Boolean(Donnees.donnees[_loc2_].age <= _loc6_) && Boolean(Donnees.donnees[_loc2_].build.buildable))
               {
                  maisonsEpoques[_loc6_].push(Donnees.donnees[_loc2_].id);
               }
            }
            nbMaisonsEpoques.push(maisonsEpoques[_loc6_].length);
            toursDefenseEpoques.push(new Vector.<String>());
            for each(_loc2_ in Donnees.toursDefense)
            {
               if(Boolean(Donnees.donnees[_loc2_] && !Donnees.donnees[_loc2_].secret) && Boolean(Donnees.donnees[_loc2_].age <= _loc6_) && Boolean(Donnees.donnees[_loc2_].build.buildable))
               {
                  toursDefenseEpoques[_loc6_].push(Donnees.donnees[_loc2_].id);
               }
            }
            nbToursDefenseEpoques.push(toursDefenseEpoques[_loc6_].length);
            soldatsEpoques.push(new Vector.<String>());
            for each(_loc2_ in Donnees.soldats)
            {
               if(Boolean(Donnees.donnees[_loc2_]) && Boolean(!Donnees.donnees[_loc2_].secret) && Donnees.donnees[_loc2_].age <= _loc6_)
               {
                  soldatsEpoques[_loc6_].push(Donnees.donnees[_loc2_].id);
               }
            }
            nbSoldatsEpoques.push(soldatsEpoques[_loc6_].length);
            batimentsResurrectionEpoques.push(new Vector.<String>());
            for each(_loc2_ in Donnees.batimentsResurrection)
            {
               if(Boolean(Donnees.donnees[_loc2_] && !Donnees.donnees[_loc2_].secret) && Boolean(Donnees.donnees[_loc2_].age <= _loc6_) && Boolean(Donnees.donnees[_loc2_].build.buildable))
               {
                  batimentsResurrectionEpoques[_loc6_].push(Donnees.donnees[_loc2_].id);
               }
            }
            nbBatimentsResurrectionEpoques.push(batimentsResurrectionEpoques[_loc6_].length);
            objetsArmesDistanceEpoques.push(new Vector.<String>());
            munitionsEpoques.push(new Dictionary());
            consommablesEpoques.push(new Dictionary());
            objetsArmesContactEpoques.push(new Vector.<String>());
            objetsEpoques.push(new Vector.<String>());
            for each(_loc1_ in Donnees.donnees)
            {
               if(!_loc1_.secret && _loc1_.age <= _loc6_ && Boolean(_loc1_.produce))
               {
                  for each(_loc3_ in _loc1_.produce)
                  {
                     if(Boolean(_loc3_.gainItem) && Boolean(!_loc3_.age) || _loc3_.age < _loc6_)
                     {
                        for(_loc2_ in _loc3_.gainItem)
                        {
                           if(Boolean(Donnees.donnees[_loc2_]) && Boolean(!Donnees.donnees[_loc2_].secret) && Donnees.donnees[_loc2_].age == _loc6_)
                           {
                              if(Donnees.donnees[_loc2_].category == "weapon" && (!Donnees.donnees[_loc2_].tag || Donnees.donnees[_loc2_].tag.indexOf("tool") == -1))
                              {
                                 if(Boolean(Donnees.donnees[_loc2_].range) && Donnees.donnees[_loc2_].range >= 100)
                                 {
                                    if(objetsArmesDistanceEpoques[_loc6_].indexOf(Donnees.donnees[_loc2_].id) == -1)
                                    {
                                       objetsArmesDistanceEpoques[_loc6_].push(Donnees.donnees[_loc2_].id);
                                    }
                                 }
                                 else if(objetsArmesContactEpoques[_loc6_].indexOf(Donnees.donnees[_loc2_].id) == -1)
                                 {
                                    objetsArmesContactEpoques[_loc6_].push(Donnees.donnees[_loc2_].id);
                                 }
                              }
                           }
                           if(Boolean(Donnees.donnees[_loc2_]) && Donnees.donnees[_loc2_].age <= _loc6_)
                           {
                              if(Donnees.donnees[_loc2_].category != "weapon" && Boolean(Donnees.donnees[_loc2_]["use"]))
                              {
                                 if(objetsEpoques[_loc6_].indexOf(Donnees.donnees[_loc2_].id) == -1)
                                 {
                                    objetsEpoques[_loc6_].push(Donnees.donnees[_loc2_].id);
                                 }
                              }
                              if(Donnees.donnees[_loc2_].age == _loc6_ && categoriesPriorites.indexOf(Donnees.donnees[_loc2_].category) != -1)
                              {
                                 if(objetsCategories[Donnees.donnees[_loc2_].category][_loc6_].indexOf(Donnees.donnees[_loc2_].id) == -1)
                                 {
                                    objetsCategories[Donnees.donnees[_loc2_].category][_loc6_].push(Donnees.donnees[_loc2_].id);
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
            for each(_loc1_ in Donnees.donnees)
            {
               if(!_loc1_.secret && _loc1_.age <= _loc6_)
               {
                  if(Boolean(_loc1_["use"]) && Boolean(_loc1_["use"].gainPrimaryCharacteristic))
                  {
                     for(_loc2_ in _loc1_["use"].gainPrimaryCharacteristic)
                     {
                        if(!consommablesEpoques[_loc6_][_loc2_])
                        {
                           consommablesEpoques[_loc6_][_loc2_] = new Vector.<String>();
                        }
                        consommablesEpoques[_loc6_][_loc2_].push(_loc1_.id);
                     }
                  }
               }
            }
            nbObjetsArmesDistanceEpoques.push(objetsArmesDistanceEpoques[_loc6_].length);
            nbObjetsArmesContactEpoques.push(objetsArmesContactEpoques[_loc6_].length);
            nbObjetsEpoques.push(objetsEpoques[_loc6_].length);
            _loc6_++;
         }
         for each(_loc1_ in Donnees.donnees)
         {
            if(!_loc1_.secret)
            {
               _loc6_ = 0;
               while(_loc6_ < objetsArmesDistanceEpoques.length)
               {
                  for each(_loc2_ in objetsArmesDistanceEpoques[_loc6_])
                  {
                     if(Boolean(Donnees.donnees[_loc2_].attack) && Donnees.donnees[_loc2_].category == "weapon")
                     {
                        if(Donnees.donnees[_loc2_].attack.costItem)
                        {
                           for(_loc3_ in Donnees.donnees[_loc2_].attack.costItem)
                           {
                              if(_loc1_.category == _loc3_)
                              {
                                 _loc7_ = _loc6_;
                                 while(_loc7_ < Donnees.epoques.length)
                                 {
                                    if(_loc1_.age <= _loc7_)
                                    {
                                       if(!munitionsEpoques[_loc7_][_loc2_])
                                       {
                                          munitionsEpoques[_loc7_][_loc2_] = new Vector.<String>();
                                       }
                                       munitionsEpoques[_loc7_][_loc2_].push(_loc1_.id);
                                    }
                                    _loc7_++;
                                 }
                              }
                           }
                        }
                        if(Boolean(_loc1_.category == "edible") && Boolean(_loc1_["use"]) && Boolean(_loc1_["use"].gainPrimaryCharacteristic) && Boolean(Donnees.donnees[_loc2_].attack.costPrimaryCharacteristic))
                        {
                           for(_loc3_ in Donnees.donnees[_loc2_].attack.costPrimaryCharacteristic)
                           {
                              for(_loc4_ in _loc1_["use"].gainPrimaryCharacteristic)
                              {
                                 if(_loc3_ == _loc4_)
                                 {
                                    _loc7_ = _loc6_;
                                    while(_loc7_ < Donnees.epoques.length)
                                    {
                                       if(_loc1_.age <= _loc7_)
                                       {
                                          if(!munitionsEpoques[_loc7_][_loc2_])
                                          {
                                             munitionsEpoques[_loc7_][_loc2_] = new Vector.<String>();
                                          }
                                          munitionsEpoques[_loc7_][_loc2_].push(_loc1_.id);
                                       }
                                       _loc7_++;
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
                  _loc6_++;
               }
            }
         }
         objetsAteliers = new Dictionary();
         soldatsAteliers = new Dictionary();
         soldatsObjets = new Dictionary();
         _loc6_ = 0;
         while(_loc6_ < Donnees.epoques.length)
         {
            for each(_loc1_ in Donnees.donnees)
            {
               if(_loc1_.age == _loc6_)
               {
                  if(_loc1_.type == "workshop" || _loc1_.type == "townCenter" || _loc1_.type == "barrack" || _loc1_.type == "house")
                  {
                     if(_loc1_.produce)
                     {
                        _loc7_ = 0;
                        while(_loc7_ < _loc1_.produce.length)
                        {
                           if(_loc1_.produce[_loc7_].gainItem)
                           {
                              for(_loc2_ in _loc1_.produce[_loc7_].gainItem)
                              {
                                 if(!objetsAteliers[_loc2_])
                                 {
                                    objetsAteliers[_loc2_] = new Vector.<Object>();
                                 }
                                 objetsAteliers[_loc2_].push({
                                    "id":_loc1_.id,
                                    "no":_loc7_
                                 });
                              }
                           }
                           if(_loc1_.produce[_loc7_].createCharacter)
                           {
                              for(_loc2_ in _loc1_.produce[_loc7_].createCharacter)
                              {
                                 if(!soldatsAteliers[_loc2_])
                                 {
                                    soldatsAteliers[_loc2_] = new Vector.<Object>();
                                 }
                                 soldatsAteliers[_loc2_].push({
                                    "id":_loc1_.id,
                                    "no":_loc7_
                                 });
                              }
                           }
                           _loc7_++;
                        }
                     }
                  }
                  else if(_loc1_.type == "item")
                  {
                     if(Boolean(_loc1_["use"]) && Boolean(_loc1_["use"].create))
                     {
                        for each(_loc3_ in _loc1_["use"].create)
                        {
                           if(!soldatsObjets[_loc3_.id])
                           {
                              soldatsObjets[_loc3_.id] = new Vector.<String>();
                           }
                           soldatsObjets[_loc3_.id].push(_loc1_.id);
                        }
                     }
                  }
               }
            }
            _loc6_++;
         }
         caracteristiquesPrimaires = new Vector.<String>();
         for each(_loc1_ in Donnees.caracteristiquesPrimaires)
         {
            if(_loc1_.id != "health")
            {
               caracteristiquesPrimaires.push(_loc1_.id);
            }
         }
      }
      
      public static function init(param1:Dictionary, param2:Dictionary, param3:Dictionary, param4:Dictionary, param5:Vector.<Tresor>, param6:Dictionary, param7:Dictionary, param8:Dictionary, param9:Dictionary, param10:Dictionary, param11:Terrain) : void
      {
         var _loc12_:Object = null;
         IA.persos = param1;
         IA.ressourcesTerrain = param2;
         IA.montures = param3;
         IA.combattants = param4;
         IA.batiments = param6;
         IA.tresors = param5;
         IA.batimentsDefense = param7;
         IA.batimentResurrection = param8;
         IA.batimentCaserne = param9;
         IA.centresVille = param10;
         IA.terrain = param11;
         for each(_loc12_ in param1)
         {
            if(_loc12_ is Artisan)
            {
               gerer_artisan_init(Artisan(_loc12_));
            }
         }
      }
      
      public static function trouver_ennemi_proche(param1:Object, param2:int = 2147483647) : Object
      {
         var _loc4_:int = 0;
         var _loc5_:Object = null;
         var _loc6_:Object = null;
         if(param2 < int.MAX_VALUE)
         {
            param2 += param1.rayon;
         }
         var _loc3_:int = int.MAX_VALUE;
         for each(_loc6_ in combattants)
         {
            if(Boolean(_loc6_.vivant) && _loc6_.equipe != param1.equipe)
            {
               _loc4_ = int(param1.distance(_loc6_));
               if(_loc4_ < _loc3_ && _loc4_ < _loc6_.rayon + param2)
               {
                  _loc3_ = _loc4_;
                  _loc5_ = _loc6_;
               }
            }
         }
         return _loc5_;
      }
      
      public static function trouver_ennemis_zone(param1:int, param2:int, param3:int, param4:int) : Vector.<Object>
      {
         var _loc6_:Object = null;
         var _loc5_:Vector.<Object> = new Vector.<Object>();
         param4 *= param4;
         for each(_loc6_ in persos)
         {
            if(Boolean(_loc6_ is Vivant && _loc6_.vivant) && Boolean(_loc6_.equipe != param3) && Math.pow(param1 - _loc6_.x,2) + Math.pow(param2 - _loc6_.y,2) < param4)
            {
               _loc5_.push(_loc6_);
            }
         }
         return _loc5_;
      }
      
      public static function trouver_ennemi_proche_exceptions(param1:int, param2:int, param3:int, param4:Vector.<Object>, param5:int) : Object
      {
         var _loc7_:int = 0;
         var _loc8_:Object = null;
         var _loc9_:Object = null;
         var _loc6_:int = int.MAX_VALUE;
         param5 *= param5;
         for each(_loc9_ in persos)
         {
            if(Boolean(_loc9_ is Vivant && _loc9_.vivant) && Boolean(_loc9_.equipe != param3) && param4.indexOf(_loc9_) == -1)
            {
               _loc7_ = Math.pow(param1 - _loc9_.x,2) + Math.pow(param2 - _loc9_.y,2);
               if(_loc7_ < _loc6_ && _loc7_ < param5)
               {
                  _loc6_ = _loc7_;
                  _loc8_ = _loc9_;
               }
            }
         }
         return _loc8_;
      }
      
      public static function trouver_ennemis_chaine(param1:Object, param2:int, param3:int, param4:int, param5:int, param6:int) : Vector.<Object>
      {
         var _loc8_:Object = null;
         var _loc7_:Vector.<Object> = new Vector.<Object>();
         _loc7_.push(param1);
         var _loc9_:int = 0;
         while(_loc9_ < param6)
         {
            _loc8_ = trouver_ennemi_proche_exceptions(param2,param3,param4,_loc7_,param5);
            if(!_loc8_)
            {
               break;
            }
            _loc7_.push(_loc8_);
            _loc9_++;
         }
         return _loc7_;
      }
      
      private static function en_danger(param1:Artisan, param2:int = 384) : Boolean
      {
         var _loc3_:Object = null;
         for each(_loc3_ in combattants)
         {
            if(Boolean(_loc3_.cibleCombat != null && (_loc3_.cibleCombat == param1 || _loc3_.cibleCombat == param1.cibleTravail)) && Boolean(_loc3_.vivant) && param1.distance(_loc3_) < param2)
            {
               return true;
            }
         }
         return false;
      }
      
      public static function trouver_butin_proche(param1:Object, param2:int) : Object
      {
         var _loc4_:int = 0;
         var _loc5_:Object = null;
         var _loc3_:int = int.MAX_VALUE;
         for each(_loc5_ in ressourcesTerrain)
         {
            if(_loc5_ is RessourceTerrain && _loc5_.idCreateur == param2)
            {
               return _loc5_;
            }
         }
         return null;
      }
      
      public static function trouver_ennemi_procheXY(param1:Object, param2:Number, param3:Number, param4:int = 88) : Object
      {
         var _loc6_:int = 0;
         var _loc7_:Object = null;
         var _loc8_:Object = null;
         var _loc5_:int = int.MAX_VALUE;
         for each(_loc8_ in combattants)
         {
            if(Boolean(_loc8_.vivant) && _loc8_.equipe != param1.equipe)
            {
               _loc6_ = Math.sqrt(Math.pow(param2 - _loc8_.x,2) + Math.pow(param3 - _loc8_.y,2));
               if(_loc6_ < _loc5_ && _loc6_ < _loc8_.rayon + param4)
               {
                  _loc5_ = _loc6_;
                  _loc7_ = _loc8_;
               }
            }
         }
         return _loc7_;
      }
      
      public static function trouver_ennemi_attaquant_cible(param1:Object, param2:Object) : Object
      {
         var _loc4_:int = 0;
         var _loc5_:Object = null;
         var _loc6_:Object = null;
         var _loc3_:int = int.MAX_VALUE;
         for each(_loc6_ in combattants)
         {
            if(Boolean(_loc6_.vivant) && Boolean(_loc6_.equipe != param1.equipe) && _loc6_.cibleCombat == param2)
            {
               _loc4_ = Math.sqrt(Math.pow(param2.x - _loc6_.x,2) + Math.pow(param2.y - _loc6_.y,2));
               if(_loc4_ < _loc3_)
               {
                  _loc3_ = _loc4_;
                  _loc5_ = _loc6_;
               }
            }
         }
         return _loc5_;
      }
      
      public static function trouver_cible_proche(param1:Object, param2:int = 2147483647) : Vivant
      {
         var _loc4_:int = 0;
         var _loc5_:Vivant = null;
         var _loc6_:Object = null;
         if(param2 < int.MAX_VALUE)
         {
            param2 += param1.rayon;
         }
         var _loc3_:int = int.MAX_VALUE;
         for each(_loc6_ in persos)
         {
            if(_loc6_ is Vivant)
            {
               if(Boolean(_loc6_.vivant && _loc6_.visible && _loc6_.equipe != param1.equipe && !(_loc6_ is RessourceMobile)) && Boolean(!(_loc6_ is Animal)) && !(_loc6_ is Mur))
               {
                  _loc4_ = int(param1.distance(_loc6_));
                  if(_loc4_ < _loc3_ && _loc4_ < _loc6_.rayon + param2)
                  {
                     _loc3_ = _loc4_;
                     _loc5_ = Vivant(_loc6_);
                  }
               }
            }
         }
         return _loc5_;
      }
      
      public static function trouver_tresor_proche(param1:Artisan, param2:int = 800) : void
      {
         var _loc4_:int = 0;
         var _loc5_:Tresor = null;
         var _loc6_:Tresor = null;
         var _loc3_:int = int.MAX_VALUE;
         for each(_loc6_ in tresors)
         {
            if(_loc6_.visible)
            {
               _loc4_ = param1.distance(_loc6_);
               if(_loc4_ < _loc3_ && _loc4_ < param2)
               {
                  _loc3_ = _loc4_;
                  _loc5_ = _loc6_;
               }
            }
         }
         if(_loc5_)
         {
            param1.aller(_loc5_.x,_loc5_.y);
         }
      }
      
      public static function trouver_allies_proches(param1:Object, param2:int = 2147483647) : Vector.<Object>
      {
         var _loc4_:int = 0;
         var _loc6_:Object = null;
         if(param2 < int.MAX_VALUE)
         {
            param2 += param1.rayon;
         }
         var _loc3_:int = int.MAX_VALUE;
         var _loc5_:Vector.<Object> = new Vector.<Object>();
         for each(_loc6_ in persos)
         {
            if(_loc6_ is Vivant)
            {
               if(Boolean(_loc6_ is Mobile && !(_loc6_ is BatimentMobile) && _loc6_.vivant && _loc6_.visible) && Boolean(_loc6_.equipe == param1.equipe) && _loc6_ != param1)
               {
                  _loc4_ = int(param1.distance(_loc6_));
                  if(_loc4_ < _loc3_ && _loc4_ < _loc6_.rayon + param2)
                  {
                     _loc3_ = _loc4_;
                     _loc5_.push(_loc6_);
                  }
               }
            }
         }
         return _loc5_;
      }
      
      public static function trouver_blesse_proche(param1:Object, param2:int = 2147483647) : Vivant
      {
         var _loc4_:int = 0;
         var _loc5_:Vivant = null;
         var _loc6_:Object = null;
         if(param2 < int.MAX_VALUE)
         {
            param2 += param1.rayon;
         }
         var _loc3_:int = int.MAX_VALUE;
         for each(_loc6_ in persos)
         {
            if(_loc6_ is Vivant)
            {
               if(Boolean(_loc6_ is Combattant && !(_loc6_ is BatimentMobile) && _loc6_.vivant && _loc6_.visible && _loc6_.equipe == param1.equipe) && Boolean(_loc6_.vie.resteRecuperer > 0) && _loc6_ != param1)
               {
                  _loc4_ = int(param1.distance(_loc6_));
                  if(_loc4_ < _loc3_ && _loc4_ < _loc6_.rayon + param2)
                  {
                     _loc3_ = _loc4_;
                     _loc5_ = Vivant(_loc6_);
                  }
               }
            }
         }
         return _loc5_;
      }
      
      public static function trouver_batiment_vente(param1:Object) : Object
      {
         var _loc3_:int = 0;
         var _loc4_:Vivant = null;
         var _loc5_:Object = null;
         var _loc2_:int = int.MAX_VALUE;
         for each(_loc5_ in persos)
         {
            if(_loc5_ is Batiment)
            {
               if(Boolean(Donnees.donnees[_loc5_.race].buyItems) && Boolean(_loc5_.vivant) && Boolean(_loc5_.visible) && _loc5_.equipe == param1.equipe)
               {
                  _loc3_ = int(param1.distance(_loc5_));
                  if(_loc3_ < _loc2_)
                  {
                     _loc2_ = _loc3_;
                     _loc4_ = Vivant(_loc5_);
                  }
               }
            }
         }
         return _loc4_;
      }
      
      public static function projectile_cible_proche(param1:Object, param2:int = 2147483647) : Vivant
      {
         var _loc3_:int = 0;
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         var _loc6_:int = 0;
         var _loc7_:int = 0;
         var _loc8_:Vivant = null;
         var _loc9_:Object = null;
         if(param2 < int.MAX_VALUE)
         {
            param2 += param1.rayon;
         }
         _loc3_ = int.MAX_VALUE;
         _loc5_ = int(param1.x);
         _loc6_ = param1.y - param1.hauteur * 0.5;
         _loc7_ = int(param1.equipe);
         for each(_loc9_ in persos)
         {
            if(Boolean(_loc9_ is Vivant && _loc9_.equipe != _loc7_) && Boolean(_loc9_.vivant) && Boolean(_loc9_.visible) && _loc9_ != param1)
            {
               _loc4_ = Math.sqrt(Math.pow(_loc5_ - _loc9_.x,2) + Math.pow(_loc6_ - _loc9_.y + _loc9_.hauteur * 0.5,2));
               if(_loc4_ < _loc9_.rayon + param2 && _loc4_ < _loc3_)
               {
                  _loc8_ = Vivant(_loc9_);
               }
            }
         }
         return _loc8_;
      }
      
      public static function zone_sure(param1:Number, param2:Number, param3:int, param4:int = 128) : Boolean
      {
         var _loc5_:Object = null;
         for each(_loc5_ in combattants)
         {
            if(Boolean(_loc5_.vivant) && _loc5_.equipe != param3)
            {
               if(Math.abs(_loc5_.x - param1) < param4 && Math.abs(_loc5_.y - param2) < param4)
               {
                  return false;
               }
            }
         }
         return true;
      }
      
      public static function gerer_mobile(param1:Mobile) : void
      {
         if(param1.enAttente)
         {
            deplacement_aleatoire(param1);
         }
      }
      
      public static function gerer_combattant(param1:Combattant) : void
      {
         if(!param1.suitOrdre)
         {
            tempCible = trouver_cible_proche(param1,param1.portee + 64);
            if(Math.random() < 0.9)
            {
               if(!param1.enCombat)
               {
                  if(agressif)
                  {
                     tempCible = trouver_cible_proche(param1,Math.random() < 0.95 ? 768 : int.MAX_VALUE);
                  }
                  else
                  {
                     tempCible = trouver_cible_proche(param1,Math.random() < 0.99 ? 512 : 2048);
                  }
                  if(tempCible)
                  {
                     param1.attaquer(tempCible);
                  }
               }
               else
               {
                  tempCible = trouver_cible_proche(param1,param1.portee + 64);
                  if(Boolean(tempCible) && (tempCible is Combattant || tempCible is BatimentOffensif || tempCible is BatimentMobile || tempCible is Mur))
                  {
                     param1.attaquer(tempCible);
                  }
               }
            }
            else
            {
               gerer_mobile(param1);
            }
         }
      }
      
      public static function gerer_guerisseur(param1:Guerisseur) : void
      {
         var _loc2_:int = 0;
         var _loc3_:Vivant = null;
         if(!param1.suitOrdre && param1.ordre != Soldat.ORDRE_ARRET)
         {
            _loc2_ = Math.max(128,param1.portee);
            _loc3_ = trouver_blesse_proche(param1,_loc2_);
            if(_loc3_)
            {
               param1.attaquer(_loc3_);
            }
            else if(param1.enAttente)
            {
               if(param1.ordre == Soldat.ORDRE_SUIVRE)
               {
                  param1.suivre_maitre();
               }
               else if(param1.ordre != Soldat.ORDRE_PATROUILLE && param1.revenirPositionOrigine)
               {
                  param1.revenir_origine();
               }
               else
               {
                  gerer_mobile(param1);
               }
            }
         }
      }
      
      public static function gerer_serviteur(param1:Object) : void
      {
         var _loc2_:Vivant = null;
         if(!param1.suitOrdre)
         {
            switch(param1.ordre)
            {
               case Soldat.ORDRE_SUIVRE:
                  param1.suivre_maitre();
                  break;
               case Soldat.ORDRE_ATTAQUE:
                  _loc2_ = trouver_cible_proche(param1);
                  if(_loc2_)
                  {
                     param1.attaquer(_loc2_);
                  }
                  if(Boolean(param1.enAttente) && Boolean(param1.revenirPositionOrigine))
                  {
                     param1.revenir_origine();
                  }
                  break;
               case Soldat.ORDRE_DEFENSE:
                  if(param1 is Combattant && Boolean(param1.portee))
                  {
                     _loc2_ = trouver_cible_proche(param1,param1.portee);
                  }
                  else if(param1.revenirPositionOrigine)
                  {
                     _loc2_ = Vivant(trouver_ennemi_procheXY(param1,param1.origineX,param1.origineY,512));
                  }
                  else
                  {
                     _loc2_ = trouver_cible_proche(param1,512);
                  }
                  if(_loc2_)
                  {
                     param1.attaquer(_loc2_);
                  }
                  if(Boolean(param1.enAttente) && Boolean(param1.revenirPositionOrigine))
                  {
                     param1.revenir_origine();
                  }
                  break;
               case Soldat.ORDRE_PATROUILLE:
                  _loc2_ = trouver_cible_proche(param1,Math.max(512,param1.portee));
                  if(_loc2_)
                  {
                     param1.attaquer(_loc2_);
                  }
                  if(param1.enAttente)
                  {
                     gerer_mobile(Mobile(param1));
                  }
            }
         }
      }
      
      public static function gerer_villageois(param1:Serviteur) : void
      {
         var _loc3_:String = null;
         var _loc4_:int = 0;
         var _loc5_:String = null;
         var _loc6_:Object = null;
         var _loc7_:Object = null;
         var _loc8_:int = 0;
         var _loc9_:int = 0;
         var _loc10_:Object = null;
         var _loc11_:String = null;
         var _loc12_:Object = null;
         var _loc2_:BatimentCentreVille = trouver_centre_ville(param1);
         if(Boolean(param1.enAttente) && Boolean(param1.iaRessourceOrdre) && param1.ressources[param1.iaRessourceOrdre].quantite > 0)
         {
            if(param1.batimentEntrer == _loc2_ && !param1.visible)
            {
               for(_loc3_ in param1.ressources)
               {
                  if(param1.ressources[_loc3_].quantite > 0)
                  {
                     param1.entrepot_ressource(false,_loc3_,param1.ressources[_loc3_].quantite);
                  }
               }
            }
            else
            {
               param1.aller_batiment(_loc2_);
            }
            return;
         }
         if(param1.vie.resteRecuperer > 0)
         {
            recuperer_caracteristiquePrimaire(param1,"health");
            if(param1.enAttente && param1.vie.resteRecuperer > 0)
            {
               trouver_ressource_procheCarac(param1,"health",false);
            }
         }
         else if(recuperer_caracteristiques(param1,0.5))
         {
            if(param1.enAttente)
            {
               if(_loc2_)
               {
                  if(Math.random() > 0.95)
                  {
                     _loc8_ = 1024;
                     for each(_loc10_ in ressourcesTerrain)
                     {
                        if((_loc10_ is RessourceTerrain || _loc10_ is RessourceMobile || _loc10_ is Animal) && Math.random() < 0.1 && zone_sure(_loc10_.x,_loc10_.y,param1.equipe))
                        {
                           _loc9_ = param1.distance(_loc10_);
                           if(_loc9_ < _loc8_)
                           {
                              _loc8_ = _loc9_;
                              _loc7_ = _loc10_;
                           }
                        }
                     }
                     if(_loc7_)
                     {
                        if(_loc7_ is Animal)
                        {
                           param1.attaquer(Vivant(_loc7_));
                           param1.iaRessourceOrdre;
                        }
                        else
                        {
                           param1.aller_travailler(Perso(_loc7_));
                        }
                        for(_loc11_ in persoRessource)
                        {
                           for each(_loc12_ in persoRessource[_loc11_])
                           {
                              if(_loc12_.id == _loc7_.race)
                              {
                                 param1.iaRessourceOrdre = _loc11_;
                                 param1.iaBesoinRessourcesQuantite = 0;
                              }
                           }
                        }
                        return;
                     }
                  }
                  _loc4_ = int.MAX_VALUE;
                  for each(_loc6_ in Donnees.ressources)
                  {
                     if(_loc6_.age <= param1.epoque && !_loc6_.sellResource)
                     {
                        if(_loc2_.ressources[_loc6_.id].quantite == 0)
                        {
                           param1.iaRessourceOrdre = _loc6_.id;
                           param1.iaBesoinRessourcesQuantite = 1;
                           trouver_ressource(param1,_loc6_.id);
                           return;
                        }
                        if(_loc2_.ressources[_loc6_.id].quantite < _loc4_ && Math.random() < 0.25)
                        {
                           _loc4_ = int(_loc2_.ressources[_loc6_.id].quantite);
                           _loc5_ = _loc6_.id;
                        }
                     }
                  }
                  if(reparer_batiment(param1) && construire_centre_ville(param1))
                  {
                     if(_loc5_)
                     {
                        param1.iaRessourceOrdre = _loc5_;
                        param1.iaBesoinRessourcesQuantite = 0;
                        trouver_ressource(param1,_loc5_);
                        return;
                     }
                  }
                  return;
               }
               construire_centre_ville(param1);
            }
         }
      }
      
      private static function gerer_artisan_init(param1:Artisan) : void
      {
         if(consommablesEpoques[param1.epoque]["stamina"])
         {
            param1.iaConstruireObjet = consommablesEpoques[param1.epoque]["stamina"][int(Math.random() * consommablesEpoques[param1.epoque]["stamina"].length)];
         }
      }
      
      public static function gerer_artisan(param1:Artisan) : void
      {
         if(param1.vivant)
         {
            if(param1.iaPersonnalisee)
            {
               gerer_ia_personnalisee(param1);
            }
            else
            {
               gerer_artisan2(param1);
            }
         }
         else if(param1.enAttente)
         {
            trouver_batimentResurrection(param1);
         }
      }
      
      public static function gerer_artisan2(param1:Artisan) : void
      {
         var _loc2_:int = 0;
         var _loc3_:Boolean = false;
         var _loc4_:String = null;
         var _loc5_:Vivant = null;
         gerer_equipement(param1);
         if(param1.iaPretAuCombat)
         {
            if(param1.vie.resteRecuperer > 0)
            {
               recuperer_caracteristiquePrimaire(param1,"health");
               if(param1.iaConstruireObjet == "" || !Donnees.donnees[param1.iaConstruireObjet]["use"] || !Donnees.donnees[param1.iaConstruireObjet]["use"].gainPrimaryCharacteristic)
               {
                  if(consommablesEpoques[param1.epoque]["health"])
                  {
                     param1.iaConstruireObjet = consommablesEpoques[param1.epoque]["health"][int(Math.random() * consommablesEpoques[param1.epoque]["health"].length)];
                  }
               }
            }
            else if(param1.vie.auMax)
            {
               riposter(param1);
            }
            if(Math.random() <= 0.02)
            {
               trouver_tresor_proche(param1);
            }
            if(param1.enAttente)
            {
               if(recuperer_caracteristiques(param1,0.1))
               {
                  if(param1.vie.resteRecuperer > 0)
                  {
                     trouver_ressource_procheCarac(param1,"health",false);
                  }
                  else if(recuperer_caracteristiques(param1,0.5))
                  {
                     if(trouver_monture(param1))
                     {
                        return;
                     }
                     if(reparer_batiment(param1) && construire_centre_ville(param1) && construire_maison(param1,true))
                     {
                        _loc2_ = param1.epoque;
                        if(agressif)
                        {
                           if(possede_batiments_resurrection(param1.equipe,false) || batimentsResurrectionEpoques[_loc2_].length == 0 && param1.iaArmesDistancesPreferees.length > 0 && !param1.iaArmesDistancesMunitionsNecessaires && param1.iaArmesDistancesPreferees[0].donnees.age == _loc2_ && Math.random() < 0.65)
                           {
                              tempCible = trouver_cible_proche(param1,Math.random() < 0.95 ? 512 : int.MAX_VALUE);
                              if(tempCible)
                              {
                                 param1.attaquer(tempCible);
                              }
                           }
                        }
                        else if(param1.iaEquipementAuMax && possede_batiments_resurrection(param1.equipe,false) || batimentsResurrectionEpoques[_loc2_].length == 0 && !param1.iaArmesDistancesMunitionsNecessaires && Math.random() < 0.5)
                        {
                           tempCible = trouver_cible_proche(param1,int.MAX_VALUE);
                           if(tempCible)
                           {
                              param1.attaquer(tempCible);
                           }
                        }
                        if(param1.enAttente)
                        {
                           if(param1.iaConstruireObjet == "" && param1.iaConstruireBatiment == "" && param1.iaConstruireSoldat == "")
                           {
                              _loc3_ = possede_batiments_resurrection(param1.equipe) || batimentsResurrectionEpoques[_loc2_].length == 0;
                              if(Math.random() < 0.95 && _loc3_)
                              {
                                 if(param1.iaConstruireObjet == "")
                                 {
                                    param1.iaConstruireObjet = choisir_objet_a_fabriquer(param1);
                                 }
                              }
                              else if(Math.random() < 0.15 && _loc3_)
                              {
                                 if(param1.iaConstruireSoldat == "")
                                 {
                                    if(soldatsEpoques[_loc2_].length > 0)
                                    {
                                       param1.iaConstruireSoldat = soldatsEpoques[_loc2_][int(Math.random() * nbSoldatsEpoques[_loc2_])];
                                    }
                                 }
                              }
                              else if(param1.iaConstruireBatiment == "")
                              {
                                 if((batimentsResurrectionEpoques[_loc2_].length == 0 || _loc3_) && toursDefenseEpoques[_loc2_].length > 0)
                                 {
                                    param1.iaConstruireBatiment = toursDefenseEpoques[_loc2_][int(Math.random() * nbToursDefenseEpoques[_loc2_])];
                                 }
                                 else if(batimentsResurrectionEpoques[_loc2_].length > 0)
                                 {
                                    param1.iaConstruireBatiment = batimentsResurrectionEpoques[_loc2_][int(Math.random() * nbBatimentsResurrectionEpoques[_loc2_])];
                                 }
                              }
                              return;
                           }
                           if(param1.iaConstruireObjet != "")
                           {
                              fabriquer_objet(param1,param1.iaConstruireObjet);
                           }
                           else if(param1.iaConstruireSoldat != "")
                           {
                              recruter_soldat(param1,param1.iaConstruireSoldat);
                           }
                           else if(param1.iaConstruireBatiment != "")
                           {
                              if(param1.peut_payer(Donnees.donnees[param1.iaConstruireBatiment].build,true,false))
                              {
                                 if(Donnees.donnees[param1.iaConstruireBatiment].category == "defenseTower" || Donnees.donnees[param1.iaConstruireBatiment].category == "buildingMonster" || manque_batiment(param1.iaConstruireBatiment,param1.equipe))
                                 {
                                    creer_batiment_depuis_centre_ville(param1,param1.iaConstruireBatiment);
                                 }
                                 else
                                 {
                                    param1.iaConstruireBatiment = "";
                                 }
                              }
                              else
                              {
                                 _loc4_ = besoin_ressource_construction(param1,Donnees.donnees[param1.iaConstruireBatiment].build,true);
                                 if(_loc4_)
                                 {
                                    trouver_ressource(param1,_loc4_);
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
            else if(param1.enCombat)
            {
               if(!(param1.cibleCombat is Animal))
               {
                  _loc5_ = trouver_cible_proche(param1);
                  if(_loc5_)
                  {
                     param1.attaquer(_loc5_);
                  }
               }
            }
         }
      }
      
      private static function riposter(param1:Artisan) : void
      {
         if(param1.iaMemoireCible)
         {
            if(param1.iaArmesDistancesPreferees.length > 0 && !param1.iaArmesDistancesMunitionsNecessaires)
            {
               tempCible = trouver_cible_proche(param1);
               if(tempCible)
               {
                  param1.attaquer(tempCible);
               }
            }
            param1.iaMemoireCible = false;
         }
      }
      
      private static function choisir_objet_a_fabriquer(param1:Artisan) : String
      {
         var _loc2_:String = null;
         var _loc3_:String = null;
         var _loc4_:String = null;
         var _loc5_:String = null;
         var _loc6_:* = 0;
         var _loc7_:int = 0;
         if(param1.iaArmesDistancesPreferees.length == 0 || Boolean(param1.iaArmesDistancesPreferees.length == 1) && Boolean(param1.iaArmesDistancesPreferees[0].donnees.oneHand))
         {
            return objetsArmesDistanceEpoques[param1.epoque][int(Math.random() * nbObjetsArmesDistanceEpoques[param1.epoque])];
         }
         if(param1.iaArmesDistancesMunitionsNecessaires)
         {
            verifier_munitions(param1);
            if(param1.iaArmesDistancesMunitionsNecessaires)
            {
               if(param1.iaArmesDistancesPreferees.length > 0)
               {
                  if(munitionsEpoques[param1.epoque][param1.iaArmesDistancesPreferees[0].id])
                  {
                     _loc2_ = munitionsEpoques[param1.epoque][param1.iaArmesDistancesPreferees[0].id][int(Math.random() * munitionsEpoques[param1.epoque][param1.iaArmesDistancesPreferees[0]])];
                     if(param1.quantite_objet(_loc2_) <= (Donnees.donnees[_loc2_].category == "edible" ? 5 : 50))
                     {
                        return _loc2_;
                     }
                  }
               }
               if(param1.iaArmesDistancesPreferees.length > 1 && Boolean(param1.iaArmesDistancesPreferees[0].donnees.oneHand))
               {
                  if(munitionsEpoques[param1.epoque][param1.iaArmesDistancesPreferees[1].id])
                  {
                     _loc3_ = munitionsEpoques[param1.epoque][param1.iaArmesDistancesPreferees[1].id][int(Math.random() * munitionsEpoques[param1.epoque][param1.iaArmesDistancesPreferees[1]])];
                     if(param1.quantite_objet(_loc3_) <= (Donnees.donnees[_loc3_].category == "edible" ? 5 : 50))
                     {
                        return _loc3_;
                     }
                  }
               }
            }
            return "";
         }
         if(param1.iaArmesContactPreferees.length == 0 || Boolean(param1.iaArmesContactPreferees.length == 1) && Boolean(param1.iaArmesContactPreferees[0].donnees.oneHand))
         {
            if(objetsArmesContactEpoques[param1.epoque].length > 0)
            {
               return objetsArmesContactEpoques[param1.epoque][int(Math.random() * nbObjetsArmesContactEpoques[param1.epoque])];
            }
            return "";
         }
         if(param1.iaArmesDistancesPreferees.length > 0 && param1.iaArmesDistancesPreferees[0].donnees.age < param1.epoque || Boolean(param1.iaArmesDistancesPreferees.length > 1 && param1.iaArmesDistancesPreferees[0].donnees.oneHand) && Boolean(param1.iaArmesDistancesPreferees[1].donnees.age < param1.epoque))
         {
            return objetsArmesDistanceEpoques[param1.epoque][int(Math.random() * nbObjetsArmesDistanceEpoques[param1.epoque])];
         }
         if(param1.iaArmesContactPreferees.length > 0 && param1.iaArmesContactPreferees[0].donnees.age < param1.epoque || Boolean(param1.iaArmesContactPreferees.length > 1 && param1.iaArmesContactPreferees[0].donnees.oneHand) && Boolean(param1.iaArmesContactPreferees[1].donnees.age < param1.epoque))
         {
            return objetsArmesContactEpoques[param1.epoque][int(Math.random() * nbObjetsArmesContactEpoques[param1.epoque])];
         }
         if(!param1.iaEquipementAuMax)
         {
            for each(_loc5_ in categoriesPriorites)
            {
               if(!param1.possede_categorie(_loc5_))
               {
                  _loc6_ = param1.epoque;
                  while(_loc6_ > 0 && objetsCategories[_loc5_][_loc6_].length == 0)
                  {
                     _loc6_--;
                  }
                  if(objetsCategories[_loc5_][_loc6_].length > 0)
                  {
                     _loc4_ = objetsCategories[_loc5_][_loc6_][int(Math.random() * objetsCategories[_loc5_][_loc6_].length)];
                  }
                  break;
               }
            }
            if(!_loc4_)
            {
               for each(_loc5_ in categoriesPriorites)
               {
                  if(param1.possede_categorie_epoque(_loc5_) < param1.epoque)
                  {
                     if(objetsCategories[_loc5_][param1.epoque].length > 0)
                     {
                        _loc4_ = objetsCategories[_loc5_][param1.epoque][int(Math.random() * objetsCategories[_loc5_][param1.epoque].length)];
                     }
                     break;
                  }
               }
            }
         }
         if(!_loc4_)
         {
            param1.iaEquipementAuMax = true;
            _loc7_ = int(Math.random() * (param1.epoque + 1));
            _loc4_ = objetsEpoques[_loc7_][int(Math.random() * nbObjetsEpoques[_loc7_])];
         }
         if(param1.possede_objet(_loc4_) != -1)
         {
            return "";
         }
         return _loc4_;
      }
      
      private static function gerer_ia_personnalisee(param1:Artisan) : void
      {
         var _loc2_:Object = null;
         var _loc3_:int = 0;
         var _loc4_:int = 0;
         var _loc5_:Vivant = null;
         gerer_equipement(param1);
         if(param1.iaPretAuCombat)
         {
            if(param1.vie.resteRecuperer > 0)
            {
               recuperer_caracteristiquePrimaire(param1,"health");
               if(param1.vie.resteRecuperer > 0 && !param1.enCombat)
               {
                  trouver_ressource_procheCarac(param1,"health",false);
               }
            }
            else if(param1.vie.auMax)
            {
               riposter(param1);
            }
            if(param1.enAttente)
            {
               if(Math.random() <= 0.01)
               {
                  trouver_tresor_proche(param1);
                  return;
               }
               if(recuperer_caracteristiques(param1,0.5))
               {
                  if(trouver_monture(param1))
                  {
                     return;
                  }
                  if(reparer_batiment(param1) && construire_centre_ville(param1) && construire_maison(param1,false))
                  {
                     _loc4_ = 0;
                     while(_loc4_ < param1.iaOrdresEpoques[param1.epoque].length)
                     {
                        _loc2_ = param1.iaOrdresEpoques[param1.epoque][_loc4_];
                        if(_loc2_.item)
                        {
                           if(param1.quantite_objet(_loc2_.item) < _loc2_.quantite)
                           {
                              if(Boolean(Donnees.donnees[_loc2_.item].gain) && Boolean(Donnees.donnees[_loc2_.item].gain.king) && Boolean(villes[param1.ville].roi))
                              {
                                 gerer_artisan2(param1);
                                 return;
                              }
                              if(gerer_ia_personnalisee_zone_sure(param1))
                              {
                                 fabriquer_objet(param1,_loc2_.item);
                              }
                              return;
                           }
                        }
                        else if(_loc2_.ressource)
                        {
                           if(param1.ressources[_loc2_.ressource].quantite < _loc2_.quantite)
                           {
                              if(gerer_ia_personnalisee_zone_sure(param1))
                              {
                                 trouver_ressource(param1,_loc2_.ressource);
                              }
                              return;
                           }
                        }
                        else if(_loc2_.landRessource)
                        {
                           if(nombre_ressources(param1,_loc2_.landRessource,param1.equipe,640) < _loc2_.quantite)
                           {
                              if(gerer_ia_personnalisee_zone_sure(param1))
                              {
                                 param1.creer_perso(_loc2_.landRessource);
                                 deplacement_aleatoire(param1);
                              }
                              return;
                           }
                        }
                        else if(_loc2_.animal)
                        {
                           if(nombre_ressources(param1,_loc2_.animal,param1.equipe,640) < _loc2_.quantite)
                           {
                              if(gerer_ia_personnalisee_zone_sure(param1))
                              {
                                 param1.creer_perso(_loc2_.animal);
                                 deplacement_aleatoire(param1);
                              }
                              return;
                           }
                        }
                        else if(_loc2_.defenseTower)
                        {
                           if(reparer_batiment_type(param1,_loc2_.defenseTower))
                           {
                              return;
                           }
                           if(nombre_persos(_loc2_.defenseTower,param1.equipe) < _loc2_.quantite)
                           {
                              if(gerer_ia_personnalisee_zone_sure(param1))
                              {
                                 gerer_ia_personnalisee_construction(param1,_loc2_.defenseTower);
                              }
                              return;
                           }
                        }
                        else if(_loc2_.resurrectTower)
                        {
                           if(reparer_batiment_type(param1,_loc2_.resurrectTower))
                           {
                              return;
                           }
                           if(nombre_persos(_loc2_.resurrectTower,param1.equipe) < _loc2_.quantite)
                           {
                              if(gerer_ia_personnalisee_zone_sure(param1))
                              {
                                 gerer_ia_personnalisee_construction(param1,_loc2_.resurrectTower);
                              }
                              return;
                           }
                        }
                        else if(_loc2_.buildingMonster)
                        {
                           if(reparer_batiment_type(param1,_loc2_.buildingMonster))
                           {
                              return;
                           }
                           if(nombre_persos(_loc2_.buildingMonster,param1.equipe) < _loc2_.quantite)
                           {
                              if(gerer_ia_personnalisee_zone_sure(param1))
                              {
                                 gerer_ia_personnalisee_construction(param1,_loc2_.buildingMonster);
                              }
                              return;
                           }
                        }
                        else if(_loc2_.barrack)
                        {
                           if(reparer_batiment_type(param1,_loc2_.barrack))
                           {
                              return;
                           }
                           if(nombre_persos(_loc2_.barrack,param1.equipe) < _loc2_.quantite)
                           {
                              if(gerer_ia_personnalisee_zone_sure(param1))
                              {
                                 gerer_ia_personnalisee_construction(param1,_loc2_.barrack);
                              }
                              return;
                           }
                        }
                        else if(_loc2_.workshop)
                        {
                           if(reparer_batiment_type(param1,_loc2_.workshop))
                           {
                              return;
                           }
                           if(nombre_persos(_loc2_.workshop,param1.equipe) < _loc2_.quantite)
                           {
                              if(gerer_ia_personnalisee_zone_sure(param1))
                              {
                                 gerer_ia_personnalisee_construction(param1,_loc2_.workshop);
                              }
                              return;
                           }
                        }
                        else if(_loc2_.house)
                        {
                           if(_loc3_ < 1)
                           {
                              if(Boolean(param1.maison) && Boolean(Vivant(param1.maison).blesse) && param1.peut_payer(Donnees.donnees[_loc2_.house].build,true,false))
                              {
                                 param1.aller_reparer(param1.maison);
                                 return;
                              }
                              if(!param1.maison || param1.maison is Fondations && Fondations(param1.maison).creation != _loc2_.house || !(param1.maison is Fondations) && param1.maison.race != _loc2_.house)
                              {
                                 if(gerer_ia_personnalisee_zone_sure(param1))
                                 {
                                    gerer_ia_personnalisee_maison(param1,_loc2_.house);
                                 }
                                 return;
                              }
                              _loc3_++;
                           }
                        }
                        else if(_loc2_.monster)
                        {
                           if(nombre_serviteurs(_loc2_.monster,param1) < _loc2_.quantite)
                           {
                              if(gerer_ia_personnalisee_zone_sure(param1))
                              {
                                 gerer_ia_personnalisee_soldats(param1,_loc2_.monster);
                              }
                              return;
                           }
                        }
                        _loc4_++;
                     }
                     renforcer_equipement(param1);
                     if(param1.enAttente)
                     {
                        riposter(param1);
                        if(param1.enAttente)
                        {
                           tempCible = trouver_cible_proche(param1);
                           if(tempCible)
                           {
                              param1.attaquer(tempCible);
                           }
                           else if(reparer_batiment(param1,true))
                           {
                              deplacement_aleatoire(param1);
                           }
                        }
                     }
                  }
               }
            }
            else if(param1.enCombat)
            {
               if(!(param1.cibleCombat is Animal))
               {
                  _loc5_ = trouver_cible_proche(param1);
                  if(_loc5_)
                  {
                     param1.attaquer(_loc5_);
                  }
               }
            }
         }
      }
      
      private static function gerer_ia_personnalisee_zone_sure(param1:Artisan) : Boolean
      {
         var _loc2_:Vivant = null;
         if(en_danger(param1))
         {
            if(Math.pow(param1.x - villes[param1.equipe].x,2) + Math.pow(param1.y - villes[param1.equipe].y,2) > 2048)
            {
               aller_centre_ville(param1);
            }
            else
            {
               if(!param1.iaPretAuCombat)
               {
                  return true;
               }
               _loc2_ = trouver_cible_proche(param1);
               if(_loc2_)
               {
                  param1.attaquer(_loc2_);
               }
            }
            return false;
         }
         return true;
      }
      
      private static function gerer_ia_personnalisee_construction(param1:Artisan, param2:String) : void
      {
         var _loc3_:Object = null;
         var _loc4_:String = null;
         if(param1.peut_payer(Donnees.donnees[param2].build,true,false))
         {
            _loc3_ = trouver_fondation(param1,param2);
            if(_loc3_)
            {
               param1.aller_reparer(Perso(_loc3_));
            }
            else
            {
               param1.creer_perso(param2);
               if(param1.enAttente)
               {
                  deplacement_aleatoire(param1);
               }
            }
         }
         else
         {
            _loc4_ = besoin_ressource_construction(param1,Donnees.donnees[param2].build,true);
            if(_loc4_)
            {
               trouver_ressource(param1,_loc4_);
            }
         }
      }
      
      private static function gerer_ia_personnalisee_maison(param1:Artisan, param2:String) : void
      {
         var _loc3_:Object = null;
         var _loc4_:String = null;
         if(param1.peut_payer(Donnees.donnees[param2].build,true,false))
         {
            _loc3_ = param1.maison;
            if(_loc3_)
            {
               param1.aller_reparer(Perso(_loc3_));
            }
            else
            {
               param1.creer_perso(param2);
               if(param1.enAttente)
               {
                  deplacement_aleatoire(param1);
               }
            }
         }
         else
         {
            _loc4_ = besoin_ressource_construction(param1,Donnees.donnees[param2].build,true);
            if(_loc4_)
            {
               trouver_ressource(param1,_loc4_);
            }
         }
      }
      
      private static function trouver_fondation(param1:Artisan, param2:String) : Object
      {
         var _loc3_:Object = null;
         var _loc5_:int = 0;
         var _loc6_:Object = null;
         var _loc4_:int = int.MAX_VALUE;
         for each(_loc6_ in batiments)
         {
            if(_loc6_ is Fondations && _loc6_.creation == param2 && _loc6_.equipe == param1.equipe)
            {
               _loc5_ = param1.distance(_loc6_);
               if(_loc5_ < _loc4_)
               {
                  _loc4_ = _loc5_;
                  _loc3_ = _loc6_;
               }
            }
         }
         return _loc3_;
      }
      
      private static function gerer_ia_personnalisee_soldats(param1:Artisan, param2:String) : void
      {
         var _loc4_:String = null;
         var _loc6_:String = null;
         var _loc3_:Array = Donnees.donnees[param2].from;
         var _loc5_:int = 0;
         while(_loc5_ < _loc3_.length)
         {
            if(Boolean(Donnees.donnees[_loc3_[_loc5_]]) && Boolean(Donnees.donnees[_loc3_[_loc5_]].age <= param1.epoque) && (!Donnees.donnees[_loc3_[_loc5_]].endingAge || Donnees.donnees[_loc3_[_loc5_]].endingAge >= param1.epoque))
            {
               _loc4_ = _loc3_[_loc5_];
               break;
            }
            _loc5_++;
         }
         if(_loc4_)
         {
            if(Donnees.donnees[_loc4_].type == "barrack" || Donnees.donnees[_loc4_].type == "townCenter" || Donnees.donnees[_loc4_].type == "workshop" || Donnees.donnees[_loc4_].type == "house")
            {
               recruter_soldat(param1,param2);
            }
            else
            {
               for each(_loc6_ in _loc3_)
               {
                  _loc5_ = 0;
                  while(_loc5_ < param1.objets.length)
                  {
                     if(param1.objets[_loc5_].id == _loc6_)
                     {
                        param1.utiliser_objet(_loc5_);
                        return;
                     }
                     _loc5_++;
                  }
               }
               fabriquer_objet(param1,_loc4_);
            }
         }
      }
      
      private static function nombre_persos(param1:String, param2:int) : int
      {
         var _loc3_:int = 0;
         var _loc4_:Object = null;
         for each(_loc4_ in persos)
         {
            if(_loc4_ is Vivant && _loc4_.equipe == param2 && _loc4_.race == param1)
            {
               _loc3_++;
            }
         }
         return _loc3_;
      }
      
      private static function nombre_serviteurs(param1:String, param2:Object) : int
      {
         var _loc3_:int = 0;
         var _loc4_:Object = null;
         for each(_loc4_ in combattants)
         {
            if(_loc4_.race == param1)
            {
               if(_loc4_ is Soldat && _loc4_.maitre == param2)
               {
                  _loc3_++;
               }
               else if(_loc4_ is Serviteur)
               {
                  _loc3_++;
               }
            }
         }
         return _loc3_;
      }
      
      private static function nombre_ressources(param1:Artisan, param2:String, param3:int, param4:int = 640) : int
      {
         var _loc5_:int = 0;
         var _loc6_:Object = null;
         for each(_loc6_ in persos)
         {
            if(_loc6_.race == param2 || _loc6_ is Intermediaire && _loc6_.creation == param2 && _loc6_.distance(param1) < param4)
            {
               _loc5_++;
            }
         }
         return _loc5_;
      }
      
      public static function peut_invoquer(param1:int, param2:int = 1) : Boolean
      {
         return villes[param1].nbSoldats + param2 < villes[param1].nbSoldatsMax + 1;
      }
      
      public static function verifier_munitions(param1:Aventurier) : void
      {
         var _loc2_:int = 0;
         var _loc3_:String = null;
         var _loc4_:String = null;
         param1.iaArmesDistancesMunitionsNecessaires = false;
         if(param1.iaArmesDistancesPreferees.length > 0)
         {
            for each(_loc3_ in munitionsEpoques[param1.epoque][param1.iaArmesDistancesPreferees[0].id])
            {
               param1.iaArmesDistancesMunitionsNecessaires = true;
               _loc2_ = param1.possede_objet(_loc3_);
               if(_loc2_ != -1 && param1.objets[_loc2_].quantite >= (Donnees.donnees[_loc3_].category == "edible" ? 5 : 50))
               {
                  param1.iaArmesDistancesMunitionsNecessaires = false;
                  break;
               }
            }
         }
         if(Boolean(param1.iaArmesDistancesPreferees.length > 1) && Boolean(param1.iaArmesDistancesPreferees[0].donnees.oneHand) && Boolean(param1.iaArmesDistancesPreferees[1].donnees.oneHand))
         {
            for each(_loc4_ in munitionsEpoques[param1.epoque][param1.iaArmesDistancesPreferees[1].id])
            {
               param1.iaArmesDistancesMunitionsNecessaires = true;
               _loc2_ = param1.possede_objet(_loc4_);
               if(_loc2_ != -1 && param1.objets[_loc2_].quantite >= (Donnees.donnees[_loc4_].category == "edible" ? 5 : 50))
               {
                  param1.iaArmesDistancesMunitionsNecessaires = false;
                  break;
               }
            }
         }
      }
      
      private static function possede_batiments_resurrection(param1:int, param2:Boolean = true) : Boolean
      {
         var _loc3_:BatimentResurrection = null;
         var _loc4_:Object = null;
         for each(_loc3_ in batimentResurrection)
         {
            if(_loc3_.equipe == param1)
            {
               return true;
            }
         }
         if(param2)
         {
            for each(_loc4_ in batiments)
            {
               if(_loc4_ is Fondations && Donnees.donnees[_loc4_.creation].type == "resurrectTower" && _loc4_.equipe == param1)
               {
                  return true;
               }
            }
         }
         return false;
      }
      
      private static function manque_batiment(param1:String, param2:int) : Boolean
      {
         var _loc3_:Object = null;
         for each(_loc3_ in batiments)
         {
            if(_loc3_.id == param1 && _loc3_.equipe == param2 || _loc3_ is Fondations && _loc3_.creation == param1)
            {
               return false;
            }
         }
         return true;
      }
      
      private static function fabriquer_objet(param1:Artisan, param2:String) : void
      {
         var _loc3_:int = 0;
         var _loc4_:int = 0;
         var _loc6_:String = null;
         var _loc7_:String = null;
         _loc3_ = 0;
         while(_loc3_ < param1.objets.length)
         {
            if(param1.objets[_loc3_].donnees.upgrade)
            {
               _loc4_ = 0;
               while(_loc4_ < param1.objets[_loc3_].donnees.upgrade.length)
               {
                  if(param1.objets[_loc3_].donnees.upgrade[_loc4_].gainItem)
                  {
                     for(_loc6_ in param1.objets[_loc3_].donnees.upgrade[_loc4_].gainItem)
                     {
                        if(_loc6_ == param2)
                        {
                           ameliorer_objet(param1,_loc3_,_loc4_,param1.objets[_loc3_].donnees.upgrade[_loc4_].workshop);
                           return;
                        }
                     }
                  }
                  _loc4_++;
               }
            }
            _loc3_++;
         }
         if(Donnees.donnees[param2].from)
         {
            for each(_loc7_ in Donnees.donnees[param2].from)
            {
               _loc3_ = 0;
               while(_loc3_ < param1.objets.length)
               {
                  if(param1.objets[_loc3_].id == _loc7_)
                  {
                     param1.utiliser_objet(_loc3_);
                     return;
                  }
                  _loc3_++;
               }
            }
            _loc3_ = 0;
            while(_loc3_ < Donnees.donnees[param2].from.length)
            {
               if(Donnees.donnees[Donnees.donnees[param2].from[_loc3_]].age <= param1.epoque)
               {
                  param2 = Donnees.donnees[Donnees.donnees[param2].from[_loc3_]].id;
                  break;
               }
               _loc3_++;
            }
         }
         var _loc5_:int = Math.random() * objetsAteliers[param2].length;
         while(Boolean(Donnees.donnees[objetsAteliers[param2][_loc5_].id].endingAge) && Donnees.donnees[objetsAteliers[param2][_loc5_].id].endingAge < param1.epoque + 1)
         {
            _loc5_ = Math.random() * objetsAteliers[param2].length;
         }
         trouver_creation(param1,objetsAteliers[param2][_loc5_].id,objetsAteliers[param2][_loc5_].no);
      }
      
      private static function recruter_soldat(param1:Artisan, param2:String) : void
      {
         var _loc3_:int = soldatsAteliers[param2].length - 1;
         trouver_creation(param1,soldatsAteliers[param2][_loc3_].id,soldatsAteliers[param2][_loc3_].no);
      }
      
      private static function trouver_creation(param1:Artisan, param2:String, param3:int) : void
      {
         var _loc5_:String = null;
         var _loc4_:Object = trouver_ressource_proche2(param1,param2);
         if(_loc4_)
         {
            if(_loc4_ is Fondations)
            {
               reparer_batiment2(param1,_loc4_);
            }
            else
            {
               _loc5_ = besoin_ressource_construction(param1,Donnees.donnees[param2].produce[param3]);
               if(_loc5_)
               {
                  trouver_ressource(param1,_loc5_);
               }
               else
               {
                  param1.creer_objet(Perso(_loc4_),param3);
               }
            }
         }
         else
         {
            creer_atelier2(param1,param2);
         }
      }
      
      private static function ameliorer_objet(param1:Artisan, param2:int, param3:int, param4:String) : void
      {
         var _loc6_:String = null;
         var _loc5_:Object = trouver_ressource_proche2(param1,param4);
         if(_loc5_)
         {
            if(_loc5_ is Fondations)
            {
               reparer_batiment2(param1,_loc5_);
            }
            else
            {
               _loc6_ = besoin_ressource_construction(param1,Donnees.donnees[param1.objets[param2].id].upgrade[param3]);
               if(_loc6_)
               {
                  trouver_ressource(param1,_loc6_);
               }
               else if(_loc6_ is Fondations)
               {
                  reparer_batiment2(param1,_loc6_);
               }
               else
               {
                  param1.ameliorer_objet(param2,param3);
               }
            }
         }
         else
         {
            creer_atelier2(param1,param4);
         }
      }
      
      private static function creer_atelier2(param1:Artisan, param2:String) : void
      {
         var _loc3_:String = null;
         if(Donnees.donnees[param2].type == "townCenter")
         {
            construire_centre_ville(param1);
         }
         else
         {
            _loc3_ = besoin_ressource_construction(param1,Donnees.donnees[param2].build,true);
            if(_loc3_)
            {
               trouver_ressource(param1,_loc3_);
            }
            else
            {
               creer_atelier(param1,param2);
            }
         }
      }
      
      private static function construire_centre_ville(param1:Artisan) : Boolean
      {
         var _loc3_:BatimentCentreVille = null;
         var _loc4_:Object = null;
         var _loc5_:String = null;
         var _loc6_:Point = null;
         var _loc7_:String = null;
         if(!param1.enAttente)
         {
            return false;
         }
         if(Math.random() > 0.25)
         {
            return true;
         }
         var _loc2_:Ville = villes[param1.ville];
         if(_loc2_.sansCentreVille)
         {
            return true;
         }
         if(_loc2_.iaIdCentreVille)
         {
            if(param1.peut_payer(Donnees.donnees[_loc2_.iaIdCentreVille].build,true,false))
            {
               for each(_loc4_ in batiments)
               {
                  if(_loc4_.ville == param1.ville)
                  {
                     if(_loc4_ is Fondations && _loc4_.creation == _loc2_.iaIdCentreVille)
                     {
                        param1.aller_travailler(Fondations(_loc4_));
                        return false;
                     }
                  }
               }
            }
            for each(_loc3_ in centresVille)
            {
               if(_loc3_.ville == param1.ville)
               {
                  if(_loc3_.blesse)
                  {
                     if(param1.peut_payer(Donnees.donnees[_loc3_.creation ? _loc3_.creation : _loc3_.race].build,true,false))
                     {
                        param1.aller_travailler(_loc3_);
                        return false;
                     }
                     _loc5_ = besoin_ressource_construction(param1,Donnees.donnees[_loc3_.creation ? _loc3_.creation : _loc3_.race].build,true);
                     if(_loc5_)
                     {
                        trouver_ressource(param1,_loc5_);
                        return false;
                     }
                     if(param1.enAttente)
                     {
                        deplacement_aleatoire(param1);
                     }
                     return true;
                  }
                  return true;
               }
            }
            if(param1.peut_payer(Donnees.donnees[_loc2_.iaIdCentreVille].build,true,false))
            {
               _loc6_ = trouver_position_centre_ville(villes[param1.ville].x,villes[param1.ville].y,Donnees.donnees[_loc2_.iaIdCentreVille].width,Donnees.donnees[_loc2_.iaIdCentreVille].height,16,2048);
               if(_loc6_)
               {
                  param1.creer_persoXY(_loc2_.iaIdCentreVille,_loc6_.x,_loc6_.y);
               }
               else
               {
                  param1.creer_perso(_loc2_.iaIdCentreVille);
               }
               if(param1.enAttente)
               {
                  deplacement_aleatoire(param1);
               }
               return false;
            }
            _loc7_ = besoin_ressource_construction(param1,Donnees.donnees[_loc2_.iaIdCentreVille].build,true);
            if(_loc7_)
            {
               trouver_ressource(param1,_loc7_);
               return false;
            }
            if(param1.enAttente)
            {
               deplacement_aleatoire(param1);
            }
            return true;
         }
         return true;
      }
      
      private static function creer_batiment_depuis_centre_ville(param1:Artisan, param2:String) : void
      {
         var _loc4_:int = 0;
         var _loc5_:BatimentCentreVille = null;
         var _loc6_:BatimentCentreVille = null;
         var _loc7_:Point = null;
         var _loc3_:int = int.MAX_VALUE;
         for each(_loc6_ in centresVille)
         {
            if(_loc6_.ville == param1.ville)
            {
               _loc4_ = param1.distance(_loc6_);
               if(_loc4_ < _loc3_)
               {
                  _loc3_ = _loc4_;
                  _loc5_ = _loc6_;
               }
            }
         }
         if(_loc5_)
         {
            _loc7_ = trouver_position_libre_construction_depuis_centre_ville(_loc5_.x,_loc5_.y,Donnees.donnees[param2].width,Donnees.donnees[param2].height,16,Math.max(Terrain.largeur,Terrain.hauteur) * 0.0625);
            if(_loc7_)
            {
               param1.creer_persoXY(param2,_loc7_.x,_loc7_.y);
               return;
            }
            param1.creer_perso(param2);
         }
         _loc7_ = trouver_position_libre_construction_depuis_centre_ville(villes[param1.ville].x,villes[param1.ville].y,Donnees.donnees[param2].width,Donnees.donnees[param2].height,16,Math.max(Terrain.largeur,Terrain.hauteur) * 0.0625);
         if(_loc7_)
         {
            param1.creer_persoXY(param2,_loc7_.x,_loc7_.y);
         }
      }
      
      private static function trouver_position_centre_ville(param1:Number, param2:Number, param3:int, param4:int, param5:int, param6:int) : Point
      {
         var _loc7_:int = 0;
         var _loc8_:int = 0;
         var _loc9_:int = 0;
         var _loc10_:int = 0;
         if(position_libre_contruction(param3,param4,param1,param2))
         {
            return new Point(param1,param2);
         }
         switch(int(Math.random() * 4))
         {
            case 0:
               _loc10_ = 0;
               _loc9_ = param5;
               break;
            case 1:
               _loc10_ = param5;
               _loc9_ = 0;
               break;
            case 2:
               _loc10_ = 0;
               _loc9_ = -param5;
               break;
            case 3:
               _loc10_ = -param5;
               _loc9_ = 0;
         }
         continue loop0;
      }
      
      private static function trouver_position_libre_construction_depuis_centre_ville(param1:Number, param2:Number, param3:int, param4:int, param5:int, param6:int) : Point
      {
         var _loc7_:int = 0;
         var _loc8_:int = 0;
         var _loc9_:int = 0;
         var _loc10_:int = 0;
         var _loc11_:int = 0;
         var _loc12_:int = 0;
         var _loc13_:int = 0;
         var _loc14_:int = 0;
         if(!position_libre_contruction(param3,param4,param1,param2))
         {
            _loc7_ = (Math.random() - 0.5) * param5;
            _loc8_ = (Math.random() - 0.5) * param5;
            if(_loc7_ == 0 && _loc8_ == 0)
            {
               return null;
            }
            _loc9_ = _loc10_ = _loc11_ = param1;
            _loc12_ = _loc13_ = _loc14_ = param2;
            while(param1 > 0 && param1 < Terrain.largeur && param2 > 0 && param2 < Terrain.hauteur)
            {
               param1 += _loc7_;
               param2 += _loc8_;
               if(position_libre_contruction(param3,param4,param1,param2))
               {
                  return new Point(param1,param2);
               }
               _loc9_ -= _loc7_;
               _loc12_ += _loc8_;
               if(position_libre_contruction(param3,param4,_loc9_,_loc12_))
               {
                  return new Point(_loc9_,_loc12_);
               }
               _loc10_ += _loc7_;
               _loc13_ -= _loc8_;
               if(position_libre_contruction(param3,param4,_loc10_,_loc13_))
               {
                  return new Point(_loc10_,_loc13_);
               }
               _loc11_ -= _loc7_;
               _loc14_ -= _loc8_;
               if(position_libre_contruction(param3,param4,_loc11_,_loc14_))
               {
                  return new Point(_loc11_,_loc14_);
               }
            }
            return null;
         }
         return new Point(param1,param2);
      }
      
      private static function position_libre_contruction(param1:int, param2:int, param3:int, param4:int) : Boolean
      {
         var _loc5_:Perso = null;
         if(!Terrain.emplacement_constructible(param3,param4,param1,param2))
         {
            return false;
         }
         for each(_loc5_ in persos)
         {
            if(_loc5_ is RessourceTerrain || _loc5_ is Batiment || _loc5_ is BatimentMobile || _loc5_ is Intermediaire || _loc5_ is Fondations)
            {
               if(param3 + param1 * 0.5 + _loc5_.largeur * 0.5 >= _loc5_.x && param3 <= _loc5_.x + param1 * 0.5 + _loc5_.largeur * 0.5 && param4 + _loc5_.hauteur >= _loc5_.y && param4 <= _loc5_.y + param2)
               {
                  return false;
               }
            }
         }
         return true;
      }
      
      private static function construire_maison(param1:Artisan, param2:Boolean) : Boolean
      {
         var _loc3_:String = null;
         var _loc4_:String = null;
         if(Math.random() > 0.05)
         {
            return true;
         }
         if(param1.maison)
         {
            if(param1.maison is Fondations)
            {
               _loc3_ = besoin_ressource_construction(param1,Donnees.donnees[Fondations(param1.maison).creation].build,true);
               if(_loc3_)
               {
                  trouver_ressource(param1,_loc3_);
               }
               else
               {
                  param1.rentrer_maison();
               }
               return false;
            }
            if(param2)
            {
               if(param1.maisonEpoque < param1.epoque)
               {
                  _loc4_ = maisonsEpoques[param1.epoque][int(Math.random() * nbMaisonsEpoques[param1.epoque])];
                  if(Donnees.donnees[_loc4_].age > param1.maisonEpoque)
                  {
                     param1.demolir_maison();
                     param1.iaConstruireBatiment = _loc4_;
                  }
               }
               return true;
            }
         }
         else if(maisonsEpoques[param1.epoque].length > 0)
         {
            param1.iaConstruireBatiment = maisonsEpoques[param1.epoque][int(Math.random() * nbMaisonsEpoques[param1.epoque])];
            return true;
         }
         return true;
      }
      
      private static function reparer_batiment(param1:Artisan, param2:Boolean = false) : Boolean
      {
         var _loc3_:Object = null;
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         var _loc6_:Object = null;
         var _loc7_:String = null;
         if(!(param1 is Joueur) || param2)
         {
            _loc4_ = 1024;
            for each(_loc6_ in batiments)
            {
               if(_loc6_.equipe == param1.equipe && _loc6_ is Fondations && Donnees.donnees[_loc6_.creation].type == "resurrectTower")
               {
                  _loc5_ = param1.distance(_loc6_);
                  if(_loc5_ < _loc4_)
                  {
                     _loc4_ = _loc5_;
                     _loc3_ = _loc6_;
                  }
               }
            }
            if(!_loc3_)
            {
               _loc4_ = 1024;
               for each(_loc6_ in batiments)
               {
                  if(Boolean(_loc6_.equipe == param1.equipe && _loc6_.blesse && _loc6_.vivant) && Boolean(!(_loc6_ is BatimentDonjon)) && (!(_loc6_ is BatimentMobile) || BatimentMobile(_loc6_).enAttente))
                  {
                     if(_loc6_ is Fondations && _loc6_.creation == param1.iaConstruireBatiment)
                     {
                        _loc3_ = _loc6_;
                        break;
                     }
                     _loc5_ = param1.distance(_loc6_);
                     if(_loc5_ < _loc4_)
                     {
                        _loc4_ = _loc5_;
                        _loc3_ = _loc6_;
                     }
                  }
               }
            }
            if(_loc3_)
            {
               if(_loc3_ is Fondations)
               {
                  _loc7_ = _loc3_.creation;
               }
               else
               {
                  _loc7_ = _loc3_.race;
               }
               if(Math.random() < 0.5 || _loc7_ == param1.iaConstruireBatiment)
               {
                  reparer_batiment2(param1,_loc3_);
                  return false;
               }
            }
         }
         return true;
      }
      
      private static function reparer_batiment_type(param1:Artisan, param2:String) : Boolean
      {
         var _loc3_:Object = null;
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         var _loc6_:Object = null;
         var _loc7_:String = null;
         if(param1.peut_payer(Donnees.donnees[param2].build,true,false))
         {
            _loc4_ = int.MAX_VALUE;
            for each(_loc6_ in batiments)
            {
               if(Boolean(_loc6_.race == param2 && _loc6_.equipe == param1.equipe) && Boolean(_loc6_.blesse) && Boolean(_loc6_.vivant) && (!(_loc6_ is BatimentMobile) || BatimentMobile(_loc6_).enAttente))
               {
                  _loc5_ = param1.distance(_loc6_);
                  if(_loc5_ < _loc4_)
                  {
                     _loc4_ = _loc5_;
                     _loc3_ = _loc6_;
                  }
               }
            }
            if(_loc3_)
            {
               if(proteger_cible(param1,_loc3_))
               {
                  reparer_batiment2(param1,_loc3_);
               }
               return true;
            }
            return false;
         }
         _loc7_ = besoin_ressource_construction(param1,Donnees.donnees[param2].build,true);
         if(_loc7_)
         {
            trouver_ressource(param1,_loc7_);
            return true;
         }
         return false;
      }
      
      private static function proteger_cible(param1:Artisan, param2:Object) : Boolean
      {
         var _loc3_:Object = null;
         _loc3_ = trouver_ennemi_attaquant_cible(param1,param2);
         if(_loc3_)
         {
            param1.attaquer(Vivant(_loc3_));
            return false;
         }
         return true;
      }
      
      private static function reparer_batiment2(param1:Artisan, param2:Object) : void
      {
         var _loc3_:String = null;
         var _loc4_:String = null;
         if(param2 is Fondations)
         {
            _loc3_ = param2.creation;
         }
         else
         {
            _loc3_ = param2.race;
         }
         param1.iaConstruireBatiment = "";
         if(param1.peut_payer(Donnees.donnees[_loc3_].build,true,false))
         {
            param1.aller_reparer(Perso(param2));
         }
         else
         {
            _loc4_ = besoin_ressource_construction(param1,Donnees.donnees[_loc3_].build,true);
            if(_loc4_)
            {
               trouver_ressource(param1,_loc4_);
            }
         }
      }
      
      public static function trouver_monture(param1:Artisan) : Boolean
      {
         var _loc2_:Perso = null;
         if(param1.monture == "" && Math.random() < 0.1)
         {
            for each(_loc2_ in montures)
            {
               if(param1.distance(_loc2_) < 192)
               {
                  param1.aller_travailler(_loc2_);
                  return true;
               }
            }
         }
         return false;
      }
      
      public static function gerer_equipement(param1:Artisan) : void
      {
         if(param1.enCombat && param1.iaPretAuCombat)
         {
            if((param1.distance(param1.cibleCombat) > 100 || param1.iaArmesContactPreferees.length == 0) && param1.iaArmesDistancesPreferees.length > 0)
            {
               if(!param1.iaArmesDistancesPreferees[0].equipe && !param1.verifier_peut_attaquer(param1.iaArmesDistancesPreferees[0].donnees,true,false,false))
               {
                  utiliser_objet(param1,param1.iaArmesDistancesPreferees[0],false);
               }
               if(Boolean(param1.iaArmesDistancesPreferees.length > 1) && Boolean(param1.iaArmesDistancesPreferees[0].donnees.oneHand) && Boolean(param1.iaArmesDistancesPreferees[1].donnees.oneHand))
               {
                  if(!param1.iaArmesDistancesPreferees[1].equipe && !param1.verifier_peut_attaquer(param1.iaArmesDistancesPreferees[1].donnees,true,false,false))
                  {
                     utiliser_objet(param1,param1.iaArmesDistancesPreferees[1],true);
                  }
               }
            }
            else if(param1.iaArmesContactPreferees.length > 0)
            {
               if(!param1.iaArmesContactPreferees[0].equipe)
               {
                  utiliser_objet(param1,param1.iaArmesContactPreferees[0],false);
               }
               if(Boolean(param1.iaArmesContactPreferees.length > 1) && Boolean(param1.iaArmesContactPreferees[0].donnees.oneHand) && Boolean(param1.iaArmesContactPreferees[1].donnees.oneHand))
               {
                  if(!param1.iaArmesContactPreferees[1].equipe)
                  {
                     utiliser_objet(param1,param1.iaArmesContactPreferees[1],true);
                  }
               }
            }
         }
         else if(param1.enAttente)
         {
            param1.iaPretAuCombat = true;
         }
         var _loc2_:int = int(param1.objets.length);
         var _loc3_:int = 0;
         while(_loc3_ < _loc2_)
         {
            if(Boolean(param1.objets[_loc3_].donnees["use"] && param1.objets[_loc3_].donnees["use"].gainTemporaryItem) && Boolean(!param1.objets[_loc3_].donnees["use"].gainPrimaryCharacteristic) && Math.random() < 1 / _loc2_)
            {
               param1.utiliser_objet(_loc3_);
               return;
            }
            _loc3_++;
         }
      }
      
      private static function utiliser_objet(param1:Artisan, param2:Object, param3:Boolean) : void
      {
         var _loc4_:int = 0;
         var _loc5_:Object = null;
         for each(_loc5_ in param1.objets)
         {
            if(_loc5_ == param2)
            {
               param1.utiliser_objet_equipe(_loc4_,param3);
            }
            _loc4_++;
         }
      }
      
      private static function recuperer_caracteristiques(param1:Artisan, param2:Number = 0.5) : Boolean
      {
         var _loc3_:Object = null;
         var _loc4_:String = null;
         for each(_loc4_ in caracteristiquesPrimaires)
         {
            if(param1.caracteristiquesPrimaires[_loc4_].coef <= param2)
            {
               recuperer_caracteristiquePrimaire(param1,_loc4_);
            }
         }
         for each(_loc4_ in caracteristiquesPrimaires)
         {
            _loc3_ = param1.caracteristiquesPrimaires[_loc4_];
            if((_loc3_.score + _loc3_.recuperation) / _loc3_.scoreMax <= param2)
            {
               trouver_ressource_procheCarac(param1,_loc4_);
               if(param1.iaConstruireObjet == "" || !Donnees.donnees[param1.iaConstruireObjet]["use"] || !Donnees.donnees[param1.iaConstruireObjet]["use"].gainPrimaryCharacteristic)
               {
                  if(consommablesEpoques[param1.epoque].length > 0)
                  {
                     param1.iaConstruireObjet = consommablesEpoques[param1.epoque][_loc4_][int(Math.random() * consommablesEpoques[param1.epoque][_loc4_].length)];
                  }
               }
               return false;
            }
         }
         return true;
      }
      
      private static function besoin_ressource_construction(param1:Artisan, param2:Object, param3:Boolean = false, param4:int = 1) : String
      {
         var _loc5_:String = null;
         var _loc7_:String = null;
         var _loc6_:Object = param2.costRessource;
         if(param3)
         {
            for(_loc5_ in _loc6_)
            {
               if(param1.ressources[_loc5_].quantite < 1)
               {
                  param1.iaBesoinRessources = _loc5_;
                  param1.iaBesoinRessourcesQuantite = _loc6_[_loc5_];
                  return _loc5_;
               }
            }
         }
         else
         {
            for(_loc5_ in _loc6_)
            {
               if(param1.ressources[_loc5_].quantite < _loc6_[_loc5_] * param4)
               {
                  if(param2.gainItem)
                  {
                     for(_loc7_ in param2.gainItem)
                     {
                        if(Donnees.donnees[_loc7_].maxQuantity)
                        {
                           param1.iaBesoinRessources = _loc5_;
                           param1.iaBesoinRessourcesQuantite = param1.ressources[_loc5_].quantiteMax;
                           return _loc5_;
                        }
                     }
                  }
                  param1.iaBesoinRessources = _loc5_;
                  param1.iaBesoinRessourcesQuantite = _loc6_[_loc5_] * param4 - param1.ressources[_loc5_].quantite;
                  return _loc5_;
               }
            }
         }
         param1.iaBesoinRessources = "";
         param1.iaBesoinRessourcesQuantite = -1;
         return "";
      }
      
      private static function renforcer_equipement(param1:Artisan) : void
      {
         var _loc2_:int = 0;
         var _loc3_:Object = null;
         var _loc4_:int = 0;
         var _loc5_:String = null;
         var _loc6_:String = null;
         var _loc7_:Object = null;
         if(param1.iaPersonnalisee && param1.vivant && param1.ia)
         {
            while(_loc2_ < param1.objets.length)
            {
               if(param1.objets[_loc2_].donnees.enhance)
               {
                  for each(_loc3_ in param1.iaOrdresEpoques[param1.epoque])
                  {
                     if(_loc3_.item)
                     {
                        if(_loc3_.item == param1.objets[_loc2_].id && param1.competences[param1.objets[_loc2_].donnees.enhance[0].skill].scoreBase >= (param1.objets[_loc2_].renforcer + 1) * 50 + 100)
                        {
                           _loc4_ = param1.objets[_loc2_].renforcer + 1;
                           _loc4_ = Artisan.cout_renforcement(_loc4_) - Artisan.cout_renforcement(param1.objets[_loc2_].renforcer);
                           _loc5_ = besoin_ressource_construction(param1,param1.objets[_loc2_].donnees.enhance[0],false,_loc4_);
                           if((Boolean(_loc5_)) && param1.iaBesoinRessourcesQuantite <= param1.ressources[_loc5_].quantiteMax)
                           {
                              trouver_ressource(param1,_loc5_);
                              break;
                           }
                           _loc6_ = param1.objets[_loc2_].donnees.enhance[0].workshop;
                           _loc7_ = trouver_ressource_proche2(param1,_loc6_);
                           if(_loc7_)
                           {
                              if(_loc7_ is Fondations)
                              {
                                 reparer_batiment2(param1,_loc7_);
                                 break;
                              }
                              param1.renforcer_objet(_loc2_,param1.objets[_loc2_].renforcer + 1);
                              break;
                           }
                           creer_atelier2(param1,_loc6_);
                           break;
                        }
                     }
                  }
               }
               _loc2_++;
            }
         }
      }
      
      public static function recycler_equipement(param1:Artisan) : void
      {
         var _loc2_:int = 0;
         var _loc3_:Boolean = false;
         var _loc4_:Object = null;
         var _loc5_:Object = null;
         var _loc6_:String = null;
         if(param1.iaPersonnalisee && param1.vivant && param1.ia)
         {
            while(_loc2_ < param1.objets.length)
            {
               if(param1.objets[_loc2_] is ObjetEquipe && !param1.objets[_loc2_].equipe && Boolean(param1.objets[_loc2_].donnees.recycle))
               {
                  _loc3_ = true;
                  for each(_loc4_ in param1.iaOrdresEpoques[param1.epoque])
                  {
                     if(_loc4_.item)
                     {
                        if(_loc4_.item == param1.objets[_loc2_].id)
                        {
                           _loc3_ = false;
                           break;
                        }
                        if(param1.objets[_loc2_].donnees.upgrade)
                        {
                           for each(_loc5_ in param1.objets[_loc2_].donnees.upgrade)
                           {
                              if(_loc5_.gainItem)
                              {
                                 for(_loc6_ in _loc5_.gainItem)
                                 {
                                    if(_loc6_ == _loc4_.item)
                                    {
                                       _loc3_ = false;
                                       break;
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
                  if(_loc3_)
                  {
                     param1.recycler_objet(_loc2_,true);
                  }
               }
               _loc2_++;
            }
         }
      }
      
      public static function recuperer_caracteristiquePrimaire(param1:Artisan, param2:String) : void
      {
         var _loc4_:int = 0;
         var _loc5_:String = null;
         var _loc6_:int = 0;
         var _loc7_:Object = null;
         var _loc3_:CaracteristiquePrimaireArtisan = param1.caracteristiquesPrimaires[param2];
         if(_loc3_.resteRecuperer <= 0)
         {
            return;
         }
         if(objetsCarac[param2])
         {
            for each(_loc5_ in objetsCarac[param2])
            {
               if(!param1.rechargement.en_cours_selon_objet(_loc5_))
               {
                  _loc4_ = param1.possede_objet(_loc5_);
                  if(_loc4_ != -1)
                  {
                     param1.utiliser_objet2(_loc4_);
                     return;
                  }
               }
            }
         }
         if(ressourcesCarac[param2])
         {
            for each(_loc7_ in ressourcesCarac[param2])
            {
               _loc6_ = Math.max(_loc3_.resteRecuperer / _loc7_.score / param1.caracteristiquesPrimaires[param2].bonusEquipement,1);
               if(_loc6_ > param1.ressources[_loc7_.id].quantite)
               {
                  _loc6_ = int(param1.ressources[_loc7_.id].quantite);
               }
               if(_loc6_ > 0)
               {
                  param1.utiliser_ressource(_loc7_.id,_loc6_);
                  if(_loc3_.resteRecuperer <= 0)
                  {
                     return;
                  }
               }
            }
         }
      }
      
      private static function trouver_ressource_procheCarac(param1:Artisan, param2:String, param3:Boolean = true) : void
      {
         param1.iaBesoinRessourcesQuantite = 0;
         trouver_ressourceTerrain_proche(param1,ressourcesTerrainCarac[param2],param3);
      }
      
      private static function trouver_ressource(param1:Artisan, param2:String, param3:Vector.<String> = null, param4:String = "") : void
      {
         var _loc5_:BatimentCentreVille = null;
         var _loc6_:Object = null;
         if(Donnees.donnees[param2].age > param1.epoque)
         {
            return;
         }
         if(!(param1 is Serviteur))
         {
            if(param1.batimentEntrer is BatimentCentreVille && !param1.visible && BatimentCentreVille(param1.batimentEntrer).ressources[param2].quantite > 0)
            {
               param1.entrepot_ressource(true,param2,param1.iaBesoinRessourcesQuantite);
               return;
            }
            if(Math.random() < 0.25)
            {
               _loc5_ = trouver_centre_ville(param1);
               if((Boolean(_loc5_)) && _loc5_.ressources[param2].quantite > 0)
               {
                  param1.aller_batiment(_loc5_);
                  return;
               }
            }
         }
         if(matieresPremieresObligatoires[param2])
         {
            for each(_loc6_ in matieresPremieres[param2])
            {
               if(_loc6_.age <= param1.epoque)
               {
                  if(!param3 || param3.indexOf(_loc6_.id) == -1)
                  {
                     if(param1.ressources[_loc6_.id].quantite <= _loc6_.nb)
                     {
                        if(!param3)
                        {
                           param3 = new Vector.<String>();
                        }
                        param3.push(_loc6_.id);
                        param1.iaBesoinRessources = _loc6_.id;
                        if(_loc6_.nb != 1)
                        {
                           param1.iaBesoinRessourcesQuantite = Math.ceil(param1.iaBesoinRessourcesQuantite * _loc6_.nb);
                        }
                        trouver_ressource(param1,_loc6_.id,param3,param4);
                        return;
                     }
                  }
               }
            }
         }
         trouver_ressourceTerrain_proche(param1,persoRessource[param2]);
      }
      
      private static function trouver_ressourceTerrain_proche(param1:Artisan, param2:Vector.<Object>, param3:Boolean = true) : void
      {
         var _loc5_:Object = null;
         var _loc6_:Object = null;
         var _loc7_:int = 0;
         var _loc4_:Object = trouver_ressource_proche3(param1,param2,param3);
         if(param3 || Boolean(_loc4_) && Boolean(zone_sure(_loc4_.x,_loc4_.y,param1.equipe)))
         {
            if(_loc4_)
            {
               if(_loc4_ is Animal)
               {
                  param1.attaquer(Vivant(_loc4_));
               }
               else if(_loc4_ is Fondations)
               {
                  reparer_batiment2(param1,_loc4_);
               }
               else
               {
                  for each(_loc5_ in param2)
                  {
                     if(_loc4_.race == _loc5_.id)
                     {
                        param1.creer_objet(Perso(_loc4_),_loc5_.no);
                        break;
                     }
                  }
               }
            }
            else
            {
               do
               {
                  _loc6_ = param2[int(Math.random() * param2.length)];
                  if(++_loc7_ > 1000)
                  {
                     return;
                  }
               }
               while(!Donnees.donnees[_loc6_.id].build || param1.epoque < Donnees.donnees[_loc6_.id].age);
               switch(Donnees.donnees[_loc6_.id].type)
               {
                  case "landRessource":
                  case "animal":
                     param1.creer_perso(_loc6_.id);
                     deplacement_aleatoire(param1);
                     break;
                  case "workshop":
                     creer_atelier(param1,_loc6_.id);
               }
            }
         }
         else if(!fuir(param1,null,128,false))
         {
            trouver_ressourceTerrain_proche(param1,param2);
         }
      }
      
      public static function fuir(param1:Artisan, param2:Object = null, param3:Number = 128, param4:Boolean = true) : Boolean
      {
         if(!param2)
         {
            param2 = trouver_ennemi_proche(param1,128);
         }
         if(Boolean(param2) && param1.iaPretAuCombat)
         {
            if(param1.visible && trouver_batiment_defense(param1))
            {
               param1.iaMemoireCible = true;
               if(param4)
               {
                  param1.parler_aleatoire("flee");
               }
               return true;
            }
            if(Boolean(param1.visible && param1.maison && !(param1.maison is Fondations)) && Boolean(param1.maison.distance(param1) < 1024) && Batiment(param1.maison).vie.coef >= 1)
            {
               param1.rentrer_maison();
               param1.iaMemoireCible = true;
               if(param4)
               {
                  param1.parler_aleatoire("flee");
               }
               return true;
            }
            if(Math.pow(param1.x - villes[param1.equipe].x,2) + Math.pow(param1.y - villes[param1.equipe].y,2) > 2048)
            {
               aller_centre_ville(param1);
               param1.iaMemoireCible = true;
               if(param4)
               {
                  param1.parler_aleatoire("flee");
               }
               return true;
            }
            if(param1.reculer2(param2))
            {
               param1.iaMemoireCible = true;
               if(param4)
               {
                  param1.parler_aleatoire("flee");
               }
               return true;
            }
         }
         return false;
      }
      
      private static function trouver_batiment_defense(param1:Artisan, param2:int = 640, param3:Number = 0.75) : Boolean
      {
         var _loc4_:BatimentOffensif = null;
         var _loc6_:int = 0;
         var _loc7_:BatimentOffensif = null;
         var _loc5_:int = param2;
         for each(_loc7_ in batimentsDefense)
         {
            if(_loc7_.vie.coef >= param3 && _loc7_.equipe == param1.equipe)
            {
               _loc6_ = param1.distance(_loc7_);
               if(_loc6_ < _loc5_)
               {
                  _loc5_ = _loc6_;
                  _loc4_ = _loc7_;
               }
            }
         }
         if(_loc4_)
         {
            param1.aller_batiment(_loc4_);
            return true;
         }
         return false;
      }
      
      private static function creer_atelier(param1:Artisan, param2:String) : void
      {
         var _loc3_:String = null;
         if(param1.peut_payer(Donnees.donnees[param2].build,true,false))
         {
            creer_batiment_depuis_centre_ville(param1,param2);
         }
         else
         {
            _loc3_ = besoin_ressource_construction(param1,Donnees.donnees[param2].build,true);
            if(_loc3_ != "")
            {
               trouver_ressource(param1,_loc3_,null,param2);
            }
         }
      }
      
      private static function distance_ressource_proche(param1:Object, param2:int, param3:int) : int
      {
         if(param1 is RessourceTerrain || param1 is Animal || param1 is RessourceMobile)
         {
            return param3;
         }
         if(param1 is Maison)
         {
            return int.MAX_VALUE;
         }
         return param2;
      }
      
      public static function trouver_ressource_proche2(param1:Artisan, param2:String, param3:Boolean = true, param4:int = 2048, param5:int = 320) : Object
      {
         var _loc6_:Object = null;
         var _loc8_:int = 0;
         var _loc9_:Object = null;
         var _loc10_:Object = null;
         var _loc7_:int = int.MAX_VALUE;
         for each(_loc10_ in centresVille)
         {
            if(_loc10_.ville == param1.ville)
            {
               for each(_loc9_ in ressourcesTerrain)
               {
                  if(Boolean(_loc9_.race == param2 && _loc9_.visible) && (Boolean(!(_loc9_ is Batiment) && !(_loc9_ is Fondations) || _loc9_.equipe == param1.equipe)) && (param3 || zone_sure(_loc9_.x,_loc9_.y,param1.equipe)))
                  {
                     _loc8_ = int(_loc10_.distance(_loc9_));
                     if(_loc8_ < _loc7_ && _loc8_ < distance_ressource_proche(_loc9_,param4,param5))
                     {
                        _loc7_ = _loc8_;
                        _loc6_ = _loc9_;
                     }
                  }
               }
               for each(_loc9_ in batiments)
               {
                  if(_loc9_ is Fondations && _loc9_.creation == param2 && _loc9_.equipe == param1.equipe)
                  {
                     _loc8_ = int(_loc10_.distance(_loc9_));
                     if(_loc8_ < _loc7_ && _loc8_ < param4)
                     {
                        _loc7_ = _loc8_;
                        _loc6_ = _loc9_;
                     }
                  }
               }
            }
         }
         if(!_loc6_)
         {
            _loc6_ = trouver_ressource_proche2_sansCentreVille(param1,param2,param3,param4,param5);
         }
         return _loc6_;
      }
      
      public static function trouver_ressource_proche2_sansCentreVille(param1:Artisan, param2:String, param3:Boolean = true, param4:int = 2048, param5:int = 320) : Object
      {
         var _loc6_:Object = null;
         var _loc8_:int = 0;
         var _loc9_:Object = null;
         var _loc7_:int = int.MAX_VALUE;
         for each(_loc9_ in ressourcesTerrain)
         {
            if(Boolean(_loc9_.race == param2 && _loc9_.visible) && (Boolean(!(_loc9_ is Batiment) && !(_loc9_ is Fondations) || _loc9_.equipe == param1.equipe)) && (param3 || zone_sure(_loc9_.x,_loc9_.y,param1.equipe)))
            {
               _loc8_ = param1.distance(_loc9_);
               if(_loc8_ < _loc7_ && _loc8_ < distance_ressource_proche(_loc9_,param4,param5))
               {
                  _loc7_ = _loc8_;
                  _loc6_ = _loc9_;
               }
            }
         }
         for each(_loc9_ in batiments)
         {
            if(_loc9_ is Fondations && _loc9_.creation == param2 && _loc9_.equipe == param1.equipe)
            {
               _loc8_ = param1.distance(_loc9_);
               if(_loc8_ < _loc7_ && _loc8_ < param4)
               {
                  _loc7_ = _loc8_;
                  _loc6_ = _loc9_;
               }
            }
         }
         return _loc6_;
      }
      
      private static function trouver_ressource_proche3(param1:Artisan, param2:Vector.<Object>, param3:Boolean = true, param4:int = 2048, param5:int = 640) : Object
      {
         var _loc6_:Object = null;
         var _loc8_:int = 0;
         var _loc9_:Object = null;
         var _loc10_:BatimentCentreVille = null;
         var _loc11_:Object = null;
         var _loc7_:int = int.MAX_VALUE;
         for each(_loc11_ in param2)
         {
            if(_loc11_.age <= param1.epoque)
            {
               for each(_loc10_ in centresVille)
               {
                  if(_loc10_.ville == param1.ville)
                  {
                     for each(_loc9_ in ressourcesTerrain)
                     {
                        if(Boolean(_loc9_.race == _loc11_.id && _loc9_.visible) && (Boolean(!(_loc9_ is Batiment) && !(_loc9_ is Fondations) || _loc9_.equipe == param1.equipe)) && (param3 || zone_sure(_loc9_.x,_loc9_.y,param1.equipe)))
                        {
                           _loc8_ = _loc10_.distance(_loc9_);
                           if(_loc8_ < _loc7_ && _loc8_ < distance_ressource_proche(_loc9_,param4,param5))
                           {
                              _loc7_ = _loc8_;
                              _loc6_ = _loc9_;
                           }
                        }
                     }
                  }
               }
               if(!_loc6_)
               {
                  for each(_loc9_ in ressourcesTerrain)
                  {
                     if(Boolean(_loc9_.race == _loc11_.id && _loc9_.visible) && (Boolean(!(_loc9_ is Batiment) && !(_loc9_ is Fondations) || _loc9_.equipe == param1.equipe)) && (param3 || zone_sure(_loc9_.x,_loc9_.y,param1.equipe)))
                     {
                        _loc8_ = param1.distance(_loc9_);
                        if(_loc8_ < _loc7_ && _loc8_ < distance_ressource_proche(_loc9_,param4,param5))
                        {
                           _loc7_ = _loc8_;
                           _loc6_ = _loc9_;
                        }
                     }
                  }
               }
               if(!_loc6_)
               {
                  for each(_loc10_ in centresVille)
                  {
                     if(_loc10_.ville == param1.ville)
                     {
                        for each(_loc9_ in batiments)
                        {
                           if(_loc9_ is Fondations && _loc9_.creation == _loc11_.id && _loc9_.equipe == param1.equipe)
                           {
                              _loc8_ = _loc10_.distance(_loc9_);
                              if(_loc8_ < _loc7_ && _loc8_ < param4)
                              {
                                 _loc7_ = _loc8_;
                                 _loc6_ = _loc9_;
                              }
                           }
                        }
                     }
                  }
               }
               if(!_loc6_)
               {
                  for each(_loc9_ in batiments)
                  {
                     if(_loc9_ is Fondations && _loc9_.creation == _loc11_.id && _loc9_.equipe == param1.equipe)
                     {
                        _loc8_ = param1.distance(_loc9_);
                        if(_loc8_ < _loc7_ && _loc8_ < param4)
                        {
                           _loc7_ = _loc8_;
                           _loc6_ = _loc9_;
                        }
                     }
                  }
               }
            }
         }
         return _loc6_;
      }
      
      public static function trouver_mur_proche_allie(param1:Object, param2:int = 64) : Mur
      {
         var _loc3_:Mur = null;
         var _loc5_:int = 0;
         var _loc6_:Object = null;
         var _loc4_:int = param2;
         for each(_loc6_ in persos)
         {
            if(_loc6_ is Mur && _loc6_.equipe == param1.equipe)
            {
               _loc5_ = int(param1.distance(_loc6_));
               if(_loc5_ < _loc4_)
               {
                  _loc4_ = _loc5_;
                  _loc3_ = _loc6_ as Mur;
               }
            }
         }
         return _loc3_;
      }
      
      public static function continuer_construire_mur(param1:Artisan, param2:String, param3:int = 128) : void
      {
         var _loc4_:Perso = null;
         var _loc6_:int = 0;
         var _loc7_:Perso = null;
         var _loc5_:int = param3;
         for each(_loc7_ in batiments)
         {
            if(_loc7_.race == param2)
            {
               _loc6_ = param1.distance(_loc7_);
               if(_loc6_ < _loc5_)
               {
                  _loc5_ = _loc6_;
                  _loc4_ = _loc7_;
               }
            }
         }
         if(_loc4_)
         {
            param1.aller_travailler(_loc4_);
         }
      }
      
      public static function continuer_reparer_mur(param1:Artisan, param2:String, param3:int = 128) : void
      {
         var _loc4_:Perso = null;
         var _loc6_:int = 0;
         var _loc7_:Perso = null;
         var _loc5_:int = param3;
         for each(_loc7_ in batiments)
         {
            if(_loc7_.race == param2 && Vivant(_loc7_).blesse)
            {
               _loc6_ = param1.distance(_loc7_);
               if(_loc6_ < _loc5_)
               {
                  _loc5_ = _loc6_;
                  _loc4_ = _loc7_;
               }
            }
         }
         if(_loc4_)
         {
            param1.aller_travailler(_loc4_);
         }
      }
      
      public static function trouver_batimentResurrection(param1:Artisan) : Boolean
      {
         var _loc2_:BatimentResurrection = null;
         var _loc4_:int = 0;
         var _loc5_:BatimentResurrection = null;
         var _loc3_:int = int.MAX_VALUE;
         for each(_loc5_ in batimentResurrection)
         {
            if(_loc5_.equipe == param1.equipe && _loc5_.visible)
            {
               _loc4_ = param1.distance(_loc5_);
               if(_loc4_ < _loc3_)
               {
                  _loc3_ = _loc4_;
                  _loc2_ = _loc5_;
               }
            }
         }
         if(_loc2_)
         {
            param1.aller_travailler(_loc2_);
            return true;
         }
         return false;
      }
      
      public static function trouver_centre_ville(param1:Artisan) : BatimentCentreVille
      {
         var _loc2_:BatimentCentreVille = null;
         var _loc4_:int = 0;
         var _loc5_:BatimentCentreVille = null;
         var _loc3_:int = int.MAX_VALUE;
         for each(_loc5_ in centresVille)
         {
            if(_loc5_.equipe == param1.equipe && _loc5_.visible)
            {
               _loc4_ = param1.distance(_loc5_);
               if(_loc4_ < _loc3_)
               {
                  _loc3_ = _loc4_;
                  _loc2_ = _loc5_;
               }
            }
         }
         return _loc2_;
      }
      
      private static function deplacement_aleatoire(param1:Object, param2:int = 64) : void
      {
         var _loc3_:int = 0;
         var _loc4_:int = 0;
         param2 *= param1.vitesse * 0.25;
         if(param1.equipe != -1 && Math.random() < 0.01)
         {
            aller_centre_ville(param1);
            return;
         }
         _loc3_ = param1.x + Math.random() * param2 * 2 - param2;
         _loc4_ = param1.y + Math.random() * param2 * 2 - param2;
         if(_loc3_ < param1.largeur * 0.5)
         {
            _loc3_ = param1.largeur * 0.5;
         }
         else if(_loc3_ > Terrain.largeur - param1.largeur * 0.5)
         {
            _loc3_ = Terrain.largeur - param1.largeur * 0.5;
         }
         if(_loc4_ < param1.hauteur)
         {
            _loc4_ = int(param1.hauteur);
         }
         else if(_loc4_ > Terrain.hauteur)
         {
            _loc4_ = Terrain.hauteur;
         }
         param1.aller(_loc3_,_loc4_);
      }
      
      private static function aller_centre_ville(param1:Object, param2:int = 128) : void
      {
         param1.aller(villes[param1.ville].x + Math.random() * param2 * 2 - param2,villes[param1.ville].y + Math.random() * param2 * 2 - param2);
      }
      
      public static function verifier_destinationX(param1:Number) : Number
      {
         if(param1 < 0)
         {
            param1 = 0;
         }
         else if(param1 > Terrain.largeur)
         {
            param1 = Terrain.largeur;
         }
         return param1;
      }
      
      public static function verifier_destinationY(param1:Number) : Number
      {
         if(param1 < 0)
         {
            param1 = 0;
         }
         else if(param1 > Terrain.hauteur)
         {
            param1 = Terrain.hauteur;
         }
         return param1;
      }
      
      public static function virer_residents(param1:Batiment) : void
      {
         var _loc2_:Object = null;
         for each(_loc2_ in combattants)
         {
            if(_loc2_ is Artisan && _loc2_.batimentEntrer == param1 && !_loc2_.visible)
            {
               _loc2_.sortir();
            }
         }
      }
   }
}

