package aurora.jeuModele.perso
{
   public class BatimentCaserne extends Atelier
   {
      
      public var garnison:Vector.<Object>;
      
      public function BatimentCaserne()
      {
         super();
      }
      
      override public function init(param1:Object) : void
      {
         super.init(param1);
         this.garnison = new Vector.<Object>();
      }
      
      override public function detruire() : void
      {
         super.detruire();
         this.garnison = null;
      }
   }
}

