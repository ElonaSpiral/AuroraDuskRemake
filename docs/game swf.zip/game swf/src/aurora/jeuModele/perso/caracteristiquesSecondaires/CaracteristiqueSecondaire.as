package aurora.jeuModele.perso.caracteristiquesSecondaires
{
   import flash.events.EventDispatcher;
   
   public class CaracteristiqueSecondaire extends EventDispatcher
   {
      
      public var id:String;
      
      protected var _score:int;
      
      protected var _scoreBase:int;
      
      public function CaracteristiqueSecondaire(param1:String, param2:int)
      {
         super();
         this.id = param1;
         this._score = this.scoreBase = param2;
      }
      
      public function get score() : int
      {
         return this._score;
      }
      
      public function set score(param1:int) : void
      {
         this._score = param1;
      }
      
      public function get scoreBase() : int
      {
         return this._scoreBase;
      }
      
      public function set scoreBase(param1:int) : void
      {
         this._scoreBase = param1;
      }
      
      public function get coefBonus() : Number
      {
         return this.score * 0.01;
      }
   }
}

