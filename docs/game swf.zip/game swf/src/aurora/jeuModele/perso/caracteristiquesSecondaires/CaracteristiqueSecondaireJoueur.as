package aurora.jeuModele.perso.caracteristiquesSecondaires
{
   public class CaracteristiqueSecondaireJoueur extends CaracteristiqueSecondaire
   {
      
      public static var coefGainXp:int = 1;
      
      public static var xpPremierNivSuivant:int = 100;
      
      public static var xpNivSup:int = 5;
      
      public var niveau:int;
      
      private var _xp:Number = 0;
      
      private var xpNivPrecedent:int;
      
      private var xpNivSuivant:int;
      
      public var niveauDepart:Number;
      
      public var noJoueur:int;
      
      public function CaracteristiqueSecondaireJoueur(param1:String, param2:int)
      {
         super(param1,param2);
         this.xpNivSuivant = xpPremierNivSuivant;
      }
      
      public function init() : void
      {
         this.niveauDepart = this.niveau + (this._xp - this.xpNivPrecedent) / (this.xpNivSuivant - this.xpNivPrecedent);
      }
      
      public function statistiques() : Number
      {
         return this.niveau + (this._xp - this.xpNivPrecedent) / (this.xpNivSuivant - this.xpNivPrecedent) - this.niveauDepart;
      }
      
      public function statistiques_entiers() : int
      {
         return this.niveau - int(this.niveauDepart);
      }
      
      public function recuperer_infos() : void
      {
         dispatchEvent(new CaracteristiqueSecondaireEvent(CaracteristiqueSecondaireEvent.ACTUALISER_SCORE,id,_score));
         dispatchEvent(new CaracteristiqueSecondaireEvent(CaracteristiqueSecondaireEvent.ACTUALISER_SCORE_BASE,id,_scoreBase));
         dispatchEvent(new CaracteristiqueSecondaireEvent(CaracteristiqueSecondaireEvent.ACTUALISER_XP,id,this._xp));
         dispatchEvent(new CaracteristiqueSecondaireEvent(CaracteristiqueSecondaireEvent.ACTUALISER_XP_MIN,id,this.xpNivPrecedent));
         dispatchEvent(new CaracteristiqueSecondaireEvent(CaracteristiqueSecondaireEvent.ACTUALISER_XP_MAX,id,this.xpNivSuivant));
      }
      
      override public function set scoreBase(param1:int) : void
      {
         super.scoreBase = param1;
         dispatchEvent(new CaracteristiqueSecondaireEvent(CaracteristiqueSecondaireEvent.ACTUALISER_SCORE_BASE,id,_scoreBase));
      }
      
      override public function set score(param1:int) : void
      {
         super.score = param1;
         dispatchEvent(new CaracteristiqueSecondaireEvent(CaracteristiqueSecondaireEvent.ACTUALISER_SCORE,id,_score));
      }
      
      public function get xp() : Number
      {
         return this._xp;
      }
      
      public function set xp(param1:Number) : void
      {
         var _loc2_:Boolean = false;
         this._xp = param1;
         try
         {
            while(this._xp >= this.xpNivSuivant)
            {
               ++this.niveau;
               this.xpNivPrecedent = this.xpNivSuivant;
               this.xpNivSuivant += xpPremierNivSuivant + this.niveau * xpNivSup;
               ++score;
               ++scoreBase;
               _loc2_ = true;
            }
            if(_loc2_)
            {
               dispatchEvent(new CaracteristiqueSecondaireEvent(CaracteristiqueSecondaireEvent.ACTUALISER_XP_MIN,id,this.xpNivPrecedent));
               dispatchEvent(new CaracteristiqueSecondaireEvent(CaracteristiqueSecondaireEvent.ACTUALISER_XP_MAX,id,this.xpNivSuivant));
               dispatchEvent(new CaracteristiqueSecondaireEvent(CaracteristiqueSecondaireEvent.GAIN_NIVEAU,id,score));
            }
            dispatchEvent(new CaracteristiqueSecondaireEvent(CaracteristiqueSecondaireEvent.ACTUALISER_XP,id,int(this._xp)));
         }
         catch(e:Error)
         {
         }
      }
      
      public function charger(param1:Object) : void
      {
         this._xp = param1["xp"];
         this.niveau = param1["lvl"];
         this.score = score + this.niveau;
         this.scoreBase = scoreBase + this.niveau;
         this.xpNivPrecedent = param1["prev"];
         this.xpNivSuivant = param1["next"];
      }
      
      public function sauvegarde() : Object
      {
         var _loc1_:Object = new Object();
         _loc1_[id] = {"xp":int(this.xp)};
         return _loc1_;
      }
   }
}

