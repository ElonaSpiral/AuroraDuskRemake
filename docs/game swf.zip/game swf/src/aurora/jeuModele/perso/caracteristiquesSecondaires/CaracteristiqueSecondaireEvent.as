package aurora.jeuModele.perso.caracteristiquesSecondaires
{
   import flash.events.Event;
   
   public class CaracteristiqueSecondaireEvent extends Event
   {
      
      public static const ACTUALISER_SCORE:String = "actualiserScore";
      
      public static const ACTUALISER_SCORE_BASE:String = "actualiserScoreBase";
      
      public static const ACTUALISER_XP:String = "actualiserXp";
      
      public static const ACTUALISER_XP_MIN:String = "actualiserXpMin";
      
      public static const ACTUALISER_XP_MAX:String = "actualiserXpMax";
      
      public static const GAIN_NIVEAU:String = "gainNiveau";
      
      public var id:String;
      
      public var score:int;
      
      public function CaracteristiqueSecondaireEvent(param1:String, param2:String, param3:int)
      {
         this.id = param2;
         this.score = param3;
         super(param1);
      }
   }
}

