package aurora.jeuModele.perso
{
   import aurora.jeuModele.IA;
   import aurora.jeuModele.PersosEvent;
   import flash.events.TimerEvent;
   import flash.utils.Timer;
   
   public class BatimentRotatif extends BatimentOffensif
   {
      
      protected const INTERVAL_ROTATION:int = 80;
      
      private var rotationTimer:Timer;
      
      private var timerAttaque:Timer;
      
      public var rotation:Number;
      
      private var effetTir:String;
      
      private var vitesseRotationBase:Number;
      
      private var vitesseRotation:Number;
      
      private var pojectilePret:Boolean;
      
      private var canonX:Number;
      
      private var canonY:Number;
      
      private var canonLongueur:Number;
      
      private var pauseRotation:Boolean;
      
      private var pauseAttaque:Boolean;
      
      public function BatimentRotatif()
      {
         super();
         this.rotationTimer = new Timer(this.INTERVAL_ROTATION);
         this.rotationTimer.addEventListener(TimerEvent.TIMER,this.tourner);
      }
      
      override public function init(param1:Object) : void
      {
         super.init(param1);
         gestionIA.delay = 1000;
         this.timerAttaque = new Timer(param1.attackTime * 1000,1);
         this.timerAttaque.addEventListener(TimerEvent.TIMER_COMPLETE,this.charger_projectile);
         this.timerAttaque.start();
         this.effetTir = param1.rotateTower.effect;
         this.vitesseRotationBase = this.vitesseRotation = param1.rotateTower.speed;
         this.canonX = x + param1.rotateTower.x;
         this.canonY = y + param1.rotateTower.y;
         this.canonLongueur = param1.rotateTower.length;
         this.rotation = param1.rotateTower.startingRotation;
      }
      
      private function charger_projectile(param1:TimerEvent) : void
      {
         this.pojectilePret = true;
      }
      
      override protected function gerer_ia(param1:TimerEvent = null) : void
      {
         if(gestionIA)
         {
            if(verifier_cible() && cibleCombat.distance(this) <= portee)
            {
               this.rotationTimer.start();
            }
            else
            {
               this.rotationTimer.stop();
               cibleCombat = IA.trouver_ennemi_proche(this,portee);
            }
         }
         else
         {
            param1.currentTarget.stop();
            param1.currentTarget.removeEventListener(TimerEvent.TIMER,this.gerer_ia);
         }
      }
      
      private function tourner(param1:TimerEvent) : void
      {
         var _loc2_:Number = Math.atan2(cibleCombat.y - cibleCombat.hauteur * 0.5 - this.canonY,cibleCombat.x - this.canonX);
         if(this.rotation < _loc2_)
         {
            this.vitesseRotation = this.vitesseRotationBase;
         }
         else if(this.rotation > _loc2_)
         {
            this.vitesseRotation = -this.vitesseRotationBase;
         }
         if(Math.abs(this.rotation - _loc2_) > 3.14)
         {
            this.vitesseRotation = -this.vitesseRotation;
         }
         if(Math.abs(this.rotation - _loc2_) > this.vitesseRotationBase)
         {
            this.rotation += this.vitesseRotation;
            if(this.rotation > 3.14)
            {
               this.rotation -= 6.28;
            }
            else if(this.rotation < -3.14)
            {
               this.rotation += 6.28;
            }
            dispatchEvent(new PersosEvent(PersosEvent.ROTATION));
         }
         else if(this.pojectilePret)
         {
            this.attaquer();
            this.timerAttaque.start();
            this.pojectilePret = false;
         }
      }
      
      override protected function attaquer() : void
      {
         special.fixedAngle = this.rotation;
         dispatchEvent(new AnimationEvent(AnimationEvent.ANIMER,""));
         var _loc1_:Number = x + attaqueDX + this.canonLongueur * Math.cos(this.rotation);
         var _loc2_:Number = y + attaqueDY + this.canonLongueur * Math.sin(this.rotation);
         dispatchEvent(new EffetEvent(EffetEvent.EFFET,_loc1_,_loc2_,this.effetTir,this.rotation));
         dispatchEvent(new ProjectileEvent(ProjectileEvent.CREER,this,projectile,_loc1_,_loc2_,attaque,portee,0,0,special,degats,attaqueDY));
      }
      
      override public function pause() : void
      {
         if(this.rotationTimer.running)
         {
            this.pauseRotation = true;
            this.rotationTimer.stop();
         }
         if(this.timerAttaque.running)
         {
            this.pauseAttaque = true;
            this.timerAttaque.stop();
         }
         super.pause();
      }
      
      override public function reprendre() : void
      {
         if(this.pauseRotation)
         {
            this.rotationTimer.start();
            this.pauseRotation = false;
         }
         if(this.pauseAttaque)
         {
            this.timerAttaque.start();
            this.pauseAttaque = false;
         }
         super.reprendre();
      }
      
      override public function detruire() : void
      {
         super.detruire();
         this.rotationTimer.removeEventListener(TimerEvent.TIMER,this.tourner);
         this.rotationTimer.stop();
         this.rotationTimer = null;
         this.timerAttaque.removeEventListener(TimerEvent.TIMER,this.charger_projectile);
         this.timerAttaque.stop();
         this.timerAttaque = null;
      }
   }
}

