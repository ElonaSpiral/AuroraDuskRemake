package aurora.jeuModele.perso
{
   import aurora.jeuModele.Donnees;
   import aurora.jeuModele.IA;
   import aurora.jeuModele.perso.attaque.Attaque;
   import flash.events.TimerEvent;
   import flash.utils.Timer;
   
   public class BatimentOffensif extends Batiment
   {
      
      public const intervalAttaques:int = 1000;
      
      protected var gestionIA:Timer;
      
      public var cibleCombat:Object;
      
      public var attaque:int;
      
      protected var attaqueDY:int;
      
      protected var attaqueDX:int;
      
      public var portee:int;
      
      protected var projectile:String;
      
      protected var special:Object;
      
      protected var degats:Vector.<String>;
      
      private var son:String;
      
      public function BatimentOffensif()
      {
         super();
      }
      
      override public function init(param1:Object) : void
      {
         super.init(param1);
         this.attaque = param1.attack;
         if(param1.attackTime)
         {
            this.gestionIA = new Timer(this.intervalAttaques);
            this.gestionIA.addEventListener(TimerEvent.TIMER,this.gerer_ia);
            this.gestionIA.start();
            this.gestionIA.delay = param1.attackTime * 1000;
         }
         if(param1.attackDX)
         {
            this.attaqueDX = param1.attackDX;
         }
         if(param1.attackDY)
         {
            this.attaqueDY = param1.attackDY;
         }
         else
         {
            this.attaqueDY = hauteur * 0.5;
         }
         this.portee = param1.range;
         this.projectile = param1.missile;
         this.special = param1.special;
         this.degats = Attaque.convertir_degats(param1.damage);
         this.son = param1.sound;
      }
      
      override public function set puissance(param1:Number) : void
      {
         super.puissance = param1;
         this.attaque *= param1;
      }
      
      protected function gerer_ia(param1:TimerEvent = null) : void
      {
         if(this.gestionIA)
         {
            if(this.verifier_cible() && this.cibleCombat.distance(this) <= this.distanceAttaque)
            {
               this.attaquer();
            }
            else
            {
               this.cibleCombat = IA.trouver_ennemi_proche(this,this.portee);
               if(this.cibleCombat)
               {
                  this.attaquer();
               }
            }
         }
         else
         {
            param1.currentTarget.stop();
            param1.currentTarget.removeEventListener(TimerEvent.TIMER,this.gerer_ia);
         }
      }
      
      protected function attaquer() : void
      {
         dispatchEvent(new ProjectileEvent(ProjectileEvent.CREER,this,this.projectile,x + this.attaqueDX,y + this.attaqueDY,this.attaque,this.portee,0,0,this.special,this.degats,this.attaqueDY));
         if(this.son)
         {
            jouer_son(this.son);
         }
      }
      
      public function toucher3(param1:Object, param2:int, param3:String, param4:int, param5:String = null, param6:Attaque = null, param7:Object = null, param8:Vector.<String> = null, param9:Object = null, param10:Boolean = true) : int
      {
         var _loc12_:int = 0;
         var _loc13_:int = 0;
         var _loc11_:int = Math.ceil((Math.random() * 10 + 5) * param2 / Combattant.calcul_defense(param1.defense)) * param1.total_resistances(param8);
         if(_loc11_ > 0)
         {
            if(Vivant(param1).vie.score <= _loc11_)
            {
               param1.gerer_mort(this);
            }
            Vivant(param1).editer_vie(-_loc11_);
            dispatchEvent(new EffetEvent(EffetEvent.EFFET,param1.x,param1.y - param1.hauteur * 0.5,param3,0,param1 is Joueur ? int(-_loc11_) : 0));
            if(param5)
            {
               _loc12_ = x + param6.attaqueDX;
               _loc13_ = y + param6.attaqueDY;
               dispatchEvent(new EffetEvent(EffetEvent.EFFET,(_loc12_ + param1.x) * 0.5,(_loc13_ + param1.y) * 0.5,param5,Math.atan2(param1.y - _loc13_,param1.x - _loc12_),0,Math.sqrt(Math.pow(_loc12_ - param1.x,2) + Math.pow(param1.y - param1.y,2)) / Donnees.donnees[param5].width * 0.5));
            }
            if(Boolean(param10) && Boolean(param9) && Boolean(param9.area))
            {
               this.toucher_zone(param1,param9.area.attack,param9.area.range,param9.area.effect,param4,param5,param6,param7,param8,param9);
            }
            if(param1.vivant)
            {
               if(param1 is Combattant)
               {
                  Combattant(param1).riposter(this);
               }
               if(param1 is Mobile)
               {
                  param1.appliquer_inertie(this,_loc11_);
                  if(param7)
                  {
                     param1.penalites.ajouter_penalite(param7.id,param7.time);
                  }
               }
            }
            else
            {
               if(param1 is Artisan)
               {
                  Tresor.piller_perso(Artisan(param1),this);
               }
               param1.gerer_mort(this);
            }
         }
         return _loc11_;
      }
      
      private function toucher_zone(param1:Object, param2:int, param3:int, param4:String, param5:int, param6:String = null, param7:Attaque = null, param8:Object = null, param9:Vector.<String> = null, param10:Object = null) : void
      {
         var _loc11_:int = 0;
         var _loc13_:Object = null;
         var _loc12_:Vector.<Object> = IA.trouver_ennemis_zone(param1.x,param1.y,equipe,param3);
         for each(_loc13_ in _loc12_)
         {
            if(_loc13_ != param1)
            {
               this.toucher3(_loc13_,param2,param4,param5,param6,param7,param8,param9,param10,false);
            }
         }
      }
      
      private function get distanceAttaque() : int
      {
         return this.portee + rayon + this.cibleCombat.rayon;
      }
      
      protected function verifier_cible() : Boolean
      {
         if(this.cibleCombat)
         {
            if(Boolean(this.cibleCombat.visible) && Boolean(this.cibleCombat.vivant))
            {
               return true;
            }
            this.cibleCombat = null;
            return false;
         }
         return false;
      }
      
      override public function pause() : void
      {
         if(this.gestionIA)
         {
            this.gestionIA.stop();
         }
         super.pause();
      }
      
      override public function reprendre() : void
      {
         if(this.gestionIA)
         {
            this.gestionIA.start();
         }
         super.reprendre();
      }
      
      override public function detruire() : void
      {
         super.detruire();
         this.cibleCombat = null;
         if(this.gestionIA)
         {
            this.gestionIA.removeEventListener(TimerEvent.TIMER,this.gerer_ia);
            this.gestionIA.stop();
            this.gestionIA = null;
         }
         this.special = null;
      }
   }
}

