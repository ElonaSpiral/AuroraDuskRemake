package aurora.jeuModele.perso
{
   import aurora.jeuModele.IA;
   import aurora.jeuModele.PersosEvent;
   import flash.events.TimerEvent;
   import flash.utils.Timer;
   
   public class Projectile extends Perso
   {
      
      protected const INTERVAL_DEPLACEMENT:int = 80;
      
      public var vitesse:Number;
      
      public var pas:int;
      
      public var rotation:Number;
      
      public var dx:Number;
      
      public var dy:Number;
      
      public var l:Number;
      
      public var deplacementTimer:Timer;
      
      public var delaiTimer:Timer;
      
      public var attaque:int;
      
      public var effet:String;
      
      public var lanceur:Object;
      
      public var equipe:int;
      
      public var noAttaque:int;
      
      public var orientation:Boolean;
      
      public var transperce:Boolean;
      
      public var animFin:String;
      
      protected var effetDeplacement:String;
      
      public var penalite:Object;
      
      public var special:Object;
      
      public var degats:Vector.<String>;
      
      public function Projectile()
      {
         super();
      }
      
      public static function calcul_defense(param1:int) : int
      {
         if(param1 < 100)
         {
            return 100;
         }
         return Math.log(param1 * 0.01) * 100 + 100;
      }
      
      override public function init(param1:Object) : void
      {
         super.init(param1);
         this.vitesse = param1.speed;
         this.effet = param1.attackEffect;
         if(param1.noOrientation)
         {
            this.orientation = false;
         }
         else
         {
            this.orientation = true;
         }
         this.effetDeplacement = param1.moveEffect;
      }
      
      public function aller(param1:Object, param2:int, param3:int, param4:Number, param5:Number = 0) : void
      {
         var _loc6_:int = 0;
         var _loc7_:int = 0;
         this.attaque = param2;
         if(isNaN(param4))
         {
            _loc6_ = int(param1.x);
            _loc7_ = param1.y - param1.hauteur * 0.5;
            this.dx = _loc6_ - x;
            this.dy = _loc7_ - y;
            this.l = Math.sqrt(Math.pow(this.dx,2) + Math.pow(this.dy,2));
            this.dx = this.vitesse * this.dx / this.l * Mobile.MULTIPLICATEUR_VITESSE;
            this.dy = this.vitesse * this.dy / this.l * Mobile.MULTIPLICATEUR_VITESSE;
            if(this.orientation)
            {
               this.rotation = Math.atan2(_loc7_ - y,_loc6_ - x);
               dispatchEvent(new PersosEvent(PersosEvent.ROTATION));
            }
         }
         else
         {
            this.rotation = param4 + Math.atan2(param1.y - param1.hauteur * 0.5 - y,param1.x - x);
            this.dx = Math.cos(this.rotation) * this.vitesse * Mobile.MULTIPLICATEUR_VITESSE;
            this.dy = Math.sin(this.rotation) * this.vitesse * Mobile.MULTIPLICATEUR_VITESSE;
            if(this.orientation)
            {
               dispatchEvent(new PersosEvent(PersosEvent.ROTATION));
            }
         }
         this.init_deplacement(param3 / this.vitesse * 1.5);
         if(param5)
         {
            this.delaiTimer = new Timer(param5 * 1000,1);
            this.delaiTimer.addEventListener(TimerEvent.TIMER_COMPLETE,this.commencer_deplacement);
            this.delaiTimer.start();
         }
         else
         {
            this.commencer_deplacement();
         }
      }
      
      public function copier_degats(param1:Vector.<String>) : void
      {
         var _loc2_:String = null;
         this.degats = new Vector.<String>();
         for each(_loc2_ in param1)
         {
            this.degats.push(_loc2_);
         }
      }
      
      public function init_deplacement(param1:int, param2:Number = 0) : void
      {
         this.deplacementTimer = new Timer(this.INTERVAL_DEPLACEMENT,param1);
         this.deplacementTimer.addEventListener(TimerEvent.TIMER,this.deplacer);
         this.deplacementTimer.addEventListener(TimerEvent.TIMER_COMPLETE,this.finir_deplacement);
      }
      
      protected function commencer_deplacement(param1:TimerEvent = null) : void
      {
         this.deplacementTimer.start();
      }
      
      protected function deplacer(param1:TimerEvent) : void
      {
         var _loc2_:Object = null;
         _loc2_ = IA.projectile_cible_proche(this,0);
         if(_loc2_)
         {
            if(this.transperce)
            {
               if(Boolean(this.lanceur) && Boolean(this.lanceur.vivant))
               {
                  this.attaque -= this.lanceur.toucher3(_loc2_,this.attaque,this.effet,this.noAttaque,null,null,this.penalite,this.degats,Boolean(this.special) && Boolean(this.special.special) ? this.special.special : this.special);
               }
               else
               {
                  this.toucher(_loc2_);
               }
               if(Boolean(_loc2_.vivant) || this.attaque <= 0)
               {
                  mourir();
               }
            }
            else
            {
               if(Boolean(this.lanceur) && Boolean(this.lanceur.vivant))
               {
                  this.lanceur.toucher3(_loc2_,this.attaque,this.effet,this.noAttaque,null,null,this.penalite,this.degats,Boolean(this.special) && Boolean(this.special.special) ? this.special.special : this.special);
               }
               else
               {
                  this.toucher(_loc2_);
               }
               mourir();
            }
         }
         else
         {
            x += this.dx;
            y += this.dy;
            dispatchEvent(new PersosEvent(PersosEvent.DEPLACER));
         }
         this.animer_deplacement();
      }
      
      protected function animer_deplacement() : void
      {
         if(Boolean(this.effetDeplacement) && Boolean(this.lanceur))
         {
            this.lanceur.dispatchEvent(new EffetEvent(EffetEvent.EFFET,x,y,this.effetDeplacement,this.rotation));
         }
      }
      
      private function toucher(param1:Object) : int
      {
         var _loc2_:int = Math.ceil(this.alea_degats * this.attaque / calcul_defense(param1.defense)) * param1.total_resistances(this.degats);
         if(_loc2_ > 0)
         {
            if(Vivant(param1).vie.score <= _loc2_)
            {
               param1.gerer_mort(this);
            }
            Vivant(param1).editer_vie(-_loc2_);
            param1.dispatchEvent(new EffetEvent(EffetEvent.EFFET,param1.x,param1.y - param1.hauteur * 0.5,this.effet,0,param1 is Joueur ? int(-_loc2_) : 0));
            if(param1.vivant)
            {
               if(Boolean(param1 is Combattant) && Boolean(this.lanceur) && Boolean(this.lanceur.vivant))
               {
                  Combattant(param1).riposter(Vivant(this.lanceur));
               }
               if(param1 is Mobile)
               {
                  param1.appliquer_inertie(this,_loc2_);
               }
            }
         }
         return _loc2_;
      }
      
      private function get alea_degats() : Number
      {
         return Math.random() * 10 + 5;
      }
      
      protected function finir_deplacement(param1:TimerEvent) : void
      {
         if(Boolean(this.animFin) && Boolean(this.lanceur))
         {
            this.lanceur.dispatchEvent(new EffetEvent(EffetEvent.EFFET,x,y - hauteur * 0.5,this.animFin));
         }
         mourir();
      }
      
      override public function pause() : void
      {
         this.deplacementTimer.stop();
         if(this.delaiTimer)
         {
            this.delaiTimer.stop();
         }
         super.pause();
      }
      
      override public function reprendre() : void
      {
         this.deplacementTimer.start();
         if(this.delaiTimer)
         {
            this.delaiTimer.start();
         }
         super.reprendre();
      }
      
      override public function detruire() : void
      {
         super.detruire();
         if(this.deplacementTimer)
         {
            this.deplacementTimer.removeEventListener(TimerEvent.TIMER,this.deplacer);
            this.deplacementTimer.removeEventListener(TimerEvent.TIMER_COMPLETE,this.finir_deplacement);
            this.deplacementTimer.stop();
            this.deplacementTimer = null;
         }
         if(this.delaiTimer)
         {
            this.delaiTimer.removeEventListener(TimerEvent.TIMER_COMPLETE,this.commencer_deplacement);
            this.delaiTimer.stop();
            this.delaiTimer = null;
         }
         this.lanceur = null;
      }
   }
}

