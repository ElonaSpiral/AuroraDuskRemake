package aurora.jeuModele.perso.joueur
{
   import flash.events.Event;
   
   public class JoueurEvent extends Event
   {
      
      public static const ACTUALISER_INFOS:String = "actualiserInfos";
      
      public var typeInfo:int;
      
      public var infos:String;
      
      public function JoueurEvent(param1:String, param2:int, param3:String)
      {
         this.typeInfo = param2;
         this.infos = param3;
         super(param1,bubbles,cancelable);
      }
   }
}

