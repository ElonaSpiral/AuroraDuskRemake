package aurora.jeuModele.perso.joueur
{
   import flash.events.Event;
   
   public class JaugeEvent extends Event
   {
      
      public static const ACTUALISER_JAUGE_TRAVAIL:String = "actualiserJaugeTravail";
      
      public var id:int;
      
      public var coef:Number;
      
      public function JaugeEvent(param1:String, param2:int, param3:Number)
      {
         super(param1);
         this.id = param2;
         this.coef = param3;
      }
   }
}

