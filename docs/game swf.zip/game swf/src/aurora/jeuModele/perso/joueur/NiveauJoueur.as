package aurora.jeuModele.perso.joueur
{
   import flash.events.EventDispatcher;
   
   public class NiveauJoueur extends EventDispatcher
   {
      
      public static var xpPremierNivSuivant:int = 10000;
      
      public static var xpNivSup:int = 5;
      
      private var _niveau:int = 1;
      
      private var _xp:Number = 0;
      
      private var xpNivPrecedent:int;
      
      private var xpNivSuivant:int;
      
      public var niveauDepart:Number;
      
      public function NiveauJoueur()
      {
         super();
         this.xpNivSuivant = xpPremierNivSuivant;
      }
      
      public function get niveau() : int
      {
         return this._niveau;
      }
      
      public function get xp() : Number
      {
         return this._xp;
      }
      
      public function set xp(param1:Number) : void
      {
         this._xp = param1;
         while(this._xp >= this.xpNivSuivant)
         {
            ++this._niveau;
            this.xpNivPrecedent = this.xpNivSuivant;
            this.xpNivSuivant += xpPremierNivSuivant + this._niveau * xpNivSup;
            dispatchEvent(new NiveauEvent(NiveauEvent.GAIN_NIVEAU,this._niveau));
         }
      }
      
      public function init() : void
      {
         this.niveauDepart = this.niveau + (this._xp - this.xpNivPrecedent) / (this.xpNivSuivant - this.xpNivPrecedent);
      }
      
      public function statistiques() : Number
      {
         return this.niveau + (this._xp - this.xpNivPrecedent) / (this.xpNivSuivant - this.xpNivPrecedent) - this.niveauDepart;
      }
      
      public function charger(param1:Object) : void
      {
         this._xp = param1["xp"];
         this._niveau = param1["lvl"];
         this.xpNivPrecedent = param1["prev"];
         this.xpNivSuivant = param1["next"];
      }
   }
}

