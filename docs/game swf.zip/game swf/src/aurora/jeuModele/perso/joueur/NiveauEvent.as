package aurora.jeuModele.perso.joueur
{
   import flash.events.Event;
   
   public class NiveauEvent extends Event
   {
      
      public static const GAIN_NIVEAU:String = "gainNiveau";
      
      public var niveau:int;
      
      public function NiveauEvent(param1:String, param2:int)
      {
         this.niveau = param2;
         super(param1);
      }
   }
}

