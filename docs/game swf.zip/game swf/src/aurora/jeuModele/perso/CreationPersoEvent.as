package aurora.jeuModele.perso
{
   import flash.events.Event;
   
   public class CreationPersoEvent extends Event
   {
      
      public static const CREER:String = "creerPerso";
      
      public var creation:String;
      
      public var bonusCreation:Number;
      
      public var x:int;
      
      public var y:int;
      
      public var equipe:int;
      
      public var anim:String;
      
      public var rechercheEmplacement:Boolean;
      
      public function CreationPersoEvent(param1:String, param2:String, param3:int, param4:int, param5:int, param6:Number = 1, param7:String = "", param8:Boolean = true)
      {
         this.creation = param2;
         this.bonusCreation = param6;
         this.x = param3;
         this.y = param4;
         this.equipe = param5;
         this.anim = param7;
         this.rechercheEmplacement = param8;
         super(param1);
      }
   }
}

