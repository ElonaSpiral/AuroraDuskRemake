package aurora.jeuModele.perso
{
   public class Animal extends Mobile
   {
      
      public var bonusCreation:Number = 1;
      
      public function Animal()
      {
         super();
      }
      
      public function ajouter_bonus(param1:Number) : void
      {
         this.bonusCreation = param1;
      }
   }
}

