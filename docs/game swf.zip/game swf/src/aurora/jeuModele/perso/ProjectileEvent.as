package aurora.jeuModele.perso
{
   import flash.events.Event;
   
   public class ProjectileEvent extends Event
   {
      
      public static const CREER:String = "creerProjectile";
      
      public var lanceur:Object;
      
      public var projectile:String;
      
      public var x:Number;
      
      public var y:Number;
      
      public var attaque:int;
      
      public var portee:int;
      
      public var no:int;
      
      public var delai:Number;
      
      public var special:Object;
      
      public var degats:Vector.<String>;
      
      public var decalageY:int;
      
      public function ProjectileEvent(param1:String, param2:Object, param3:String, param4:Number, param5:Number, param6:int, param7:int, param8:int = 0, param9:Number = 0, param10:Object = null, param11:Vector.<String> = null, param12:int = 0)
      {
         this.lanceur = param2;
         this.projectile = param3;
         this.x = param4;
         this.y = param5;
         this.attaque = param6;
         this.portee = param7;
         this.no = param8;
         this.delai = param9;
         this.special = param10;
         this.degats = param11;
         this.decalageY = param12;
         super(param1);
      }
   }
}

