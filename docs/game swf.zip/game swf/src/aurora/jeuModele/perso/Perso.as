package aurora.jeuModele.perso
{
   import aurora.jeuModele.PersosEvent;
   import flash.events.EventDispatcher;
   
   public class Perso extends EventDispatcher
   {
      
      public static var prochaineId:int;
      
      public var id:int;
      
      public var race:String;
      
      public var visible:Boolean;
      
      public var x:Number;
      
      public var y:Number;
      
      public var largeur:int;
      
      public var hauteur:int;
      
      public var rayon:int;
      
      public var rayonCarre:int;
      
      public function Perso()
      {
         super();
         this.id = prochaineId++;
      }
      
      public function init(param1:Object) : void
      {
         this.race = param1.id;
         this.largeur = param1.width;
         this.hauteur = param1.height;
         this.rayon = this.largeur * 0.5;
         this.rayonCarre = this.rayon * this.rayon;
         this.visible = true;
      }
      
      public function distance(param1:Object) : Number
      {
         var _loc2_:int = 0;
         var _loc3_:int = 0;
         _loc2_ = this.x - param1.x;
         _loc3_ = this.y - param1.y;
         return Math.sqrt(_loc2_ * _loc2_ + _loc3_ * _loc3_);
      }
      
      public function mourir() : void
      {
         this.visible = false;
         dispatchEvent(new PersosEvent(PersosEvent.EFFACER));
         this.detruire();
      }
      
      public function pause() : void
      {
      }
      
      public function reprendre() : void
      {
      }
      
      public function detruire() : void
      {
         dispatchEvent(new PersosEvent(PersosEvent.DETRUIRE));
      }
   }
}

