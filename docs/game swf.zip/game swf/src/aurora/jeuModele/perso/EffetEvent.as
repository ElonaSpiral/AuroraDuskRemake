package aurora.jeuModele.perso
{
   import flash.events.Event;
   
   public class EffetEvent extends Event
   {
      
      public static const EFFET:String = "effet";
      
      public var x:int;
      
      public var y:int;
      
      public var effet:String;
      
      public var rotation:Number;
      
      public var score:int;
      
      public var echelleX:Number;
      
      public var echelleY:Number;
      
      public function EffetEvent(param1:String, param2:int, param3:int, param4:String, param5:Number = 0, param6:int = 0, param7:Number = 1, param8:Number = 1)
      {
         this.x = param2;
         this.y = param3;
         this.effet = param4;
         this.rotation = param5;
         this.score = param6;
         this.echelleX = param7;
         this.echelleY = param8;
         super(param1);
      }
      
      override public function clone() : Event
      {
         return new EffetEvent(type,this.x,this.y,this.effet,this.rotation,this.score,this.echelleX,this.echelleY);
      }
   }
}

