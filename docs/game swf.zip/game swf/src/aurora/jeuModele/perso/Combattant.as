package aurora.jeuModele.perso
{
   import aurora.jeuModele.Donnees;
   import aurora.jeuModele.IA;
   import aurora.jeuModele.PersosEvent;
   import aurora.jeuModele.Terrain;
   import aurora.jeuModele.perso.attaque.Attaque;
   import aurora.jeuModele.perso.attaque.AttaqueEvent;
   import aurora.jeuModele.perso.attaque.EffetArmeEvent;
   import aurora.messages.perso.MessagePersoOrienter;
   import flash.events.Event;
   import flash.events.TimerEvent;
   import flash.utils.Timer;
   
   public class Combattant extends Mobile
   {
      
      protected var intervalAttaques:Number = 1;
      
      public var cibleCombat:Vivant;
      
      protected var deplacementAttaqueTimer:Timer;
      
      public var portee:int;
      
      public var attaque:Attaque;
      
      private var cibleMobile:Boolean;
      
      public var suitOrdre:Boolean;
      
      public var kamikaze:Boolean;
      
      public function Combattant()
      {
         super();
         this.deplacementAttaqueTimer = new Timer(INTERVAL_DEPLACEMENT);
         this.deplacementAttaqueTimer.addEventListener(TimerEvent.TIMER,this.deplacer_attaque);
         this.attaque = new Attaque();
         this.attaque.addEventListener(AttaqueEvent.ATTAQUER,this.toucher);
      }
      
      public static function calcul_defense(param1:int) : int
      {
         if(param1 < 100)
         {
            return 100;
         }
         return Math.log(param1 * 0.01) * 100 + 100;
      }
      
      override public function init(param1:Object) : void
      {
         super.init(param1);
         this.attaque.init_score(param1.attack);
         this.attaque.effet = param1.attackEffect;
         this.attaque.son = param1.sound;
         this.attaque.actualiser_degats(param1.damage);
         if(param1.attackTime)
         {
            this.attaque.tempsAttaque = this.intervalAttaques = param1.attackTime;
         }
         if(param1.range)
         {
            this.attaque.portee = this.portee = param1.range;
         }
         if(param1.missile)
         {
            this.attaque.projectile = param1.missile;
            if(param1.attackDX)
            {
               this.attaque.attaqueDX = param1.attackDX;
            }
            if(param1.attackDY)
            {
               this.attaque.attaqueDY = param1.attackDY;
            }
         }
         if(param1.special)
         {
            this.attaque.coutAttaque = new Object();
            this.attaque.coutAttaque.special = param1.special;
         }
         if(param1.kamikaze)
         {
            this.kamikaze = param1.kamikaze;
         }
         if(param1.kill)
         {
            this.attaque.effetTueur = param1.kill;
         }
      }
      
      override public function set puissance(param1:Number) : void
      {
         super.puissance = param1;
         this.attaque.scoreBase *= param1;
         this.attaque.score *= param1;
      }
      
      override protected function appliquer_penalites(param1:Event = null) : void
      {
         this.attaque.score = this.attaque.scoreBase;
         penalites.appliquer_penalites_combattants(this);
         super.appliquer_penalites(param1);
      }
      
      override protected function voler(param1:TimerEvent) : void
      {
         if(!deplacementTimer.running && !this.deplacementAttaqueTimer.running)
         {
            ++_pas;
            if(_pas > 3)
            {
               _pas = 0;
            }
            dispatchEvent(new PersosEvent(PersosEvent.DEPLACER));
         }
      }
      
      override protected function gerer_ia(param1:TimerEvent = null) : void
      {
         if(iaTimer)
         {
            IA.gerer_combattant(this);
         }
         else
         {
            param1.currentTarget.stop();
            param1.currentTarget.removeEventListener(TimerEvent.TIMER,this.gerer_ia);
         }
      }
      
      override public function aller(param1:Number, param2:Number) : void
      {
         this.cibleCombat = null;
         this.deplacementAttaqueTimer.stop();
         super.aller(param1,param2);
      }
      
      override public function get enAttente() : Boolean
      {
         return super.enAttente && !this.cibleCombat;
      }
      
      public function attaquer(param1:Vivant) : void
      {
         if(!vivant)
         {
            return;
         }
         deplacementTimer.stop();
         this.cibleCombat = param1;
         this.cibleMobile = param1 is Mobile;
         this.destinationX = param1.x;
         this.destinationY = param1.y;
         this.deplacementAttaqueTimer.start();
         orienter();
      }
      
      protected function cible_proche(param1:Object, param2:int) : Boolean
      {
         return x > param1.x - param1.largeur * 0.5 - param2 && x < param1.x + param1.largeur * 0.5 + param2 && y > param1.y - Math.min(param1.largeur,param1.hauteur) - param2 && y < param1.y + param2;
      }
      
      protected function cible_proche2(param1:int) : Boolean
      {
         var _loc2_:Number = destinationX - x;
         var _loc3_:Number = destinationY - y;
         var _loc4_:Number = Math.sqrt(Math.pow(_loc2_,2) + Math.pow(_loc3_,2));
         return _loc4_ <= param1;
      }
      
      private function deplacer_attaque(param1:TimerEvent) : void
      {
         var _loc2_:Number = NaN;
         var _loc3_:Number = NaN;
         var _loc4_:Number = NaN;
         var _loc5_:Number = NaN;
         if(this.verifier_cible_combat())
         {
            if(this.cibleMobile)
            {
               destinationX = this.cibleCombat.x;
               destinationY = this.cibleCombat.y;
               orienter();
            }
            if(this.distanceAttaqueOk())
            {
               this.deplacementAttaqueTimer.stop();
               _pas = 0;
               this.frapper();
            }
            else
            {
               _loc2_ = destinationX - x;
               _loc3_ = destinationY - y;
               _loc4_ = Math.sqrt(Math.pow(_loc2_,2) + Math.pow(_loc3_,2));
               if(_loc4_ < this.distanceAttaque)
               {
                  _loc4_ = this.distanceAttaque;
               }
               _loc5_ = vitesse * MULTIPLICATEUR_VITESSE / _loc4_ * (volant ? 1 : Terrain.case_vitesse(x,y));
               x += _loc5_ * _loc2_;
               y += _loc5_ * _loc3_;
               ++_pas;
               if(_pas > 3)
               {
                  _pas = 0;
               }
               gerer_deplacement_terrain();
            }
            dispatchEvent(new PersosEvent(PersosEvent.DEPLACER));
         }
         else
         {
            this.deplacementAttaqueTimer.stop();
            if(_pas != 0)
            {
               _pas = 0;
               dispatchEvent(new PersosEvent(PersosEvent.DEPLACER));
            }
         }
      }
      
      protected function get distanceAttaque() : int
      {
         return rayon + this.cibleCombat.rayon + this.portee;
      }
      
      protected function distanceAttaque2(param1:int) : Boolean
      {
         return (this.cibleCombat is Batiment || this.cibleCombat is Fondations) && this.cible_proche(this.cibleCombat,rayon + param1) || !(this.cibleCombat is Batiment || this.cibleCombat is Fondations) && this.cible_proche2(rayon + this.cibleCombat.rayon + param1);
      }
      
      protected function distanceAttaqueOk() : Boolean
      {
         return (this.cibleCombat is Batiment || this.cibleCombat is Fondations) && this.cible_proche(this.cibleCombat,rayon + this.portee) || !(this.cibleCombat is Batiment || this.cibleCombat is Fondations) && this.cible_proche2(this.distanceAttaque);
      }
      
      protected function verifier_cible_combat() : Boolean
      {
         if(this.cibleCombat)
         {
            if(this.cibleCombat.visible && this.cibleCombat.vivant)
            {
               return true;
            }
            this.cibleCombat = null;
            return false;
         }
         return false;
      }
      
      public function verifier_peut_attaquer(param1:Object, param2:Boolean = false, param3:Boolean = false, param4:Boolean = true) : Boolean
      {
         return false;
      }
      
      protected function frapper() : void
      {
         if(Boolean(vivant) && Boolean(this.attaque) && !this.attaque.attaqueEnCours)
         {
            this.toucher2(this.attaque);
         }
      }
      
      override public function arreter() : void
      {
         this.deplacementAttaqueTimer.stop();
         this.cibleCombat = null;
         this.suitOrdre = false;
         super.arreter();
      }
      
      public function get enCombat() : Boolean
      {
         return this.cibleCombat != null;
      }
      
      protected function toucher(param1:AttaqueEvent) : void
      {
         this.toucher2(Attaque(param1.currentTarget));
      }
      
      protected function toucher2(param1:Attaque) : void
      {
         if(Boolean(this.cibleCombat) && (!this.cibleCombat.visible || !this.cibleCombat.vivant))
         {
            this.cibleCombat = Vivant(IA.trouver_ennemi_procheXY(this,this.cibleCombat.x,this.cibleCombat.y));
            if(this.cibleCombat)
            {
               this.attaquer(this.cibleCombat);
            }
         }
         else if(this.verifier_cible_combat())
         {
            if(Boolean(this.cibleCombat) && this.cibleMobile)
            {
               destinationX = this.cibleCombat.x;
               destinationY = this.cibleCombat.y;
               orienter();
            }
            if(!this.distanceAttaque2(param1.portee))
            {
               if(!this.distanceAttaqueOk())
               {
                  this.attaquer(this.cibleCombat);
               }
            }
            else if(!this.distanceAttaque2(param1.portee) && !this.verifier_peut_attaquer(param1.coutAttaque,false,true))
            {
               if(!this.distanceAttaqueOk())
               {
                  this.attaquer(this.cibleCombat);
               }
            }
            else if(!this.verifier_peut_attaquer(param1.coutAttaque,false,true))
            {
               this.toucher2Prime(param1);
               if(param1.effetArme)
               {
                  if(orientation == MessagePersoOrienter.HAUT || orientation == MessagePersoOrienter.BAS)
                  {
                     dispatchEvent(new EffetArmeEvent(EffetArmeEvent.EFFET_ARME,param1.effetArme.arme,param1.effetArme.anim,param1.effetArme.son,x + param1.attaqueDX,y - hauteur * 0.5 - (orientation == MessagePersoOrienter.HAUT ? largeur * 0.25 : 0) + (orientation == MessagePersoOrienter.BAS ? largeur * 0.25 : 0),Math.atan2(destinationY - y,destinationX - x) + 2.355));
                  }
                  else
                  {
                     dispatchEvent(new EffetArmeEvent(EffetArmeEvent.EFFET_ARME,param1.effetArme.arme,param1.effetArme.anim,param1.effetArme.son,x + param1.attaqueDX * 0.25 - (orientation == MessagePersoOrienter.GAUCHE ? largeur * 0.25 : 0) + (orientation == MessagePersoOrienter.DROITE ? largeur * 0.25 : 0),y - hauteur * 0.5,Math.atan2(destinationY - y,destinationX - x) + 2.355));
                  }
               }
               if(param1.son)
               {
                  jouer_son(param1.son);
               }
               param1.demarrer();
               this.verifier_peut_attaquer(param1.coutAttaque,false,false);
            }
         }
      }
      
      protected function toucher2Prime(param1:Attaque) : void
      {
         if(param1.projectile)
         {
            if(param1.attaquesMultiples)
            {
               this.lancer_attaques_multiples(param1);
            }
            else
            {
               dispatchEvent(new ProjectileEvent(ProjectileEvent.CREER,this,param1.projectile,Math.round(x + param1.attaqueDX),Math.round(y + param1.attaqueDY) + decalageY,param1.score,param1.portee,param1.no,param1.delai,Boolean(param1.coutAttaque) && Boolean(param1.coutAttaque.special) ? param1.coutAttaque.special : null,param1.degats,this.attaque.attaqueDY + (param1.attaqueDY ? param1.attaqueDY : 0)));
            }
         }
         else
         {
            this.toucher3(this.cibleCombat,param1.score,param1.effet,param1.no,param1.effetLigne,param1,Boolean(param1.coutAttaque) && Boolean(param1.coutAttaque.special) ? param1.coutAttaque.special.penality : null,param1.degats,param1.coutAttaque ? param1.coutAttaque.special : null);
         }
      }
      
      protected function lancer_attaques_multiples(param1:Attaque) : void
      {
         var _loc2_:Object = null;
         if(param1.coutAttaque)
         {
            for each(_loc2_ in param1.coutAttaque.attacks)
            {
               dispatchEvent(new ProjectileEvent(ProjectileEvent.CREER,this,_loc2_.missile,Math.round(x + param1.attaqueDX + (_loc2_.attackDX ? _loc2_.attackDX : 0)),Math.round(y + param1.attaqueDY + (_loc2_.attackDY ? _loc2_.attackDY : 0)) + decalageY,param1.score,_loc2_.range,param1.no,_loc2_.attackDelay,_loc2_,Attaque.convertir_degats(param1.degats),param1.attaqueDY + (_loc2_.attackDY ? _loc2_.attackDY : 0)));
            }
         }
      }
      
      public function toucher3(param1:Object, param2:int, param3:String, param4:int, param5:String = null, param6:Attaque = null, param7:Object = null, param8:Vector.<String> = null, param9:Object = null, param10:Boolean = true) : int
      {
         var _loc12_:int = 0;
         var _loc13_:int = 0;
         var _loc14_:int = 0;
         var _loc15_:int = 0;
         var _loc11_:int = Math.ceil(this.alea_degats * param2 / calcul_defense(param1.defense)) * param1.total_resistances(param8);
         if(_loc11_ > 0)
         {
            _loc12_ = param1.x + Math.random() * param1.largeur * 0.5 - param1.largeur * 0.25;
            _loc13_ = param1.y - param1.hauteur * 0.75 + Math.random() * param1.hauteur * 0.5;
            dispatchEvent(new EffetEvent(EffetEvent.EFFET,_loc12_,_loc13_,param3,0,this is Joueur || param1 is Joueur ? int(-_loc11_) : 0));
            if(param5)
            {
               _loc14_ = x + param6.attaqueDX;
               _loc15_ = y + param6.attaqueDY;
               dispatchEvent(new EffetEvent(EffetEvent.EFFET,(_loc14_ + _loc12_) * 0.5,(_loc15_ + _loc13_) * 0.5,param5,Math.atan2(_loc13_ - _loc15_,_loc12_ - _loc14_),0,Math.sqrt(Math.pow(_loc14_ - _loc12_,2) + Math.pow(_loc15_ - _loc13_,2)) / Donnees.donnees[param5].width * 0.5));
            }
            if(Vivant(param1).vie.score <= _loc11_)
            {
               param1.gerer_mort(this);
            }
            Vivant(param1).editer_vie(-_loc11_);
            if(param10)
            {
               this.toucher4(_loc11_,param4);
            }
            param1.toucher5(_loc11_);
            if(param10 && Boolean(param9))
            {
               if(param9.area)
               {
                  this.toucher_zone(param1,param9.area.attack,param9.area.range,param9.area.effect,param4,param5,param6,param7,param8,param9);
               }
               if(param9.chain)
               {
                  this.toucher_chaine(param1,param9.chain.number,param9.chain.attack,param9.chain.range,param9.chain.effect,param4,param9.chain.effectLine,param6,param7,param8,param9);
               }
            }
            if(param1.vivant)
            {
               if(param1 is Mobile)
               {
                  param1.appliquer_inertie(this,_loc11_);
                  if(param7)
                  {
                     param1.penalites.ajouter_penalite(param7.id,param7.time);
                  }
                  if(param9)
                  {
                     if(param9.poison)
                     {
                        param1.empoisonne(Math.ceil(this.alea_degats * param9.poison.attack * 0.01) * (param1.resistances["poison"] == null ? 1 : param1.resistances["poison"]),param9.poison.time,this);
                     }
                  }
                  if(param1 is Combattant)
                  {
                     if(param1 is Artisan)
                     {
                        if(param1.ia)
                        {
                           IA.gerer_equipement(Artisan(param1));
                        }
                     }
                     param1.riposter(this);
                  }
               }
            }
            else
            {
               if(param1 is Artisan)
               {
                  Tresor.piller_perso(Artisan(param1),this);
               }
               if(vivant)
               {
                  if(param1 == this.cibleCombat)
                  {
                     if(Boolean(this is Artisan) && Boolean(Donnees.donnees[param1.race].death) && Boolean(Donnees.donnees[param1.race].death.build))
                     {
                        Artisan(this).cibleTravail = Perso(IA.trouver_butin_proche(this,param1.id));
                        if(Artisan(this).cibleTravail)
                        {
                           Artisan(this).aller_travailler(Artisan(this).cibleTravail);
                        }
                     }
                     else
                     {
                        this.cibleCombat = Vivant(IA.trouver_ennemi_procheXY(this,param1.x,param1.y));
                        if(this.cibleCombat)
                        {
                           this.attaquer(this.cibleCombat);
                        }
                        else
                        {
                           this.arreter();
                        }
                     }
                  }
               }
               if(Boolean(param6 && param6.effetTueur) && Boolean(param1 is Combattant) && !(param1 is BatimentMobile))
               {
                  this.appliquer_effet_tueur(param6.effetTueur,param1.x,param1.y,param1.hauteur,param1);
               }
            }
            if(this.kamikaze)
            {
               mourir();
            }
         }
         return _loc11_;
      }
      
      protected function toucher4(param1:int, param2:int) : void
      {
      }
      
      override public function toucher5(param1:int) : void
      {
      }
      
      private function get alea_degats() : Number
      {
         return Math.random() * 10 + 5;
      }
      
      private function toucher_zone(param1:Object, param2:int, param3:int, param4:String, param5:int, param6:String = null, param7:Attaque = null, param8:Object = null, param9:Vector.<String> = null, param10:Object = null) : void
      {
         var _loc12_:Object = null;
         var _loc11_:Vector.<Object> = IA.trouver_ennemis_zone(param1.x,param1.y,equipe,param3);
         for each(_loc12_ in _loc11_)
         {
            if(_loc12_ != param1)
            {
               this.toucher3(_loc12_,param2,param4,param5,param6,param7,param8,param9,param10,false);
            }
         }
      }
      
      private function toucher_chaine(param1:Object, param2:int, param3:int, param4:int, param5:String, param6:int, param7:String = null, param8:Attaque = null, param9:Object = null, param10:Vector.<String> = null, param11:Object = null) : void
      {
         var _loc13_:int = 0;
         var _loc14_:int = 0;
         var _loc15_:int = 0;
         var _loc16_:int = 0;
         var _loc12_:Vector.<Object> = IA.trouver_ennemis_chaine(param1,param1.x,param1.y,equipe,param4,param2);
         var _loc17_:int = 1;
         while(_loc17_ < _loc12_.length)
         {
            this.toucher3(_loc12_[_loc17_],param3,param5,param6,null,param8,param9,param10,param11,false);
            if(param7)
            {
               _loc13_ = int(_loc12_[_loc17_ - 1].x);
               _loc14_ = _loc12_[_loc17_ - 1].y - _loc12_[_loc17_ - 1].hauteur * 0.5;
               _loc15_ = int(_loc12_[_loc17_].x);
               _loc16_ = _loc12_[_loc17_].y - _loc12_[_loc17_].hauteur * 0.5;
               dispatchEvent(new EffetEvent(EffetEvent.EFFET,(_loc13_ + _loc15_) * 0.5,(_loc14_ + _loc16_) * 0.5,param7,Math.atan2(_loc16_ - _loc14_,_loc15_ - _loc13_),0,Math.sqrt(Math.pow(_loc13_ - _loc15_,2) + Math.pow(_loc14_ - _loc16_,2)) / Donnees.donnees[param7].width * 0.5));
            }
            _loc17_++;
         }
      }
      
      protected function appliquer_effet_tueur(param1:Object, param2:int, param3:int, param4:int, param5:Object) : void
      {
         var _loc6_:Object = null;
         var _loc7_:Boolean = false;
         var _loc8_:Boolean = false;
         var _loc9_:String = null;
         if(param1.create)
         {
            for each(_loc6_ in param1.create)
            {
               _loc8_ = true;
               if(_loc6_.except)
               {
                  for each(_loc9_ in _loc6_.except)
                  {
                     if(Boolean(Donnees.donnees[param5.race].tag) && Donnees.donnees[param5.race].tag.indexOf(_loc9_) != -1)
                     {
                        _loc8_ = false;
                        break;
                     }
                  }
               }
               if(_loc8_)
               {
                  dispatchEvent(new CreationPersoEvent(CreationPersoEvent.CREER,_loc6_.id,param2,param3,equipe));
                  _loc7_ = true;
               }
            }
         }
         if(_loc7_ && Boolean(param1.effect))
         {
            dispatchEvent(new EffetEvent(EffetEvent.EFFET,param2,param3 - param4 * 0.5,param1.effect.name,0,0,param1.effect.scale ? Number(param1.effect.scale) : 1,param1.effect.scale ? Number(param1.effect.scale) : 1));
         }
      }
      
      public function riposter(param1:Vivant) : void
      {
         if(param1.vivant)
         {
            if(this.enAttente || ia && (!this.enCombat || this.cibleCombat is BatimentOffensif && param1 is Combattant) && (!this.cibleCombat || !(this.cibleCombat is Combattant)) && !(deplacementTimer.running && this.suitOrdre))
            {
               this.attaquer(param1);
            }
            if(param1 is Aventurier)
            {
               Aventurier(param1).reculer(this);
            }
         }
      }
      
      public function preparer_attaques() : void
      {
         this.attaque.arreter();
      }
      
      override public function pause() : void
      {
         this.deplacementAttaqueTimer.stop();
         if(this.attaque.attaqueEnCours)
         {
            this.attaque.timerAttaque.stop();
         }
         super.pause();
      }
      
      override public function reprendre() : void
      {
         if(this.cibleCombat)
         {
            this.deplacementAttaqueTimer.start();
         }
         if(this.attaque.attaqueEnCours)
         {
            this.attaque.timerAttaque.start();
         }
         super.reprendre();
      }
      
      override public function detruire() : void
      {
         super.detruire();
         this.cibleCombat = null;
         this.deplacementAttaqueTimer.stop();
         this.deplacementAttaqueTimer.removeEventListener(TimerEvent.TIMER,this.deplacer_attaque);
         this.deplacementAttaqueTimer = null;
         this.attaque.removeEventListener(AttaqueEvent.ATTAQUER,this.toucher);
         this.attaque.detruire();
         this.attaque = null;
      }
   }
}

