package aurora.jeuModele.perso.ressources
{
   import flash.events.EventDispatcher;
   
   public class Ressource extends EventDispatcher
   {
      
      public var id:String;
      
      protected var _quantite:int;
      
      protected var _quantiteMax:int;
      
      public var plein:Boolean;
      
      public var illimite:Boolean;
      
      public function Ressource(param1:String, param2:int, param3:Boolean)
      {
         super();
         this.id = param1;
         this._quantiteMax = param2;
         this.illimite = param3;
      }
      
      public function get quantite() : int
      {
         return this._quantite;
      }
      
      public function set quantite(param1:int) : void
      {
         if(param1 > 999999999)
         {
            param1 = 999999999;
         }
         this._quantite = param1;
         this.actualiser();
      }
      
      public function get quantiteMax() : int
      {
         return this._quantiteMax;
      }
      
      public function set quantiteMax(param1:int) : void
      {
         this._quantiteMax = param1;
         this.actualiser();
      }
      
      private function actualiser() : void
      {
         if(this._quantite > this._quantiteMax)
         {
            this._quantite = this._quantiteMax;
         }
         this.plein = this._quantite == this._quantiteMax;
      }
   }
}

