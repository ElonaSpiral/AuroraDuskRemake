package aurora.jeuModele.perso.ressources
{
   import aurora.MainJeu;
   
   public class RessourceJoueur extends Ressource
   {
      
      public var noJoueur:int;
      
      public function RessourceJoueur(param1:String, param2:int, param3:Boolean)
      {
         super(param1,param2,param3);
      }
      
      public function recuperer_infos() : void
      {
         dispatchEvent(new RessourceEvent(RessourceEvent.ACTUALISER_QUANTITE,id,_quantite));
         dispatchEvent(new RessourceEvent(RessourceEvent.ACTUALISER_QUANTITE_MAX,id,_quantiteMax));
      }
      
      override public function set quantite(param1:int) : void
      {
         if(MainJeu.bacASable)
         {
            super.quantite = 100;
         }
         else
         {
            super.quantite = param1;
         }
         dispatchEvent(new RessourceEvent(RessourceEvent.ACTUALISER_QUANTITE,id,_quantite));
      }
      
      override public function set quantiteMax(param1:int) : void
      {
         if(_quantite > param1)
         {
            dispatchEvent(new RessourceEvent(RessourceEvent.ACTUALISER_QUANTITE,id,param1));
         }
         super.quantiteMax = param1;
         dispatchEvent(new RessourceEvent(RessourceEvent.ACTUALISER_QUANTITE_MAX,id,_quantiteMax));
      }
      
      public function detruire() : void
      {
      }
   }
}

