package aurora.jeuModele.perso.ressources
{
   import flash.events.Event;
   
   public class RessourceEvent extends Event
   {
      
      public static const ACTUALISER_QUANTITE:String = "actualiserQuantite";
      
      public static const ACTUALISER_QUANTITE_MAX:String = "actualiserQuantiteMax";
      
      public static const ACTUALISER_ENTREPOT:String = "actualiserEntrepot";
      
      public var id:String;
      
      public var quantite:int;
      
      public function RessourceEvent(param1:String, param2:String, param3:int)
      {
         this.id = param2;
         this.quantite = param3;
         super(param1);
      }
   }
}

