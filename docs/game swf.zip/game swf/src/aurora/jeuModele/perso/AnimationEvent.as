package aurora.jeuModele.perso
{
   import flash.events.Event;
   
   public class AnimationEvent extends Event
   {
      
      public static const ANIMER:String = "animer";
      
      public var animation:String;
      
      public var id:int;
      
      public function AnimationEvent(param1:String, param2:String, param3:int = 0)
      {
         this.animation = param2;
         this.id = param3;
         super(param1);
      }
   }
}

