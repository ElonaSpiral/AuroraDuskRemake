package aurora.jeuModele.perso.rechargements
{
   import aurora.jeuModele.Donnees;
   import flash.events.EventDispatcher;
   import flash.utils.Dictionary;
   
   public class Rechargements extends EventDispatcher
   {
      
      protected var rechargements:Dictionary;
      
      public function Rechargements()
      {
         super();
         this.rechargements = new Dictionary();
      }
      
      public function ajouter(param1:String, param2:int) : void
      {
         this.rechargements[param1] = new Rechargement(param1,param2);
         this.rechargements[param1].addEventListener(RechargementEvent.TERMINER,this.effacer_rechargement);
      }
      
      public function en_cours(param1:String) : Boolean
      {
         return this.rechargements[param1];
      }
      
      public function en_cours_selon_objet(param1:String) : Boolean
      {
         var _loc2_:Object = null;
         if(Donnees.donnees[param1]["use"])
         {
            _loc2_ = Donnees.donnees[param1]["use"].cooldown;
         }
         if(_loc2_)
         {
            return this.en_cours(_loc2_.id);
         }
         return false;
      }
      
      protected function effacer_rechargement(param1:RechargementEvent) : void
      {
         this.effacer_rechargement2(param1.currentTarget.id);
      }
      
      protected function effacer_rechargement2(param1:String) : void
      {
         this.rechargements[param1].removeEventListener(RechargementEvent.TERMINER,this.effacer_rechargement);
         this.rechargements[param1].detruire();
         this.rechargements[param1] = null;
         delete this.rechargements[param1];
      }
      
      public function arreter() : void
      {
         var _loc1_:String = null;
         for(_loc1_ in this.rechargements)
         {
            this.rechargements[_loc1_].arreter();
         }
      }
      
      public function reprendre() : void
      {
         var _loc1_:String = null;
         for(_loc1_ in this.rechargements)
         {
            this.rechargements[_loc1_].reprendre();
         }
      }
      
      public function detruire() : void
      {
         var _loc1_:String = null;
         for(_loc1_ in this.rechargements)
         {
            this.effacer_rechargement2(_loc1_);
         }
         this.rechargements = null;
      }
   }
}

