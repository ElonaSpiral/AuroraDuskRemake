package aurora.jeuModele.perso.rechargements
{
   import flash.events.Event;
   
   public class RechargementEvent extends Event
   {
      
      public static const TERMINER:String = "terminer";
      
      public function RechargementEvent(param1:String)
      {
         super(param1);
      }
   }
}

