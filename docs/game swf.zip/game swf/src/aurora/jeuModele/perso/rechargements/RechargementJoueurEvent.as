package aurora.jeuModele.perso.rechargements
{
   public class RechargementJoueurEvent extends RechargementEvent
   {
      
      public static const ACTUALISER_TEMPS:String = "actualiserTemps";
      
      public var id:String;
      
      public var temps:int;
      
      public function RechargementJoueurEvent(param1:String, param2:String, param3:int)
      {
         this.id = param2;
         this.temps = param3;
         super(param1);
      }
   }
}

