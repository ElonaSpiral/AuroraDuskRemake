package aurora.jeuModele.perso.rechargements
{
   public class RechargementsJoueur extends Rechargements
   {
      
      public var noJoueur:int;
      
      public function RechargementsJoueur()
      {
         super();
      }
      
      override public function ajouter(param1:String, param2:int) : void
      {
         rechargements[param1] = new RechargementJoueur(param1,param2);
         rechargements[param1].addEventListener(RechargementJoueurEvent.ACTUALISER_TEMPS,this.actualiser_temps);
         rechargements[param1].addEventListener(RechargementEvent.TERMINER,effacer_rechargement);
         dispatchEvent(new RechargementJoueurEvent(RechargementJoueurEvent.ACTUALISER_TEMPS,param1,param2));
      }
      
      private function actualiser_temps(param1:RechargementJoueurEvent) : void
      {
         dispatchEvent(new RechargementJoueurEvent(RechargementJoueurEvent.ACTUALISER_TEMPS,param1.id,param1.temps));
      }
      
      override protected function effacer_rechargement2(param1:String) : void
      {
         rechargements[param1].removeEventListener(RechargementJoueurEvent.ACTUALISER_TEMPS,this.actualiser_temps);
         rechargements[param1].removeEventListener(RechargementEvent.TERMINER,effacer_rechargement);
         super.effacer_rechargement2(param1);
      }
   }
}

