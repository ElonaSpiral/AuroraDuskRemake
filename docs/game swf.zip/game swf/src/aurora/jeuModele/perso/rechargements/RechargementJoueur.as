package aurora.jeuModele.perso.rechargements
{
   import flash.events.TimerEvent;
   
   public class RechargementJoueur extends Rechargement
   {
      
      public function RechargementJoueur(param1:String, param2:int)
      {
         super(param1,param2);
         timer.addEventListener(TimerEvent.TIMER,this.actualiser_temps);
      }
      
      private function actualiser_temps(param1:TimerEvent) : void
      {
         dispatchEvent(new RechargementJoueurEvent(RechargementJoueurEvent.ACTUALISER_TEMPS,id,timer.repeatCount - timer.currentCount));
      }
      
      override public function detruire() : void
      {
         timer.removeEventListener(TimerEvent.TIMER,this.actualiser_temps);
         super.detruire();
      }
   }
}

