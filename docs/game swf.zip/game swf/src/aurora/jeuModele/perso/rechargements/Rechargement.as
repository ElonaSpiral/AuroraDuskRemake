package aurora.jeuModele.perso.rechargements
{
   import flash.events.EventDispatcher;
   import flash.events.TimerEvent;
   import flash.utils.Timer;
   
   public class Rechargement extends EventDispatcher
   {
      
      public var id:String;
      
      protected var timer:Timer;
      
      public function Rechargement(param1:String, param2:int)
      {
         super();
         this.id = param1;
         this.timer = new Timer(1000,param2);
         this.timer.addEventListener(TimerEvent.TIMER_COMPLETE,this.terminer);
         this.timer.start();
      }
      
      public function arreter() : void
      {
         this.timer.stop();
      }
      
      public function reprendre() : void
      {
         this.timer.start();
      }
      
      protected function terminer(param1:TimerEvent) : void
      {
         dispatchEvent(new RechargementEvent(RechargementEvent.TERMINER));
      }
      
      public function detruire() : void
      {
         this.timer.removeEventListener(TimerEvent.TIMER_COMPLETE,this.terminer);
         this.timer.stop();
         this.timer = null;
      }
   }
}

