package aurora.jeuModele.perso
{
   import aurora.jeuModele.perso.attaque.Attaque;
   import aurora.jeuModele.perso.attaque.AttaqueEvent;
   import flash.events.Event;
   import flash.events.TimerEvent;
   import flash.utils.Timer;
   
   public class CombattantAvance extends Combattant
   {
      
      public var attaquesSupplementaires:Vector.<Attaque> = new Vector.<Attaque>();
      
      protected var attaqueTimer:Timer = new Timer(INTERVAL_DEPLACEMENT);
      
      public function CombattantAvance()
      {
         this.attaqueTimer.addEventListener(TimerEvent.TIMER,this.gerer_attaques);
         super();
      }
      
      override public function init(param1:Object) : void
      {
         var _loc2_:Vector.<Attaque> = null;
         var _loc3_:Object = null;
         var _loc4_:Attaque = null;
         super.init(param1);
         if(param1.attacks)
         {
            _loc2_ = new Vector.<Attaque>();
            for each(_loc3_ in param1.attacks)
            {
               _loc4_ = new Attaque();
               _loc4_.init_score(_loc3_.attack);
               _loc4_.actualiser_degats(_loc3_.damage);
               _loc4_.tempsAttaque = _loc3_.attackTime;
               _loc4_.effet = _loc3_.attackEffect;
               _loc4_.son = _loc3_.sound;
               _loc4_.portee = _loc3_.range;
               if(_loc3_.range > portee)
               {
                  portee = _loc3_.range;
               }
               _loc4_.projectile = _loc3_.missile;
               _loc4_.attaqueDX = _loc3_.attackDX;
               _loc4_.attaqueDY = _loc3_.attackDY;
               if(_loc3_.attackDelay)
               {
                  _loc4_.delai = _loc3_.attackDelay;
               }
               _loc4_.coutAttaque = _loc3_;
               _loc2_.push(_loc4_);
            }
            this.ajouter_attaques_supplementaires(_loc2_,0);
         }
      }
      
      override public function set puissance(param1:Number) : void
      {
         var _loc2_:Attaque = null;
         super.puissance = param1;
         for each(_loc2_ in this.attaquesSupplementaires)
         {
            _loc2_.scoreBase *= param1;
            _loc2_.score *= param1;
         }
      }
      
      override protected function appliquer_penalites(param1:Event = null) : void
      {
         var _loc2_:Attaque = null;
         for each(_loc2_ in this.attaquesSupplementaires)
         {
            _loc2_.score = _loc2_.scoreBase;
         }
         penalites.appliquer_penalites_combattantsAvances(this);
         super.appliquer_penalites(param1);
      }
      
      protected function effacer_attaques_supplementaires() : void
      {
         var _loc1_:Attaque = null;
         if(this.attaquesSupplementaires.length > 0)
         {
            for each(_loc1_ in this.attaquesSupplementaires)
            {
               _loc1_.removeEventListener(AttaqueEvent.ATTAQUER,toucher);
               _loc1_.detruire();
               _loc1_ = null;
            }
            this.attaquesSupplementaires = new Vector.<Attaque>();
         }
      }
      
      protected function ajouter_attaques_supplementaires(param1:Vector.<Attaque>, param2:int) : void
      {
         var _loc3_:Attaque = null;
         for each(_loc3_ in param1)
         {
            this.attaquesSupplementaires.push(new Attaque());
            this.attaquesSupplementaires[this.attaquesSupplementaires.length - 1].copier(_loc3_);
            this.attaquesSupplementaires[this.attaquesSupplementaires.length - 1].no = this.attaquesSupplementaires.length;
         }
         for each(_loc3_ in this.attaquesSupplementaires)
         {
            _loc3_.augmenter_score(param2);
            _loc3_.addEventListener(AttaqueEvent.ATTAQUER,toucher);
         }
      }
      
      override protected function frapper() : void
      {
         var _loc1_:Attaque = null;
         super.frapper();
         for each(_loc1_ in this.attaquesSupplementaires)
         {
            if(!_loc1_.attaqueEnCours)
            {
               toucher2(_loc1_);
            }
         }
         if(this.attaqueTimer)
         {
            this.attaqueTimer.start();
         }
      }
      
      private function gerer_attaques(param1:TimerEvent) : void
      {
         var _loc2_:Attaque = null;
         if(cibleCombat)
         {
            super.frapper();
            for each(_loc2_ in this.attaquesSupplementaires)
            {
               if(!_loc2_.attaqueEnCours)
               {
                  toucher2(_loc2_);
               }
            }
         }
      }
      
      override public function preparer_attaques() : void
      {
         var _loc1_:Attaque = null;
         super.preparer_attaques();
         for each(_loc1_ in this.attaquesSupplementaires)
         {
            _loc1_.arreter();
         }
      }
      
      override public function pause() : void
      {
         var _loc1_:Attaque = null;
         if(vivant)
         {
            this.attaqueTimer.stop();
            for each(_loc1_ in this.attaquesSupplementaires)
            {
               if(_loc1_.attaqueEnCours)
               {
                  _loc1_.timerAttaque.stop();
               }
            }
         }
         super.pause();
      }
      
      override public function reprendre() : void
      {
         var _loc1_:Attaque = null;
         if(vivant)
         {
            this.attaqueTimer.start();
            for each(_loc1_ in this.attaquesSupplementaires)
            {
               if(_loc1_.attaqueEnCours)
               {
                  _loc1_.timerAttaque.start();
               }
            }
         }
         super.reprendre();
      }
      
      override public function detruire() : void
      {
         super.detruire();
         this.attaqueTimer.removeEventListener(TimerEvent.TIMER,this.gerer_attaques);
         this.attaqueTimer.stop();
         this.attaqueTimer = null;
         this.effacer_attaques_supplementaires();
      }
   }
}

