package aurora.jeuModele.perso
{
   import aurora.jeuModele.Donnees;
   import flash.events.TimerEvent;
   import flash.utils.Timer;
   
   public class Intermediaire extends Perso
   {
      
      public var timer:Timer;
      
      public var creation:String;
      
      public var bonusCreation:Number;
      
      public var ville:int;
      
      public var equipe:int;
      
      public var anim:String;
      
      public function Intermediaire(param1:Number, param2:String, param3:Number, param4:int, param5:int, param6:String)
      {
         super();
         this.creation = param2;
         this.bonusCreation = param3;
         this.ville = param4;
         this.equipe = param5;
         this.anim = param6;
         this.largeur = Donnees.donnees[param2].width;
         this.hauteur = Donnees.donnees[param2].height;
         this.timer = new Timer(1000,param1);
         this.timer.addEventListener(TimerEvent.TIMER_COMPLETE,this.finir);
         this.timer.start();
      }
      
      protected function finir(param1:TimerEvent = null) : void
      {
         dispatchEvent(new CreationPersoEvent(CreationPersoEvent.CREER,this.creation,x,y,this.equipe,this.bonusCreation,this.anim));
         mourir();
      }
      
      override public function pause() : void
      {
         this.timer.stop();
         super.pause();
      }
      
      override public function reprendre() : void
      {
         this.timer.start();
         super.reprendre();
      }
      
      override public function detruire() : void
      {
         super.detruire();
         this.timer.removeEventListener(TimerEvent.TIMER_COMPLETE,this.finir);
         this.timer.stop();
         this.timer = null;
      }
   }
}

