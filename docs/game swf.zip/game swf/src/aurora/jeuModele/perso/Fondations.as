package aurora.jeuModele.perso
{
   import aurora.jeuModele.Donnees;
   import aurora.jeuModele.PersosEvent;
   
   public class Fondations extends Vivant
   {
      
      public var etape:int;
      
      public var derniereEtape:int;
      
      public var travailDuree:int;
      
      public var creation:String;
      
      public var bonusCreation:Number;
      
      private var vieCreation:int;
      
      public var anim:String;
      
      public var createur:Object;
      
      public var coutCaracteristique:Object;
      
      public var bonusCompetence:String;
      
      public var coutRessource:Vector.<Object>;
      
      public var tempsConstruction:int;
      
      public var tempsTotal:int;
      
      private var vieParConstruction:int;
      
      public function Fondations(param1:Number, param2:String, param3:Number, param4:int, param5:String, param6:Object, param7:Object)
      {
         var _loc9_:String = null;
         this.travailDuree = param1 * 1000;
         this.creation = param2;
         this.bonusCreation = param3;
         this.equipe = param4;
         this.anim = param5;
         this.createur = param7;
         this.vieCreation = param6.health;
         this.coutCaracteristique = param6.build.costPrimaryCharacteristic;
         this.bonusCompetence = param6.build.bonusSkill;
         this.coutRessource = new Vector.<Object>();
         var _loc8_:Boolean = true;
         for(_loc9_ in param6.build.costRessource)
         {
            this.tempsTotal += param6.build.costRessource[_loc9_];
            this.coutRessource.push({
               "nom":_loc9_,
               "quantite":param6.build.costRessource[_loc9_] - (_loc8_ ? 1 : 0)
            });
            if(_loc8_)
            {
               _loc8_ = false;
               ++this.tempsConstruction;
            }
         }
         this.vieParConstruction = this.vieCreation / this.tempsTotal;
         this.coutRessource.sort(this.ranger);
         super();
      }
      
      private function ranger(param1:Object, param2:Object) : int
      {
         if(Donnees.donnees[param1.nom].no < Donnees.donnees[param2.nom].no)
         {
            return -1;
         }
         if(Donnees.donnees[param1.nom].no > Donnees.donnees[param2.nom].no)
         {
            return 1;
         }
         return 0;
      }
      
      override public function init(param1:Object) : void
      {
         super.init(param1);
         this.derniereEtape = param1.steps;
         vie.scoreMax = this.vieCreation;
         vie.score = this.vieParConstruction * this.tempsConstruction;
         dispatchEvent(new PersosEvent(PersosEvent.ACTUALISER_VIE));
      }
      
      public function construire(param1:int, param2:int) : void
      {
         var _loc3_:int = 0;
         this.coutRessource[param2].quantite -= param1;
         if(this.coutRessource[param2].quantite <= 0)
         {
            this.coutRessource.splice(param2,1);
         }
         this.tempsConstruction += param1;
         vie.score += param1 * this.vieParConstruction;
         dispatchEvent(new PersosEvent(PersosEvent.ACTUALISER_VIE));
         if(this.tempsConstruction >= this.tempsTotal)
         {
            this.finir();
         }
         else
         {
            _loc3_ = this.tempsConstruction / this.tempsTotal * this.derniereEtape;
            if(_loc3_ != this.etape)
            {
               this.etape = _loc3_;
               dispatchEvent(new PersosEvent(PersosEvent.ACTUALISER_ETAPE));
            }
            dispatchEvent(new PersosEvent(PersosEvent.ACTUALISER_APPARENCE));
         }
      }
      
      public function get apparence() : Vector.<Object>
      {
         return this.coutRessource;
      }
      
      public function get constructionRestante() : int
      {
         return this.tempsTotal - this.tempsConstruction;
      }
      
      protected function finir() : void
      {
         dispatchEvent(new CreationPersoEvent(CreationPersoEvent.CREER,this.creation,x,y,equipe,this.bonusCreation,this.anim));
         mourir();
      }
      
      override public function gerer_mort(param1:Object) : void
      {
         super.gerer_mort(param1);
         Tresor.piller_fondations(this);
      }
      
      override public function detruire() : void
      {
         super.detruire();
         this.createur = null;
         this.coutCaracteristique = null;
         this.coutRessource = null;
      }
   }
}

