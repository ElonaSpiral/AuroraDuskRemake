package aurora.jeuModele.perso
{
   import aurora.jeuModele.Donnees;
   import aurora.jeuModele.TirageAlea;
   import aurora.jeuModele.vagues.VaguesCreerPerso;
   import aurora.jeuModele.vagues.VaguesCreerPersoEvent;
   import aurora.jeuModele.ville.Ville;
   import flash.events.TimerEvent;
   import flash.utils.Timer;
   
   public class BatimentDonjon extends BatimentOffensif
   {
      
      private var timerRegeneration:Timer;
      
      private var regeneration:int;
      
      private var pauseRegeneration:Boolean;
      
      private var timerVagues:Timer;
      
      private var pauseVagues:Boolean;
      
      public var nbMonstresParVagues:int;
      
      public var monstresEnAttente:Vector.<VaguesCreerPerso> = new Vector.<VaguesCreerPerso>();
      
      public var compteurMonstres:Ville;
      
      public var races:Vector.<Object>;
      
      public var epoque:int;
      
      public function BatimentDonjon(param1:Ville)
      {
         this.compteurMonstres = param1;
         super();
      }
      
      override public function init(param1:Object) : void
      {
         super.init(param1);
         this.regeneration = param1.regeneration;
         if(this.regeneration > 0)
         {
            this.timerRegeneration = new Timer(1000 * (param1.timeRegeneration ? param1.timeRegeneration : 1));
            this.timerRegeneration.addEventListener(TimerEvent.TIMER,this.regenerer);
         }
         if(param1.spawn)
         {
            this.timerVagues = new Timer(1000,param1.spawn.interval);
            this.timerVagues.addEventListener(TimerEvent.TIMER_COMPLETE,this.envoyer_vague);
            this.timerVagues.start();
         }
      }
      
      public function init_races(param1:int) : void
      {
         var _loc2_:int = 0;
         this.races = new Vector.<Object>();
         if(Donnees.peuples[param1].races)
         {
            _loc2_ = 0;
            while(_loc2_ < Donnees.peuples[param1].races.length)
            {
               this.races.push(Donnees.donnees[Donnees.peuples[param1].races[_loc2_]]);
               _loc2_++;
            }
         }
         else
         {
            _loc2_ = 0;
            while(_loc2_ < Donnees.monstres.length)
            {
               this.races.push(Donnees.monstres[_loc2_]);
               _loc2_++;
            }
         }
      }
      
      public function init_vagues(param1:int) : void
      {
         var _loc2_:Object = Donnees.donnees[race];
         if(_loc2_.spawn)
         {
            this.nbMonstresParVagues = _loc2_.spawn.baseNumber + _loc2_.spawn.coefPopulation * param1;
         }
         else
         {
            this.nbMonstresParVagues = param1;
         }
      }
      
      override protected function actualiser_vie(param1:* = null) : void
      {
         if(vivant && blesse)
         {
            this.timerRegeneration.start();
         }
         super.actualiser_vie(param1);
      }
      
      private function regenerer(param1:TimerEvent) : void
      {
         editer_vie(this.regeneration);
         if(!blesse)
         {
            this.timerRegeneration.stop();
         }
      }
      
      private function envoyer_vague(param1:TimerEvent) : void
      {
         var _loc2_:Vector.<VaguesCreerPerso> = null;
         _loc2_ = new Vector.<VaguesCreerPerso>();
         var _loc3_:TirageAlea = new TirageAlea(this.races,this.epoque);
         var _loc4_:int = 0;
         while(_loc4_ < this.nbMonstresParVagues)
         {
            if(this.compteurMonstres.nbMonstresActifs < this.compteurMonstres.nbMonstresMax)
            {
               _loc2_.push(new VaguesCreerPerso(_loc3_.tirage(),x,y,x,y,equipe,ville));
            }
            else
            {
               this.monstresEnAttente.push(new VaguesCreerPerso(_loc3_.tirage(),x,y,x,y,equipe,ville));
            }
            _loc4_++;
         }
         this.compteurMonstres.nbMonstresActifs += _loc2_.length;
         this.compteurMonstres.nbMonstres += this.nbMonstresParVagues;
         dispatchEvent(new VaguesCreerPersoEvent(VaguesCreerPersoEvent.CREER_PERSO,_loc2_));
         this.timerVagues.reset();
         this.timerVagues.start();
      }
      
      override public function pause() : void
      {
         if(Boolean(this.timerRegeneration) && this.timerRegeneration.running)
         {
            this.timerRegeneration.stop();
            this.pauseRegeneration = true;
         }
         if(Boolean(this.timerVagues) && this.timerVagues.running)
         {
            this.timerVagues.stop();
            this.pauseVagues = true;
         }
         super.pause();
      }
      
      override public function reprendre() : void
      {
         if(this.pauseRegeneration)
         {
            this.timerRegeneration.start();
            this.pauseRegeneration = false;
         }
         if(this.pauseVagues)
         {
            this.timerVagues.start();
            this.pauseVagues = false;
         }
         super.reprendre();
      }
      
      override public function detruire() : void
      {
         super.detruire();
         this.compteurMonstres.nbMonstres -= this.monstresEnAttente.length;
         this.monstresEnAttente.splice(0,this.monstresEnAttente.length);
         this.monstresEnAttente = null;
         if(this.timerRegeneration)
         {
            this.timerRegeneration.removeEventListener(TimerEvent.TIMER,this.regenerer);
            this.timerRegeneration.stop();
            this.timerRegeneration = null;
         }
         if(this.timerVagues)
         {
            this.timerVagues.removeEventListener(TimerEvent.TIMER_COMPLETE,this.envoyer_vague);
            this.timerVagues.stop();
            this.timerVagues = null;
         }
         this.compteurMonstres = null;
         this.races = null;
      }
   }
}

