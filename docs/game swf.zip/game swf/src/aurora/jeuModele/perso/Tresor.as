package aurora.jeuModele.perso
{
   import aurora.jeuModele.Donnees;
   import aurora.jeuModele.IA;
   import aurora.jeuModele.perso.objets.ObjetTemporaire;
   
   public class Tresor extends Perso
   {
      
      public static var coefPillage:Number = 0.1;
      
      public static var coefPillageDestruction:Number = 0.25;
      
      public static var coefPillageBatiment:Number = 0.2;
      
      public static var coefPillage2:Number = 10;
      
      public var quantite:int;
      
      public var renforce:int;
      
      public function Tresor()
      {
         super();
      }
      
      private static function peut_piller(param1:int) : Boolean
      {
         return Math.random() <= coefPillage * param1;
      }
      
      public static function piller_perso(param1:Artisan, param2:Object) : void
      {
         var _loc6_:Object = null;
         var _loc3_:Boolean = param2 is Artisan && param1.distance(param2) < param1.rayon + param2.rayon + 2;
         var _loc4_:Vector.<Object> = new Vector.<Object>();
         var _loc5_:Vector.<Object> = new Vector.<Object>();
         for each(_loc6_ in param1.objets)
         {
            if(!(_loc6_ is ObjetTemporaire))
            {
               if(!_loc6_.donnees.indestructible && (!_loc6_.donnees.death || _loc6_.donnees.death.quantity == null || _loc6_.donnees.death.quantity >= 0))
               {
                  if(_loc6_.quantite >= coefPillage2)
                  {
                     _loc4_.push({
                        "id":_loc6_.id,
                        "quantite":int(_loc6_.quantite * coefPillage),
                        "r":_loc6_.renforcer
                     });
                  }
                  else if(peut_piller(_loc6_.quantite))
                  {
                     _loc4_.push({
                        "id":_loc6_.id,
                        "quantite":1,
                        "r":_loc6_.renforcer
                     });
                  }
               }
            }
         }
         for each(_loc6_ in param1.ressources)
         {
            if(_loc6_.quantite >= coefPillage2)
            {
               _loc5_.push({
                  "id":_loc6_.id,
                  "quantite":int(_loc6_.quantite * coefPillage)
               });
            }
         }
         for each(_loc6_ in _loc4_)
         {
            if(Math.random() < coefPillageDestruction)
            {
               if(_loc3_)
               {
                  param2.ajouter_objet(_loc6_.id,_loc6_.quantite,_loc6_.r);
               }
               else
               {
                  poser_tresor(param1,_loc6_.id,_loc6_.quantite,_loc6_.r);
               }
            }
            param1.perdre_objet(_loc6_.id,-_loc6_.quantite);
         }
         for each(_loc6_ in _loc5_)
         {
            if(Math.random() < coefPillageDestruction)
            {
               if(_loc3_)
               {
                  param2.ressources[_loc6_.id].quantite += _loc6_.quantite;
               }
               else
               {
                  poser_tresor(param1,_loc6_.id,_loc6_.quantite);
               }
            }
            param1.ressources[_loc6_.id].quantite -= _loc6_.quantite;
         }
      }
      
      public static function piller_fondations(param1:Fondations) : void
      {
         var _loc3_:int = 0;
         var _loc4_:int = 0;
         var _loc5_:Number = NaN;
         var _loc6_:String = null;
         var _loc7_:int = 0;
         var _loc2_:Object = Donnees.donnees[param1.creation];
         if(Boolean(_loc2_.build) && Boolean(_loc2_.build.costRessource))
         {
            _loc2_ = _loc2_.build.costRessource;
            _loc5_ = param1.tempsConstruction / param1.tempsTotal;
            for(_loc6_ in _loc2_)
            {
               _loc3_ = _loc2_[_loc6_] * coefPillageBatiment * _loc5_;
               _loc4_ = Math.max(_loc3_ / 20,1);
               _loc3_ /= _loc4_;
               _loc7_ = 0;
               while(_loc7_ < _loc3_)
               {
                  poser_tresor(param1,_loc6_,_loc4_,0,1);
                  _loc7_++;
               }
            }
         }
      }
      
      public static function piller_batiment(param1:Object) : void
      {
         var _loc3_:int = 0;
         var _loc4_:int = 0;
         var _loc5_:String = null;
         var _loc6_:int = 0;
         var _loc2_:Object = Donnees.donnees[param1.race];
         if(Boolean(_loc2_.build) && Boolean(_loc2_.build.costRessource))
         {
            _loc2_ = _loc2_.build.costRessource;
            for(_loc5_ in _loc2_)
            {
               _loc3_ = _loc2_[_loc5_] * coefPillageBatiment;
               _loc4_ = Math.max(_loc3_ / 20,1);
               _loc3_ /= _loc4_;
               _loc6_ = 0;
               while(_loc6_ < _loc3_)
               {
                  poser_tresor(param1,_loc5_,_loc4_,0,1);
                  _loc6_++;
               }
            }
         }
      }
      
      public static function piller_centreVille(param1:BatimentCentreVille) : void
      {
      }
      
      public static function poser_tresor(param1:Object, param2:String, param3:int, param4:int = 0, param5:int = 4) : void
      {
         var _loc6_:int = param1.rayon * param5;
         param1.dispatchEvent(new TresorEvent(TresorEvent.CREER,param2,param1.x + (Math.random() - 0.5) * _loc6_,param1.y + (Math.random() - 0.5) * _loc6_,param3,param4));
      }
      
      override public function init(param1:Object) : void
      {
         race = param1.id;
         largeur = hauteur = 24;
         rayon = largeur * 0.5;
         visible = true;
      }
      
      public function ramasser(param1:Artisan) : Boolean
      {
         if(distance(param1) < param1.rayon + rayon)
         {
            if(Donnees.donnees[race].type == "item")
            {
               param1.ajouter_objet(race,this.quantite,this.renforce);
               IA.recycler_equipement(param1);
            }
            else
            {
               param1.ressources[race].quantite += this.quantite;
            }
            mourir();
            return true;
         }
         return false;
      }
   }
}

