package aurora.jeuModele.perso
{
   import aurora.jeuModele.perso.ressources.RessourceEvent;
   import flash.utils.Dictionary;
   
   public class Atelier extends Batiment
   {
      
      public var _quantite:int;
      
      public var quantiteMax:int;
      
      public var quantiteLimite:Boolean;
      
      public var production:Array;
      
      private var anime:Boolean;
      
      public var etapes:Dictionary;
      
      public function Atelier()
      {
         super();
      }
      
      override public function init(param1:Object) : void
      {
         super.init(param1);
         if(param1.quantity)
         {
            this.quantiteMax = this.quantite = param1.quantity;
            this.quantiteLimite = true;
         }
         this.production = param1.produce;
         this.anime = param1.frames;
         this.etapes = new Dictionary();
      }
      
      public function ajouter_bonus(param1:Number) : void
      {
         this._quantite *= param1;
         this.quantiteMax *= param1;
      }
      
      public function get quantite() : int
      {
         return this._quantite;
      }
      
      public function set quantite(param1:int) : void
      {
         this._quantite = param1;
         if(this._quantite <= 0)
         {
            mourir();
         }
         else
         {
            if(this.anime)
            {
               dispatchEvent(new AnimationEvent(AnimationEvent.ANIMER,""));
            }
            if(this.quantiteLimite)
            {
               dispatchEvent(new RessourceEvent(RessourceEvent.ACTUALISER_QUANTITE,String(id),this.quantite));
            }
         }
      }
      
      public function etapes_restantes(param1:int) : int
      {
         if(!this.etapes[param1])
         {
            return this.production[param1].steps;
         }
         return this.production[param1].steps - this.etapes[param1];
      }
      
      public function etapes_pcent(param1:int) : Number
      {
         if(!this.etapes[param1])
         {
            return 0;
         }
         return this.etapes[param1] / this.production[param1].steps;
      }
      
      public function ajouter_etape(param1:int, param2:int) : Boolean
      {
         if(!this.etapes[param1])
         {
            this.etapes[param1] = param2;
         }
         else
         {
            this.etapes[param1] += param2;
         }
         if(this.etapes[param1] >= this.production[param1].steps)
         {
            return true;
         }
         return false;
      }
      
      public function effacer_etape(param1:int) : void
      {
         this.etapes[param1] = 0;
      }
      
      public function nombre_etapes() : int
      {
         var _loc1_:int = 0;
         var _loc2_:String = null;
         for(_loc2_ in this.etapes)
         {
            _loc1_++;
         }
         return _loc1_;
      }
      
      override public function detruire() : void
      {
         var _loc1_:Object = null;
         super.detruire();
         this.production = null;
         for(_loc1_ in this.etapes)
         {
            delete this.etapes[_loc1_];
         }
         this.etapes = null;
      }
   }
}

