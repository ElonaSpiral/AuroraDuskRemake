package aurora.jeuModele.perso.objets
{
   import flash.events.Event;
   
   public class ObjetEvent extends Event
   {
      
      public static const INFOS_OBJET:String = "infosObjet";
      
      public var action:int;
      
      public var id:int;
      
      public var deltaQuantite:int;
      
      public var donnnes:Object;
      
      public function ObjetEvent(param1:String, param2:int, param3:int, param4:int = 0, param5:Object = null)
      {
         this.action = param2;
         this.id = param3;
         this.deltaQuantite = param4;
         this.donnnes = param5;
         super(param1);
      }
   }
}

