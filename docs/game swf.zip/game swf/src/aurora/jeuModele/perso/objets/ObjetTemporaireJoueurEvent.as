package aurora.jeuModele.perso.objets
{
   public class ObjetTemporaireJoueurEvent extends ObjetTemporaireEvent
   {
      
      public static const ACTUALISER_TEMPS:String = "actualiserTemps";
      
      public var temps:int;
      
      public function ObjetTemporaireJoueurEvent(param1:String, param2:int)
      {
         this.temps = param2;
         super(param1);
      }
   }
}

