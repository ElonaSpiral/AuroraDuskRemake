package aurora.jeuModele.perso.objets
{
   import flash.events.TimerEvent;
   import flash.utils.Timer;
   
   public class ObjetTemporaire extends ObjetEquipe
   {
      
      public var timer:Timer;
      
      public function ObjetTemporaire()
      {
         super();
      }
      
      public function get tempsRestant() : int
      {
         return this.timer.repeatCount - this.timer.currentCount;
      }
      
      public function set tempsRestant(param1:int) : void
      {
         this.timer = new Timer(1000,param1);
         this.timer.addEventListener(TimerEvent.TIMER_COMPLETE,this.dissiper);
         this.timer.start();
      }
      
      public function augmenterTemps(param1:int) : void
      {
         this.timer.repeatCount += param1;
      }
      
      override public function arreter() : void
      {
         super.arreter();
         this.timer.stop();
      }
      
      override public function reprendre() : void
      {
         super.reprendre();
         this.timer.start();
      }
      
      protected function dissiper(param1:TimerEvent) : void
      {
         dispatchEvent(new ObjetTemporaireEvent(ObjetTemporaireEvent.DISSIPER));
      }
      
      override public function detruire() : void
      {
         this.timer.removeEventListener(TimerEvent.TIMER_COMPLETE,this.dissiper);
         this.timer = null;
         super.detruire();
      }
   }
}

