package aurora.jeuModele.perso.objets
{
   import flash.events.EventDispatcher;
   import flash.utils.Dictionary;
   
   public class Objet extends EventDispatcher
   {
      
      public var id:String;
      
      public var donnees:Object;
      
      protected var _quantite:int = 1;
      
      protected var _quantiteMax:int;
      
      public var plein:Boolean;
      
      private var _renforcer:int;
      
      public var multiplicateur:Number;
      
      public function Objet()
      {
         super();
      }
      
      public function init(param1:String, param2:Object) : void
      {
         this.id = param1;
         this.donnees = param2;
      }
      
      public function get quantite() : int
      {
         return this._quantite;
      }
      
      public function set quantite(param1:int) : void
      {
         this._quantite = param1;
         this.actualiser();
      }
      
      public function get quantiteMax() : int
      {
         return this._quantiteMax;
      }
      
      public function set quantiteMax(param1:int) : void
      {
         this._quantiteMax = param1;
         this.actualiser();
      }
      
      public function get renforcer() : int
      {
         return this._renforcer;
      }
      
      public function set renforcer(param1:int) : void
      {
         this._renforcer = param1;
         this.multiplicateur = 1 + this._renforcer * 0.2;
      }
      
      public function actualiser_quantite_max(param1:Dictionary) : void
      {
         var _loc2_:String = null;
         if(this.donnees.maxQuantity == "infinity")
         {
            this._quantiteMax = int.MAX_VALUE;
         }
         else
         {
            this._quantiteMax = 0;
            for(_loc2_ in this.donnees.maxQuantity)
            {
               this._quantiteMax += this.donnees.maxQuantity[_loc2_] * param1[_loc2_].scoreSansBonus;
            }
            this.actualiser();
         }
      }
      
      private function actualiser() : void
      {
         if(this._quantite > this._quantiteMax)
         {
            this._quantite = this._quantiteMax;
         }
         this.plein = this._quantite == this._quantiteMax;
      }
      
      public function detruire() : void
      {
         this.donnees = null;
      }
   }
}

