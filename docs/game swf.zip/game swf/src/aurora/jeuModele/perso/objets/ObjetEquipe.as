package aurora.jeuModele.perso.objets
{
   public class ObjetEquipe extends ObjetAuto
   {
      
      public var categorie:String;
      
      public var equipe:Boolean;
      
      public var gauche:Boolean;
      
      public var changeApparence:Boolean;
      
      public function ObjetEquipe()
      {
         super();
      }
      
      override public function init(param1:String, param2:Object) : void
      {
         super.init(param1,param2);
         this.changeApparence = param2.appearance;
      }
      
      override public function detruire() : void
      {
         super.detruire();
      }
   }
}

