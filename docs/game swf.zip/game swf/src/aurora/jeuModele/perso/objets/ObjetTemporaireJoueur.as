package aurora.jeuModele.perso.objets
{
   import flash.events.TimerEvent;
   import flash.utils.Timer;
   
   public class ObjetTemporaireJoueur extends ObjetTemporaire
   {
      
      public function ObjetTemporaireJoueur()
      {
         super();
      }
      
      override public function set tempsRestant(param1:int) : void
      {
         timer = new Timer(1000,param1);
         timer.addEventListener(TimerEvent.TIMER,this.actualiser);
         timer.addEventListener(TimerEvent.TIMER_COMPLETE,dissiper);
         timer.start();
      }
      
      private function actualiser(param1:TimerEvent) : void
      {
         dispatchEvent(new ObjetTemporaireJoueurEvent(ObjetTemporaireJoueurEvent.ACTUALISER_TEMPS,timer.repeatCount - timer.currentCount));
      }
      
      override public function detruire() : void
      {
         timer.removeEventListener(TimerEvent.TIMER,this.actualiser);
         super.detruire();
      }
   }
}

