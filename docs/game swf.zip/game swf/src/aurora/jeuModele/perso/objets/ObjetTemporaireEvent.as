package aurora.jeuModele.perso.objets
{
   import flash.events.Event;
   
   public class ObjetTemporaireEvent extends Event
   {
      
      public static const DISSIPER:String = "dissiper";
      
      public function ObjetTemporaireEvent(param1:String)
      {
         super(param1);
      }
   }
}

