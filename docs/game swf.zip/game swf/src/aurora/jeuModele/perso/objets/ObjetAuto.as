package aurora.jeuModele.perso.objets
{
   import flash.events.Event;
   import flash.events.TimerEvent;
   import flash.utils.Timer;
   
   public class ObjetAuto extends Objet
   {
      
      private var utilisationAuto:Timer;
      
      public function ObjetAuto()
      {
         super();
      }
      
      override public function init(param1:String, param2:Object) : void
      {
         super.init(param1,param2);
         if(param2.autoUse)
         {
            this.utilisationAuto = new Timer(param2.autoUse.time * 1000);
            this.utilisationAuto.addEventListener(TimerEvent.TIMER,this.utiliser);
            this.utilisationAuto.start();
         }
      }
      
      private function utiliser(param1:TimerEvent) : void
      {
         dispatchEvent(new Event(Event.ACTIVATE));
      }
      
      public function arreter() : void
      {
         if(this.utilisationAuto)
         {
            this.utilisationAuto.stop();
         }
      }
      
      public function reprendre() : void
      {
         if(this.utilisationAuto)
         {
            this.utilisationAuto.start();
         }
      }
      
      override public function detruire() : void
      {
         if(this.utilisationAuto)
         {
            this.utilisationAuto.removeEventListener(TimerEvent.TIMER,this.utiliser);
            this.utilisationAuto.stop();
            this.utilisationAuto = null;
         }
         super.detruire();
      }
   }
}

