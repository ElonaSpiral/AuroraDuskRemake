package aurora.jeuModele.perso
{
   import aurora.jeuModele.Donnees;
   import aurora.jeuModele.IA;
   import aurora.jeuModele.PersosEvent;
   import aurora.jeuModele.perso.attaque.Attaque;
   import aurora.jeuModele.perso.ressources.RessourceJoueur;
   import flash.events.TimerEvent;
   import flash.utils.Dictionary;
   import flash.utils.Timer;
   
   public class BatimentCentreVille extends BatimentCaserne
   {
      
      public var creation:String;
      
      public var ameliorationEnCours:Boolean;
      
      public var coutCaracteristique:Object;
      
      public var bonusCompetenceConstruction:String;
      
      public var coutRessource:Vector.<Object>;
      
      public var tempsConstruction:int;
      
      public var travailDuree:int;
      
      public var tempsTotal:int;
      
      private var vieParConstruction:int;
      
      public const intervalAttaques:int = 1000;
      
      protected var gestionIA:Timer;
      
      public var cibleCombat:Object;
      
      public var attaque:int;
      
      protected var attaqueDY:int;
      
      protected var attaqueDX:int;
      
      public var portee:int;
      
      protected var projectile:String;
      
      protected var special:Object;
      
      protected var degats:Vector.<String>;
      
      private var son:String;
      
      public var ressources:Dictionary;
      
      public function BatimentCentreVille(param1:String, param2:Array)
      {
         var _loc4_:Object = null;
         var _loc3_:int = 0;
         while(_loc3_ < param2.length - 1)
         {
            if(param2[_loc3_] == param1)
            {
               this.creation = param2[_loc3_ + 1];
            }
            _loc3_++;
         }
         super();
         this.gestionIA = new Timer(this.intervalAttaques);
         this.gestionIA.addEventListener(TimerEvent.TIMER,this.gerer_ia);
         this.gestionIA.start();
         this.ressources = new Dictionary();
         for each(_loc4_ in Donnees.ressources)
         {
            this.ressources[_loc4_.id] = new RessourceJoueur(_loc4_.id,int.MAX_VALUE,true);
         }
      }
      
      public function copier_ressources(param1:BatimentCentreVille) : void
      {
         var _loc2_:String = null;
         for(_loc2_ in this.ressources)
         {
            this.ressources[_loc2_].quantite = param1.ressources[_loc2_].quantite;
         }
      }
      
      override public function init(param1:Object) : void
      {
         super.init(param1);
         this.attaque = param1.attack;
         if(param1.attackTime)
         {
            this.gestionIA.delay = param1.attackTime * 1000;
         }
         if(param1.attackDX)
         {
            this.attaqueDX = param1.attackDX;
         }
         if(param1.attackDY)
         {
            this.attaqueDY = param1.attackDY;
         }
         else
         {
            this.attaqueDY = hauteur * 0.5;
         }
         this.portee = param1.range;
         this.projectile = param1.missile;
         this.special = param1.special;
         this.degats = Attaque.convertir_degats(param1.damage);
         this.son = param1.sound;
      }
      
      protected function gerer_ia(param1:TimerEvent = null) : void
      {
         if(this.gestionIA)
         {
            if(this.verifier_cible() && this.cibleCombat.distance(this) <= this.distanceAttaque)
            {
               this.attaquer();
            }
            else
            {
               this.cibleCombat = IA.trouver_ennemi_proche(this,this.portee);
               if(this.cibleCombat)
               {
                  this.attaquer();
               }
            }
         }
         else
         {
            param1.currentTarget.stop();
            param1.currentTarget.removeEventListener(TimerEvent.TIMER,this.gerer_ia);
         }
      }
      
      public function passer_epoque_suivante(param1:Boolean) : void
      {
         var _loc2_:Object = null;
         var _loc3_:String = null;
         if(this.creation)
         {
            if(param1)
            {
               this.ameliorationEnCours = true;
               _loc2_ = Donnees.donnees[this.creation];
               vie.scoreMax = _loc2_.health;
               this.coutCaracteristique = _loc2_.build.costPrimaryCharacteristic;
               this.bonusCompetenceConstruction = _loc2_.build.bonusSkill;
               this.coutRessource = new Vector.<Object>();
               for(_loc3_ in _loc2_.build.costRessource)
               {
                  this.tempsTotal += _loc2_.build.costRessource[_loc3_];
                  this.coutRessource.push({
                     "nom":_loc3_,
                     "quantite":_loc2_.build.costRessource[_loc3_]
                  });
               }
               this.vieParConstruction = (Donnees.donnees[this.creation].health - Donnees.donnees[race].health) / this.tempsTotal;
               this.travailDuree = _loc2_.build.prebuild.time * 1000;
               dispatchEvent(new PersosEvent(PersosEvent.ACTUALISER_VIE));
               dispatchEvent(new PersosEvent(PersosEvent.ACTUALISER_APPARENCE));
            }
            else
            {
               this.finir();
            }
         }
      }
      
      public function get apparence() : Vector.<Object>
      {
         return this.coutRessource;
      }
      
      public function construire(param1:int, param2:int) : void
      {
         this.coutRessource[param2].quantite -= param1;
         if(this.coutRessource[param2].quantite <= 0)
         {
            this.coutRessource.splice(param2,1);
         }
         this.tempsConstruction += param1;
         vie.score += param1 * this.vieParConstruction;
         dispatchEvent(new PersosEvent(PersosEvent.ACTUALISER_VIE));
         if(this.tempsConstruction >= this.tempsTotal)
         {
            this.finir();
         }
         else
         {
            dispatchEvent(new PersosEvent(PersosEvent.ACTUALISER_APPARENCE));
         }
      }
      
      public function get constructionRestante() : int
      {
         return this.tempsTotal - this.tempsConstruction;
      }
      
      override public function get reparable() : Boolean
      {
         return !this.ameliorationEnCours && vie.score < vie.scoreMax && Boolean(repair);
      }
      
      protected function finir() : void
      {
         dispatchEvent(new CreationPersoEvent(CreationPersoEvent.CREER,this.creation,x,y,equipe));
         mourir();
      }
      
      override public function gerer_mort(param1:Object) : void
      {
         super.gerer_mort(param1);
         Tresor.piller_centreVille(this);
      }
      
      protected function attaquer() : void
      {
         dispatchEvent(new ProjectileEvent(ProjectileEvent.CREER,this,this.projectile,x + this.attaqueDX,y + this.attaqueDY,this.attaque,this.portee,0,0,this.special,this.degats,this.attaqueDY));
         if(this.son)
         {
            jouer_son(this.son);
         }
      }
      
      public function toucher3(param1:Object, param2:int, param3:String, param4:int, param5:String = null, param6:Attaque = null, param7:Object = null, param8:Vector.<String> = null, param9:Object = null, param10:Boolean = true) : int
      {
         var _loc12_:int = 0;
         var _loc13_:int = 0;
         var _loc11_:int = Math.ceil((Math.random() * 10 + 5) * param2 / Combattant.calcul_defense(param1.defense)) * param1.total_resistances(param8);
         if(_loc11_ > 0)
         {
            if(Vivant(param1).vie.score <= _loc11_)
            {
               param1.gerer_mort(this);
            }
            Vivant(param1).editer_vie(-_loc11_);
            dispatchEvent(new EffetEvent(EffetEvent.EFFET,param1.x,param1.y - param1.hauteur * 0.5,param3,0,param1 is Joueur ? int(-_loc11_) : 0));
            if(param5)
            {
               _loc12_ = x + param6.attaqueDX;
               _loc13_ = y + param6.attaqueDY;
               dispatchEvent(new EffetEvent(EffetEvent.EFFET,(_loc12_ + param1.x) * 0.5,(_loc13_ + param1.y) * 0.5,param5,Math.atan2(param1.y - _loc13_,param1.x - _loc12_),0,Math.sqrt(Math.pow(_loc12_ - param1.x,2) + Math.pow(param1.y - param1.y,2)) / Donnees.donnees[param5].width * 0.5));
            }
            if(Boolean(param10) && Boolean(param9) && Boolean(param9.area))
            {
               this.toucher_zone(param1,param9.area.attack,param9.area.range,param9.area.effect,param4,param5,param6,param7,param8,param9);
            }
            if(param1.vivant)
            {
               if(param1 is Combattant)
               {
                  Combattant(param1).riposter(this);
               }
               if(param1 is Mobile)
               {
                  param1.appliquer_inertie(this,_loc11_);
                  if(param7)
                  {
                     param1.penalites.ajouter_penalite(param7.id,param7.time);
                  }
               }
            }
            else
            {
               if(param1 is Artisan)
               {
                  Tresor.piller_perso(Artisan(param1),this);
               }
               param1.gerer_mort(this);
            }
         }
         return _loc11_;
      }
      
      private function toucher_zone(param1:Object, param2:int, param3:int, param4:String, param5:int, param6:String = null, param7:Attaque = null, param8:Object = null, param9:Vector.<String> = null, param10:Object = null) : void
      {
         var _loc11_:int = 0;
         var _loc13_:Object = null;
         var _loc12_:Vector.<Object> = IA.trouver_ennemis_zone(param1.x,param1.y,equipe,param3);
         for each(_loc13_ in _loc12_)
         {
            if(_loc13_ != param1)
            {
               this.toucher3(_loc13_,param2,param4,param5,param6,param7,param8,param9,param10,false);
            }
         }
      }
      
      private function get distanceAttaque() : int
      {
         return this.portee + rayon + this.cibleCombat.rayon;
      }
      
      protected function verifier_cible() : Boolean
      {
         if(this.cibleCombat)
         {
            if(Boolean(this.cibleCombat.visible) && Boolean(this.cibleCombat.vivant))
            {
               return true;
            }
            this.cibleCombat = null;
            return false;
         }
         return false;
      }
      
      override public function pause() : void
      {
         if(this.gestionIA)
         {
            this.gestionIA.stop();
         }
         super.pause();
      }
      
      override public function reprendre() : void
      {
         if(this.gestionIA)
         {
            this.gestionIA.start();
         }
         super.reprendre();
      }
      
      override public function detruire() : void
      {
         this.coutRessource = null;
         super.detruire();
         this.cibleCombat = null;
         this.gestionIA.removeEventListener(TimerEvent.TIMER,this.gerer_ia);
         this.gestionIA.stop();
         this.gestionIA = null;
         this.special = null;
      }
   }
}

