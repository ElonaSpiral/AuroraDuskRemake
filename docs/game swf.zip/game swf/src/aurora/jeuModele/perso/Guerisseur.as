package aurora.jeuModele.perso
{
   import aurora.jeuModele.Donnees;
   import aurora.jeuModele.IA;
   import aurora.jeuModele.perso.attaque.Attaque;
   import aurora.jeuModele.perso.caracteristiquesPrimaires.CaracteristiquePrimaireArtisan;
   import flash.events.TimerEvent;
   
   public class Guerisseur extends Soldat
   {
      
      public var scoreGuerison:int;
      
      public var guerisonLimite:Boolean;
      
      public function Guerisseur()
      {
         super();
      }
      
      override public function init(param1:Object) : void
      {
         super.init(param1);
         if(!param1.unlimitedHealing)
         {
            this.guerisonLimite = true;
         }
         if(param1.healingScore)
         {
            this.scoreGuerison = param1.healingScore;
         }
         else
         {
            this.scoreGuerison = 1;
         }
      }
      
      override protected function gerer_ia(param1:TimerEvent = null) : void
      {
         if(iaTimer)
         {
            IA.gerer_guerisseur(this);
         }
         else
         {
            param1.currentTarget.stop();
            param1.currentTarget.removeEventListener(TimerEvent.TIMER,this.gerer_ia);
         }
      }
      
      override protected function verifier_cible_combat() : Boolean
      {
         if(cibleCombat)
         {
            if(cibleCombat.visible && cibleCombat.vivant && (cibleCombat.equipe != equipe || cibleCombat.vie.resteRecuperer > 0))
            {
               return true;
            }
            cibleCombat = null;
            return false;
         }
         return false;
      }
      
      override protected function get distanceAttaque() : int
      {
         if(cibleCombat.equipe == equipe)
         {
            return rayon + cibleCombat.rayon;
         }
         return rayon + cibleCombat.rayon + portee;
      }
      
      override protected function distanceAttaque2(param1:int) : Boolean
      {
         if(cibleCombat.equipe == equipe)
         {
            return cible_proche2(rayon + cibleCombat.rayon);
         }
         return (cibleCombat is Batiment || cibleCombat is Fondations) && cible_proche(cibleCombat,rayon + param1) || !(cibleCombat is Batiment || cibleCombat is Fondations) && cible_proche2(rayon + cibleCombat.rayon + param1);
      }
      
      override protected function distanceAttaqueOk() : Boolean
      {
         if(cibleCombat.equipe == equipe)
         {
            return cible_proche2(rayon + cibleCombat.rayon);
         }
         return (cibleCombat is Batiment || cibleCombat is Fondations) && cible_proche(cibleCombat,rayon + portee) || !(cibleCombat is Batiment || cibleCombat is Fondations) && cible_proche2(this.distanceAttaque);
      }
      
      override protected function toucher2Prime(param1:Attaque) : void
      {
         if(Boolean(param1.projectile) && cibleCombat.equipe != equipe)
         {
            if(param1.attaquesMultiples)
            {
               lancer_attaques_multiples(param1);
            }
            else
            {
               dispatchEvent(new ProjectileEvent(ProjectileEvent.CREER,this,param1.projectile,Math.round(x + param1.attaqueDX),Math.round(y + param1.attaqueDY) + decalageY,param1.score,param1.portee,param1.no,param1.delai,Boolean(param1.coutAttaque) && Boolean(param1.coutAttaque.special) ? param1.coutAttaque.special : null,param1.degats,attaque.attaqueDY + (param1.attaqueDY ? param1.attaqueDY : 0)));
            }
         }
         else
         {
            this.toucher3(cibleCombat,param1.score,param1.effet,param1.no,param1.effetLigne,param1,Boolean(param1.coutAttaque) && Boolean(param1.coutAttaque.special) ? param1.coutAttaque.special.penality : null,param1.degats,param1.coutAttaque ? param1.coutAttaque.special : null);
         }
      }
      
      public function ajouter_bonus(param1:Number) : void
      {
         this.scoreGuerison *= param1;
      }
      
      override public function set puissance(param1:Number) : void
      {
         super.puissance = param1;
         this.scoreGuerison *= param1;
      }
      
      override public function toucher3(param1:Object, param2:int, param3:String, param4:int, param5:String = null, param6:Attaque = null, param7:Object = null, param8:Vector.<String> = null, param9:Object = null, param10:Boolean = true) : int
      {
         var _loc11_:int = 0;
         if(param1.equipe != equipe)
         {
            return super.toucher3(param1,param2,param3,param4,param5,param6,param7,param8,param9,param10);
         }
         _loc11_ = Math.min(this.scoreGuerison,param1.vie.resteRecuperer);
         dispatchEvent(new EffetEvent(EffetEvent.EFFET,param1.x + Math.random() * param1.largeur * 0.5 - param1.largeur * 0.25,param1.y - param1.hauteur * 0.75 + Math.random() * param1.hauteur * 0.5,Donnees.donnees[race].healingEffect));
         if(param1.vie is CaracteristiquePrimaireArtisan)
         {
            param1.vie.recuperer(_loc11_ * param1.vie.bonusEquipement);
         }
         else
         {
            param1.vie.recuperer(_loc11_);
         }
         if(this.guerisonLimite)
         {
            this.scoreGuerison -= _loc11_;
            if(this.scoreGuerison < 0)
            {
               mourir();
            }
         }
         return _loc11_;
      }
   }
}

