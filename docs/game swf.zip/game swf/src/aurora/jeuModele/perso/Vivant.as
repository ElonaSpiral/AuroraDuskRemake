package aurora.jeuModele.perso
{
   import aurora.jeuModele.Donnees;
   import aurora.jeuModele.PersosEvent;
   import aurora.jeuModele.perso.caracteristiquesPrimaires.CaracteristiquePrimaire;
   import flash.utils.Dictionary;
   
   public class Vivant extends Perso
   {
      
      public var vie:*;
      
      public var defense:int;
      
      public var equipe:int;
      
      public var ville:int;
      
      public var resistances:Dictionary;
      
      public var caseTerrainX:int = -1;
      
      public var caseTerrainY:int = -1;
      
      public function Vivant()
      {
         super();
         this.resistances = new Dictionary();
      }
      
      override public function init(param1:Object) : void
      {
         var _loc2_:String = null;
         super.init(param1);
         this.vie = new CaracteristiquePrimaire("health",param1.health);
         this.defense = param1.defense;
         if(param1.resistance)
         {
            for(_loc2_ in param1.resistance)
            {
               this.resistances[_loc2_] = param1.resistance[_loc2_];
            }
         }
      }
      
      public function set puissance(param1:Number) : void
      {
         this.vie.scoreMax *= param1;
         this.vie.score *= param1;
         this.defense *= param1;
      }
      
      public function total_resistances(param1:Vector.<String>) : Number
      {
         var _loc3_:String = null;
         var _loc2_:Number = 1;
         for each(_loc3_ in param1)
         {
            if(this.resistances[_loc3_])
            {
               _loc2_ *= this.resistances[_loc3_];
            }
         }
         return _loc2_;
      }
      
      public function editer_vie(param1:int) : void
      {
         this.vie.score += param1;
         this.actualiser_vie();
      }
      
      public function charger_vie(param1:int) : void
      {
         this.vie.score = param1;
         this.actualiser_vie();
      }
      
      protected function actualiser_vie(param1:* = null) : void
      {
         if(this.vie.score <= 0)
         {
            mourir();
         }
         dispatchEvent(new PersosEvent(PersosEvent.ACTUALISER_VIE));
      }
      
      public function get blesse() : Boolean
      {
         return this.vie.score < this.vie.scoreMax;
      }
      
      public function get vivant() : Boolean
      {
         return Boolean(this.vie) && this.vie.score > 0;
      }
      
      public function gerer_mort(param1:Object) : void
      {
         var _loc2_:Number = NaN;
         var _loc3_:String = null;
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         var _loc6_:int = 0;
         if(Donnees.donnees[race].death)
         {
            if(Donnees.donnees[race].death.build)
            {
               if(this is Animal)
               {
                  _loc2_ = Animal(this).bonusCreation;
               }
               else
               {
                  _loc2_ = 1;
               }
               dispatchEvent(new CreationPersoEvent(CreationPersoEvent.CREER,Donnees.donnees[race].death.build.name,x,y,this is Animal ? (param1 ? int(param1.equipe) : -1) : this.equipe,Donnees.donnees[race].death.build.quantity * _loc2_));
            }
            if(Donnees.donnees[race].death.createResource)
            {
               for(_loc3_ in Donnees.donnees[race].death.createResource)
               {
                  _loc4_ = int(Donnees.donnees[race].death.createResource[_loc3_]);
                  _loc5_ = Math.max(_loc4_ / 20,1);
                  _loc4_ /= _loc5_;
                  _loc6_ = 0;
                  while(_loc6_ < _loc4_)
                  {
                     Tresor.poser_tresor(this,_loc3_,_loc5_,0,1);
                     _loc6_++;
                  }
               }
            }
            if(Donnees.donnees[race].death.effect)
            {
               dispatchEvent(new EffetEvent(EffetEvent.EFFET,x,y - hauteur * 0.5,Donnees.donnees[race].death.effect.name,0,0,Donnees.donnees[race].death.effect.scale ? Number(Donnees.donnees[race].death.effect.scale) : 1,Donnees.donnees[race].death.effect.scale ? Number(Donnees.donnees[race].death.effect.scale) : 1));
            }
         }
      }
      
      public function toucher5(param1:int) : void
      {
      }
      
      protected function jouer_son(param1:String) : void
      {
         var _loc2_:Object = null;
         _loc2_ = Donnees.donnees[param1];
         if(_loc2_)
         {
            dispatchEvent(new SonEvent(SonEvent.SON,_loc2_.chemin + _loc2_.files[int(Math.random() * _loc2_.files.length)],x,y));
         }
      }
      
      override public function detruire() : void
      {
         var _loc1_:String = null;
         if(this.vie)
         {
            this.vie.detruire();
            this.vie = null;
         }
         for(_loc1_ in this.resistances)
         {
            this.resistances[_loc1_] = null;
            delete this.resistances[_loc1_];
         }
         this.resistances = null;
         super.detruire();
      }
   }
}

