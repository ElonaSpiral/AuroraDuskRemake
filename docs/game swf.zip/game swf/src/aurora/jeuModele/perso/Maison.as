package aurora.jeuModele.perso
{
   public class Maison extends BatimentCaserne
   {
      
      public var proprietaire:int;
      
      public var donnee:Object;
      
      public function Maison()
      {
         super();
      }
      
      override public function init(param1:Object) : void
      {
         super.init(param1);
         this.donnee = param1;
      }
      
      override public function detruire() : void
      {
         super.detruire();
         this.donnee = null;
      }
   }
}

