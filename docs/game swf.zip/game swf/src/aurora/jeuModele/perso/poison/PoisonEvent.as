package aurora.jeuModele.perso.poison
{
   import flash.events.Event;
   
   public class PoisonEvent extends Event
   {
      
      public static const DEGATS:String = "degats";
      
      public var degats:int;
      
      public var tueur:Object;
      
      public function PoisonEvent(param1:String, param2:int = 0, param3:Object = null)
      {
         this.degats = param2;
         this.tueur = param3;
         super(param1);
      }
      
      override public function clone() : Event
      {
         return new PoisonEvent(type,this.degats,this.tueur);
      }
   }
}

