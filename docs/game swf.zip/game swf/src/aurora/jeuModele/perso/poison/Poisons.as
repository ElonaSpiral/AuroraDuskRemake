package aurora.jeuModele.perso.poison
{
   import flash.events.EventDispatcher;
   import flash.events.TimerEvent;
   
   public class Poisons extends EventDispatcher
   {
      
      public var poisons:Vector.<Poison>;
      
      public function Poisons()
      {
         super();
         this.poisons = new Vector.<Poison>();
      }
      
      public function ajouter(param1:int, param2:int, param3:Object) : void
      {
         var _loc4_:Poison = new Poison(Math.ceil(param1 / param2),param2,param3);
         _loc4_.addEventListener(TimerEvent.TIMER,this.gerer_poison);
         _loc4_.addEventListener(TimerEvent.TIMER_COMPLETE,this.terminer_poison);
         _loc4_.start();
         this.poisons.push(_loc4_);
      }
      
      private function gerer_poison(param1:TimerEvent) : void
      {
         dispatchEvent(new PoisonEvent(PoisonEvent.DEGATS,Poison(param1.currentTarget).degats,Poison(param1.currentTarget).tueur));
      }
      
      private function terminer_poison(param1:TimerEvent) : void
      {
         param1.currentTarget.removeEventListener(TimerEvent.TIMER,this.gerer_poison);
         param1.currentTarget.removeEventListener(TimerEvent.TIMER_COMPLETE,this.terminer_poison);
         var _loc2_:int = 0;
         while(_loc2_ < this.poisons.length)
         {
            if(this.poisons[_loc2_] == param1.currentTarget)
            {
               this.poisons[_loc2_].detruire();
               this.poisons[_loc2_] = null;
               this.poisons.splice(_loc2_,1);
               break;
            }
            _loc2_++;
         }
      }
      
      public function vider() : void
      {
         while(this.poisons.length > 0)
         {
            this.poisons[0].removeEventListener(TimerEvent.TIMER,this.gerer_poison);
            this.poisons[0].removeEventListener(TimerEvent.TIMER_COMPLETE,this.terminer_poison);
            this.poisons[0].stop();
            this.poisons[0].detruire();
            this.poisons[0] = null;
            this.poisons.splice(0,1);
         }
      }
      
      public function detruire() : void
      {
         this.vider();
         this.poisons = null;
      }
   }
}

