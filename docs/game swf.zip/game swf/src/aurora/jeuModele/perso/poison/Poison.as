package aurora.jeuModele.perso.poison
{
   import flash.utils.Timer;
   
   public class Poison extends Timer
   {
      
      public var degats:int;
      
      public var tueur:Object;
      
      public function Poison(param1:int, param2:int = 0, param3:Object = null)
      {
         this.degats = param1;
         this.tueur = param3;
         super(1000,param2);
      }
      
      public function detruire() : void
      {
         this.tueur = null;
      }
   }
}

