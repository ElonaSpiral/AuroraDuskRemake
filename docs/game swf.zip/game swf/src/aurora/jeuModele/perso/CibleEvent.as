package aurora.jeuModele.perso
{
   import flash.events.Event;
   
   public class CibleEvent extends Event
   {
      
      public static const ACTUALISER_CIBLE:String = "actualiserCible";
      
      public static const ACTUALISER_QUANTITE:String = "actualiserQuantite";
      
      public var typeCible:int;
      
      public var cibleX:int;
      
      public var cibleY:int;
      
      public function CibleEvent(param1:String, param2:int, param3:Number = 0, param4:Number = 0)
      {
         this.typeCible = param2;
         this.cibleX = param3;
         this.cibleY = param4;
         super(param1);
      }
   }
}

