package aurora.jeuModele.perso
{
   import aurora.MainJeu;
   import aurora.jeuModele.Donnees;
   import aurora.jeuModele.IA;
   import aurora.jeuModele.PersosEvent;
   import aurora.jeuModele.Terrain;
   import aurora.jeuModele.perso.objets.ObjetEquipe;
   import aurora.jeuModele.perso.objets.ObjetTemporaire;
   import aurora.jeuModele.perso.poison.PoisonEvent;
   import aurora.jeuModele.perso.ressources.Ressource;
   import flash.events.TimerEvent;
   import flash.utils.Dictionary;
   import flash.utils.Timer;
   
   public class Artisan extends Aventurier
   {
      
      public var ressources:Dictionary;
      
      public var cibleTravail:Perso;
      
      public var cibleTravailRace:String;
      
      protected var deplacementTravailTimer:Timer;
      
      protected var travailTimer:Timer;
      
      private var pauseDeplacementTravail:Boolean;
      
      private var pauseTravail:Boolean;
      
      private var _dansUnBatiment:Boolean;
      
      protected var choixProduction:int;
      
      protected var choixAmeliorationObjet:Object;
      
      protected var choixRenforcerObjet:Object;
      
      protected var renforcer:int;
      
      public var iaBesoinRessources:String;
      
      public var iaBesoinRessourcesQuantite:int;
      
      public var iaConstruireBatiment:String = "";
      
      public var iaConstruireSoldat:String = "";
      
      public var iaConstruireObjet:String = "";
      
      public var iaPersonnalisee:Boolean;
      
      public var iaOrdresEpoques:Vector.<Vector.<Object>>;
      
      public var iaAvidite:Number = 0.02;
      
      public var iaAgressivite:Number = 0.5;
      
      public var iaCourage:Number = 0.7;
      
      public var iaAssistanceMorts:Number = 0.95;
      
      public var iaAssistanceDefenses:Number = 0.15;
      
      public var joueur:Boolean;
      
      public var fantome:Boolean;
      
      protected var _possedeMaison:Boolean;
      
      protected var _dansMaison:Boolean;
      
      private var _maison:Perso;
      
      public var maisonEpoque:int;
      
      public var batimentEntrer:Batiment;
      
      private var donneEquipement:Boolean;
      
      private var donneObjetNo:int;
      
      private var donneRessourceId:String;
      
      private var donneQuantite:int;
      
      private var vente:Boolean;
      
      public function Artisan()
      {
         super();
         this.deplacementTravailTimer = new Timer(INTERVAL_DEPLACEMENT);
         this.deplacementTravailTimer.addEventListener(TimerEvent.TIMER,this.deplacer_travail);
         this.travailTimer = new Timer(1000);
      }
      
      public static function cout_renforcement(param1:uint) : uint
      {
         var _loc2_:int = 0;
         var _loc3_:int = 1;
         while(_loc3_ <= param1)
         {
            _loc2_ += _loc3_;
            _loc3_++;
         }
         return _loc2_;
      }
      
      override public function init(param1:Object) : void
      {
         var _loc2_:Object = null;
         var _loc3_:int = 0;
         var _loc4_:Boolean = false;
         var _loc5_:String = null;
         super.init(param1);
         if(param1.scaleX)
         {
            largeur *= param1.scaleX;
         }
         if(param1.scaleY)
         {
            hauteur *= param1.scaleY;
         }
         if(param1.scale)
         {
            largeur *= param1.scale;
            hauteur *= param1.scale;
         }
         this.ressources = new Dictionary();
         for each(_loc2_ in Donnees.ressources)
         {
            if(_loc2_.maxQuantity == "infinity")
            {
               _loc4_ = true;
               _loc3_ = int.MAX_VALUE;
            }
            else
            {
               _loc3_ = 0;
               _loc4_ = false;
               for(_loc5_ in _loc2_.maxQuantity)
               {
                  _loc3_ += _loc2_.maxQuantity[_loc5_] * competences[_loc5_].scoreSansBonus;
               }
            }
            this.ressources[_loc2_.id] = new Ressource(_loc2_.id,_loc3_,_loc4_);
         }
      }
      
      override public function set puissance(param1:Number) : void
      {
         var _loc2_:Object = null;
         super.puissance = param1;
         for each(_loc2_ in Donnees.ressources)
         {
            if(this.ressources[_loc2_.id].quantiteMax != int.MAX_VALUE)
            {
               this.ressources[_loc2_.id].quantiteMax *= param1;
            }
         }
      }
      
      override public function actualiser_bonus(param1:Object = null) : void
      {
         var _loc2_:Object = null;
         var _loc3_:int = 0;
         var _loc4_:Object = null;
         var _loc5_:int = 0;
         var _loc6_:String = null;
         if(Boolean(this._maison) && this._maison is Maison)
         {
            _loc2_ = Maison(this._maison).donnee;
         }
         super.actualiser_bonus(_loc2_);
         for each(_loc4_ in objets)
         {
            if(_loc4_ is ObjetEquipe && Boolean(_loc4_.equipe))
            {
               if(_loc4_.donnees.resourcesMaxQuantity)
               {
                  _loc3_ += _loc4_.donnees.resourcesMaxQuantity;
               }
            }
         }
         for each(_loc4_ in Donnees.ressources)
         {
            if(!this.ressources[_loc4_.id].illimite)
            {
               _loc5_ = _loc3_;
               for(_loc6_ in _loc4_.maxQuantity)
               {
                  _loc5_ += _loc4_.maxQuantity[_loc6_] * competences[_loc6_].scoreBase;
               }
               this.ressources[_loc4_.id].quantiteMax = _loc5_;
            }
         }
      }
      
      override protected function gerer_ia(param1:TimerEvent = null) : void
      {
         if(iaTimer)
         {
            IA.gerer_artisan(this);
         }
         else
         {
            param1.currentTarget.stop();
            param1.currentTarget.removeEventListener(TimerEvent.TIMER,this.gerer_ia);
         }
      }
      
      public function personnaliser_ia(param1:Object) : void
      {
         var _loc2_:int = 0;
         var _loc3_:String = null;
         var _loc4_:Object = null;
         if(param1)
         {
            this.iaPersonnalisee = true;
            this.iaOrdresEpoques = new Vector.<Vector.<Object>>();
            _loc2_ = 0;
            while(_loc2_ < Donnees.epoques.length)
            {
               this.iaOrdresEpoques.push(new Vector.<Object>());
               _loc2_++;
            }
            for each(_loc4_ in param1.orders)
            {
               _loc2_ = 0;
               while(_loc2_ < Donnees.epoques.length)
               {
                  if(_loc4_.item)
                  {
                     _loc3_ = _loc4_.item;
                  }
                  if(_loc4_.ressource)
                  {
                     _loc3_ = _loc4_.ressource;
                  }
                  if(_loc4_.landRessource)
                  {
                     _loc3_ = _loc4_.landRessource;
                  }
                  if(_loc4_.animal)
                  {
                     _loc3_ = _loc4_.animal;
                  }
                  if(_loc4_.defenseTower)
                  {
                     _loc3_ = _loc4_.defenseTower;
                  }
                  if(_loc4_.resurrectTower)
                  {
                     _loc3_ = _loc4_.resurrectTower;
                  }
                  if(_loc4_.buildingMonster)
                  {
                     _loc3_ = _loc4_.buildingMonster;
                  }
                  if(_loc4_.barrack)
                  {
                     _loc3_ = _loc4_.barrack;
                  }
                  if(_loc4_.workshop)
                  {
                     _loc3_ = _loc4_.workshop;
                  }
                  if(_loc4_.house)
                  {
                     _loc3_ = _loc4_.house;
                  }
                  if(_loc4_.monster)
                  {
                     _loc3_ = _loc4_.monster;
                  }
                  if(Donnees.donnees[_loc3_])
                  {
                     if(Math.max(Boolean(_loc4_.startingAge) && Boolean(Donnees.donnees[_loc4_.startingAge]) ? Number(Donnees.donnees[_loc4_.startingAge].no) : 0,Donnees.donnees[_loc3_].age ? Number(Donnees.donnees[_loc3_].age) : 0) <= _loc2_ && (Boolean(_loc4_.endingAge) && Boolean(Donnees.donnees[_loc4_.endingAge]) ? Donnees.donnees[_loc4_.endingAge].no - 1 : Donnees.epoques.length - 1) >= _loc2_)
                     {
                        this.iaOrdresEpoques[_loc2_].push(new Object());
                        this.iaOrdresEpoques[_loc2_][this.iaOrdresEpoques[_loc2_].length - 1][Donnees.donnees[_loc3_].type] = _loc3_;
                        if(_loc4_.quantity)
                        {
                           this.iaOrdresEpoques[_loc2_][this.iaOrdresEpoques[_loc2_].length - 1].quantite = _loc4_.quantity;
                        }
                        else
                        {
                           this.iaOrdresEpoques[_loc2_][this.iaOrdresEpoques[_loc2_].length - 1].quantite = 1;
                        }
                     }
                  }
                  _loc2_++;
               }
            }
            IA.recycler_equipement(this);
         }
         else
         {
            this.iaPersonnalisee = false;
         }
      }
      
      override public function init_ia(param1:Boolean) : void
      {
         super.init_ia(param1);
         IA.recycler_equipement(this);
      }
      
      override public function aller(param1:Number, param2:Number) : void
      {
         this.sortir();
         this.deplacementTravailTimer.stop();
         this.travailTimer.stop();
         this.arreter_travail();
         super.aller(param1,param2);
      }
      
      protected function entrer() : void
      {
         visible = false;
         if(this.batimentEntrer == this._maison)
         {
            this.dansMaison = true;
         }
         dispatchEvent(new PersosEvent(PersosEvent.VISIBLE));
      }
      
      public function sortir() : void
      {
         this.batimentEntrer = null;
         if(!visible && vivant)
         {
            this.dansMaison = false;
            visible = true;
            dispatchEvent(new PersosEvent(PersosEvent.VISIBLE));
         }
      }
      
      override public function get enAttente() : Boolean
      {
         return super.enAttente && !this.deplacementTravailTimer.running && !this.travailTimer.running;
      }
      
      public function get possedeMaison() : Boolean
      {
         return this._possedeMaison;
      }
      
      public function set possedeMaison(param1:Boolean) : void
      {
         this._possedeMaison = param1;
      }
      
      public function get dansMaison() : Boolean
      {
         return this._dansMaison;
      }
      
      public function set dansMaison(param1:Boolean) : void
      {
         var _loc2_:Object = null;
         this._dansMaison = param1;
         for each(_loc2_ in caracteristiquesPrimaires)
         {
            _loc2_.multiplicateurRegeneration = this._dansMaison ? 5 : 1;
         }
      }
      
      public function get maison() : Perso
      {
         return this._maison;
      }
      
      public function set maison(param1:Perso) : void
      {
         this._maison = param1;
         this.actualiser_bonus();
      }
      
      override public function set roi(param1:Boolean) : void
      {
         super.roi = param1;
         if(!param1)
         {
            this.demolir_maison();
         }
      }
      
      override public function arreter() : void
      {
         this.deplacementTravailTimer.stop();
         this.travailTimer.stop();
         this.arreter_travail();
         super.arreter();
      }
      
      public function peut_payer_creation(param1:String) : Boolean
      {
         var _loc2_:String = Donnees.donnees[param1].type;
         var _loc3_:Boolean = _loc2_ == "workshop" || _loc2_ == "defenseTower" || _loc2_ == "resurrectTower" || _loc2_ == "buildingMonster" || _loc2_ == "house" || _loc2_ == "barrack" || _loc2_ == "wall" || _loc2_ == "townCenter";
         return this.peut_payer(Donnees.donnees[param1].build,_loc3_,false);
      }
      
      public function peut_payer(param1:Object, param2:Boolean = false, param3:Boolean = true) : Boolean
      {
         var _loc4_:Object = null;
         var _loc5_:Object = null;
         var _loc6_:String = null;
         _loc4_ = param1.costPrimaryCharacteristic;
         if(_loc4_)
         {
            for(_loc6_ in _loc4_)
            {
               if(caracteristiquesPrimaires[_loc6_].score < _loc4_[_loc6_])
               {
                  if(this.joueur)
                  {
                     if(caracteristiquesPrimaires[_loc6_].score < 1)
                     {
                        parler_depuis_donnee(Donnees.donnees[_loc6_]["zero"]);
                     }
                     else
                     {
                        parler_depuis_donnee(Donnees.donnees[_loc6_]["lack"]);
                     }
                  }
                  return false;
               }
            }
         }
         _loc5_ = param1.costRessource;
         if(_loc5_)
         {
            if(param2)
            {
               for(_loc6_ in _loc5_)
               {
                  if(this.ressources[_loc6_].quantite < 1)
                  {
                     if(this.joueur)
                     {
                        parler_depuis_donnee(Donnees.donnees[_loc6_]["zero"]);
                     }
                     return false;
                  }
                  if(param3)
                  {
                     return true;
                  }
               }
            }
            else
            {
               for(_loc6_ in _loc5_)
               {
                  if(this.ressources[_loc6_].quantite < _loc5_[_loc6_])
                  {
                     if(this.joueur)
                     {
                        if(this.ressources[_loc6_].quantite < 1)
                        {
                           parler_depuis_donnee(Donnees.donnees[_loc6_]["zero"]);
                        }
                        else
                        {
                           parler_depuis_donnee(Donnees.donnees[_loc6_]["lack"]);
                        }
                     }
                     return false;
                  }
               }
            }
         }
         return true;
      }
      
      public function creer_perso(param1:String) : void
      {
         if(this.peut_payer_creation(param1))
         {
            dispatchEvent(new CreationPersoEvent(CreationPersoEvent.CREER,param1,x,y,equipe));
         }
      }
      
      public function creer_persoXY(param1:String, param2:int, param3:int) : void
      {
         if(this.peut_payer_creation(param1))
         {
            dispatchEvent(new CreationPersoEvent(CreationPersoEvent.CREER,param1,param2,param3,equipe,1,"",false));
         }
      }
      
      public function payer_cout_creation_perso(param1:String) : void
      {
         var _loc3_:Object = null;
         var _loc4_:Object = null;
         var _loc5_:String = null;
         var _loc2_:Object = Donnees.donnees[param1].build;
         _loc3_ = _loc2_.costPrimaryCharacteristic;
         _loc4_ = _loc2_.costRessource;
         var _loc6_:String = Donnees.donnees[Donnees.donnees[param1].id].type;
         var _loc7_:Boolean = _loc6_ == "workshop" || _loc6_ == "defenseTower" || _loc6_ == "resurrectTower" || _loc6_ == "buildingMonster" || _loc6_ == "house" || _loc6_ == "barrack" || _loc6_ == "wall" || _loc6_ == "townCenter";
         if(_loc3_)
         {
            for(_loc5_ in _loc3_)
            {
               caracteristiquesPrimaires[_loc5_].score -= _loc3_[_loc5_];
            }
         }
         if(_loc4_)
         {
            if(_loc7_)
            {
               var _loc8_:int = 0;
               var _loc9_:* = _loc4_;
               for(_loc5_ in _loc9_)
               {
                  --this.ressources[_loc5_].quantite;
               }
            }
            else
            {
               for(_loc5_ in _loc4_)
               {
                  this.ressources[_loc5_].quantite -= _loc4_[_loc5_];
               }
            }
         }
      }
      
      public function aller_batiment(param1:Batiment) : void
      {
         this.arreter();
         this.aller(param1.x,param1.y);
         this.batimentEntrer = param1;
      }
      
      public function rentrer_maison() : void
      {
         if(this._maison)
         {
            if(this._maison is Fondations)
            {
               this.aller_travailler(this._maison);
            }
            else if(Maison(this._maison).reparable)
            {
               this.aller_reparer(this._maison);
            }
            else
            {
               this.aller_batiment(Maison(this._maison));
            }
         }
      }
      
      public function demolir_maison() : void
      {
         if(this._maison)
         {
            Tresor.piller_batiment(this._maison);
            this._maison.mourir();
         }
      }
      
      public function detruire_batiment() : Boolean
      {
         if(this.cibleTravail)
         {
            if(this.cibleTravail is Animal || this.cibleTravail is RessourceMobile || this.cibleTravail is RessourceTerrain)
            {
               return false;
            }
            Tresor.piller_batiment(this.cibleTravail);
            this.cibleTravail.mourir();
            return true;
         }
         if(this.batimentEntrer)
         {
            Tresor.piller_batiment(this.batimentEntrer);
            this.batimentEntrer.mourir();
            return true;
         }
         return false;
      }
      
      override protected function deplacer(param1:TimerEvent) : void
      {
         super.deplacer(param1);
         if(Boolean(this.enAttente) && Boolean(this.batimentEntrer) && this.batimentEntrer.visible)
         {
            this.entrer();
         }
      }
      
      override public function attaquer(param1:Vivant) : void
      {
         super.attaquer(param1);
         this.deplacementTravailTimer.stop();
         this.arreter_travail();
         this.cibleTravail = null;
         this.sortir();
      }
      
      public function creer_objet(param1:Perso, param2:int) : void
      {
         this.cibleTravail = param1;
         this.cibleTravailRace = param1.race;
         this.choixAmeliorationObjet = this.choixRenforcerObjet = null;
         this.choixProduction = param2;
         if(this.peut_produire())
         {
            this.aller_travailler(this.cibleTravail,param2);
         }
         else
         {
            this.arreter();
         }
      }
      
      public function ameliorer_objet(param1:int, param2:int) : void
      {
         var _loc3_:String = null;
         var _loc4_:Object = null;
         if(Boolean(objets[param1].donnees.upgrade) && Boolean(objets[param1].donnees.upgrade.length > param2) && this.peut_produire2(objets[param1].donnees.upgrade[param2]))
         {
            _loc3_ = objets[param1].donnees.upgrade[param2].workshop;
            _loc4_ = IA.trouver_ressource_proche2_sansCentreVille(this,_loc3_,false,int.MAX_VALUE);
            if(_loc4_)
            {
               this.choixAmeliorationObjet = {
                  "no":param1,
                  "type":objets[param1].id,
                  "choix":param2
               };
               this.choixRenforcerObjet = null;
               this.aller_travailler2(Perso(_loc4_));
            }
            else if(Boolean(Donnees.donnees[_loc3_]) && Boolean(Donnees.donnees[_loc3_].zero))
            {
               parler_depuis_donnee(Donnees.donnees[_loc3_].zero);
            }
         }
      }
      
      public function renforcer_objet(param1:int, param2:int) : void
      {
         var _loc3_:String = null;
         var _loc4_:Object = null;
         if(Boolean(objets[param1].donnees.enhance) && this.peut_produire2(objets[param1].donnees.enhance[0],cout_renforcement(param2) - cout_renforcement(objets[param1].renforcer)))
         {
            _loc3_ = objets[param1].donnees.enhance[0].workshop;
            _loc4_ = IA.trouver_ressource_proche2_sansCentreVille(this,_loc3_,false,int.MAX_VALUE);
            if(_loc4_)
            {
               this.choixAmeliorationObjet = null;
               this.choixRenforcerObjet = {
                  "no":param1,
                  "type":objets[param1].id,
                  "multiplicateur":cout_renforcement(param2 + 1) - cout_renforcement(objets[param1].renforcer + 1)
               };
               this.renforcer = param2;
               this.aller_travailler2(Perso(_loc4_));
            }
            else if(Boolean(Donnees.donnees[_loc3_]) && Boolean(Donnees.donnees[_loc3_].zero))
            {
               parler_depuis_donnee(Donnees.donnees[_loc3_].zero);
            }
         }
      }
      
      public function aller_reparer(param1:Perso) : void
      {
         this.choixProduction = -1;
         this.aller_travailler(param1);
      }
      
      public function aller_travailler(param1:Perso, param2:int = -1) : void
      {
         this.choixProduction = param2;
         this.choixAmeliorationObjet = this.choixRenforcerObjet = null;
         this.vente = false;
         this.aller_travailler2(param1);
      }
      
      public function aller_travailler2(param1:Perso) : void
      {
         this.sortir();
         this.arreter();
         this.cibleTravail = param1;
         this.cibleTravailRace = param1.race;
         if(this.cibleTravail is RessourceTerrain || this.cibleTravail is RessourceMobile || this.cibleTravail is Atelier)
         {
            if(!Object(this.cibleTravail).production)
            {
               this.choixProduction = -1;
            }
            else if(Object(this.cibleTravail).production.length == 1)
            {
               this.choixProduction = 0;
            }
         }
         destinationX = this.cibleTravail.x;
         destinationY = this.cibleTravail.y;
         this.deplacementTravailTimer.start();
         orienter();
      }
      
      public function get travaille() : Boolean
      {
         return this.deplacementTravailTimer.running || this.travailTimer.running;
      }
      
      public function utiliser_ressource(param1:String, param2:int) : void
      {
         var _loc3_:String = null;
         if(param2 > this.ressources[param1].quantite)
         {
            param2 = int(this.ressources[param1].quantite);
         }
         this.ressources[param1].quantite -= param2;
         for(_loc3_ in Donnees.donnees[param1].gain)
         {
            caracteristiquesPrimaires[_loc3_].recuperer(Donnees.donnees[param1].gain[_loc3_] * param2 * caracteristiquesPrimaires[_loc3_].bonusEquipement);
         }
      }
      
      public function donner_objet(param1:Perso, param2:int, param3:int) : void
      {
         this.donneEquipement = true;
         this.donneObjetNo = param2;
         this.donneQuantite = param3;
         this.aller_travailler(param1);
      }
      
      public function donner_ressource(param1:Perso, param2:String, param3:int) : void
      {
         this.donneEquipement = false;
         this.donneRessourceId = param2;
         this.donneQuantite = param3;
         this.aller_travailler(param1);
      }
      
      public function entrepot_ressource(param1:Boolean, param2:String, param3:int) : void
      {
         if(Boolean(this.batimentEntrer) && Boolean(this.batimentEntrer.vivant) && this.batimentEntrer is BatimentCentreVille)
         {
            if(param1)
            {
               if(param3 > BatimentCentreVille(this.batimentEntrer).ressources[param2].quantite)
               {
                  param3 = int(BatimentCentreVille(this.batimentEntrer).ressources[param2].quantite);
               }
               if(param3 > this.ressources[param2].quantiteMax - this.ressources[param2].quantite)
               {
                  param3 = this.ressources[param2].quantiteMax - this.ressources[param2].quantite;
               }
               BatimentCentreVille(this.batimentEntrer).ressources[param2].quantite = BatimentCentreVille(this.batimentEntrer).ressources[param2].quantite - param3;
               this.ressources[param2].quantite += param3;
            }
            else
            {
               if(param3 > this.ressources[param2].quantite)
               {
                  param3 = int(this.ressources[param2].quantite);
               }
               this.ressources[param2].quantite -= param3;
               BatimentCentreVille(this.batimentEntrer).ressources[param2].quantite = BatimentCentreVille(this.batimentEntrer).ressources[param2].quantite + param3;
            }
         }
      }
      
      protected function deplacer_travail(param1:TimerEvent) : void
      {
         var _loc2_:Number = NaN;
         var _loc3_:Number = NaN;
         var _loc4_:Number = NaN;
         var _loc5_:Number = NaN;
         if(this.verifier_cible_travail())
         {
            if(this.cibleTravail is RessourceMobile || this.cibleTravail is BatimentMobile)
            {
               destinationX = this.cibleTravail.x;
               destinationY = this.cibleTravail.y;
               orienter();
            }
            if((this.cibleTravail is Batiment || this.cibleTravail is Fondations) && cible_proche(this.cibleTravail,rayon) || !(this.cibleTravail is Batiment || this.cibleTravail is Fondations) && cible_proche2(rayon + this.cibleTravail.rayon))
            {
               _pas = 0;
               this.travailTimer.reset();
               if(this.vente)
               {
                  this.vendre_objet2();
                  this.arreter_deplacementTravail();
                  dispatchEvent(new PersosEvent(PersosEvent.DEPLACER));
                  return;
               }
               if((Boolean(this.choixProduction != -1 || this.choixAmeliorationObjet) || Boolean(this.choixRenforcerObjet)) && (this.cibleTravail is RessourceTerrain || this.cibleTravail is RessourceMobile || this.cibleTravail is Atelier && !Atelier(this.cibleTravail).reparable))
               {
                  this.travailTimer.addEventListener(TimerEvent.TIMER,this.produire);
                  this.travailTimer.removeEventListener(TimerEvent.TIMER,this.construire_batiment);
                  this.travailTimer.removeEventListener(TimerEvent.TIMER,this.reparer_batiment);
                  this.travailTimer.removeEventListener(TimerEvent.TIMER,this.ressusciter);
                  if(this.choixAmeliorationObjet)
                  {
                     this.deplacer_travail2(Donnees.donnees[this.choixAmeliorationObjet.type].upgrade[this.choixAmeliorationObjet.choix]);
                  }
                  else if(this.choixRenforcerObjet)
                  {
                     this.deplacer_travail2(Donnees.donnees[this.choixRenforcerObjet.type].enhance[0],this.choixRenforcerObjet.multiplicateur);
                  }
                  else
                  {
                     this.deplacer_travail2(Object(this.cibleTravail).production[this.choixProduction]);
                  }
               }
               else if(this.cibleTravail is Batiment || this.cibleTravail is BatimentMobile)
               {
                  if(this.cibleTravail is BatimentCentreVille && BatimentCentreVille(this.cibleTravail).ameliorationEnCours)
                  {
                     this.travailTimer.removeEventListener(TimerEvent.TIMER,this.produire);
                     this.travailTimer.addEventListener(TimerEvent.TIMER,this.construire_batiment);
                     this.travailTimer.removeEventListener(TimerEvent.TIMER,this.reparer_batiment);
                     this.travailTimer.removeEventListener(TimerEvent.TIMER,this.ressusciter);
                     this.travailTimer.delay = BatimentCentreVille(this.cibleTravail).travailDuree;
                  }
                  else if(this.cibleTravail is BatimentResurrection && !vivant)
                  {
                     this.travailTimer.removeEventListener(TimerEvent.TIMER,this.produire);
                     this.travailTimer.removeEventListener(TimerEvent.TIMER,this.construire_batiment);
                     this.travailTimer.removeEventListener(TimerEvent.TIMER,this.reparer_batiment);
                     this.travailTimer.addEventListener(TimerEvent.TIMER,this.ressusciter);
                     this.travailTimer.delay = BatimentResurrection(this.cibleTravail).tempsResurrection;
                  }
                  else
                  {
                     this.travailTimer.removeEventListener(TimerEvent.TIMER,this.produire);
                     this.travailTimer.removeEventListener(TimerEvent.TIMER,this.construire_batiment);
                     this.travailTimer.addEventListener(TimerEvent.TIMER,this.reparer_batiment);
                     this.travailTimer.removeEventListener(TimerEvent.TIMER,this.ressusciter);
                     this.travailTimer.delay = Object(this.cibleTravail).constructionDuree;
                  }
               }
               else
               {
                  if(this.cibleTravail is Artisan)
                  {
                     if(this.donneEquipement)
                     {
                        if(objets[this.donneObjetNo] is ObjetTemporaire)
                        {
                           Artisan(this.cibleTravail).gagner_objet_temporaire(objets[this.donneObjetNo].id,objets[this.donneObjetNo].tempsRestant,objets[this.donneObjetNo].renforcer);
                        }
                        else
                        {
                           Artisan(this.cibleTravail).ajouter_objet(objets[this.donneObjetNo].id,this.donneQuantite,objets[this.donneObjetNo].renforcer);
                        }
                        supprimer_quantite_objet(this.donneObjetNo,-this.donneQuantite);
                        this.actualiser_bonus();
                     }
                     else
                     {
                        Artisan(this.cibleTravail).ressources[this.donneRessourceId].quantite = Artisan(this.cibleTravail).ressources[this.donneRessourceId].quantite + this.donneQuantite;
                        this.ressources[this.donneRessourceId].quantite -= this.donneQuantite;
                     }
                     Artisan(this.cibleTravail).parler_aleatoire("thank");
                     this.arreter_deplacementTravail();
                     dispatchEvent(new PersosEvent(PersosEvent.DEPLACER));
                     return;
                  }
                  if(!(this.cibleTravail is Fondations))
                  {
                     this.arreter_deplacementTravail();
                     if(_pas != 0)
                     {
                        _pas = 0;
                        dispatchEvent(new PersosEvent(PersosEvent.DEPLACER));
                     }
                     return;
                  }
                  this.travailTimer.removeEventListener(TimerEvent.TIMER,this.produire);
                  this.travailTimer.addEventListener(TimerEvent.TIMER,this.construire_batiment);
                  this.travailTimer.removeEventListener(TimerEvent.TIMER,this.reparer_batiment);
                  this.travailTimer.removeEventListener(TimerEvent.TIMER,this.ressusciter);
                  this.travailTimer.delay = Object(this.cibleTravail).travailDuree;
               }
               this.deplacementTravailTimer.stop();
               this.travailTimer.start();
            }
            else
            {
               _loc2_ = destinationX - x;
               _loc3_ = destinationY - y;
               _loc4_ = Math.sqrt(Math.pow(_loc2_,2) + Math.pow(_loc3_,2));
               _loc5_ = vitesse * MULTIPLICATEUR_VITESSE / _loc4_ * (volant ? 1 : Terrain.case_vitesse(x,y));
               x += _loc5_ * _loc2_;
               y += _loc5_ * _loc3_;
               ++_pas;
               if(_pas > 3)
               {
                  _pas = 0;
               }
               gerer_deplacement_terrain();
            }
            dispatchEvent(new PersosEvent(PersosEvent.DEPLACER));
         }
         else
         {
            this.arreter_deplacementTravail();
            if(_pas != 0)
            {
               _pas = 0;
               dispatchEvent(new PersosEvent(PersosEvent.DEPLACER));
            }
         }
      }
      
      private function deplacer_travail2(param1:Object, param2:int = 1) : void
      {
         this.travailTimer.delay = param1.time * 1000 * param2;
         if(param1.bonusTimeSkill)
         {
            this.travailTimer.delay /= competences[param1.bonusTimeSkill].coefBonus;
         }
         if(this.cibleTravail is RessourceMobile)
         {
            RessourceMobile(this.cibleTravail).bloquer(this.travailTimer.delay);
         }
      }
      
      private function peut_produire() : Boolean
      {
         if(this.cibleTravail is Fondations || !Object(this.cibleTravail).hasOwnProperty("production"))
         {
            return false;
         }
         return this.peut_produire2(Object(this.cibleTravail).production[this.choixProduction]);
      }
      
      private function peut_produire2(param1:Object, param2:int = 1) : Boolean
      {
         var _loc4_:String = null;
         var _loc5_:Object = null;
         var _loc6_:Object = null;
         var _loc7_:Boolean = false;
         var _loc8_:String = null;
         var _loc3_:Object = param1.costPrimaryCharacteristic;
         for(_loc4_ in _loc3_)
         {
            if(caracteristiquesPrimaires[_loc4_].score < _loc3_[_loc4_] * param2)
            {
               if(this.joueur)
               {
                  parler_depuis_donnee(Donnees.donnees[_loc4_]["zero"]);
               }
               return false;
            }
         }
         _loc5_ = param1.costRessource;
         for(_loc4_ in _loc5_)
         {
            if(this.ressources[_loc4_].quantite < _loc5_[_loc4_] * param2)
            {
               if(this.joueur)
               {
                  if(this.ressources[_loc4_].quantite < 1)
                  {
                     parler_depuis_donnee(Donnees.donnees[_loc4_]["zero"]);
                  }
                  else
                  {
                     parler_depuis_donnee(Donnees.donnees[_loc4_]["lack"]);
                  }
               }
               return false;
            }
         }
         _loc6_ = param1.gainRessource;
         if(_loc6_)
         {
            _loc7_ = true;
            for(_loc4_ in _loc6_)
            {
               if(this.ressources[_loc4_].plein)
               {
                  _loc8_ = _loc4_;
               }
               else
               {
                  _loc7_ = false;
               }
            }
            if(_loc7_)
            {
               if(this.joueur)
               {
                  parler_depuis_donnee(Donnees.donnees[_loc8_]["full"]);
               }
               return false;
            }
         }
         return true;
      }
      
      protected function ressusciter(param1:TimerEvent) : void
      {
         if(this.verifier_cible_travail())
         {
            Object(this.cibleTravail).ressusciter(this);
         }
         this.arreter_travail();
      }
      
      protected function produire(param1:TimerEvent) : void
      {
         var _loc2_:int = 0;
         if(!this.cibleTravail || !this.cibleTravail.visible)
         {
            if(ia)
            {
               this.cibleTravail = Perso(IA.trouver_ressource_proche2_sansCentreVille(this,this.cibleTravailRace,true,176));
            }
            else
            {
               this.cibleTravail = Perso(IA.trouver_ressource_proche2(this,this.cibleTravailRace,true,176));
            }
            if(this.cibleTravail)
            {
               this.aller_travailler(this.cibleTravail);
            }
            else
            {
               this.arreter_travail();
            }
         }
         else if(this.verifier_cible_travail())
         {
            if(this.choixAmeliorationObjet)
            {
               if(Boolean(this.choixAmeliorationObjet.no < objets.length) && Boolean(objets[this.choixAmeliorationObjet.no]) && objets[this.choixAmeliorationObjet.no].id == this.choixAmeliorationObjet.type)
               {
                  supprimer_objet(this.choixAmeliorationObjet.no);
                  this.produire2(Donnees.donnees[this.choixAmeliorationObjet.type].upgrade[this.choixAmeliorationObjet.choix]);
               }
               else
               {
                  this.arreter_travail();
               }
            }
            else if(this.choixRenforcerObjet)
            {
               if(Boolean(this.choixRenforcerObjet.no < objets.length) && Boolean(objets[this.choixRenforcerObjet.no]) && objets[this.choixRenforcerObjet.no].id == this.choixRenforcerObjet.type)
               {
                  _loc2_ = int(objets[this.choixRenforcerObjet.no].renforcer);
                  supprimer_objet(this.choixRenforcerObjet.no);
                  this.produire2(Donnees.donnees[this.choixRenforcerObjet.type].enhance[0],1,this.renforcer,this.choixRenforcerObjet.multiplicateur);
               }
               else
               {
                  this.arreter_travail();
               }
            }
            else
            {
               this.produire2(Object(this.cibleTravail).production[this.choixProduction],Timer(param1.currentTarget).currentCount);
            }
         }
         else
         {
            this.arreter_travail();
         }
      }
      
      protected function produire2(param1:Object, param2:int = 1, param3:int = 0, param4:int = 1) : void
      {
         var _loc6_:int = 0;
         var _loc7_:String = null;
         var _loc8_:int = 0;
         var _loc9_:Object = null;
         var _loc10_:Object = null;
         var _loc11_:Boolean = false;
         var _loc12_:String = null;
         var _loc14_:String = null;
         var _loc15_:Object = null;
         if(param1.anim)
         {
            this.cibleTravail.dispatchEvent(new AnimationEvent(AnimationEvent.ANIMER,param1.anim));
         }
         var _loc5_:Object = param1.costPrimaryCharacteristic;
         if(param1.bonusSkill)
         {
            _loc6_ = competences[param1.bonusSkill].multiplicateur * param4;
         }
         else
         {
            _loc6_ = param4;
         }
         for(_loc7_ in _loc5_)
         {
            if(caracteristiquesPrimaires[_loc7_].score < _loc5_[_loc7_])
            {
               if(caracteristiquesPrimaires[_loc7_].score < 1)
               {
                  parler_depuis_donnee(Donnees.donnees[_loc7_]["zero"]);
               }
               else
               {
                  parler_depuis_donnee(Donnees.donnees[_loc7_]["lack"]);
               }
               this.arreter_travail();
               return;
            }
            _loc6_ = Math.min(_loc6_,caracteristiquesPrimaires[_loc7_].score / _loc5_[_loc7_]);
         }
         _loc9_ = param1.costRessource;
         for(_loc7_ in _loc9_)
         {
            if(this.ressources[_loc7_].quantite < _loc9_[_loc7_])
            {
               this.arreter_travail();
               if(this.ressources[_loc7_].quantite < 1)
               {
                  if(param2 > 1)
                  {
                     parler_depuis_donnee(Donnees.donnees[_loc7_]["out"]);
                  }
                  else
                  {
                     parler_depuis_donnee(Donnees.donnees[_loc7_]["zero"]);
                  }
               }
               else
               {
                  parler_depuis_donnee(Donnees.donnees[_loc7_]["lack"]);
               }
               return;
            }
            _loc6_ = Math.min(_loc6_,this.ressources[_loc7_].quantite / _loc9_[_loc7_]);
         }
         _loc10_ = param1.gainRessource;
         if(_loc10_)
         {
            _loc11_ = true;
            for(_loc7_ in _loc10_)
            {
               if(this.ressources[_loc7_].plein)
               {
                  _loc12_ = _loc7_;
               }
               else if(_loc7_ == this.iaBesoinRessources && this.iaBesoinRessourcesQuantite > 0 && ia && this.ressources[_loc7_].quantite >= this.iaBesoinRessourcesQuantite)
               {
                  this.arreter_travail();
                  _loc11_ = false;
               }
               else
               {
                  _loc11_ = false;
               }
            }
            if(_loc11_)
            {
               this.arreter_travail();
               parler_depuis_donnee(Donnees.donnees[_loc12_]["full"]);
            }
         }
         var _loc13_:Object = param1.gainItem;
         if(_loc13_)
         {
            _loc11_ = true;
            for(_loc7_ in _loc13_)
            {
               _loc8_ = possede_objet(_loc7_);
               if(_loc8_ != -1)
               {
                  if(objets[_loc8_].plein)
                  {
                     _loc14_ = _loc7_;
                  }
                  else
                  {
                     _loc11_ = false;
                  }
               }
               else
               {
                  _loc11_ = false;
               }
            }
            if(_loc11_)
            {
               this.arreter_travail();
               parler_depuis_donnee(Donnees.donnees[_loc14_]["full"]);
            }
         }
         if(Object(this.cibleTravail).quantiteLimite)
         {
            _loc6_ = Math.min(_loc6_,Object(this.cibleTravail).quantite);
         }
         if(Boolean(param1.steps) && this.cibleTravail is Atelier)
         {
            _loc6_ = Math.min(_loc6_,Atelier(this.cibleTravail).etapes_restantes(this.choixProduction));
         }
         for(_loc7_ in _loc5_)
         {
            caracteristiquesPrimaires[_loc7_].score -= _loc5_[_loc7_] * _loc6_;
         }
         for(_loc7_ in _loc9_)
         {
            this.ressources[_loc7_].quantite -= _loc9_[_loc7_] * _loc6_;
         }
         if(Boolean(this.cibleTravail is Atelier) && Boolean(param1.steps) && Atelier(this.cibleTravail).etapes_restantes(this.choixProduction) > _loc6_)
         {
            Atelier(this.cibleTravail).ajouter_etape(this.choixProduction,_loc6_);
         }
         else
         {
            if(this.cibleTravail is Atelier && Boolean(param1.steps))
            {
               Atelier(this.cibleTravail).effacer_etape(this.choixProduction);
            }
            if(Boolean(_loc10_) || Boolean(_loc13_))
            {
               _loc11_ = true;
               if(_loc10_)
               {
                  for(_loc7_ in _loc10_)
                  {
                     this.ressources[_loc7_].quantite += _loc10_[_loc7_] * _loc6_;
                     if(this.ressources[_loc7_].plein)
                     {
                        _loc12_ = _loc7_;
                     }
                     else
                     {
                        _loc11_ = false;
                     }
                  }
               }
               if(_loc13_)
               {
                  for(_loc7_ in _loc13_)
                  {
                     if(ajouter_objet(_loc7_,param3 > 0 ? 1 : int(_loc13_[_loc7_] * _loc6_),param3))
                     {
                        _loc11_ = false;
                     }
                     else
                     {
                        _loc14_ = _loc7_;
                     }
                     if(_loc7_ == this.iaConstruireObjet)
                     {
                        this.iaConstruireObjet = "";
                     }
                  }
               }
            }
            _loc15_ = param1.createCharacter;
            if(_loc15_)
            {
               for(_loc7_ in _loc15_)
               {
                  _loc8_ = 0;
                  while(_loc8_ < _loc15_[_loc7_])
                  {
                     dispatchEvent(new CreationPersoEvent(CreationPersoEvent.CREER,_loc7_,this.cibleTravail.x,this.cibleTravail.y,equipe,1,"",false));
                     _loc8_++;
                  }
                  if(_loc7_ == this.iaConstruireSoldat)
                  {
                     this.iaConstruireSoldat = "";
                  }
               }
            }
            if(Object(this.cibleTravail).quantiteLimite)
            {
               Object(this.cibleTravail).quantite = Object(this.cibleTravail).quantite + param1.quantity * _loc6_;
            }
            if(_loc11_)
            {
               this.arreter_travail();
               if(_loc12_)
               {
                  parler_depuis_donnee(Donnees.donnees[_loc12_]["full"]);
               }
               else if(_loc13_)
               {
                  parler_depuis_donnee(Donnees.donnees[_loc14_]["full"]);
               }
            }
            if(!param1.repeat)
            {
               this.arreter_travail();
            }
            else if(!Donnees.donnees[this.cibleTravail.race].produce || !this.cibleTravail.visible)
            {
               this.cibleTravail = Perso(IA.trouver_ressource_proche2_sansCentreVille(this,this.cibleTravail.race,ia,176,176));
               if(Boolean(this.cibleTravail) && this.peut_produire())
               {
                  this.aller_travailler(this.cibleTravail);
               }
               else
               {
                  this.arreter_travail();
               }
            }
            else if(!this.peut_produire())
            {
               this.arreter_travail();
            }
         }
      }
      
      protected function construire_batiment(param1:TimerEvent) : void
      {
         var _loc2_:String = null;
         var _loc3_:Object = null;
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         var _loc6_:Object = null;
         if(this.verifier_cible_travail() && (this.cibleTravail is Fondations || this.cibleTravail is BatimentCentreVille))
         {
            _loc3_ = Object(this.cibleTravail).coutCaracteristique;
            _loc4_ = int(competences[Object(this.cibleTravail).bonusCompetence].multiplicateur);
            for(_loc2_ in _loc3_)
            {
               if(caracteristiquesPrimaires[_loc2_].score < _loc3_[_loc2_])
               {
                  this.arreter_travail();
                  parler_depuis_donnee(Donnees.donnees[_loc2_]["zero"]);
                  return;
               }
               _loc4_ = Math.min(_loc4_,caracteristiquesPrimaires[_loc2_].score / _loc3_[_loc2_]);
            }
            _loc5_ = 0;
            while(_loc5_ < Object(this.cibleTravail).coutRessource.length)
            {
               _loc6_ = Object(this.cibleTravail).coutRessource[_loc5_];
               if(this.ressources[_loc6_.nom].quantite > 0)
               {
                  break;
               }
               if(_loc5_ == Object(this.cibleTravail).coutRessource.length - 1)
               {
                  this.arreter_travail();
                  if(Timer(param1.currentTarget).currentCount > 1)
                  {
                     parler_depuis_donnee(Donnees.donnees[_loc6_.nom]["out"]);
                  }
                  else
                  {
                     parler_depuis_donnee(Donnees.donnees[_loc6_.nom]["zero"]);
                  }
                  return;
               }
               _loc5_++;
            }
            _loc4_ = Math.min(Math.min(Math.min(_loc4_,Object(this.cibleTravail).coutRessource[_loc5_].quantite),this.ressources[_loc6_.nom].quantite),Object(this.cibleTravail).constructionRestante);
            if(MainJeu.bacASable)
            {
               _loc4_ = 100;
            }
            for(_loc2_ in _loc3_)
            {
               caracteristiquesPrimaires[_loc2_].score -= _loc3_[_loc2_] * _loc4_;
            }
            this.ressources[_loc6_.nom].quantite -= _loc4_;
            Object(this.cibleTravail).construire(_loc4_,_loc5_);
            if(this.joueur && (this.cibleTravail is Fondations || this.cibleTravail is BatimentCentreVille))
            {
               Joueur(this).gagner_xp(Donnees.donnees[Object(this.cibleTravail).creation].build,1);
            }
            if(!this.cibleTravail.visible && this.cibleTravail is Fondations && Donnees.donnees[Fondations(this.cibleTravail).creation].type == "wall")
            {
               IA.continuer_construire_mur(this,this.cibleTravail.race);
            }
         }
         else
         {
            this.arreter_travail();
         }
      }
      
      protected function reparer_batiment(param1:TimerEvent = null) : void
      {
         var _loc2_:String = null;
         var _loc3_:Object = null;
         var _loc4_:int = 0;
         var _loc5_:Object = null;
         if(this.verifier_cible_travail())
         {
            if(this.cibleTravail is BatimentMobile)
            {
               destinationX = this.cibleTravail.x;
               destinationY = this.cibleTravail.y;
               if(!cible_proche2(rayon + this.cibleTravail.rayon))
               {
                  this.arreter_travail();
                  this.aller_reparer(this.cibleTravail);
                  return;
               }
            }
            _loc3_ = Object(this.cibleTravail).repair.costPrimaryCharacteristic;
            _loc4_ = int(competences[Object(this.cibleTravail).bonusCompetence].multiplicateur);
            for(_loc2_ in _loc3_)
            {
               if(caracteristiquesPrimaires[_loc2_].score < _loc3_[_loc2_])
               {
                  this.arreter_travail();
                  if(this.cibleTravail is Maison)
                  {
                     this.rentrer_maison();
                  }
                  parler_depuis_donnee(Donnees.donnees[_loc2_]["zero"]);
                  return;
               }
               _loc4_ = Math.min(_loc4_,caracteristiquesPrimaires[_loc2_].score / _loc3_[_loc2_]);
            }
            _loc5_ = Object(this.cibleTravail).repair.costRessource;
            for(_loc2_ in _loc5_)
            {
               if(this.ressources[_loc2_].quantite < _loc5_[_loc2_])
               {
                  this.arreter_travail();
                  if(this.cibleTravail is Maison)
                  {
                     this.rentrer_maison();
                  }
                  if(this.ressources[_loc2_].quantite < 1)
                  {
                     if(Timer(param1.currentTarget).currentCount > 1)
                     {
                        parler_depuis_donnee(Donnees.donnees[_loc2_]["out"]);
                     }
                     else
                     {
                        parler_depuis_donnee(Donnees.donnees[_loc2_]["zero"]);
                     }
                  }
                  else
                  {
                     parler_depuis_donnee(Donnees.donnees[_loc2_]["lack"]);
                  }
                  return;
               }
               _loc4_ = Math.min(_loc4_,this.ressources[_loc2_].quantite);
            }
            _loc4_ = Math.min(_loc4_,Object(this.cibleTravail).reparationRestante);
            for(_loc2_ in _loc3_)
            {
               caracteristiquesPrimaires[_loc2_].score -= _loc3_[_loc2_] * _loc4_;
            }
            for(_loc2_ in _loc5_)
            {
               this.ressources[_loc2_].quantite -= _loc5_[_loc2_] * _loc4_;
            }
            Object(this.cibleTravail).reparer(_loc4_);
            if(!Vivant(this.cibleTravail).blesse)
            {
               this.arreter_travail();
               if(this.cibleTravail is Mur)
               {
                  IA.continuer_reparer_mur(this,this.cibleTravail.race);
               }
               else if(this.cibleTravail is Maison)
               {
                  this.rentrer_maison();
               }
            }
            if(this.joueur && Boolean(this.cibleTravail))
            {
               Joueur(this).gagner_xp(Donnees.donnees[Object(this.cibleTravail).race].repair,1);
            }
         }
         else
         {
            this.arreter_travail();
         }
      }
      
      protected function arreter_deplacementTravail() : void
      {
         this.deplacementTravailTimer.stop();
      }
      
      protected function arreter_travail() : void
      {
         this.travailTimer.stop();
      }
      
      protected function verifier_cible_travail() : Boolean
      {
         if(this.cibleTravail)
         {
            if(this.cibleTravail.visible)
            {
               return true;
            }
            this.cibleTravail = null;
            return false;
         }
         return false;
      }
      
      override protected function utiliser_objet4(param1:Object, param2:int = 1) : Boolean
      {
         var _loc3_:String = null;
         var _loc4_:String = null;
         if(super.utiliser_objet4(param1))
         {
            if(param1.gainRessource)
            {
               for(_loc3_ in param1.gainRessource)
               {
                  if(param1.gainRessource[_loc3_] is int)
                  {
                     this.ressources[_loc3_].quantite += param1.gainRessource[_loc3_] * param2;
                  }
                  else
                  {
                     for(_loc4_ in param1.gainRessource[_loc3_])
                     {
                        this.ressources[_loc3_].quantite += competences[_loc4_].score * param1.gainRessource[_loc3_][_loc4_] * param2;
                     }
                  }
               }
            }
            return true;
         }
         return false;
      }
      
      public function recycler_objet(param1:int, param2:Boolean = false) : void
      {
         var _loc3_:Boolean = false;
         var _loc4_:Boolean = false;
         if(objets[param1].donnees.recycle)
         {
            if(objets[param1] is ObjetEquipe && Boolean(objets[param1].equipe))
            {
               _loc4_ = true;
               if(objets[param1].changeApparence)
               {
                  _loc3_ = true;
               }
            }
            if(param2)
            {
               this.utiliser_objet4(objets[param1].donnees.recycle,objets[param1].quantite / objets[param1].donnees.recycle.quantity);
               supprimer_objet(param1);
               if(_loc4_)
               {
                  this.actualiser_bonus();
                  if(_loc3_)
                  {
                     actualiser_apparence();
                  }
               }
            }
            else
            {
               this.utiliser_objet4(objets[param1].donnees.recycle,cout_renforcement(objets[param1].renforcer + 1));
               if(supprimer_quantite_objet(param1,-objets[param1].donnees.recycle.quantity))
               {
                  if(_loc4_)
                  {
                     this.actualiser_bonus();
                     if(_loc3_)
                     {
                        actualiser_apparence();
                     }
                  }
               }
            }
         }
      }
      
      public function vendre_objet(param1:int, param2:Boolean = false) : void
      {
         var _loc3_:Object = null;
         if(objets[param1].donnees.sell)
         {
            _loc3_ = IA.trouver_batiment_vente(this);
            if(_loc3_)
            {
               if(param2)
               {
                  this.donneQuantite = -objets[param1].quantite;
               }
               else
               {
                  this.donneQuantite = -objets[param1].donnees.sell.quantity;
               }
               this.aller_travailler(Perso(_loc3_));
               this.donneEquipement = true;
               this.vente = true;
               this.donneObjetNo = param1;
            }
            else
            {
               parler(Donnees.traduction.noSell);
            }
         }
      }
      
      public function vendre_objet2() : void
      {
         var _loc1_:Boolean = false;
         var _loc2_:Boolean = false;
         if(objets[this.donneObjetNo] is ObjetEquipe && Boolean(objets[this.donneObjetNo].equipe))
         {
            _loc2_ = true;
            if(objets[this.donneObjetNo].changeApparence)
            {
               _loc1_ = true;
            }
         }
         this.utiliser_objet4(objets[this.donneObjetNo].donnees.sell,Math.ceil(-this.donneQuantite / objets[this.donneObjetNo].donnees.sell.quantity) * cout_renforcement(objets[this.donneObjetNo].renforcer + 1));
         if(supprimer_quantite_objet(this.donneObjetNo,this.donneQuantite))
         {
            if(_loc2_)
            {
               this.actualiser_bonus();
               if(_loc1_)
               {
                  actualiser_apparence();
               }
            }
         }
      }
      
      override public function riposter(param1:Vivant) : void
      {
         if(ia && vie.coef < 0.6 && IA.fuir(this,param1,480))
         {
            iaPretAuCombat = false;
         }
         else if(this.enAttente || ia && iaPretAuCombat && (!enCombat || cibleCombat is BatimentOffensif && param1 is Combattant) && (!cibleCombat || !(cibleCombat is Combattant)) && !(deplacementTimer.running && suitOrdre))
         {
            this.attaquer(param1);
         }
      }
      
      override protected function degats_poison(param1:PoisonEvent) : void
      {
         if(param1.degats >= vie.score)
         {
            Tresor.piller_perso(this,null);
         }
         super.degats_poison(param1);
      }
      
      override public function mourir() : void
      {
         var _loc1_:Object = null;
         utiliser_objets_mort();
         if(!vivant)
         {
            for each(_loc1_ in caracteristiquesPrimaires)
            {
               _loc1_.arreter();
               _loc1_.recuperation = 0;
            }
            this.arreter();
            penalites.vider();
            poisons.vider();
            visible = false;
            if(!this.fantome)
            {
               this.fantome = true;
               dispatchEvent(new PersosEvent(PersosEvent.FANTOME));
            }
         }
      }
      
      override public function revivre() : void
      {
         super.revivre();
         if(this.fantome)
         {
            this.fantome = false;
            dispatchEvent(new PersosEvent(PersosEvent.FANTOME));
         }
      }
      
      override public function pause() : void
      {
         if(this.deplacementTravailTimer.running)
         {
            this.pauseDeplacementTravail = true;
            this.deplacementTravailTimer.stop();
         }
         if(this.travailTimer.running)
         {
            this.pauseTravail = true;
            this.travailTimer.stop();
         }
         super.pause();
      }
      
      override public function reprendre() : void
      {
         if(this.pauseDeplacementTravail)
         {
            this.deplacementTravailTimer.start();
            this.pauseDeplacementTravail = false;
         }
         if(this.pauseTravail)
         {
            this.travailTimer.start();
            this.pauseTravail = false;
         }
         super.reprendre();
      }
      
      override public function detruire() : void
      {
         var _loc1_:String = null;
         super.detruire();
         for(_loc1_ in this.ressources)
         {
            this.ressources[_loc1_] = null;
            delete this.ressources[_loc1_];
         }
         this.ressources = null;
         this.cibleTravail = null;
         this._maison = null;
         this.batimentEntrer = null;
         this.deplacementTravailTimer.stop();
         this.deplacementTravailTimer.removeEventListener(TimerEvent.TIMER,this.deplacer_travail);
         this.deplacementTravailTimer = null;
         this.travailTimer.stop();
         this.travailTimer.removeEventListener(TimerEvent.TIMER,this.produire);
         this.travailTimer.removeEventListener(TimerEvent.TIMER,this.construire_batiment);
         this.travailTimer.removeEventListener(TimerEvent.TIMER,this.reparer_batiment);
         this.travailTimer.removeEventListener(TimerEvent.TIMER,this.ressusciter);
         this.travailTimer = null;
         this.choixAmeliorationObjet = null;
         this.choixRenforcerObjet = null;
      }
   }
}

