package aurora.jeuModele.perso
{
   import aurora.jeuModele.IA;
   import aurora.jeuModele.PersosEvent;
   import flash.events.TimerEvent;
   import flash.utils.Timer;
   
   public class ProjectileAutoguide extends Projectile
   {
      
      public var cible:Object;
      
      public var vitesseRotation:Number;
      
      public var vitesseRotationBase:Number;
      
      public function ProjectileAutoguide()
      {
         super();
      }
      
      public function lancer(param1:Object, param2:int, param3:int, param4:Number, param5:Number, param6:Number = 0) : void
      {
         this.cible = param1;
         this.attaque = param2;
         if(isNaN(param4))
         {
            this.rotation = Math.atan2(param1.y - param1.hauteur * 0.5 - y,param1.x - x);
         }
         else
         {
            this.rotation = param4;
         }
         this.vitesseRotationBase = this.vitesseRotation = param5;
         deplacementTimer = new Timer(INTERVAL_DEPLACEMENT,param3 / vitesse * 1.5);
         deplacementTimer.addEventListener(TimerEvent.TIMER,this.deplacer);
         deplacementTimer.addEventListener(TimerEvent.TIMER_COMPLETE,finir_deplacement);
         this.actualiser_rotation();
         if(param6)
         {
            delaiTimer = new Timer(param6 * 1000,1);
            delaiTimer.addEventListener(TimerEvent.TIMER_COMPLETE,commencer_deplacement);
            delaiTimer.start();
         }
         else
         {
            commencer_deplacement();
         }
      }
      
      override protected function deplacer(param1:TimerEvent) : void
      {
         var _loc2_:Object = null;
         var _loc3_:Number = NaN;
         _loc2_ = IA.projectile_cible_proche(this,0);
         if(_loc2_)
         {
            if(transperce)
            {
               if(lanceur)
               {
                  attaque -= lanceur.toucher3(_loc2_,attaque,effet,noAttaque,null,null,penalite,degats);
                  if(Boolean(_loc2_.vivant) || attaque <= 0)
                  {
                     mourir();
                  }
               }
               else
               {
                  mourir();
               }
            }
            else
            {
               if(lanceur)
               {
                  lanceur.toucher3(_loc2_,attaque,effet,noAttaque,null,null,penalite,degats);
               }
               mourir();
            }
         }
         else
         {
            if(!this.cible || !this.cible.vivant || !this.cible.visible)
            {
               this.cible = IA.trouver_cible_proche(this);
               if(!this.cible)
               {
                  x += dx;
                  y += dy;
                  dispatchEvent(new PersosEvent(PersosEvent.DEPLACER));
                  return;
               }
            }
            _loc3_ = Math.atan2(this.cible.y - this.cible.hauteur * 0.5 - y,this.cible.x - x);
            if(rotation < _loc3_)
            {
               this.vitesseRotation = this.vitesseRotationBase;
            }
            else if(rotation > _loc3_)
            {
               this.vitesseRotation = -this.vitesseRotationBase;
            }
            if(Math.abs(rotation - _loc3_) > 3.14)
            {
               this.vitesseRotation = -this.vitesseRotation;
            }
            if(Math.abs(rotation - _loc3_) > this.vitesseRotationBase)
            {
               rotation += this.vitesseRotation;
               if(rotation > 3.14)
               {
                  rotation -= 6.28;
               }
               else if(rotation < -3.14)
               {
                  rotation += 6.28;
               }
               this.actualiser_rotation();
            }
            x += dx;
            y += dy;
            dispatchEvent(new PersosEvent(PersosEvent.DEPLACER));
         }
         animer_deplacement();
      }
      
      private function actualiser_rotation() : void
      {
         dx = Math.cos(rotation) * vitesse * Mobile.MULTIPLICATEUR_VITESSE;
         dy = Math.sin(rotation) * vitesse * Mobile.MULTIPLICATEUR_VITESSE;
         if(orientation)
         {
            dispatchEvent(new PersosEvent(PersosEvent.ROTATION));
         }
      }
      
      override public function detruire() : void
      {
         super.detruire();
         this.cible = null;
      }
   }
}

