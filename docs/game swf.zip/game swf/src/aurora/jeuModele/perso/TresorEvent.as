package aurora.jeuModele.perso
{
   import flash.events.Event;
   
   public class TresorEvent extends Event
   {
      
      public static const CREER:String = "creerTresor";
      
      public var creation:String;
      
      public var x:int;
      
      public var y:int;
      
      public var quantite:int;
      
      public var renforce:int = this.renforce;
      
      public function TresorEvent(param1:String, param2:String, param3:int, param4:int, param5:int, param6:int)
      {
         this.creation = param2;
         this.x = param3;
         this.y = param4;
         this.quantite = param5;
         super(param1);
      }
   }
}

