package aurora.jeuModele.perso
{
   import aurora.MainJeu;
   import aurora.jeuModele.IA;
   import aurora.jeuModele.PersosEvent;
   import aurora.jeuModele.Terrain;
   import aurora.jeuModele.perso.penalites.Penalite;
   import aurora.jeuModele.perso.penalites.Penalites;
   import aurora.jeuModele.perso.poison.PoisonEvent;
   import aurora.jeuModele.perso.poison.Poisons;
   import aurora.messages.perso.MessagePersoOrienter;
   import flash.events.Event;
   import flash.events.TimerEvent;
   import flash.utils.Timer;
   
   public class Mobile extends Vivant
   {
      
      public static var MULTIPLICATEUR_VITESSE:Number = 1;
      
      protected const INTERVAL_DEPLACEMENT:int = 80;
      
      protected const INTERVAL_IA:int = 3000;
      
      protected const INTERVAL_INERTIE:int = 40;
      
      protected const INERTIE_DECELERATION:int = 2;
      
      public var vitesse:Number;
      
      protected var vitesseBase:Number;
      
      protected var defenseBase:int;
      
      public var volant:Boolean;
      
      public var destinationX:Number;
      
      public var destinationY:Number;
      
      public var aucuneInertie:Boolean = true;
      
      public var inertieX:Number = 0;
      
      public var inertieY:Number = 0;
      
      public var orientation:int;
      
      protected var _pas:int;
      
      protected var deplacementTimer:Timer = new Timer(this.INTERVAL_DEPLACEMENT);
      
      private var inertieTimer:Timer;
      
      protected var volantTimer:Timer;
      
      private var _decalageY:int;
      
      private var niveauSol:int;
      
      public var ia:Boolean;
      
      private var timerDemarrerIA:Timer;
      
      public var iaTimer:Timer;
      
      public var penalites:Penalites;
      
      private var _couleur:int = -1;
      
      public var poisons:Poisons;
      
      private var pauseDeplacement:Boolean;
      
      public function Mobile()
      {
         this.deplacementTimer.addEventListener(TimerEvent.TIMER,this.deplacer);
         this.inertieTimer = new Timer(this.INTERVAL_INERTIE);
         this.inertieTimer.addEventListener(TimerEvent.TIMER,this.gerer_inertie);
         this.penalites = new Penalites();
         this.penalites.addEventListener(Event.CHANGE,this.appliquer_penalites);
         this.poisons = new Poisons();
         this.poisons.addEventListener(PoisonEvent.DEGATS,this.degats_poison);
         super();
      }
      
      override public function init(param1:Object) : void
      {
         super.init(param1);
         this.vitesse = this.vitesseBase = param1.speed;
         this.defenseBase = defense;
         this.volant = param1.flying;
         if(this.volant)
         {
            this.volantTimer = new Timer(this.INTERVAL_DEPLACEMENT);
            this.volantTimer.addEventListener(TimerEvent.TIMER,this.voler);
            this.volantTimer.start();
         }
      }
      
      protected function appliquer_penalites(param1:Event = null) : void
      {
         this.vitesse = this.vitesseBase;
         defense = this.defenseBase;
         this.penalites.appliquer_penalites_mobiles(this);
         this.couleur = this.penalites.couleur;
      }
      
      public function get couleur() : int
      {
         return this._couleur;
      }
      
      public function set couleur(param1:int) : void
      {
         if(this._couleur != param1)
         {
            this._couleur = param1;
            dispatchEvent(new PersosEvent(PersosEvent.ACTUALISER_COULEUR));
         }
      }
      
      public function empoisonne(param1:int, param2:int, param3:Object) : void
      {
         if(param1 > 0)
         {
            this.poisons.ajouter(param1,param2,param3);
            this.penalites.ajouter_penalite(Penalite.TYPE_POISON,param2);
         }
      }
      
      protected function degats_poison(param1:PoisonEvent) : void
      {
         if(param1.degats >= vie.score)
         {
            gerer_mort(this);
            if(param1.tueur is Joueur)
            {
               param1.tueur.ajouter_bestiaire(this);
            }
         }
         if(this is Joueur || param1.tueur is Joueur)
         {
            dispatchEvent(new EffetEvent(EffetEvent.EFFET,x,y - hauteur * 0.5,"",0,param1.degats));
         }
         editer_vie(-param1.degats);
      }
      
      protected function voler(param1:TimerEvent) : void
      {
         if(!this.deplacementTimer.running)
         {
            ++this._pas;
            if(this._pas > 3)
            {
               this._pas = 0;
            }
            dispatchEvent(new PersosEvent(PersosEvent.DEPLACER));
         }
      }
      
      public function init_ia(param1:Boolean) : void
      {
         if(this.ia)
         {
            if(param1)
            {
               if(!this.timerDemarrerIA)
               {
                  this.timerDemarrerIA = new Timer(Math.random() * this.INTERVAL_IA,1);
                  this.timerDemarrerIA.addEventListener(TimerEvent.TIMER_COMPLETE,this.demarrer_ia);
               }
               this.timerDemarrerIA.start();
            }
            else
            {
               this.demarrer_ia();
            }
         }
      }
      
      private function demarrer_ia(param1:TimerEvent = null) : void
      {
         if(this.timerDemarrerIA)
         {
            this.timerDemarrerIA.removeEventListener(TimerEvent.TIMER_COMPLETE,this.demarrer_ia);
            this.timerDemarrerIA.stop();
            this.timerDemarrerIA = null;
         }
         if(this.ia && !MainJeu.bacASable)
         {
            if(!this.iaTimer)
            {
               this.iaTimer = new Timer(this.INTERVAL_IA);
               this.iaTimer.addEventListener(TimerEvent.TIMER,this.gerer_ia);
            }
            this.iaTimer.start();
            this.gerer_ia();
         }
      }
      
      public function arreter_ia() : void
      {
         if(this.iaTimer)
         {
            this.iaTimer.stop();
         }
      }
      
      protected function gerer_ia(param1:TimerEvent = null) : void
      {
         if(this.iaTimer)
         {
            IA.gerer_mobile(this);
         }
         else
         {
            param1.currentTarget.stop();
            param1.currentTarget.removeEventListener(TimerEvent.TIMER,this.gerer_ia);
         }
      }
      
      public function appliquer_inertie(param1:Object, param2:Number) : void
      {
         var _loc3_:Number = x - param1.x;
         var _loc4_:Number = y - param1.y;
         var _loc5_:Number = Math.abs(_loc3_) + Math.abs(_loc4_);
         var _loc6_:Number = vie.scoreMax * 0.1;
         if(_loc5_ == 0)
         {
            this.inertieX = Math.random() * 2 - 1;
            this.inertieY = Math.random() * 2 - 1;
         }
         else
         {
            this.inertieX += _loc3_ / _loc5_ * param2 / _loc6_;
            this.inertieY += _loc4_ / _loc5_ * param2 / _loc6_;
         }
         this.aucuneInertie = false;
         this.inertieTimer.start();
      }
      
      public function appliquer_collision(param1:Object, param2:Number) : void
      {
         var _loc3_:Number = NaN;
         var _loc4_:Number = NaN;
         var _loc5_:Number = NaN;
         if(this.aucuneInertie)
         {
            _loc3_ = x - param1.x;
            _loc4_ = y - param1.y;
            _loc5_ = Math.abs(_loc3_) + Math.abs(_loc4_);
            if(_loc5_ == 0)
            {
               this.inertieX = Math.random() * 2 - 1;
               this.inertieY = Math.random() * 2 - 1;
            }
            else
            {
               this.inertieX += _loc3_ / _loc5_ * param2;
               this.inertieY += _loc4_ / _loc5_ * param2;
            }
            this.aucuneInertie = false;
            this.inertieTimer.start();
         }
      }
      
      protected function gerer_inertie(param1:TimerEvent) : void
      {
         x += this.inertieX;
         y += this.inertieY;
         if(this.inertieX < 0)
         {
            this.inertieX = Math.min(this.inertieX + this.INERTIE_DECELERATION,0);
         }
         else if(this.inertieX > 0)
         {
            this.inertieX = Math.max(this.inertieX - this.INERTIE_DECELERATION,0);
         }
         if(this.inertieY < 0)
         {
            this.inertieY = Math.min(this.inertieY + this.INERTIE_DECELERATION,0);
         }
         else if(this.inertieY > 0)
         {
            this.inertieY = Math.max(this.inertieY - this.INERTIE_DECELERATION,0);
         }
         if(this.inertieX == 0 && this.inertieY == 0)
         {
            this.aucuneInertie = true;
            this.inertieTimer.stop();
         }
         dispatchEvent(new PersosEvent(PersosEvent.DEPLACER));
      }
      
      protected function init_deplacement() : void
      {
      }
      
      public function aller(param1:Number, param2:Number) : void
      {
         this.destinationX = param1;
         this.destinationY = param2;
         this.init_deplacement();
         this.deplacementTimer.start();
         this.orienter();
      }
      
      public function arreter() : void
      {
         this.deplacementTimer.stop();
         this._pas = 0;
         dispatchEvent(new PersosEvent(PersosEvent.DEPLACER));
      }
      
      public function get enAttente() : Boolean
      {
         return Boolean(this.deplacementTimer) && !this.deplacementTimer.running;
      }
      
      protected function orienter() : void
      {
         var _loc2_:int = 0;
         var _loc1_:Number = Math.atan2(this.destinationY - y,this.destinationX - x);
         if(_loc1_ >= -0.78 && _loc1_ < 0.78)
         {
            _loc2_ = MessagePersoOrienter.DROITE;
         }
         else if(_loc1_ >= 0.78 && _loc1_ < 2.35)
         {
            _loc2_ = MessagePersoOrienter.BAS;
         }
         else if(_loc1_ >= 2.35 || _loc1_ < -2.35)
         {
            _loc2_ = MessagePersoOrienter.GAUCHE;
         }
         else
         {
            _loc2_ = MessagePersoOrienter.HAUT;
         }
         if(_loc2_ != this.orientation)
         {
            this.orientation = _loc2_;
            dispatchEvent(new PersosEvent(PersosEvent.ORIENTER));
         }
      }
      
      protected function deplacer(param1:TimerEvent) : void
      {
         var _loc2_:Number = NaN;
         var _loc3_:Number = NaN;
         var _loc4_:Number = NaN;
         var _loc5_:Number = NaN;
         _loc2_ = this.destinationX - x;
         _loc3_ = this.destinationY - y;
         _loc4_ = Math.sqrt(_loc2_ * _loc2_ + _loc3_ * _loc3_);
         _loc5_ = this.vitesse * MULTIPLICATEUR_VITESSE * (this.volant ? 1 : Terrain.case_vitesse(x,y));
         if(_loc4_ < _loc5_)
         {
            x = this.destinationX;
            y = this.destinationY;
            this.arreter();
         }
         else
         {
            x += _loc5_ * _loc2_ / _loc4_;
            y += _loc5_ * _loc3_ / _loc4_;
            if(this._pas > 2)
            {
               this._pas = 0;
            }
            else
            {
               ++this._pas;
            }
         }
         this.gerer_deplacement_terrain();
         dispatchEvent(new PersosEvent(PersosEvent.DEPLACER));
      }
      
      public function gerer_deplacement_terrain() : void
      {
         var _loc1_:String = null;
         if(!this.volant)
         {
            this.decalageY = Terrain.case_DecalageY(x,y);
            _loc1_ = Terrain.case_effet(x,y);
            if(Boolean(_loc1_) && Boolean(vivant) && (this is Animal || this is Artisan))
            {
               dispatchEvent(new EffetEvent(EffetEvent.EFFET,x,y,_loc1_,0,0,largeur * 0.02,largeur * 0.02));
            }
         }
      }
      
      public function get pas() : int
      {
         return this._pas == 2 ? 0 : this._pas;
      }
      
      public function set decalageY(param1:int) : void
      {
         if(this._decalageY != param1)
         {
            this._decalageY = param1;
            dispatchEvent(new PersosEvent(PersosEvent.DECALER_Y));
         }
      }
      
      public function get decalageY() : int
      {
         return this._decalageY;
      }
      
      override public function mourir() : void
      {
         this.arreter();
         super.mourir();
      }
      
      override public function pause() : void
      {
         if(this.deplacementTimer.running)
         {
            this.deplacementTimer.stop();
            this.pauseDeplacement = true;
         }
         this.inertieTimer.stop();
         if(this.volantTimer)
         {
            this.volantTimer.stop();
         }
         if(this.timerDemarrerIA)
         {
            this.timerDemarrerIA.stop();
         }
         if(this.iaTimer)
         {
            this.arreter_ia();
         }
         super.pause();
      }
      
      override public function reprendre() : void
      {
         if(this.pauseDeplacement)
         {
            this.deplacementTimer.start();
            this.pauseDeplacement = false;
         }
         if(!this.aucuneInertie)
         {
            this.inertieTimer.start();
         }
         if(this.volantTimer)
         {
            this.volantTimer.start();
         }
         this.init_ia(true);
         super.reprendre();
      }
      
      override public function detruire() : void
      {
         super.detruire();
         this.deplacementTimer.removeEventListener(TimerEvent.TIMER,this.deplacer);
         this.deplacementTimer.stop();
         this.deplacementTimer = null;
         this.inertieTimer.removeEventListener(TimerEvent.TIMER,this.gerer_inertie);
         this.inertieTimer.stop();
         this.inertieTimer = null;
         if(this.iaTimer)
         {
            this.iaTimer.removeEventListener(TimerEvent.TIMER,this.gerer_ia);
            this.iaTimer.stop();
            this.iaTimer = null;
         }
         this.ia = false;
         if(this.volantTimer)
         {
            this.volantTimer.removeEventListener(TimerEvent.TIMER,this.voler);
            this.volantTimer.stop();
            this.volantTimer = null;
         }
         if(this.timerDemarrerIA)
         {
            this.timerDemarrerIA.removeEventListener(TimerEvent.TIMER_COMPLETE,this.demarrer_ia);
            this.timerDemarrerIA.stop();
            this.timerDemarrerIA = null;
         }
         if(this.penalites)
         {
            this.penalites.removeEventListener(Event.CHANGE,this.appliquer_penalites);
            this.penalites.detruire();
            this.penalites = null;
         }
         this.poisons.removeEventListener(PoisonEvent.DEGATS,this.degats_poison);
         this.poisons.detruire();
         this.poisons = null;
      }
   }
}

