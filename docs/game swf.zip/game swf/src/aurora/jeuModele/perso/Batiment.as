package aurora.jeuModele.perso
{
   import aurora.jeuModele.Donnees;
   import aurora.jeuModele.IA;
   import flash.events.Event;
   import flash.events.TimerEvent;
   import flash.utils.Timer;
   
   public class Batiment extends Vivant
   {
      
      public var repair:Object;
      
      public var reparationVie:int;
      
      public var constructionDuree:int;
      
      public var bonusCompetence:String;
      
      private var productionAuto:Timer;
      
      private var productionNo:int;
      
      public function Batiment()
      {
         super();
      }
      
      override public function init(param1:Object) : void
      {
         super.init(param1);
         if(param1.repair)
         {
            this.repair = param1.repair;
            this.reparationVie = param1.repair.health;
            this.constructionDuree = param1.repair.time * 1000;
            this.bonusCompetence = param1.repair.bonusSkill;
         }
         if(param1.autoProduce)
         {
            this.productionAuto = new Timer(1000,param1.autoProduce[0].time);
            this.productionAuto.addEventListener(TimerEvent.TIMER_COMPLETE,this.production_auto);
            this.productionAuto.start();
         }
      }
      
      private function production_auto(param1:Event) : void
      {
         var _loc3_:String = null;
         var _loc4_:int = 0;
         var _loc2_:Object = Donnees.donnees[race].autoProduce[this.productionNo].createCharacter;
         if(_loc2_)
         {
            for(_loc3_ in _loc2_)
            {
               _loc4_ = 0;
               while(_loc4_ < _loc2_[_loc3_])
               {
                  if(IA.peut_invoquer(equipe,1))
                  {
                     dispatchEvent(new CreationPersoEvent(CreationPersoEvent.CREER,_loc3_,x,y,equipe,1,"",false));
                  }
                  _loc4_++;
               }
            }
         }
         ++this.productionNo;
         if(this.productionNo >= Donnees.donnees[race].autoProduce.length)
         {
            this.productionNo = 0;
         }
         this.productionAuto.repeatCount = Donnees.donnees[race].autoProduce[this.productionNo].time;
         this.productionAuto.reset();
         this.productionAuto.start();
      }
      
      public function get reparable() : Boolean
      {
         return vie.score < vie.scoreMax && Boolean(this.repair);
      }
      
      public function reparer(param1:int) : void
      {
         editer_vie(this.reparationVie * param1);
      }
      
      public function get reparationRestante() : int
      {
         return Math.ceil((vie.scoreMax - vie.score) / this.reparationVie);
      }
      
      override public function pause() : void
      {
         if(this.productionAuto)
         {
            this.productionAuto.stop();
         }
         super.pause();
      }
      
      override public function reprendre() : void
      {
         if(this.productionAuto)
         {
            this.productionAuto.start();
         }
         super.reprendre();
      }
      
      override public function gerer_mort(param1:Object) : void
      {
         super.gerer_mort(param1);
         Tresor.piller_batiment(this);
      }
      
      override public function mourir() : void
      {
         IA.virer_residents(this);
         super.mourir();
      }
      
      override public function detruire() : void
      {
         super.detruire();
         this.repair = null;
         if(this.productionAuto)
         {
            this.productionAuto.removeEventListener(TimerEvent.TIMER,this.production_auto);
            this.productionAuto.stop();
            this.productionAuto = null;
         }
      }
   }
}

