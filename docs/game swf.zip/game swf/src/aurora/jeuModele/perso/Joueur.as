package aurora.jeuModele.perso
{
   import aurora.MainJeu;
   import aurora.jeuModele.Donnees;
   import aurora.jeuModele.IA;
   import aurora.jeuModele.PersosEvent;
   import aurora.jeuModele.perso.attaque.Attaque;
   import aurora.jeuModele.perso.bestaire.Bestiaire;
   import aurora.jeuModele.perso.caracteristiquesPrimaires.CaracteristiquePrimaire;
   import aurora.jeuModele.perso.caracteristiquesPrimaires.CaracteristiquePrimaireEvent;
   import aurora.jeuModele.perso.caracteristiquesPrimaires.CaracteristiquePrimaireJoueur;
   import aurora.jeuModele.perso.caracteristiquesSecondaires.CaracteristiqueSecondaireEvent;
   import aurora.jeuModele.perso.caracteristiquesSecondaires.CaracteristiqueSecondaireJoueur;
   import aurora.jeuModele.perso.competences.CompetenceEvent;
   import aurora.jeuModele.perso.competences.CompetenceJoueur;
   import aurora.jeuModele.perso.joueur.JaugeEvent;
   import aurora.jeuModele.perso.joueur.JoueurEvent;
   import aurora.jeuModele.perso.joueur.NiveauEvent;
   import aurora.jeuModele.perso.joueur.NiveauJoueur;
   import aurora.jeuModele.perso.objets.ObjetEquipe;
   import aurora.jeuModele.perso.objets.ObjetEvent;
   import aurora.jeuModele.perso.objets.ObjetTemporaireEvent;
   import aurora.jeuModele.perso.objets.ObjetTemporaireJoueur;
   import aurora.jeuModele.perso.objets.ObjetTemporaireJoueurEvent;
   import aurora.jeuModele.perso.rechargements.RechargementsJoueur;
   import aurora.jeuModele.perso.ressources.RessourceEvent;
   import aurora.jeuModele.perso.ressources.RessourceJoueur;
   import aurora.messages.joueur.MessageJoueurCible;
   import aurora.messages.joueur.MessageJoueurDonnees;
   import aurora.messages.objet.MessageObjetDonnees;
   import flash.events.Event;
   import flash.events.TimerEvent;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.Timer;
   
   public class Joueur extends Artisan
   {
      
      private const COEF_XP_ATTAQUE:Number = 7;
      
      private const COEF_XP_DEFENSE:Number = 10;
      
      private const COEF_XP_ATTAQUE_COMPETENCE:Number = 28;
      
      private const COEF_XP_DEFENSE_COMPETENCE:Number = 40;
      
      public var nom:String;
      
      public var niveau:NiveauJoueur;
      
      private var morts:int;
      
      private var xpAttaque:Vector.<Object>;
      
      private var xpDefense:Vector.<Object>;
      
      private var xpPrimaryCharacteristic:Dictionary;
      
      private var xpSecondaryCharacteristic:Dictionary;
      
      private var xpSkill:Dictionary;
      
      private var coefXp:Number = 1;
      
      public var bestiaire:Bestiaire;
      
      private var timerJauge:Timer;
      
      private var donneesMods:Object;
      
      public var client:Boolean;
      
      public var noClient:int;
      
      public var noJoueur:int;
      
      private var tempsDepart:Number;
      
      public function Joueur()
      {
         super();
         rechargement = new RechargementsJoueur();
         this.niveau = new NiveauJoueur();
         this.xpAttaque = new Vector.<Object>();
         this.xpDefense = new Vector.<Object>();
         this.xpPrimaryCharacteristic = new Dictionary();
         this.xpSecondaryCharacteristic = new Dictionary();
         this.xpSkill = new Dictionary();
         this.bestiaire = new Bestiaire();
         this.timerJauge = new Timer(500);
         this.timerJauge.addEventListener(TimerEvent.TIMER,this.actualiser_jauge);
      }
      
      public static function convertir_donnees(param1:Object) : Object
      {
         var _loc2_:Object = null;
         var _loc3_:String = null;
         var _loc4_:int = 0;
         if(param1.caracs)
         {
            for each(_loc2_ in param1.caracs)
            {
               for(_loc3_ in _loc2_)
               {
                  _loc2_[_loc3_] = calculer_xp(_loc2_[_loc3_]["xp"],CaracteristiquePrimaireJoueur.xpPremierNivSuivant,CaracteristiquePrimaireJoueur.xpNivSup);
                  _loc4_ += _loc2_[_loc3_]["xp"];
               }
            }
         }
         if(param1.caracs2)
         {
            for each(_loc2_ in param1.caracs2)
            {
               for(_loc3_ in _loc2_)
               {
                  _loc2_[_loc3_] = calculer_xp(_loc2_[_loc3_]["xp"],CaracteristiqueSecondaireJoueur.xpPremierNivSuivant,CaracteristiqueSecondaireJoueur.xpNivSup);
                  _loc4_ += _loc2_[_loc3_]["xp"];
               }
            }
         }
         if(param1.skills)
         {
            for each(_loc2_ in param1.skills)
            {
               for(_loc3_ in _loc2_)
               {
                  _loc2_[_loc3_] = calculer_xp(_loc2_[_loc3_]["xp"],CompetenceJoueur.xpPremierNivSuivant,CompetenceJoueur.xpNivSup);
                  _loc4_ += _loc2_[_loc3_]["xp"];
               }
            }
         }
         param1.level = calculer_xp(_loc4_,NiveauJoueur.xpPremierNivSuivant,NiveauJoueur.xpNivSup);
         return param1;
      }
      
      private static function calculer_xp(param1:int, param2:int, param3:int) : Object
      {
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         var _loc6_:int = param2;
         while(param1 >= _loc6_)
         {
            _loc4_++;
            _loc5_ = _loc6_;
            _loc6_ += param2 + _loc4_ * param3;
         }
         return {
            "lvl":_loc4_,
            "prev":_loc5_,
            "next":_loc6_,
            "xp":param1
         };
      }
      
      public function init_client(param1:int) : void
      {
         var _loc2_:String = null;
         this.client = true;
         this.noClient = param1 - 1;
         this.noJoueur = param1;
         for(_loc2_ in caracteristiquesPrimaires)
         {
            caracteristiquesPrimaires[_loc2_].noJoueur = this.noJoueur;
         }
         for(_loc2_ in caracteristiquesSecondaires)
         {
            caracteristiquesSecondaires[_loc2_].noJoueur = this.noJoueur;
         }
         for(_loc2_ in competences)
         {
            competences[_loc2_].noJoueur = this.noJoueur;
         }
         for(_loc2_ in ressources)
         {
            ressources[_loc2_].noJoueur = this.noJoueur;
         }
         this.bestiaire.noJoueur = this.noJoueur;
         rechargement.noJoueur = this.noJoueur;
      }
      
      override public function init(param1:Object) : void
      {
         var _loc2_:String = null;
         super.init(param1);
         vie = new CaracteristiquePrimaireJoueur("health",param1.health);
         for(_loc2_ in caracteristiquesPrimaires)
         {
            if(caracteristiquesPrimaires[_loc2_] is CaracteristiquePrimaire)
            {
               caracteristiquesPrimaires[_loc2_] = new CaracteristiquePrimaireJoueur(caracteristiquesPrimaires[_loc2_].id,caracteristiquesPrimaires[_loc2_].score);
            }
            caracteristiquesPrimaires[_loc2_].addEventListener(CaracteristiquePrimaireEvent.GAGNER_XP,this.gagner_xp_caracteristiquesPrimaires);
            caracteristiquesPrimaires[_loc2_].addEventListener(CaracteristiquePrimaireEvent.RECUPERER,this.recuperer_carac);
         }
         caracteristiquesPrimaires["health"] = vie;
         caracteristiquesPrimaires["health"].addEventListener(CaracteristiquePrimaireEvent.ACTUALISER_SCORE,actualiser_vie);
         caracteristiquesPrimaires["health"].addEventListener(CaracteristiquePrimaireEvent.ACTUALISER_SCORE_MAX,actualiser_vie);
         caracteristiquesPrimaires["health"].addEventListener(CaracteristiquePrimaireEvent.RECUPERER,this.recuperer_carac);
         for(_loc2_ in caracteristiquesSecondaires)
         {
            caracteristiquesSecondaires[_loc2_] = new CaracteristiqueSecondaireJoueur(caracteristiquesSecondaires[_loc2_].id,caracteristiquesSecondaires[_loc2_].score);
         }
         caracteristiquesSecondaires["attack"].addEventListener(CaracteristiqueSecondaireEvent.ACTUALISER_SCORE,this.actualiser_attaque);
         caracteristiquesSecondaires["defense"].addEventListener(CaracteristiqueSecondaireEvent.ACTUALISER_SCORE,this.actualiser_defense);
         for(_loc2_ in competences)
         {
            competences[_loc2_] = new CompetenceJoueur(competences[_loc2_].id,competences[_loc2_].score,caracteristiquesSecondaires[Donnees.donnees[competences[_loc2_].id].defaultScore],param1[_loc2_] ? int(param1[_loc2_]) : 0);
         }
         for(_loc2_ in ressources)
         {
            ressources[_loc2_] = new RessourceJoueur(ressources[_loc2_].id,ressources[_loc2_].quantiteMax,ressources[_loc2_].illimite);
         }
      }
      
      private function actualiser_competence(param1:CompetenceEvent = null) : void
      {
         var _loc2_:String = null;
         for(_loc2_ in competences)
         {
            competences[_loc2_].removeEventListener(CompetenceEvent.ACTUALISER_SCORE,this.actualiser_competence);
         }
         this.actualiser_bonus();
         for(_loc2_ in competences)
         {
            competences[_loc2_].addEventListener(CompetenceEvent.ACTUALISER_SCORE,this.actualiser_competence);
         }
      }
      
      private function recuperer_carac(param1:CaracteristiquePrimaireEvent) : void
      {
         IA.recuperer_caracteristiquePrimaire(this,param1.currentTarget.id);
      }
      
      public function recuperer_infos() : void
      {
         var _loc1_:Object = null;
         var _loc2_:int = 0;
         dispatchEvent(new JoueurEvent(JoueurEvent.ACTUALISER_INFOS,MessageJoueurDonnees.NOM,this.nom));
         dispatchEvent(new JoueurEvent(JoueurEvent.ACTUALISER_INFOS,MessageJoueurDonnees.NIVEAU,String(this.niveau.niveau)));
         dispatchEvent(new JoueurEvent(JoueurEvent.ACTUALISER_INFOS,MessageJoueurDonnees.RACE,race));
         for each(_loc1_ in caracteristiquesPrimaires)
         {
            _loc1_.recuperer_infos();
         }
         for each(_loc1_ in caracteristiquesSecondaires)
         {
            _loc1_.recuperer_infos();
         }
         dispatchEvent(new JoueurEvent(JoueurEvent.ACTUALISER_INFOS,MessageJoueurDonnees.VITESSE,String(vitesse * 20)));
         for each(_loc1_ in competences)
         {
            _loc1_.recuperer_infos();
         }
         for each(_loc1_ in ressources)
         {
            _loc1_.recuperer_infos();
         }
         while(_loc2_ < objets.length)
         {
            this.ajouter_objet3(_loc2_);
            _loc2_++;
         }
         dispatchEvent(new JoueurEvent(JoueurEvent.ACTUALISER_INFOS,MessageJoueurDonnees.RESISTANCES,"del"));
         for(_loc1_ in resistances)
         {
            dispatchEvent(new JoueurEvent(JoueurEvent.ACTUALISER_INFOS,MessageJoueurDonnees.RESISTANCES,_loc1_ + "|" + resistances[_loc1_]));
         }
         this.bestiaire.recuperer_infos();
         dispatchEvent(new JoueurEvent(JoueurEvent.ACTUALISER_INFOS,MessageJoueurDonnees.MAISON,String(_possedeMaison)));
         dispatchEvent(new JoueurEvent(JoueurEvent.ACTUALISER_INFOS,MessageJoueurDonnees.ROI,String(_roi)));
      }
      
      override public function set roi(param1:Boolean) : void
      {
         super.roi = param1;
         if(_roi)
         {
            dispatchEvent(new JoueurEvent(JoueurEvent.ACTUALISER_INFOS,MessageJoueurDonnees.ROI,String(param1)));
         }
      }
      
      private function cloneObject(param1:Object) : *
      {
         var _loc2_:ByteArray = new ByteArray();
         _loc2_.writeObject(param1);
         _loc2_.position = 0;
         return _loc2_.readObject();
      }
      
      public function charger(param1:Object) : void
      {
         var _loc2_:Object = null;
         var _loc3_:String = null;
         var _loc4_:int = 0;
         var _loc5_:Date = null;
         this.nom = param1.name;
         this.niveau.removeEventListener(NiveauEvent.GAIN_NIVEAU,this.actualiser_niveau);
         this.donneesMods = new Object();
         this.donneesMods["caracs"] = new Object();
         if(param1.caracs)
         {
            for each(_loc2_ in param1.caracs)
            {
               for(_loc3_ in _loc2_)
               {
                  if(caracteristiquesPrimaires[_loc3_])
                  {
                     if(_loc2_[_loc3_]["lvl"])
                     {
                        caracteristiquesPrimaires[_loc3_].charger(_loc2_[_loc3_]);
                     }
                     else
                     {
                        _loc4_ = int(_loc2_[_loc3_]["xp"]);
                        caracteristiquesPrimaires[_loc3_].xp = _loc4_;
                        this.niveau.xp += _loc4_;
                     }
                  }
                  else if(_loc2_[_loc3_]["xp"])
                  {
                     this.donneesMods.caracs[_loc3_] = this.cloneObject(_loc2_);
                  }
               }
            }
         }
         this.donneesMods["caracs2"] = new Object();
         if(param1.caracs2)
         {
            caracteristiquesSecondaires["attack"].removeEventListener(CaracteristiqueSecondaireEvent.ACTUALISER_SCORE,this.actualiser_attaque);
            caracteristiquesSecondaires["defense"].removeEventListener(CaracteristiqueSecondaireEvent.ACTUALISER_SCORE,this.actualiser_defense);
            for each(_loc2_ in param1.caracs2)
            {
               for(_loc3_ in _loc2_)
               {
                  if(caracteristiquesSecondaires[_loc3_])
                  {
                     if(_loc2_[_loc3_]["lvl"])
                     {
                        caracteristiquesSecondaires[_loc3_].charger(_loc2_[_loc3_]);
                     }
                     else
                     {
                        _loc4_ = int(_loc2_[_loc3_]["xp"]);
                        caracteristiquesSecondaires[_loc3_].xp = _loc4_;
                        this.niveau.xp += _loc4_;
                     }
                  }
                  else if(_loc2_[_loc3_]["xp"])
                  {
                     this.donneesMods.caracs2[_loc3_] = this.cloneObject(_loc2_);
                  }
               }
            }
            caracteristiquesSecondaires["attack"].addEventListener(CaracteristiqueSecondaireEvent.ACTUALISER_SCORE,this.actualiser_attaque);
            caracteristiquesSecondaires["defense"].addEventListener(CaracteristiqueSecondaireEvent.ACTUALISER_SCORE,this.actualiser_defense);
            this.actualiser_attaque();
            this.actualiser_defense();
         }
         this.donneesMods["skills"] = new Object();
         if(param1.skills)
         {
            for each(_loc2_ in param1.skills)
            {
               for(_loc3_ in _loc2_)
               {
                  if(competences[_loc3_])
                  {
                     if(_loc2_[_loc3_]["lvl"])
                     {
                        competences[_loc3_].charger(_loc2_[_loc3_]);
                     }
                     else
                     {
                        _loc4_ = int(_loc2_[_loc3_]["xp"]);
                        competences[_loc3_].xp = _loc4_;
                        this.niveau.xp += _loc4_;
                     }
                  }
                  else if(_loc2_[_loc3_]["xp"])
                  {
                     this.donneesMods.skills[_loc3_] = this.cloneObject(_loc2_);
                  }
               }
            }
         }
         this.donneesMods["bestiary"] = new Object();
         if(param1.bestiary)
         {
            for(_loc3_ in param1.bestiary)
            {
               if(Donnees.donnees[_loc3_])
               {
                  this.bestiaire.ajouter(_loc3_,param1.bestiary[_loc3_].quantity);
               }
               else
               {
                  this.donneesMods.bestiary[_loc3_] = param1.bestiary[_loc3_];
               }
            }
         }
         if(param1.ui)
         {
            for(_loc2_ in param1.ui)
            {
               if(caracteristiquesPrimaires[_loc2_])
               {
                  caracteristiquesPrimaires[_loc2_].recuperationAuto = param1.ui[_loc2_];
               }
            }
         }
         else
         {
            for(_loc2_ in caracteristiquesPrimaires)
            {
               caracteristiquesPrimaires[_loc2_].recuperationAuto = true;
            }
         }
         if(param1.perks)
         {
            for(_loc3_ in param1.perks)
            {
               if(Donnees.donnees[_loc3_])
               {
                  ajouter_objet(_loc3_,1,param1.perks[_loc3_] - 1);
               }
            }
         }
         this.actualiser_competence();
         if(!(param1.level is int))
         {
            this.niveau.charger(param1.level);
         }
         this.niveau.addEventListener(NiveauEvent.GAIN_NIVEAU,this.actualiser_niveau);
         this.niveau.init();
         for(_loc3_ in caracteristiquesPrimaires)
         {
            caracteristiquesPrimaires[_loc3_].init();
         }
         for(_loc3_ in caracteristiquesSecondaires)
         {
            caracteristiquesSecondaires[_loc3_].init();
         }
         for(_loc3_ in competences)
         {
            competences[_loc3_].init2();
         }
         this.bestiaire.init();
         _loc5_ = new Date();
         this.tempsDepart = _loc5_.getTime();
      }
      
      override public function aller(param1:Number, param2:Number) : void
      {
         this.effacer_cible();
         super.aller(param1,param2);
         dispatchEvent(new CibleEvent(CibleEvent.ACTUALISER_CIBLE,MessageJoueurCible.ACTION_DEPLACEMENT,param1,param2));
      }
      
      override public function arreter() : void
      {
         this.effacer_cible();
         super.arreter();
         this.arreter_travail();
      }
      
      override public function payer_cout_creation_perso(param1:String) : void
      {
         super.payer_cout_creation_perso(param1);
         if(Donnees.donnees[param1].build.sound)
         {
            this.jouer_son_construction(Donnees.donnees[param1].build.sound);
         }
         this.gagner_xp(Donnees.donnees[param1].build,1);
      }
      
      override protected function arreter_deplacementTravail() : void
      {
         super.arreter_deplacementTravail();
         dispatchEvent(new CibleEvent(CibleEvent.ACTUALISER_CIBLE,MessageJoueurCible.ACTION_ARRET));
      }
      
      override protected function arreter_travail() : void
      {
         super.arreter_travail();
         if(this.timerJauge.running)
         {
            this.timerJauge.stop();
            dispatchEvent(new JaugeEvent(JaugeEvent.ACTUALISER_JAUGE_TRAVAIL,id,0));
         }
         dispatchEvent(new CibleEvent(CibleEvent.ACTUALISER_CIBLE,MessageJoueurCible.ACTION_ARRET));
      }
      
      private function effacer_cible() : void
      {
         if(cibleCombat)
         {
            cibleCombat.removeEventListener(PersosEvent.DEPLACER,this.actualiser_cibleAttaque);
            cibleCombat.removeEventListener(PersosEvent.EFFACER,this.effacer_cibleAttaque);
            cibleCombat = null;
         }
         if(cibleTravail)
         {
            cibleTravail.removeEventListener(PersosEvent.DEPLACER,this.actualiser_cibleTravail);
            cibleTravail.removeEventListener(PersosEvent.EFFACER,this.effacer_cibleTravail);
            cibleTravail.removeEventListener(RessourceEvent.ACTUALISER_QUANTITE,this.actualiser_quantite_cibleTravail);
            dispatchEvent(new CibleEvent(CibleEvent.ACTUALISER_QUANTITE,cibleTravail.id,0,0));
            cibleTravail = null;
         }
      }
      
      override public function aller_travailler(param1:Perso, param2:int = -1) : void
      {
         super.aller_travailler(param1,param2);
         if(cibleTravail is RessourceMobile || cibleTravail is BatimentMobile)
         {
            cibleTravail.addEventListener(PersosEvent.DEPLACER,this.actualiser_cibleTravail);
         }
         dispatchEvent(new CibleEvent(CibleEvent.ACTUALISER_CIBLE,MessageJoueurCible.ACTION_TRAVAIL,param1.x,param1.y - Math.min(param1.largeur,param1.hauteur) * 0.5));
         if(cibleTravail is RessourceMobile || cibleTravail is RessourceTerrain || cibleTravail is Atelier)
         {
            cibleTravail.addEventListener(RessourceEvent.ACTUALISER_QUANTITE,this.actualiser_quantite_cibleTravail);
            dispatchEvent(new CibleEvent(CibleEvent.ACTUALISER_QUANTITE,param1.id,Object(param1).quantite,Object(param1).quantiteMax));
         }
         cibleTravail.addEventListener(PersosEvent.EFFACER,this.effacer_cibleTravail);
      }
      
      override protected function deplacer_travail(param1:TimerEvent) : void
      {
         super.deplacer_travail(param1);
         if(travailTimer.running && travailTimer.hasEventListener(TimerEvent.TIMER))
         {
            if(cibleTravail is Mobile)
            {
               dispatchEvent(new CibleEvent(CibleEvent.ACTUALISER_CIBLE,MessageJoueurCible.ACTION_TRAVAIL,cibleTravail.x,cibleTravail.y - Math.min(cibleTravail.largeur,cibleTravail.hauteur) * 0.5));
            }
            if(Boolean(cibleTravail is BatimentResurrection || choixAmeliorationObjet) || Boolean(choixRenforcerObjet) || Boolean("production" in cibleTravail && choixProduction != -1 && Object(cibleTravail).production && choixProduction < Object(cibleTravail).production.length) && Boolean(Object(cibleTravail).production[choixProduction].time >= 2))
            {
               this.timerJauge.repeatCount = travailTimer.delay * 0.002;
               this.timerJauge.reset();
               this.timerJauge.start();
               dispatchEvent(new JaugeEvent(JaugeEvent.ACTUALISER_JAUGE_TRAVAIL,id,0.001));
            }
         }
      }
      
      override public function creer_objet(param1:Perso, param2:int) : void
      {
         this.effacer_cible();
         super.creer_objet(param1,param2);
      }
      
      private function actualiser_cibleTravail(param1:PersosEvent) : void
      {
         dispatchEvent(new CibleEvent(CibleEvent.ACTUALISER_CIBLE,MessageJoueurCible.ACTION_TRAVAIL,param1.currentTarget.x,param1.currentTarget.y - Math.min(param1.currentTarget.largeur,param1.currentTarget.hauteur) * 0.5));
         if(!(param1.currentTarget is BatimentMobile))
         {
            dispatchEvent(new CibleEvent(CibleEvent.ACTUALISER_QUANTITE,param1.currentTarget.id,param1.currentTarget.quantite,param1.currentTarget.quantiteMax));
         }
      }
      
      private function actualiser_quantite_cibleTravail(param1:RessourceEvent) : void
      {
         dispatchEvent(new CibleEvent(CibleEvent.ACTUALISER_QUANTITE,param1.currentTarget.id,param1.quantite,param1.currentTarget.quantiteMax));
      }
      
      private function effacer_cibleTravail(param1:PersosEvent) : void
      {
         param1.currentTarget.removeEventListener(PersosEvent.DEPLACER,this.actualiser_cibleTravail);
         param1.currentTarget.removeEventListener(PersosEvent.EFFACER,this.effacer_cibleTravail);
         dispatchEvent(new CibleEvent(CibleEvent.ACTUALISER_CIBLE,MessageJoueurCible.ACTION_ARRET));
         if(param1.currentTarget is RessourceTerrain || param1.currentTarget is RessourceMobile || param1.currentTarget is Atelier)
         {
            param1.currentTarget.removeEventListener(RessourceEvent.ACTUALISER_QUANTITE,this.actualiser_quantite_cibleTravail);
            dispatchEvent(new CibleEvent(CibleEvent.ACTUALISER_QUANTITE,param1.currentTarget.id,0,0));
         }
      }
      
      override protected function ressusciter(param1:TimerEvent) : void
      {
         super.ressusciter(param1);
         if(!travailTimer.running)
         {
            if(cibleTravail)
            {
               cibleTravail.removeEventListener(PersosEvent.DEPLACER,this.actualiser_cibleTravail);
            }
            if(cibleTravail)
            {
               cibleTravail.removeEventListener(PersosEvent.EFFACER,this.effacer_cibleTravail);
            }
            dispatchEvent(new CibleEvent(CibleEvent.ACTUALISER_CIBLE,MessageJoueurCible.ACTION_ARRET));
         }
      }
      
      protected function jouer_son_construction(param1:String) : void
      {
         var _loc2_:Object = null;
         _loc2_ = Donnees.donnees[param1];
         if(_loc2_)
         {
            dispatchEvent(new SonEvent(SonEvent.SON_TRAVAIL,_loc2_.chemin + _loc2_.files[int(Math.random() * _loc2_.files.length)],x,y));
         }
      }
      
      override protected function construire_batiment(param1:TimerEvent) : void
      {
         if(verifier_cible_travail())
         {
            if(cibleTravail is Fondations)
            {
               this.jouer_son_construction(Donnees.donnees[Fondations(cibleTravail).creation].build.sound);
            }
            else
            {
               this.jouer_son_construction(Donnees.donnees[cibleTravail.race].build.sound);
            }
         }
         super.construire_batiment(param1);
      }
      
      override protected function reparer_batiment(param1:TimerEvent = null) : void
      {
         if(verifier_cible_travail())
         {
            this.jouer_son_construction(Donnees.donnees[cibleTravail.race].repair.sound);
         }
         super.reparer_batiment(param1);
      }
      
      override protected function produire(param1:TimerEvent) : void
      {
         if(verifier_cible_travail())
         {
            if(choixAmeliorationObjet)
            {
               if(Boolean(choixAmeliorationObjet.no < objets.length) && Boolean(objets[choixAmeliorationObjet.no]) && objets[choixAmeliorationObjet.no].id == choixAmeliorationObjet.type)
               {
                  this.jouer_son_construction(Donnees.donnees[choixAmeliorationObjet.type].upgrade[choixAmeliorationObjet.choix].sound);
               }
            }
            else if(choixRenforcerObjet)
            {
               if(Boolean(choixRenforcerObjet.no < objets.length) && Boolean(objets[choixRenforcerObjet.no]) && objets[choixRenforcerObjet.no].id == choixRenforcerObjet.type)
               {
                  this.jouer_son_construction(Donnees.donnees[choixRenforcerObjet.type].enhance[0].sound);
               }
            }
            else if(Boolean(Object(cibleTravail).production) && Boolean(Object(cibleTravail).production[choixProduction].sound))
            {
               this.jouer_son_construction(Object(cibleTravail).production[choixProduction].sound);
            }
         }
         super.produire(param1);
         if(!travailTimer.running && !deplacementTravailTimer.running)
         {
            if(cibleTravail)
            {
               cibleTravail.removeEventListener(PersosEvent.DEPLACER,this.actualiser_cibleTravail);
            }
            if(cibleTravail)
            {
               cibleTravail.removeEventListener(PersosEvent.EFFACER,this.effacer_cibleTravail);
            }
            dispatchEvent(new CibleEvent(CibleEvent.ACTUALISER_CIBLE,MessageJoueurCible.ACTION_ARRET));
            dispatchEvent(new JaugeEvent(JaugeEvent.ACTUALISER_JAUGE_TRAVAIL,id,0));
         }
         else if(cibleTravail is BatimentResurrection || Boolean("production" in cibleTravail && choixProduction != -1) && (Boolean(Object(cibleTravail).production[choixProduction].time >= 2 || Object(cibleTravail).production[choixProduction].steps)))
         {
            this.timerJauge.reset();
            this.timerJauge.start();
            if(cibleTravail is Atelier && Boolean(Atelier(cibleTravail).production[choixProduction].steps))
            {
               dispatchEvent(new JaugeEvent(JaugeEvent.ACTUALISER_JAUGE_TRAVAIL,id,Atelier(cibleTravail).etapes_pcent(choixProduction)));
            }
            else
            {
               dispatchEvent(new JaugeEvent(JaugeEvent.ACTUALISER_JAUGE_TRAVAIL,id,0.001));
            }
         }
      }
      
      override protected function produire2(param1:Object, param2:int = 1, param3:int = 0, param4:int = 1) : void
      {
         super.produire2(param1,param2,param3,param4);
         Joueur(this).gagner_xp(param1,param4);
      }
      
      override public function set possedeMaison(param1:Boolean) : void
      {
         super.possedeMaison = param1;
         if(MainJeu.bacASable)
         {
            dispatchEvent(new JoueurEvent(JoueurEvent.ACTUALISER_INFOS,MessageJoueurDonnees.MAISON,String(false)));
         }
         else
         {
            dispatchEvent(new JoueurEvent(JoueurEvent.ACTUALISER_INFOS,MessageJoueurDonnees.MAISON,String(_possedeMaison)));
         }
      }
      
      override public function set dansMaison(param1:Boolean) : void
      {
         super.dansMaison = param1;
         dispatchEvent(new JoueurEvent(JoueurEvent.ACTUALISER_INFOS,MessageJoueurDonnees.DANS_MAISON,String(_dansMaison)));
      }
      
      override public function set maison(param1:Perso) : void
      {
         super.maison = param1;
         dispatchEvent(new JoueurEvent(JoueurEvent.ACTUALISER_INFOS,MessageJoueurDonnees.FINI_MAISON,""));
      }
      
      override protected function entrer() : void
      {
         var _loc1_:RessourceJoueur = null;
         super.entrer();
         if(batimentEntrer is BatimentCentreVille)
         {
            dispatchEvent(new JoueurEvent(JoueurEvent.ACTUALISER_INFOS,MessageJoueurDonnees.DANS_ENTREPOT,String(true)));
            for each(_loc1_ in BatimentCentreVille(batimentEntrer).ressources)
            {
               _loc1_.addEventListener(RessourceEvent.ACTUALISER_QUANTITE,this.actualiser_entrepot);
               _loc1_.dispatchEvent(new RessourceEvent(RessourceEvent.ACTUALISER_QUANTITE,_loc1_.id,_loc1_.quantite));
            }
         }
      }
      
      override public function sortir() : void
      {
         var _loc1_:RessourceJoueur = null;
         if(batimentEntrer is BatimentCentreVille)
         {
            dispatchEvent(new JoueurEvent(JoueurEvent.ACTUALISER_INFOS,MessageJoueurDonnees.DANS_ENTREPOT,String(false)));
            for each(_loc1_ in BatimentCentreVille(batimentEntrer).ressources)
            {
               _loc1_.removeEventListener(RessourceEvent.ACTUALISER_QUANTITE,this.actualiser_entrepot);
            }
         }
         super.sortir();
      }
      
      private function actualiser_entrepot(param1:RessourceEvent) : void
      {
         dispatchEvent(new RessourceEvent(RessourceEvent.ACTUALISER_ENTREPOT,param1.id,param1.quantite));
      }
      
      override public function attaquer(param1:Vivant) : void
      {
         this.effacer_cible();
         super.attaquer(param1);
         dispatchEvent(new CibleEvent(CibleEvent.ACTUALISER_CIBLE,param1 is BatimentDonjon ? MessageJoueurCible.ACTION_BOSS : (param1 is Combattant ? MessageJoueurCible.ACTION_ATTAQUE : MessageJoueurCible.ACTION_CHASSE),cibleCombat.x,cibleCombat.y - param1.hauteur * 0.5));
         cibleCombat.addEventListener(PersosEvent.DEPLACER,this.actualiser_cibleAttaque);
         cibleCombat.addEventListener(PersosEvent.EFFACER,this.effacer_cibleAttaque);
      }
      
      private function actualiser_cibleAttaque(param1:PersosEvent) : void
      {
         if(cibleCombat)
         {
            dispatchEvent(new CibleEvent(CibleEvent.ACTUALISER_CIBLE,cibleCombat is BatimentDonjon ? MessageJoueurCible.ACTION_BOSS : (cibleCombat is Combattant ? MessageJoueurCible.ACTION_ATTAQUE : MessageJoueurCible.ACTION_CHASSE),cibleCombat.x,cibleCombat.y - cibleCombat.hauteur * 0.5));
         }
      }
      
      override protected function verifier_cible_combat() : Boolean
      {
         if(cibleCombat)
         {
            if(cibleCombat.visible && cibleCombat.vivant)
            {
               return true;
            }
            this.effacer_cibleAttaque();
            cibleCombat = null;
            return false;
         }
         return false;
      }
      
      private function effacer_cibleAttaque(param1:PersosEvent = null) : void
      {
         if(cibleCombat)
         {
            cibleCombat.removeEventListener(PersosEvent.DEPLACER,this.actualiser_cibleAttaque);
            cibleCombat.removeEventListener(PersosEvent.EFFACER,this.effacer_cibleAttaque);
         }
         dispatchEvent(new CibleEvent(CibleEvent.ACTUALISER_CIBLE,MessageJoueurCible.ACTION_ARRET));
      }
      
      override protected function toucher4(param1:int, param2:int) : void
      {
         if(param2 > attaquesSupplementaires.length)
         {
            return;
         }
         this.gagner_xp_attaque((param2 == 0 ? param1 / attaque.score * attaque.tempsAttaque : param1 / attaquesSupplementaires[param2 - 1].score * attaquesSupplementaires[param2 - 1].tempsAttaque) / (1 + attaquesSupplementaires.length),param2);
      }
      
      override public function toucher5(param1:int) : void
      {
         var _loc2_:Number = param1 / vie.coefBonus;
         this.gagner_xp_defense(_loc2_ / defense);
         this.gagner_xp_caracteristiquesPrimaires2("health",_loc2_);
      }
      
      private function actualiser_jauge(param1:TimerEvent) : void
      {
         if(!verifier_cible_travail())
         {
            this.arreter();
         }
         if(cibleTravail is Atelier && choixProduction != -1 && choixProduction < Atelier(cibleTravail).production.length && Boolean(Atelier(cibleTravail).production[choixProduction].steps))
         {
            dispatchEvent(new JaugeEvent(JaugeEvent.ACTUALISER_JAUGE_TRAVAIL,id,Atelier(cibleTravail).etapes_pcent(choixProduction)));
         }
         else
         {
            dispatchEvent(new JaugeEvent(JaugeEvent.ACTUALISER_JAUGE_TRAVAIL,id,this.timerJauge.currentCount / this.timerJauge.repeatCount));
         }
      }
      
      private function actualiser_niveau(param1:NiveauEvent) : void
      {
         dispatchEvent(new JoueurEvent(JoueurEvent.ACTUALISER_INFOS,MessageJoueurDonnees.NIVEAU,String(this.niveau.niveau)));
      }
      
      private function actualiser_attaque(param1:CaracteristiqueSecondaireEvent = null) : void
      {
         attaqueBase = caracteristiquesSecondaires["attack"].score;
         dispatchEvent(new JoueurEvent(JoueurEvent.ACTUALISER_INFOS,MessageJoueurDonnees.ATTAQUE,this.infos_attaques));
      }
      
      private function actualiser_defense(param1:CaracteristiqueSecondaireEvent = null) : void
      {
         defenseBase = caracteristiquesSecondaires["defense"].score;
         dispatchEvent(new JoueurEvent(JoueurEvent.ACTUALISER_INFOS,MessageJoueurDonnees.DEFENSE,String(defense)));
      }
      
      public function gagner_xp(param1:Object, param2:Number) : void
      {
         var _loc3_:String = null;
         var _loc5_:Number = NaN;
         var _loc6_:Object = null;
         var _loc4_:Object = param1.xpSecondaryCharacteristic;
         if(_loc4_)
         {
            for(_loc3_ in _loc4_)
            {
               _loc5_ = _loc4_[_loc3_] * CaracteristiqueSecondaireJoueur.coefGainXp * param2 / caracteristiquesSecondaires[_loc3_].coefBonus * this.coefXp;
               caracteristiquesSecondaires[_loc3_].xp += _loc5_;
               this.niveau.xp += _loc5_;
               if(this.xpSecondaryCharacteristic[_loc3_])
               {
                  for each(_loc6_ in this.xpSecondaryCharacteristic[_loc3_])
                  {
                     this.gagner_xp_infos(_loc6_,_loc5_);
                  }
               }
            }
         }
         var _loc7_:Object = param1.xpSkill;
         if(_loc7_)
         {
            for(_loc3_ in _loc7_)
            {
               _loc5_ = _loc7_[_loc3_] * CompetenceJoueur.coefGainXp * param2 / competences[_loc3_].coefBonus * this.coefXp;
               competences[_loc3_].xp += _loc5_;
               this.niveau.xp += _loc5_;
               if(this.xpSkill[_loc3_])
               {
                  for each(_loc6_ in this.xpSkill[_loc3_])
                  {
                     this.gagner_xp_infos(_loc6_,_loc5_);
                  }
               }
            }
         }
      }
      
      public function gagner_xp_attaque(param1:Number, param2:int) : void
      {
         var _loc3_:Number = NaN;
         _loc3_ = param1 / caracteristiquesSecondaires["attack"].coefBonus * this.COEF_XP_ATTAQUE * this.coefXp;
         caracteristiquesSecondaires["attack"].xp += _loc3_;
         this.niveau.xp += _loc3_;
         if(this.xpAttaque.length >= param2 + 1)
         {
            this.gagner_xp(this.xpAttaque[param2],param1 / caracteristiquesSecondaires["attack"].coefBonus * this.COEF_XP_ATTAQUE_COMPETENCE);
         }
      }
      
      public function gagner_xp_defense(param1:Number) : void
      {
         var _loc2_:Number = NaN;
         var _loc3_:Object = null;
         _loc2_ = param1 / caracteristiquesSecondaires["defense"].coefBonus * this.COEF_XP_DEFENSE * this.coefXp;
         caracteristiquesSecondaires["defense"].xp += _loc2_;
         this.niveau.xp += _loc2_;
         for each(_loc3_ in this.xpDefense)
         {
            this.gagner_xp(_loc3_,1 / caracteristiquesSecondaires["defense"].coefBonus * param1 * this.COEF_XP_DEFENSE_COMPETENCE);
         }
      }
      
      private function gagner_xp_caracteristiquesPrimaires(param1:CaracteristiquePrimaireEvent) : void
      {
         this.gagner_xp_caracteristiquesPrimaires2(param1.id,param1.score);
      }
      
      private function gagner_xp_caracteristiquesPrimaires2(param1:String, param2:Number) : void
      {
         var _loc3_:Object = null;
         if(this.xpPrimaryCharacteristic[param1])
         {
            for each(_loc3_ in this.xpPrimaryCharacteristic[param1])
            {
               this.gagner_xp_infos(_loc3_,param2);
            }
         }
      }
      
      private function gagner_xp_infos(param1:Object, param2:Number = 1) : void
      {
         var _loc3_:String = null;
         var _loc4_:Number = NaN;
         var _loc5_:String = null;
         for(_loc5_ in param1)
         {
            switch(_loc5_)
            {
               case "xpSecondaryCharacteristic":
                  for(_loc3_ in param1[_loc5_])
                  {
                     _loc4_ = param1[_loc5_][_loc3_] * param2 * CaracteristiqueSecondaireJoueur.coefGainXp / caracteristiquesSecondaires[_loc3_].coefBonus;
                     caracteristiquesSecondaires[_loc3_].xp += _loc4_;
                     this.niveau.xp += _loc4_;
                  }
                  break;
               case "xpSkill":
                  for(_loc3_ in param1[_loc5_])
                  {
                     _loc4_ = param1[_loc5_][_loc3_] * param2 * CompetenceJoueur.coefGainXp / competences[_loc3_].coefBonus;
                     competences[_loc3_].xp += _loc4_;
                     this.niveau.xp += _loc4_;
                  }
            }
         }
      }
      
      override public function actualiser_bonus(param1:Object = null) : void
      {
         var _loc6_:String = null;
         var _loc7_:Object = null;
         var _loc8_:Object = null;
         var _loc9_:Object = null;
         var _loc2_:String = this.infos_attaques;
         var _loc3_:int = defense;
         var _loc4_:Number = vitesse;
         var _loc5_:Dictionary = new Dictionary();
         for(_loc6_ in resistances)
         {
            _loc5_[_loc6_] = resistances[_loc6_];
         }
         this.xpAttaque = new Vector.<Object>();
         this.xpDefense = new Vector.<Object>();
         for(_loc7_ in this.xpPrimaryCharacteristic)
         {
            delete this.xpPrimaryCharacteristic[_loc7_];
         }
         for(_loc7_ in this.xpSecondaryCharacteristic)
         {
            delete this.xpSecondaryCharacteristic[_loc7_];
         }
         for(_loc7_ in this.xpSkill)
         {
            delete this.xpSkill[_loc7_];
         }
         this.xpPrimaryCharacteristic = new Dictionary();
         this.xpSecondaryCharacteristic = new Dictionary();
         this.xpSkill = new Dictionary();
         this.coefXp = 1;
         for each(_loc8_ in objets)
         {
            if(_loc8_ is ObjetEquipe && Boolean(_loc8_.equipe))
            {
               this.actualiser_bonus_xp(_loc8_.donnees);
               if(_loc8_.donnees.addItems)
               {
                  for each(_loc9_ in _loc8_.donnees.addItems)
                  {
                     this.actualiser_bonus_xp(_loc9_);
                  }
               }
               if(_loc8_.donnees.bonusXP)
               {
                  this.coefXp += _loc8_.donnees.bonusXP;
               }
            }
         }
         super.actualiser_bonus();
         if(_loc2_ != this.infos_attaques)
         {
            dispatchEvent(new JoueurEvent(JoueurEvent.ACTUALISER_INFOS,MessageJoueurDonnees.ATTAQUE,this.infos_attaques));
         }
         if(_loc3_ != defense)
         {
            dispatchEvent(new JoueurEvent(JoueurEvent.ACTUALISER_INFOS,MessageJoueurDonnees.DEFENSE,String(defense)));
         }
         if(_loc4_ != vitesse)
         {
            dispatchEvent(new JoueurEvent(JoueurEvent.ACTUALISER_INFOS,MessageJoueurDonnees.VITESSE,String(vitesse * 20)));
         }
         for(_loc6_ in caracteristiquesPrimaires)
         {
            caracteristiquesPrimaires[_loc6_].coefXp = this.coefXp;
         }
         for(_loc6_ in resistances)
         {
            dispatchEvent(new JoueurEvent(JoueurEvent.ACTUALISER_INFOS,MessageJoueurDonnees.RESISTANCES,_loc6_ + "|" + resistances[_loc6_]));
            if(_loc5_[_loc6_])
            {
               delete _loc5_[_loc6_];
            }
         }
         for(_loc6_ in _loc5_)
         {
            dispatchEvent(new JoueurEvent(JoueurEvent.ACTUALISER_INFOS,MessageJoueurDonnees.RESISTANCES,_loc6_ + "|-1"));
            delete _loc5_[_loc6_];
         }
         _loc5_ = null;
         for each(_loc8_ in objets)
         {
            if(_loc8_.quantiteMax)
            {
               _loc8_.actualiser_quantite_max(competences);
            }
         }
      }
      
      private function actualiser_bonus_xp(param1:Object) : void
      {
         var _loc2_:String = null;
         if(param1.xpAttack)
         {
            this.xpAttaque.push(param1.xpAttack);
         }
         if(param1.xpDefense)
         {
            this.xpDefense.push(param1.xpDefense);
         }
         if(param1.xpPrimaryCharacteristic)
         {
            for(_loc2_ in param1.xpPrimaryCharacteristic)
            {
               if(!this.xpPrimaryCharacteristic[_loc2_])
               {
                  this.xpPrimaryCharacteristic[_loc2_] = new Vector.<Object>();
               }
               this.xpPrimaryCharacteristic[_loc2_].push(param1.xpPrimaryCharacteristic[_loc2_]);
            }
         }
         if(param1.xpSecondaryCharacteristic)
         {
            for(_loc2_ in param1.xpSecondaryCharacteristic)
            {
               if(!this.xpSecondaryCharacteristic[_loc2_])
               {
                  this.xpSecondaryCharacteristic[_loc2_] = new Vector.<Object>();
               }
               this.xpSecondaryCharacteristic[_loc2_].push(param1.xpSecondaryCharacteristic[_loc2_]);
            }
         }
         if(param1.xpSkill)
         {
            for(_loc2_ in param1.xpSkill)
            {
               if(!this.xpSkill[_loc2_])
               {
                  this.xpSkill[_loc2_] = new Vector.<Object>();
               }
               this.xpSkill[_loc2_].push(param1.xpSkill[_loc2_]);
            }
         }
      }
      
      private function get infos_attaques() : String
      {
         var _loc2_:Attaque = null;
         var _loc1_:String = String(attaque.score);
         for each(_loc2_ in attaquesSupplementaires)
         {
            _loc1_ += " / " + String(_loc2_.score);
         }
         return _loc1_;
      }
      
      public function sauvegarder() : Object
      {
         var _loc2_:Object = null;
         var _loc3_:CaracteristiquePrimaireJoueur = null;
         var _loc4_:CaracteristiqueSecondaireJoueur = null;
         var _loc5_:CompetenceJoueur = null;
         var _loc6_:String = null;
         var _loc1_:Object = new Object();
         _loc1_.race = race;
         _loc1_.level = this.niveau.niveau;
         _loc1_.caracs = new Array();
         for each(_loc3_ in caracteristiquesPrimaires)
         {
            _loc1_.caracs.push(_loc3_.sauvegarde());
         }
         for each(_loc2_ in this.donneesMods.caracs)
         {
            _loc1_.caracs.push(_loc2_);
         }
         _loc1_.caracs2 = new Array();
         for each(_loc4_ in caracteristiquesSecondaires)
         {
            _loc1_.caracs2.push(_loc4_.sauvegarde());
         }
         for each(_loc2_ in this.donneesMods.caracs2)
         {
            _loc1_.caracs2.push(_loc2_);
         }
         _loc1_.skills = new Array();
         for each(_loc5_ in competences)
         {
            _loc1_.skills.push(_loc5_.sauvegarde());
         }
         for each(_loc2_ in this.donneesMods.skills)
         {
            _loc1_.skills.push(_loc2_);
         }
         _loc1_.bestiary = this.bestiaire.sauvegarde();
         for(_loc6_ in this.donneesMods.bestiary)
         {
            _loc1_.bestiary[_loc6_] = this.donneesMods.bestiary[_loc6_];
         }
         return _loc1_;
      }
      
      public function charger_equipement(param1:Object) : void
      {
         var _loc2_:Object = null;
         for each(_loc2_ in param1.items)
         {
            if(Donnees.donnees[_loc2_.id])
            {
               ajouter_objet(_loc2_.id,_loc2_.q,_loc2_.u ? int(_loc2_.u) : 0);
               if(objets[objets.length - 1] is ObjetEquipe)
               {
                  objets[objets.length - 1].equipe = _loc2_.e;
                  objets[objets.length - 1].gauche = _loc2_.l;
               }
            }
         }
         for each(_loc2_ in param1.resources)
         {
            ressources[_loc2_.id].quantite = _loc2_.q;
         }
      }
      
      public function sauvegarder_equipement() : Object
      {
         var _loc2_:RessourceJoueur = null;
         var _loc3_:Object = null;
         var _loc4_:Object = null;
         var _loc1_:Object = new Object();
         _loc1_.resources = new Array();
         for each(_loc2_ in ressources)
         {
            if(_loc2_.quantite > 0)
            {
               _loc1_.resources.push({
                  "id":_loc2_.id,
                  "q":_loc2_.quantite
               });
            }
         }
         _loc1_.items = new Array();
         for each(_loc4_ in objets)
         {
            if(!(_loc4_ is ObjetTemporaireJoueur) && !Donnees.donnees[_loc4_.id].perk)
            {
               _loc3_ = new Object();
               _loc3_.id = _loc4_.id;
               _loc3_.q = _loc4_.quantite;
               if(_loc4_ is ObjetEquipe)
               {
                  if(_loc4_.equipe)
                  {
                     _loc3_.e = true;
                  }
                  if(_loc4_.gauche)
                  {
                     _loc3_.l = true;
                  }
               }
               if(_loc4_.renforcer)
               {
                  _loc3_.u = _loc4_.renforcer;
               }
               _loc1_.items.push(_loc3_);
            }
         }
         return _loc1_;
      }
      
      public function statistiques() : Object
      {
         var _loc2_:Number = NaN;
         var _loc3_:String = null;
         var _loc1_:Object = new Object();
         var _loc4_:Date = new Date();
         _loc1_.time = Math.floor((_loc4_.getTime() - this.tempsDepart) * 0.001);
         _loc1_.levelStart = Math.floor(this.niveau.niveauDepart);
         _loc1_.levelEnd = this.niveau.niveau;
         _loc1_.level = this.niveau.statistiques();
         _loc1_.caracs = new Object();
         for(_loc3_ in caracteristiquesPrimaires)
         {
            _loc2_ = Number(caracteristiquesPrimaires[_loc3_].statistiques());
            if(_loc2_ >= 0.01)
            {
               _loc1_.caracs[_loc3_] = _loc2_;
            }
         }
         for(_loc3_ in caracteristiquesSecondaires)
         {
            _loc2_ = Number(caracteristiquesSecondaires[_loc3_].statistiques());
            if(_loc2_ >= 0.01)
            {
               _loc1_.caracs[_loc3_] = _loc2_;
            }
         }
         _loc1_.skills = new Object();
         for(_loc3_ in competences)
         {
            _loc2_ = Number(competences[_loc3_].statistiques());
            if(_loc2_ >= 0.01)
            {
               _loc1_.skills[_loc3_] = _loc2_;
            }
         }
         _loc1_.caracsInt = new Object();
         for(_loc3_ in caracteristiquesPrimaires)
         {
            _loc2_ = Number(caracteristiquesPrimaires[_loc3_].statistiques_entiers());
            if(_loc2_ >= 1)
            {
               _loc1_.caracsInt[_loc3_] = _loc2_;
            }
         }
         for(_loc3_ in caracteristiquesSecondaires)
         {
            _loc2_ = Number(caracteristiquesSecondaires[_loc3_].statistiques_entiers());
            if(_loc2_ >= 1)
            {
               _loc1_.caracsInt[_loc3_] = _loc2_;
            }
         }
         _loc1_.skillsInt = new Object();
         for(_loc3_ in competences)
         {
            _loc2_ = Number(competences[_loc3_].statistiques_entiers());
            if(_loc2_ >= 1)
            {
               _loc1_.skillsInt[_loc3_] = _loc2_;
            }
         }
         _loc1_.bestiary = this.bestiaire.statistiques();
         _loc1_.death = this.morts;
         return _loc1_;
      }
      
      override public function toucher3(param1:Object, param2:int, param3:String, param4:int, param5:String = null, param6:Attaque = null, param7:Object = null, param8:Vector.<String> = null, param9:Object = null, param10:Boolean = true) : int
      {
         var _loc11_:int = super.toucher3(param1,param2,param3,param4,param5,param6,param7,param8,param9,param10);
         if(!param1.vivant)
         {
            this.ajouter_bestiaire(param1);
         }
         return _loc11_;
      }
      
      public function ajouter_bestiaire(param1:Object) : void
      {
         if(param1 is Combattant)
         {
            this.bestiaire.ajouter(param1.race);
         }
      }
      
      override protected function appliquer_penalites(param1:Event = null) : void
      {
         super.appliquer_penalites(param1);
         dispatchEvent(new JoueurEvent(JoueurEvent.ACTUALISER_INFOS,MessageJoueurDonnees.ATTAQUE,this.infos_attaques));
         dispatchEvent(new JoueurEvent(JoueurEvent.ACTUALISER_INFOS,MessageJoueurDonnees.VITESSE,String(vitesse * 20)));
      }
      
      override public function mourir() : void
      {
         var _loc1_:Object = null;
         super.mourir();
         for each(_loc1_ in caracteristiquesPrimaires)
         {
            _loc1_.actualiser_recuperation();
         }
         if(fantome)
         {
            ++this.morts;
         }
      }
      
      override public function ajouter_objet2(param1:String, param2:int = 1, param3:int = 0) : void
      {
         super.ajouter_objet2(param1,param2,param3);
         this.ajouter_objet3(objets.length - 1);
      }
      
      private function ajouter_objet3(param1:int) : void
      {
         var _loc2_:Object = {"id":objets[param1].id};
         if(objets[param1] is ObjetEquipe)
         {
            _loc2_.equipe = objets[param1].equipe;
            _loc2_.gauche = objets[param1].gauche;
            if(objets[param1] is ObjetTemporaireJoueur)
            {
               _loc2_.duree = objets[param1].tempsRestant;
            }
         }
         if(objets[param1].renforcer)
         {
            _loc2_.up = objets[param1].renforcer;
         }
         dispatchEvent(new ObjetEvent(ObjetEvent.INFOS_OBJET,MessageObjetDonnees.AJOUTER,param1,objets[param1].quantite,_loc2_));
      }
      
      override protected function equiper_objet(param1:int, param2:Boolean) : Boolean
      {
         var _loc3_:Object = objets[param1];
         var _loc4_:Boolean = super.equiper_objet(param1,param2);
         if(param1 < objets.length && objets[param1] == _loc3_)
         {
            dispatchEvent(new ObjetEvent(ObjetEvent.INFOS_OBJET,objets[param1].equipe ? MessageObjetDonnees.EQUIPER : MessageObjetDonnees.DESEQUIPER,param1,0,objets[param1].gauche));
         }
         return _loc4_;
      }
      
      override protected function editer_quantite_objet(param1:int, param2:int) : void
      {
         super.editer_quantite_objet(param1,param2);
         dispatchEvent(new ObjetEvent(ObjetEvent.INFOS_OBJET,MessageObjetDonnees.QUANTITE,param1,param2,objets[param1].quantite));
      }
      
      override protected function utiliser_objet3(param1:int, param2:Object) : Boolean
      {
         if(super.utiliser_objet3(param1,param2))
         {
            this.gagner_xp_infos(param2,this.coefXp);
            return true;
         }
         return false;
      }
      
      override public function gagner_objet_temporaire(param1:String, param2:int, param3:int = 0) : void
      {
         var _loc4_:ObjetTemporaireJoueur = null;
         if(possede_objet2(param1,param3) != -1)
         {
            objets[possede_objet(param1)].augmenterTemps(param2);
            dispatchEvent(new ObjetEvent(ObjetEvent.INFOS_OBJET,MessageObjetDonnees.DUREE,possede_objet(param1),0,objets[possede_objet(param1)].tempsRestant));
         }
         else
         {
            _loc4_ = new ObjetTemporaireJoueur();
            _loc4_.init(param1,Donnees.donnees[param1]);
            _loc4_.tempsRestant = param2;
            _loc4_.renforcer = param3;
            objets.push(_loc4_);
            _loc4_.addEventListener(ObjetTemporaireJoueurEvent.ACTUALISER_TEMPS,this.actualiser_objet_temporaire);
            _loc4_.addEventListener(ObjetTemporaireEvent.DISSIPER,this.perdre_objet_temporaire);
            utiliser_objet(objets.length - 1);
            this.actualiser_bonus();
            dispatchEvent(new ObjetEvent(ObjetEvent.INFOS_OBJET,MessageObjetDonnees.AJOUTER,objets.length - 1,1,{
               "id":objets[objets.length - 1].id,
               "equipe":objets[objets.length - 1].equipe,
               "gauche":objets[objets.length - 1].gauche,
               "duree":objets[objets.length - 1].tempsRestant
            }));
         }
      }
      
      private function actualiser_objet_temporaire(param1:ObjetTemporaireJoueurEvent) : void
      {
         var _loc2_:int = possede_objet(param1.currentTarget.id);
         dispatchEvent(new ObjetEvent(ObjetEvent.INFOS_OBJET,MessageObjetDonnees.DUREE,_loc2_,0,objets[_loc2_].tempsRestant));
      }
      
      override protected function perdre_objet_temporaire(param1:Object) : void
      {
         var _loc2_:ObjetTemporaireJoueur = ObjetTemporaireJoueur(param1.currentTarget);
         _loc2_.removeEventListener(ObjetTemporaireJoueurEvent.ACTUALISER_TEMPS,this.actualiser_objet_temporaire);
         _loc2_.removeEventListener(ObjetTemporaireEvent.DISSIPER,this.perdre_objet_temporaire);
         this.supprimer_objet(possede_objet(_loc2_.id));
         if(_loc2_.changeApparence)
         {
            actualiser_apparence();
         }
         this.actualiser_bonus();
      }
      
      override public function supprimer_objet(param1:int) : void
      {
         super.supprimer_objet(param1);
         this.actualiser_bonus();
         dispatchEvent(new ObjetEvent(ObjetEvent.INFOS_OBJET,MessageObjetDonnees.SUPPRIMER,param1));
      }
      
      public function changer_noJoueur(param1:int) : void
      {
         var _loc2_:CaracteristiquePrimaireJoueur = null;
         var _loc3_:CaracteristiqueSecondaireJoueur = null;
         var _loc4_:CompetenceJoueur = null;
         var _loc5_:RessourceJoueur = null;
         this.noJoueur = param1;
         for each(_loc2_ in caracteristiquesPrimaires)
         {
            _loc2_.noJoueur = param1;
         }
         for each(_loc3_ in caracteristiquesSecondaires)
         {
            _loc3_.noJoueur = param1;
         }
         for each(_loc4_ in competences)
         {
            _loc4_.noJoueur = param1;
         }
         for each(_loc5_ in ressources)
         {
            _loc5_.noJoueur = param1;
         }
      }
      
      override public function detruire() : void
      {
         var _loc1_:String = null;
         var _loc2_:Object = null;
         for(_loc1_ in caracteristiquesPrimaires)
         {
            caracteristiquesPrimaires[_loc1_].removeEventListener(CaracteristiquePrimaireEvent.GAGNER_XP,this.gagner_xp_caracteristiquesPrimaires);
            caracteristiquesPrimaires[_loc1_].removeEventListener(CaracteristiquePrimaireEvent.RECUPERER,this.recuperer_carac);
         }
         caracteristiquesPrimaires["health"].removeEventListener(CaracteristiquePrimaireEvent.ACTUALISER_SCORE,actualiser_vie);
         caracteristiquesPrimaires["health"].removeEventListener(CaracteristiquePrimaireEvent.ACTUALISER_SCORE_MAX,actualiser_vie);
         caracteristiquesSecondaires["attack"].removeEventListener(CaracteristiqueSecondaireEvent.ACTUALISER_SCORE,this.actualiser_attaque);
         caracteristiquesSecondaires["defense"].removeEventListener(CaracteristiqueSecondaireEvent.ACTUALISER_SCORE,this.actualiser_defense);
         for(_loc1_ in competences)
         {
            competences[_loc1_].removeEventListener(CompetenceEvent.ACTUALISER_SCORE,this.actualiser_competence);
         }
         for each(_loc2_ in objets)
         {
            if(_loc2_ is ObjetTemporaireJoueur)
            {
               _loc2_.removeEventListener(ObjetTemporaireJoueurEvent.ACTUALISER_TEMPS,this.actualiser_objet_temporaire);
               _loc2_.removeEventListener(ObjetTemporaireEvent.DISSIPER,this.perdre_objet_temporaire);
            }
         }
         this.effacer_cible();
         super.detruire();
         this.niveau = null;
         this.bestiaire.detruire();
         this.bestiaire = null;
         for(_loc2_ in this.xpAttaque)
         {
            _loc2_ = null;
         }
         this.xpAttaque = null;
         for(_loc2_ in this.xpDefense)
         {
            _loc2_ = null;
         }
         this.xpDefense = null;
         for(_loc1_ in this.xpPrimaryCharacteristic)
         {
            delete this.xpPrimaryCharacteristic[_loc1_];
         }
         this.xpPrimaryCharacteristic = null;
         for(_loc1_ in this.xpSecondaryCharacteristic)
         {
            delete this.xpSecondaryCharacteristic[_loc1_];
         }
         this.xpSecondaryCharacteristic = null;
         for(_loc1_ in this.xpSkill)
         {
            delete this.xpSkill[_loc1_];
         }
         this.xpSkill = null;
         for(_loc1_ in ressources)
         {
            delete ressources[_loc1_];
         }
         ressources = null;
         this.donneesMods = null;
         this.timerJauge.removeEventListener(TimerEvent.TIMER,this.actualiser_jauge);
         this.timerJauge.stop();
         this.timerJauge = null;
      }
   }
}

