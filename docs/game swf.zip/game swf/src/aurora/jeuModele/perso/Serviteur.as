package aurora.jeuModele.perso
{
   import aurora.jeuModele.Donnees;
   import aurora.jeuModele.IA;
   import aurora.jeuModele.PersosEvent;
   import flash.events.TimerEvent;
   
   public class Serviteur extends Artisan
   {
      
      public var iaRessourceOrdre:String;
      
      public function Serviteur(param1:int)
      {
         super();
         this.epoque = param1;
      }
      
      public function gerer_creation(param1:Object) : void
      {
         var _loc2_:int = 0;
         var _loc3_:int = 0;
         if(param1.created)
         {
            if(param1.created.move)
            {
               _loc2_ = param1.created.move.x ? int(param1.created.move.x) : 0;
               _loc3_ = param1.created.move.y ? int(param1.created.move.y) : 0;
               if(param1.created.move.randomX)
               {
                  _loc2_ += param1.created.move.randomX * Math.random() - param1.created.move.randomX * 0.5;
               }
               if(param1.created.move.randomY)
               {
                  _loc3_ += param1.created.move.randomY * Math.random() - param1.created.move.randomY * 0.5;
               }
               aller(x + _loc2_,y + _loc3_);
            }
         }
      }
      
      override protected function gerer_ia(param1:TimerEvent = null) : void
      {
         if(vivant)
         {
            IA.gerer_villageois(this);
         }
         else
         {
            param1.currentTarget.stop();
            param1.currentTarget.removeEventListener(TimerEvent.TIMER,this.gerer_ia);
         }
      }
      
      public function memoriser_ordre_travail(param1:Perso) : void
      {
         var _loc2_:Object = null;
         var _loc3_:String = null;
         if(Donnees.donnees[param1.race].produce)
         {
            for each(_loc2_ in Donnees.donnees[param1.race].produce)
            {
               if(_loc2_.gainRessource)
               {
                  var _loc6_:int = 0;
                  var _loc7_:* = _loc2_.gainRessource;
                  for(_loc3_ in _loc7_)
                  {
                     this.iaRessourceOrdre = _loc3_;
                     return;
                  }
               }
            }
         }
      }
      
      override public function mourir() : void
      {
         visible = false;
         dispatchEvent(new PersosEvent(PersosEvent.EFFACER));
         detruire();
      }
   }
}

