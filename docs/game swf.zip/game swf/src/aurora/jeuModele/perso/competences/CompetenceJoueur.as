package aurora.jeuModele.perso.competences
{
   import aurora.jeuModele.perso.caracteristiquesSecondaires.CaracteristiqueSecondaireEvent;
   import aurora.jeuModele.perso.caracteristiquesSecondaires.CaracteristiqueSecondaireJoueur;
   
   public class CompetenceJoueur extends Competence
   {
      
      public static var coefGainXp:int = 3;
      
      public static var xpPremierNivSuivant:int = 100;
      
      public static var xpNivSup:int = 5;
      
      public var niveau:int;
      
      private var _xp:Number = 0;
      
      private var xpNivPrecedent:int;
      
      private var xpNivSuivant:int;
      
      private var modificateur:int;
      
      private var bonusCarac:int;
      
      private var bonus:int;
      
      public var niveauDepart:Number;
      
      public var noJoueur:int;
      
      public function CompetenceJoueur(param1:String, param2:int, param3:CaracteristiqueSecondaireJoueur, param4:int)
      {
         super(param1,param2);
         this.xpNivSuivant = xpPremierNivSuivant;
         if(param3)
         {
            param3.addEventListener(CaracteristiqueSecondaireEvent.ACTUALISER_SCORE,this.actualiser_score);
         }
         this.modificateur = param4;
      }
      
      override public function init() : void
      {
         _score = this.bonusCarac + this.niveau + this.modificateur;
         this.bonus = 0;
         dispatchEvent(new CompetenceEvent(CompetenceEvent.ACTUALISER_SCORE_INFO,id,this.score_affichage));
         dispatchEvent(new CompetenceEvent(CompetenceEvent.ACTUALISER_SCORE_BASE,id,this.scoreSansBonus));
      }
      
      public function statistiques() : Number
      {
         return this.niveau + (this._xp - this.xpNivPrecedent) / (this.xpNivSuivant - this.xpNivPrecedent) - this.niveauDepart;
      }
      
      public function statistiques_entiers() : int
      {
         return this.niveau - int(this.niveauDepart);
      }
      
      public function init2() : void
      {
         this.niveauDepart = this.niveau + (this._xp - this.xpNivPrecedent) / (this.xpNivSuivant - this.xpNivPrecedent);
      }
      
      private function actualiser_score(param1:CaracteristiqueSecondaireEvent) : void
      {
         this.bonusCarac = param1.score;
         _score = this.bonusCarac + this.niveau + this.modificateur;
      }
      
      override public function get scoreSansBonus() : int
      {
         return 100 + this.niveau + this.modificateur + this.bonus;
      }
      
      override public function ajouter_bonus(param1:int) : void
      {
         super.ajouter_bonus(param1);
         this.bonus += param1;
         dispatchEvent(new CompetenceEvent(CompetenceEvent.ACTUALISER_SCORE_INFO,id,this.score_affichage));
      }
      
      public function get score_affichage() : int
      {
         return _scoreBase + this.bonus;
      }
      
      public function recuperer_infos() : void
      {
         dispatchEvent(new CompetenceEvent(CompetenceEvent.ACTUALISER_SCORE_INFO,id,this.score_affichage));
         dispatchEvent(new CompetenceEvent(CompetenceEvent.ACTUALISER_SCORE_BASE,id,this.scoreSansBonus));
         dispatchEvent(new CompetenceEvent(CompetenceEvent.ACTUALISER_XP,id,this._xp));
         dispatchEvent(new CompetenceEvent(CompetenceEvent.ACTUALISER_XP_MIN,id,this.xpNivPrecedent));
         dispatchEvent(new CompetenceEvent(CompetenceEvent.ACTUALISER_XP_MAX,id,this.xpNivSuivant));
      }
      
      public function get xp() : Number
      {
         return this._xp;
      }
      
      public function set xp(param1:Number) : void
      {
         var _loc2_:Boolean = false;
         this._xp = param1;
         while(this._xp >= this.xpNivSuivant)
         {
            ++this.niveau;
            this.xpNivPrecedent = this.xpNivSuivant;
            this.xpNivSuivant += xpPremierNivSuivant + this.niveau * xpNivSup;
            ++_score;
            ++_scoreBase;
            _loc2_ = true;
         }
         if(_loc2_)
         {
            dispatchEvent(new CompetenceEvent(CompetenceEvent.ACTUALISER_SCORE,id,this.score_affichage));
            dispatchEvent(new CompetenceEvent(CompetenceEvent.ACTUALISER_SCORE_INFO,id,this.score_affichage));
            dispatchEvent(new CompetenceEvent(CompetenceEvent.ACTUALISER_SCORE_BASE,id,this.scoreSansBonus));
            dispatchEvent(new CompetenceEvent(CompetenceEvent.ACTUALISER_XP_MIN,id,this.xpNivPrecedent));
            dispatchEvent(new CompetenceEvent(CompetenceEvent.ACTUALISER_XP_MAX,id,this.xpNivSuivant));
            dispatchEvent(new CompetenceEvent(CompetenceEvent.GAIN_NIVEAU,id,this.niveau + 100 + this.modificateur));
         }
         dispatchEvent(new CompetenceEvent(CompetenceEvent.ACTUALISER_XP,id,int(this._xp)));
      }
      
      public function charger(param1:Object) : void
      {
         this._xp = param1["xp"];
         this.niveau = param1["lvl"];
         _score += this.niveau;
         _scoreBase += this.niveau;
         score += this.niveau;
         this.xpNivPrecedent = param1["prev"];
         this.xpNivSuivant = param1["next"];
      }
      
      public function sauvegarde() : Object
      {
         var _loc1_:Object = new Object();
         _loc1_[id] = {"xp":int(this.xp)};
         return _loc1_;
      }
   }
}

