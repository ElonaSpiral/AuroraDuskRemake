package aurora.jeuModele.perso.competences
{
   import flash.events.EventDispatcher;
   
   public class Competence extends EventDispatcher
   {
      
      public var id:String;
      
      protected var _score:int;
      
      protected var _scoreBase:int;
      
      public function Competence(param1:String, param2:int)
      {
         super();
         this.id = param1;
         this._score = this._scoreBase = param2;
      }
      
      public function init() : void
      {
         this._score = this.scoreBase;
      }
      
      public function get score() : int
      {
         return this._score;
      }
      
      public function set score(param1:int) : void
      {
         this._score = param1;
      }
      
      public function get scoreBase() : int
      {
         return this._scoreBase;
      }
      
      public function set scoreBase(param1:int) : void
      {
         this._scoreBase = param1;
      }
      
      public function get scoreSansBonus() : int
      {
         return this._score;
      }
      
      public function ajouter_bonus(param1:int) : void
      {
         this.score += param1;
      }
      
      public function get multiplicateur() : int
      {
         var _loc1_:int = this.score * 0.01;
         var _loc2_:int = this.score - _loc1_ * 100;
         if(Math.random() * 100 < _loc2_)
         {
            _loc1_++;
         }
         return _loc1_;
      }
      
      public function get coefBonus() : Number
      {
         return this.score * 0.01;
      }
   }
}

