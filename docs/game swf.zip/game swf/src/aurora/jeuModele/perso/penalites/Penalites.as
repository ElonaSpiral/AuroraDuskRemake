package aurora.jeuModele.perso.penalites
{
   import aurora.jeuModele.perso.Combattant;
   import aurora.jeuModele.perso.CombattantAvance;
   import aurora.jeuModele.perso.Mobile;
   import aurora.jeuModele.perso.attaque.Attaque;
   import flash.events.Event;
   import flash.events.EventDispatcher;
   
   public class Penalites extends EventDispatcher
   {
      
      private var penalites:Vector.<Penalite>;
      
      public var couleur:int;
      
      public function Penalites()
      {
         super();
         this.penalites = new Vector.<Penalite>();
         this.couleur = -1;
      }
      
      public function ajouter_penalite(param1:String, param2:int) : void
      {
         var _loc3_:Penalite = this.penalite(param1);
         if(_loc3_)
         {
            _loc3_.ajouter_temps(param2);
         }
         else
         {
            _loc3_ = new Penalite(param1,param2);
            _loc3_.addEventListener(Event.COMPLETE,this.terminer_penalite);
            this.penalites.push(_loc3_);
         }
         this.actualiser_couleur();
         dispatchEvent(new Event(Event.CHANGE));
      }
      
      public function appliquer_penalites_mobiles(param1:Mobile) : void
      {
         var _loc2_:Penalite = null;
         for each(_loc2_ in this.penalites)
         {
            switch(_loc2_.type)
            {
               case Penalite.TYPE_RALENTISSEMENT:
                  param1.vitesse *= 0.5;
               case Penalite.TYPE_ELOUI:
                  param1.defense *= 0.75;
            }
         }
      }
      
      public function appliquer_penalites_combattants(param1:Combattant) : void
      {
         var _loc2_:Penalite = null;
         for each(_loc2_ in this.penalites)
         {
            switch(_loc2_.type)
            {
               case Penalite.TYPE_ELOUI:
                  param1.attaque.score *= 0.75;
            }
         }
      }
      
      public function appliquer_penalites_combattantsAvances(param1:CombattantAvance) : void
      {
         var _loc2_:Penalite = null;
         var _loc3_:Attaque = null;
         for each(_loc2_ in this.penalites)
         {
            switch(_loc2_.type)
            {
               case Penalite.TYPE_ELOUI:
                  if(param1.attaquesSupplementaires.length > 0)
                  {
                     for each(_loc3_ in param1.attaquesSupplementaires)
                     {
                        _loc3_.score *= 0.75;
                     }
                  }
            }
         }
      }
      
      private function terminer_penalite(param1:Event) : void
      {
         this.effacer_penalite(Penalite(param1.currentTarget));
      }
      
      private function effacer_penalite(param1:Penalite) : void
      {
         param1.removeEventListener(Event.COMPLETE,this.terminer_penalite);
         var _loc2_:int = 0;
         while(_loc2_ < this.penalites.length)
         {
            if(this.penalites[_loc2_] == param1)
            {
               this.penalites.splice(_loc2_,1);
               break;
            }
            _loc2_++;
         }
         param1 = null;
         this.actualiser_couleur();
         dispatchEvent(new Event(Event.CHANGE));
      }
      
      private function actualiser_couleur() : void
      {
         if(this.penalites.length > 0)
         {
            this.couleur = this.penalites[0].couleur;
         }
         else
         {
            this.couleur = -1;
         }
      }
      
      private function penalite(param1:String) : Penalite
      {
         var _loc2_:Penalite = null;
         for each(_loc2_ in this.penalites)
         {
            if(_loc2_.type == param1)
            {
               return _loc2_;
            }
         }
         return null;
      }
      
      public function vider() : void
      {
         while(this.penalites.length > 0)
         {
            this.penalites[0].removeEventListener(Event.COMPLETE,this.terminer_penalite);
            this.penalites[0].detruire();
            this.penalites[0] = null;
            this.penalites.splice(0,1);
         }
         this.couleur = -1;
         dispatchEvent(new Event(Event.CHANGE));
      }
      
      public function detruire() : void
      {
         var _loc1_:Penalite = null;
         for each(_loc1_ in this.penalites)
         {
            _loc1_.removeEventListener(Event.COMPLETE,this.terminer_penalite);
            _loc1_.detruire();
            _loc1_ = null;
         }
         this.penalites.splice(0,this.penalites.length);
         this.penalites = null;
      }
   }
}

