package aurora.jeuModele.perso.penalites
{
   import flash.events.Event;
   import flash.events.EventDispatcher;
   import flash.events.TimerEvent;
   import flash.utils.Timer;
   
   public class Penalite extends EventDispatcher
   {
      
      public static const TYPE_RALENTISSEMENT:String = "slowdown";
      
      public static const TYPE_ELOUI:String = "blind";
      
      public static const TYPE_POISON:String = "poison";
      
      public var type:String;
      
      public var couleur:int;
      
      public var timer:Timer;
      
      public function Penalite(param1:String, param2:int)
      {
         super();
         this.type = param1;
         switch(param1)
         {
            case Penalite.TYPE_RALENTISSEMENT:
               this.couleur = 26316;
               break;
            case Penalite.TYPE_ELOUI:
               this.couleur = 16777215;
               break;
            case Penalite.TYPE_POISON:
               this.couleur = 3368448;
         }
         this.timer = new Timer(1000,param2);
         this.timer.addEventListener(TimerEvent.TIMER_COMPLETE,this.finir);
         this.timer.start();
      }
      
      public function ajouter_temps(param1:int) : void
      {
         this.timer.repeatCount = this.timer.currentCount + param1;
      }
      
      private function finir(param1:TimerEvent) : void
      {
         dispatchEvent(new Event(Event.COMPLETE));
         this.detruire();
      }
      
      public function detruire() : void
      {
         this.timer.removeEventListener(TimerEvent.TIMER_COMPLETE,this.finir);
         this.timer.stop();
         this.timer = null;
      }
   }
}

