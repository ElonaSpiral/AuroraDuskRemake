package aurora.jeuModele.perso
{
   import aurora.jeuModele.IA;
   import aurora.jeuModele.PersosEvent;
   import aurora.messages.perso.MessagePersoOrienter;
   import flash.events.Event;
   import flash.events.TimerEvent;
   import flash.utils.Dictionary;
   
   public class BatimentMobile extends CombattantAvance
   {
      
      public var repair:Object;
      
      public var reparationVie:int;
      
      public var constructionDuree:int;
      
      public var bonusCompetence:String;
      
      public var ordre:int = Soldat.ORDRE_DEFENSE;
      
      public var maitre:Object;
      
      public var maitreDecalageX:int;
      
      public var maitreDecalageY:int;
      
      public var origineX:int;
      
      public var origineY:int;
      
      private var origineOrientation:int;
      
      public var revenirPositionOrigine:Boolean = true;
      
      public function BatimentMobile()
      {
         super();
      }
      
      override public function init(param1:Object) : void
      {
         super.init(param1);
         this.repair = param1.repair;
         this.reparationVie = param1.repair.health;
         this.constructionDuree = param1.repair.time * 1000;
         this.bonusCompetence = param1.repair.bonusSkill;
         this.definir_origine(x,y,IA.villes[equipe].x,IA.villes[equipe].y);
      }
      
      override protected function appliquer_penalites(param1:Event = null) : void
      {
      }
      
      public function init_maitre(param1:Object, param2:Dictionary) : void
      {
         var _loc4_:Object = null;
         var _loc5_:int = 0;
         var _loc6_:int = 0;
         var _loc7_:int = 0;
         var _loc8_:int = 0;
         var _loc9_:int = 0;
         var _loc10_:int = 0;
         var _loc11_:int = 0;
         var _loc12_:int = 0;
         var _loc13_:int = 0;
         var _loc3_:Vector.<Soldat> = new Vector.<Soldat>();
         this.maitre = param1;
         for each(_loc4_ in param2)
         {
            if(_loc4_ is Soldat && _loc4_.maitre == param1 && _loc4_.ordre == Soldat.ORDRE_SUIVRE)
            {
               _loc3_.push(_loc4_);
            }
         }
         _loc5_ = int(_loc3_.length);
         for each(_loc4_ in _loc3_)
         {
            if(_loc6_ < _loc4_.largeur)
            {
               _loc6_ = _loc7_ = int(_loc4_.largeur);
            }
         }
         _loc8_ = Math.floor(Math.sqrt(_loc5_));
         _loc9_ = Math.ceil(_loc5_ / _loc8_);
         _loc10_ = -(_loc8_ - 1) * _loc6_ * 0.5;
         _loc11_ = -(_loc9_ - 1) * _loc7_ * 0.5 + Math.abs(_loc7_) * 0.5;
         for each(_loc4_ in _loc3_)
         {
            _loc4_.maitreDecalageX = _loc10_ + _loc12_ * _loc6_;
            _loc4_.maitreDecalageY = _loc11_ + _loc13_ * _loc7_;
            _loc4_.suivre_maitre();
            if(++_loc12_ >= _loc8_)
            {
               _loc12_ = 0;
               _loc13_++;
            }
         }
      }
      
      public function suivre_maitre() : void
      {
         if(!cibleCombat)
         {
            if(this.maitre.cibleCombat)
            {
               this.attaquer(this.maitre.cibleCombat);
            }
            else
            {
               this.aller(this.maitre.destinationX + this.maitreDecalageX,this.maitre.destinationY + this.maitreDecalageY);
            }
         }
      }
      
      public function definir_origine(param1:int, param2:int, param3:Number, param4:int) : void
      {
         this.origineX = param1;
         this.origineY = param2;
         var _loc5_:int = param4 - param2;
         var _loc6_:int = param2 - param4;
         var _loc7_:int = param3 - param1;
         var _loc8_:int = param1 - param3;
         if(_loc5_ > _loc6_)
         {
            if(_loc7_ > _loc5_)
            {
               if(_loc7_ > _loc8_)
               {
                  this.origineOrientation = MessagePersoOrienter.GAUCHE;
               }
               else
               {
                  this.origineOrientation = MessagePersoOrienter.DROITE;
               }
            }
            else if(_loc5_ > _loc8_)
            {
               this.origineOrientation = MessagePersoOrienter.HAUT;
            }
            else
            {
               this.origineOrientation = MessagePersoOrienter.DROITE;
            }
         }
         else if(_loc7_ > _loc6_)
         {
            if(_loc7_ > _loc8_)
            {
               this.origineOrientation = MessagePersoOrienter.GAUCHE;
            }
            else
            {
               this.origineOrientation = MessagePersoOrienter.DROITE;
            }
         }
         else if(_loc6_ > _loc8_)
         {
            this.origineOrientation = MessagePersoOrienter.BAS;
         }
         else
         {
            this.origineOrientation = MessagePersoOrienter.DROITE;
         }
      }
      
      override protected function gerer_ia(param1:TimerEvent = null) : void
      {
         if(iaTimer)
         {
            IA.gerer_serviteur(this);
         }
         else
         {
            param1.currentTarget.stop();
            param1.currentTarget.removeEventListener(TimerEvent.TIMER,this.gerer_ia);
         }
      }
      
      public function bloquer() : void
      {
         arreter();
         if(iaTimer)
         {
            iaTimer.reset();
            iaTimer.start();
         }
      }
      
      public function revenir_origine() : void
      {
         if(x != this.origineX && y != this.origineY)
         {
            this.aller(this.origineX,this.origineY);
         }
         else if(orientation != this.origineOrientation)
         {
            orientation = this.origineOrientation;
            dispatchEvent(new PersosEvent(PersosEvent.ORIENTER));
         }
      }
      
      public function get reparable() : Boolean
      {
         return vie.score < vie.scoreMax;
      }
      
      public function reparer(param1:int) : void
      {
         editer_vie(this.reparationVie * param1);
      }
      
      public function get reparationRestante() : int
      {
         return Math.ceil((vie.scoreMax - vie.score) / this.reparationVie);
      }
      
      override public function aller(param1:Number, param2:Number) : void
      {
         super.aller(param1,param2);
         this.revenirPositionOrigine = true;
      }
      
      override protected function deplacer(param1:TimerEvent) : void
      {
         super.deplacer(param1);
         if(x == this.origineX && y == this.origineY && orientation == this.origineOrientation)
         {
            this.revenirPositionOrigine = false;
         }
      }
      
      override public function attaquer(param1:Vivant) : void
      {
         super.attaquer(param1);
         this.revenirPositionOrigine = true;
      }
      
      override public function gerer_mort(param1:Object) : void
      {
         super.gerer_mort(param1);
         Tresor.piller_batiment(this);
      }
      
      override public function detruire() : void
      {
         super.detruire();
         this.repair = null;
      }
   }
}

