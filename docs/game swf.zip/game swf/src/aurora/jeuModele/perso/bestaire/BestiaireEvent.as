package aurora.jeuModele.perso.bestaire
{
   import flash.events.Event;
   
   public class BestiaireEvent extends Event
   {
      
      public static const ACTUALISER_NOMBRE:String = "actualiser_nombre";
      
      public var id:String;
      
      public var nombre:int;
      
      public function BestiaireEvent(param1:String, param2:String, param3:int)
      {
         this.id = param2;
         this.nombre = param3;
         super(param1);
      }
   }
}

