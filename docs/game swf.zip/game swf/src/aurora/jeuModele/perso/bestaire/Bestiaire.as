package aurora.jeuModele.perso.bestaire
{
   import aurora.jeuModele.Donnees;
   import flash.events.EventDispatcher;
   import flash.utils.Dictionary;
   
   public class Bestiaire extends EventDispatcher
   {
      
      private var bestaireDepart:Dictionary;
      
      private var bestaire:Dictionary;
      
      public var noJoueur:int;
      
      public function Bestiaire()
      {
         super();
         this.bestaireDepart = new Dictionary();
         this.bestaire = new Dictionary();
      }
      
      public function init() : void
      {
         var _loc1_:String = null;
         for(_loc1_ in this.bestaire)
         {
            this.bestaireDepart[_loc1_] = this.bestaire[_loc1_];
         }
      }
      
      public function ajouter(param1:String, param2:int = 1) : void
      {
         if(Boolean(Donnees.donnees[param1]) && Boolean(Donnees.donnees[param1].changeBestiary))
         {
            param1 = Donnees.donnees[param1].changeBestiary;
         }
         if(this.bestaire[param1])
         {
            this.bestaire[param1] += param2;
         }
         else
         {
            this.bestaire[param1] = param2;
         }
         dispatchEvent(new BestiaireEvent(BestiaireEvent.ACTUALISER_NOMBRE,param1,this.bestaire[param1]));
      }
      
      public function sauvegarde() : Object
      {
         var _loc2_:String = null;
         var _loc1_:Object = new Object();
         for(_loc2_ in this.bestaire)
         {
            _loc1_[_loc2_] = {"quantity":this.bestaire[_loc2_]};
         }
         return _loc1_;
      }
      
      public function recuperer_infos() : void
      {
         var _loc1_:String = null;
         for(_loc1_ in this.bestaire)
         {
            dispatchEvent(new BestiaireEvent(BestiaireEvent.ACTUALISER_NOMBRE,_loc1_,this.bestaire[_loc1_]));
         }
      }
      
      public function statistiques() : Object
      {
         var _loc2_:String = null;
         var _loc1_:Object = new Object();
         for(_loc2_ in this.bestaire)
         {
            if(this.bestaireDepart[_loc2_])
            {
               if(this.bestaire[_loc2_] > this.bestaireDepart[_loc2_])
               {
                  _loc1_[_loc2_] = this.bestaire[_loc2_] - this.bestaireDepart[_loc2_];
               }
            }
            else
            {
               _loc1_[_loc2_] = this.bestaire[_loc2_];
            }
         }
         return _loc1_;
      }
      
      public function detruire() : void
      {
         var _loc1_:String = null;
         for(_loc1_ in this.bestaire)
         {
            this.bestaire[_loc1_] = null;
            delete this.bestaire[_loc1_];
         }
         this.bestaire = null;
      }
   }
}

