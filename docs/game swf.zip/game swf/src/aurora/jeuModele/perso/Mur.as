package aurora.jeuModele.perso
{
   public class Mur extends Batiment
   {
      
      public function Mur()
      {
         super();
      }
   }
}

