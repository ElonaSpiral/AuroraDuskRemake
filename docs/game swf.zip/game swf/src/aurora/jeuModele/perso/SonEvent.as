package aurora.jeuModele.perso
{
   import flash.events.Event;
   
   public class SonEvent extends Event
   {
      
      public static const SON:String = "son";
      
      public static const SON_TRAVAIL:String = "sonTravail";
      
      public var son:String;
      
      public var x:int;
      
      public var y:int;
      
      public function SonEvent(param1:String, param2:String, param3:int, param4:int)
      {
         this.son = param2;
         this.x = param3;
         this.y = param4;
         super(param1);
      }
      
      override public function clone() : Event
      {
         return new SonEvent(type,this.son,this.x,this.y);
      }
   }
}

