package aurora.jeuModele.perso.caracteristiquesPrimaires
{
   import aurora.MainJeu;
   import aurora.jeuModele.Donnees;
   import flash.events.TimerEvent;
   
   public class CaracteristiquePrimaireJoueur extends CaracteristiquePrimaireArtisan
   {
      
      public static var xpPremierNivSuivant:int = 100;
      
      public static var xpNivSup:int = 5;
      
      public var niveau:int;
      
      private var _xp:Number = 0;
      
      private var xpNivPrecedent:int;
      
      private var xpNivSuivant:int;
      
      public var coefXp:Number = 1;
      
      private var coefRecuperationAuto:Number;
      
      private var _recuperationAuto:Boolean;
      
      public var niveauDepart:Number;
      
      public var noJoueur:int;
      
      public function CaracteristiquePrimaireJoueur(param1:String, param2:int)
      {
         super(param1,param2);
         this.xpNivSuivant = xpPremierNivSuivant;
         this.coefRecuperationAuto = Donnees.donnees[param1].autoRecovery;
      }
      
      public function init() : void
      {
         this.niveauDepart = this.niveau + (this._xp - this.xpNivPrecedent) / (this.xpNivSuivant - this.xpNivPrecedent);
      }
      
      public function statistiques() : Number
      {
         return this.niveau + (this._xp - this.xpNivPrecedent) / (this.xpNivSuivant - this.xpNivPrecedent) - this.niveauDepart;
      }
      
      public function statistiques_entiers() : int
      {
         return this.niveau - int(this.niveauDepart);
      }
      
      public function recuperer_infos() : void
      {
         dispatchEvent(new CaracteristiquePrimaireEvent(CaracteristiquePrimaireEvent.ACTUALISER_SCORE,id,_score));
         dispatchEvent(new CaracteristiquePrimaireEvent(CaracteristiquePrimaireEvent.ACTUALISER_SCORE_BASE,id,_scoreMaxBase));
         dispatchEvent(new CaracteristiquePrimaireEvent(CaracteristiquePrimaireEvent.ACTUALISER_SCORE_MAX,id,_scoreMax));
         this.actualiser_recuperation();
         dispatchEvent(new CaracteristiquePrimaireEvent(CaracteristiquePrimaireEvent.ACTUALISER_XP,id,this._xp));
         dispatchEvent(new CaracteristiquePrimaireEvent(CaracteristiquePrimaireEvent.ACTUALISER_XP_MIN,id,this.xpNivPrecedent));
         dispatchEvent(new CaracteristiquePrimaireEvent(CaracteristiquePrimaireEvent.ACTUALISER_XP_MAX,id,this.xpNivSuivant));
      }
      
      override public function set score(param1:int) : void
      {
         var _loc2_:Number = NaN;
         if(param1 < 0)
         {
            param1 = 0;
         }
         if(score > param1)
         {
            _loc2_ = (score - param1) / coefBonus * this.coefXp;
            this.xp += _loc2_;
            dispatchEvent(new CaracteristiquePrimaireEvent(CaracteristiquePrimaireEvent.GAGNER_XP,id,_loc2_));
         }
         if(this.recuperationAuto && (param1 + recuperation) / _scoreMax < this.coefRecuperationAuto)
         {
            dispatchEvent(new CaracteristiquePrimaireEvent(CaracteristiquePrimaireEvent.RECUPERER,id));
         }
         if(MainJeu.bacASable)
         {
            super.score = 100;
         }
         else
         {
            super.score = param1;
         }
      }
      
      override public function chargerCoef() : void
      {
         super.chargerCoef();
         dispatchEvent(new CaracteristiquePrimaireEvent(CaracteristiquePrimaireEvent.ACTUALISER_SCORE,id,_score));
      }
      
      override protected function recuperer2(param1:TimerEvent) : void
      {
         super.recuperer2(param1);
         this.actualiser_recuperation();
      }
      
      public function actualiser_recuperation() : void
      {
         dispatchEvent(new CaracteristiquePrimaireEvent(CaracteristiquePrimaireEvent.ACTUALISER_RECUPERATION,id,recuperation <= 0 ? 0 : Math.min(_score + recuperation,_scoreMax)));
      }
      
      override public function set scoreMax(param1:int) : void
      {
         if(_score > _scoreMax)
         {
            dispatchEvent(new CaracteristiquePrimaireEvent(CaracteristiquePrimaireEvent.ACTUALISER_SCORE,id,_score));
         }
         super.scoreMax = param1;
      }
      
      override public function set scoreMaxBase(param1:int) : void
      {
         _scoreMaxBase = param1;
         dispatchEvent(new CaracteristiquePrimaireEvent(CaracteristiquePrimaireEvent.ACTUALISER_SCORE_BASE,id,_scoreMaxBase));
      }
      
      public function get xp() : Number
      {
         return this._xp;
      }
      
      public function set xp(param1:Number) : void
      {
         var _loc2_:Boolean = false;
         this._xp = param1;
         while(this._xp >= this.xpNivSuivant)
         {
            ++this.niveau;
            this.xpNivPrecedent = this.xpNivSuivant;
            this.xpNivSuivant += xpPremierNivSuivant + this.niveau * xpNivSup;
            ++scoreMax;
            ++scoreMaxBase;
            ++score;
            _loc2_ = true;
         }
         if(_loc2_)
         {
            dispatchEvent(new CaracteristiquePrimaireEvent(CaracteristiquePrimaireEvent.ACTUALISER_XP_MIN,id,this.xpNivPrecedent));
            dispatchEvent(new CaracteristiquePrimaireEvent(CaracteristiquePrimaireEvent.ACTUALISER_XP_MAX,id,this.xpNivSuivant));
            dispatchEvent(new CaracteristiquePrimaireEvent(CaracteristiquePrimaireEvent.GAIN_NIVEAU,id,scoreMaxBase));
         }
         dispatchEvent(new CaracteristiquePrimaireEvent(CaracteristiquePrimaireEvent.ACTUALISER_XP,id,int(this._xp)));
      }
      
      public function get recuperationAuto() : Boolean
      {
         return this._recuperationAuto;
      }
      
      public function set recuperationAuto(param1:Boolean) : void
      {
         this._recuperationAuto = param1;
         if(param1 && (_score + recuperation) / _scoreMax < this.coefRecuperationAuto)
         {
            dispatchEvent(new CaracteristiquePrimaireEvent(CaracteristiquePrimaireEvent.RECUPERER,id));
         }
      }
      
      public function charger(param1:Object) : void
      {
         this._xp = param1["xp"];
         this.niveau = param1["lvl"];
         this.scoreMax = scoreMax + this.niveau;
         this.scoreMaxBase = scoreMaxBase + this.niveau;
         this.score = score + this.niveau;
         this.xpNivPrecedent = param1["prev"];
         this.xpNivSuivant = param1["next"];
      }
      
      public function sauvegarde() : Object
      {
         var _loc1_:Object = new Object();
         _loc1_[id] = {"xp":int(this.xp)};
         return _loc1_;
      }
   }
}

