package aurora.jeuModele.perso.caracteristiquesPrimaires
{
   import flash.events.Event;
   
   public class CaracteristiquePrimaireEvent extends Event
   {
      
      public static const ACTUALISER_SCORE:String = "actualiserScore";
      
      public static const ACTUALISER_SCORE_BASE:String = "actualiserScoreBase";
      
      public static const ACTUALISER_RECUPERATION:String = "actualiserRecuperation";
      
      public static const ACTUALISER_SCORE_MAX:String = "actualiserScoreMax";
      
      public static const ACTUALISER_XP:String = "actualiserXp";
      
      public static const ACTUALISER_XP_MIN:String = "actualiserXpMin";
      
      public static const ACTUALISER_XP_MAX:String = "actualiserXpMax";
      
      public static const GAIN_NIVEAU:String = "gainNiveau";
      
      public static const GAGNER_XP:String = "gagnerXp";
      
      public static const RECUPERER:String = "recuperer";
      
      public var id:String;
      
      public var score:Number;
      
      public function CaracteristiquePrimaireEvent(param1:String, param2:String, param3:Number = 0)
      {
         this.id = param2;
         this.score = param3;
         super(param1);
      }
   }
}

