package aurora.jeuModele.perso.caracteristiquesPrimaires
{
   import aurora.jeuModele.Donnees;
   import flash.events.TimerEvent;
   import flash.utils.Timer;
   
   public class CaracteristiquePrimaireArtisan extends CaracteristiquePrimaire
   {
      
      private var timerRegeneration:Timer;
      
      private var regeneration:Boolean;
      
      private var timerRecuperation:Timer;
      
      public var recuperation:int;
      
      private var tempsRegeneration:Number;
      
      private var tempsRecuperation:Number;
      
      public var scoreRegeneration:int = 1;
      
      public var multiplicateurRegeneration:int = 1;
      
      protected var _scoreMaxBase:int;
      
      private var tempCoef:Number;
      
      private var enCours:Boolean;
      
      public function CaracteristiquePrimaireArtisan(param1:String, param2:int)
      {
         super(param1,param2);
         this.scoreMaxBase = param2;
         this.tempsRegeneration = Donnees.donnees[param1].timeRegeneration;
         if(this.tempsRegeneration > 0)
         {
            this.regeneration = true;
            this.timerRegeneration = new Timer(this.tempsRegeneration * 100000 / param2);
            this.timerRegeneration.addEventListener(TimerEvent.TIMER,this.regenerer);
         }
         this.tempsRecuperation = Donnees.donnees[param1].timeRecovery;
         if(this.tempsRecuperation > 0)
         {
            this.timerRecuperation = new Timer(this.tempsRecuperation * 100000 / param2);
            this.timerRecuperation.addEventListener(TimerEvent.TIMER,this.recuperer2);
         }
         this.enCours = true;
      }
      
      override public function set scoreMax(param1:int) : void
      {
         super.scoreMax = param1;
         if(this.regeneration)
         {
            this.timerRegeneration.delay = this.tempsRegeneration * 100000 / _scoreMax;
         }
         if(this.tempsRecuperation > 0)
         {
            this.timerRecuperation.delay = this.tempsRecuperation * 100000 / _scoreMax;
         }
         dispatchEvent(new CaracteristiquePrimaireEvent(CaracteristiquePrimaireEvent.ACTUALISER_SCORE_MAX,id,_scoreMax));
      }
      
      public function get scoreMaxBase() : int
      {
         return this._scoreMaxBase;
      }
      
      public function set scoreMaxBase(param1:int) : void
      {
         this._scoreMaxBase = param1;
      }
      
      override protected function actualiser() : void
      {
         super.actualiser();
      }
      
      override public function set score(param1:int) : void
      {
         if(this.regeneration && this.enCours)
         {
            if(param1 < _scoreMax)
            {
               this.timerRegeneration.start();
            }
            else
            {
               this.timerRegeneration.stop();
            }
         }
         super.score = param1;
         dispatchEvent(new CaracteristiquePrimaireEvent(CaracteristiquePrimaireEvent.ACTUALISER_SCORE,id,_score));
      }
      
      public function arreter() : void
      {
         if(this.regeneration)
         {
            this.timerRegeneration.stop();
         }
         if(this.recuperation > 0)
         {
            this.timerRecuperation.stop();
         }
         this.enCours = false;
      }
      
      public function reprendre() : void
      {
         if(this.regeneration)
         {
            this.timerRegeneration.start();
         }
         if(this.recuperation > 0)
         {
            this.timerRecuperation.start();
         }
         this.enCours = true;
      }
      
      private function regenerer(param1:TimerEvent) : void
      {
         this.score = score + this.scoreRegeneration * this.multiplicateurRegeneration;
      }
      
      override public function recuperer(param1:int) : void
      {
         this.recuperation += param1;
         this.timerRecuperation.start();
      }
      
      protected function recuperer2(param1:TimerEvent) : void
      {
         ++score;
         --this.recuperation;
         if(this.recuperation <= 0)
         {
            this.timerRecuperation.stop();
         }
      }
      
      public function enregistrerCoef() : void
      {
         this.tempCoef = coef;
      }
      
      public function chargerCoef() : void
      {
         _score = Math.round(_scoreMax * this.tempCoef);
      }
      
      override public function get resteRecuperer() : int
      {
         return scoreMax - score - this.recuperation;
      }
      
      public function get bonusEquipement() : Number
      {
         return scoreMax / this.scoreMaxBase;
      }
      
      override public function detruire() : void
      {
         if(this.timerRegeneration)
         {
            this.timerRegeneration.stop();
            this.timerRegeneration.removeEventListener(TimerEvent.TIMER,this.regenerer);
            this.timerRegeneration = null;
         }
         if(this.timerRecuperation)
         {
            this.timerRecuperation.stop();
            this.timerRecuperation.removeEventListener(TimerEvent.TIMER,this.recuperer2);
            this.timerRecuperation = null;
         }
      }
   }
}

