package aurora.jeuModele.perso.caracteristiquesPrimaires
{
   import flash.events.EventDispatcher;
   
   public class CaracteristiquePrimaire extends EventDispatcher
   {
      
      public var id:String;
      
      protected var _score:int;
      
      protected var _scoreMax:int;
      
      public function CaracteristiquePrimaire(param1:String, param2:int)
      {
         super();
         this.id = param1;
         this._score = this._scoreMax = param2;
      }
      
      public function get coef() : Number
      {
         return this._score / this._scoreMax;
      }
      
      public function set coef(param1:Number) : void
      {
         this.score = param1 * this._scoreMax;
      }
      
      public function get score() : int
      {
         return this._score;
      }
      
      public function set score(param1:int) : void
      {
         this._score = param1;
         this.actualiser();
      }
      
      public function get scoreMax() : int
      {
         return this._scoreMax;
      }
      
      public function set scoreMax(param1:int) : void
      {
         this._scoreMax = param1;
         this.actualiser();
      }
      
      public function get coefBonus() : Number
      {
         return this.scoreMax * 0.01;
      }
      
      public function recuperer(param1:int) : void
      {
         this.score += param1;
      }
      
      public function get resteRecuperer() : int
      {
         return this.scoreMax - this.score;
      }
      
      public function get auMax() : Boolean
      {
         return this.scoreMax == this.score;
      }
      
      protected function actualiser() : void
      {
         if(this._score > this._scoreMax)
         {
            this._score = this._scoreMax;
         }
      }
      
      public function detruire() : void
      {
      }
   }
}

