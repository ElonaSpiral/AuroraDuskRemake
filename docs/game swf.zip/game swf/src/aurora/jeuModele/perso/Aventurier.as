package aurora.jeuModele.perso
{
   import aurora.jeuModele.BulleEvent;
   import aurora.jeuModele.Donnees;
   import aurora.jeuModele.IA;
   import aurora.jeuModele.MessageEvent;
   import aurora.jeuModele.PersosEvent;
   import aurora.jeuModele.Terrain;
   import aurora.jeuModele.perso.attaque.Attaque;
   import aurora.jeuModele.perso.attaque.EffetArme;
   import aurora.jeuModele.perso.caracteristiquesPrimaires.CaracteristiquePrimaireArtisan;
   import aurora.jeuModele.perso.caracteristiquesPrimaires.CaracteristiquePrimaireEvent;
   import aurora.jeuModele.perso.caracteristiquesSecondaires.CaracteristiqueSecondaire;
   import aurora.jeuModele.perso.competences.Competence;
   import aurora.jeuModele.perso.objets.Objet;
   import aurora.jeuModele.perso.objets.ObjetAuto;
   import aurora.jeuModele.perso.objets.ObjetEquipe;
   import aurora.jeuModele.perso.objets.ObjetTemporaire;
   import aurora.jeuModele.perso.objets.ObjetTemporaireEvent;
   import aurora.jeuModele.perso.rechargements.Rechargements;
   import flash.events.Event;
   import flash.events.TimerEvent;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.Timer;
   
   public class Aventurier extends CombattantAvance
   {
      
      public var feminin:Boolean;
      
      protected var volantBase:Boolean;
      
      private var vitesseBonus:Number;
      
      protected var attaqueBase:int;
      
      protected var attaqueBonus:int;
      
      protected var effetBase:String;
      
      protected var defenseBonus:int;
      
      public var resistancesBase:Dictionary;
      
      public var caracteristiquesPrimaires:Dictionary;
      
      public var caracteristiquesSecondaires:Dictionary;
      
      public var competences:Dictionary;
      
      public var epoque:int;
      
      public var objets:Vector.<Object>;
      
      public var rechargement:Object;
      
      public var apparenceBase:Vector.<Object>;
      
      public var apparence:Vector.<Object>;
      
      public var monture:String = "";
      
      public var iaArmesDistancesPreferees:Vector.<Object>;
      
      public var iaArmesDistancesMunitionsNecessaires:Boolean;
      
      public var iaArmesContactPreferees:Vector.<Object>;
      
      public var iaPretAuCombat:Boolean;
      
      public var iaMemoireCible:Boolean;
      
      public var iaEquipementAuMax:Boolean;
      
      protected var _roi:Boolean;
      
      public function Aventurier()
      {
         super();
         this.objets = new Vector.<Object>();
         this.rechargement = new Rechargements();
         this.iaArmesDistancesMunitionsNecessaires = true;
      }
      
      override public function init(param1:Object) : void
      {
         var _loc2_:String = null;
         var _loc3_:Object = null;
         super.init(param1);
         if(param1.sex)
         {
            this.feminin = param1.sex == "F";
         }
         this.volantBase = volant;
         this.attaqueBase = attaque.score;
         this.effetBase = attaque.effet;
         this.defenseBonus = defense;
         vitesseBase = this.vitesseBonus = vitesse;
         this.resistancesBase = new Dictionary();
         for(_loc2_ in resistances)
         {
            this.resistancesBase[_loc2_] = resistances[_loc2_];
         }
         this.iaArmesDistancesPreferees = new Vector.<Object>();
         this.iaArmesContactPreferees = new Vector.<Object>();
         this.iaPretAuCombat = true;
         this.caracteristiquesPrimaires = new Dictionary();
         vie = new CaracteristiquePrimaireArtisan(vie.id,vie.score);
         for each(_loc3_ in Donnees.caracteristiquesPrimaires)
         {
            if(param1[_loc3_.id])
            {
               this.caracteristiquesPrimaires[_loc3_.id] = new CaracteristiquePrimaireArtisan(_loc3_.id,param1[_loc3_.id]);
            }
            else
            {
               this.caracteristiquesPrimaires[_loc3_.id] = new CaracteristiquePrimaireArtisan(_loc3_.id,_loc3_.defaultScore);
            }
         }
         this.caracteristiquesPrimaires["health"] = vie;
         this.caracteristiquesPrimaires["health"].addEventListener(CaracteristiquePrimaireEvent.ACTUALISER_SCORE,actualiser_vie);
         this.caracteristiquesPrimaires["health"].addEventListener(CaracteristiquePrimaireEvent.ACTUALISER_SCORE_MAX,actualiser_vie);
         this.caracteristiquesSecondaires = new Dictionary();
         for each(_loc3_ in Donnees.caracteristiquesSecondaires)
         {
            if(param1[_loc3_.id])
            {
               this.caracteristiquesSecondaires[_loc3_.id] = new CaracteristiqueSecondaire(_loc3_.id,param1[_loc3_.id]);
            }
            else
            {
               this.caracteristiquesSecondaires[_loc3_.id] = new CaracteristiqueSecondaire(_loc3_.id,_loc3_.defaultScore);
            }
         }
         this.caracteristiquesSecondaires["attack"].score = attaque.score;
         this.caracteristiquesSecondaires["defense"].score = defense;
         this.competences = new Dictionary();
         for each(_loc3_ in Donnees.competences)
         {
            if(param1[_loc3_.id])
            {
               this.competences[_loc3_.id] = new Competence(_loc3_.id,Donnees.donnees[_loc3_.defaultScore].defaultScore + param1[_loc3_.id]);
            }
            else
            {
               this.competences[_loc3_.id] = new Competence(_loc3_.id,Donnees.donnees[_loc3_.defaultScore].defaultScore);
            }
         }
      }
      
      override public function set puissance(param1:Number) : void
      {
         var _loc2_:Object = null;
         super.puissance = param1;
         this.attaqueBase *= param1;
         this.defenseBonus *= param1;
         for each(_loc2_ in Donnees.caracteristiquesPrimaires)
         {
            this.caracteristiquesPrimaires[_loc2_.id].scoreMaxBase *= param1;
            this.caracteristiquesPrimaires[_loc2_.id].scoreMax *= param1;
            this.caracteristiquesPrimaires[_loc2_.id].score *= param1;
         }
         for each(_loc2_ in Donnees.caracteristiquesSecondaires)
         {
            this.caracteristiquesSecondaires[_loc2_.id].score *= param1;
            this.caracteristiquesSecondaires[_loc2_.id].scoreBase *= param1;
         }
         this.caracteristiquesSecondaires["attack"].score *= param1;
         this.caracteristiquesSecondaires["defense"].score *= param1;
         for each(_loc2_ in Donnees.competences)
         {
            this.competences[_loc2_.id].score *= param1;
            this.competences[_loc2_.id].scoreBase *= param1;
         }
      }
      
      public function initialiser_apparence(param1:int = -1) : void
      {
         var _loc3_:int = 0;
         var _loc4_:Object = null;
         var _loc5_:Object = null;
         var _loc6_:Object = null;
         var _loc7_:String = null;
         var _loc8_:Object = null;
         var _loc9_:String = null;
         this.apparenceBase = new Vector.<Object>();
         if(Donnees.donnees[race].pictures)
         {
            _loc3_ = 0;
            for each(_loc4_ in Donnees.donnees[race].pictures)
            {
               for each(_loc5_ in _loc4_)
               {
                  if(_loc5_.colors)
                  {
                     if(param1 >= 0 && Boolean(_loc4_["clothes"]))
                     {
                        if(param1 >= _loc5_.colors.length)
                        {
                           param1 -= _loc5_.colors.length * int(param1 / _loc5_.colors.length);
                        }
                        this.apparenceBase.push({
                           "f":(_loc5_.nb > 0 ? int(Math.random() * _loc5_.nb) : -1),
                           "c":param1
                        });
                     }
                     else
                     {
                        this.apparenceBase.push({
                           "f":(_loc5_.nb > 0 ? int(Math.random() * _loc5_.nb) : -1),
                           "c":int(Math.random() * _loc5_.colors.length)
                        });
                     }
                  }
                  else
                  {
                     this.apparenceBase.push({"f":(_loc5_.nb > 0 ? int(Math.random() * _loc5_.nb) : -1)});
                  }
                  if(_loc5_.linkColor)
                  {
                     _loc3_ = 0;
                     for each(_loc6_ in Donnees.donnees[race].pictures)
                     {
                        for(_loc7_ in _loc6_)
                        {
                           if(_loc5_.linkColor == _loc7_ && _loc3_ < this.apparenceBase.length)
                           {
                              this.apparenceBase[_loc3_].c = this.apparenceBase[this.apparenceBase.length - 1].c;
                           }
                           _loc3_++;
                        }
                     }
                  }
                  if(_loc5_.linkShape)
                  {
                     _loc3_ = 0;
                     for each(_loc8_ in Donnees.donnees[race].pictures)
                     {
                        for(_loc9_ in _loc8_)
                        {
                           if(_loc5_.linkShape == _loc9_ && _loc3_ < this.apparenceBase.length)
                           {
                              this.apparenceBase[_loc3_].f = this.apparenceBase[this.apparenceBase.length - 1].f;
                           }
                           _loc3_++;
                        }
                     }
                  }
               }
            }
         }
         var _loc2_:ByteArray = new ByteArray();
         _loc2_.writeObject(this.apparenceBase);
         _loc2_.position = 0;
         this.apparence = _loc2_.readObject();
         dispatchEvent(new PersosEvent(PersosEvent.ACTUALISER_APPARENCE));
      }
      
      public function charger_apparence(param1:Vector.<Object>) : void
      {
         this.apparenceBase = param1;
         var _loc2_:ByteArray = new ByteArray();
         _loc2_.writeObject(this.apparenceBase);
         _loc2_.position = 0;
         this.apparence = _loc2_.readObject();
         dispatchEvent(new PersosEvent(PersosEvent.ACTUALISER_APPARENCE));
      }
      
      public function ajouter_objet(param1:String, param2:int = 1, param3:int = 0) : Boolean
      {
         var _loc4_:int = 0;
         if(Donnees.donnees[param1].maxQuantity)
         {
            _loc4_ = this.possede_objet2(param1,param3);
            if(_loc4_ != -1)
            {
               this.editer_quantite_objet(_loc4_,param2);
               if(this.objets[_loc4_].plein)
               {
                  return false;
               }
            }
            else
            {
               this.ajouter_objet2(param1,param2,param3);
            }
         }
         else
         {
            if(param2 == 1)
            {
               this.ajouter_objet2(param1,1,param3);
            }
            else
            {
               do
               {
                  this.ajouter_objet2(param1,param2,param3);
                  param2--;
               }
               while(param2 > 0);
            }
            if(Donnees.donnees[param1].gain)
            {
               this.utiliser_objet3(this.objets.length - 1,Donnees.donnees[param1].gain);
            }
         }
         return true;
      }
      
      public function ajouter_objet2(param1:String, param2:int = 1, param3:int = 0) : void
      {
         var _loc4_:Object = null;
         var _loc5_:Object = Donnees.donnees[param1];
         if(_loc5_.equip)
         {
            _loc4_ = new ObjetEquipe();
         }
         else if(_loc5_.autoUse)
         {
            _loc4_ = new ObjetAuto();
         }
         else
         {
            _loc4_ = new Objet();
         }
         if(_loc5_.autoUse)
         {
            _loc4_.addEventListener(Event.ACTIVATE,this.utiliser_objet_auto);
         }
         _loc4_.init(param1,_loc5_);
         if(_loc5_.maxQuantity)
         {
            _loc4_.actualiser_quantite_max(this.competences);
            _loc4_.quantite = param2;
         }
         _loc4_.renforcer = param3;
         this.objets.push(_loc4_);
         if(_loc4_ is ObjetEquipe)
         {
            this.utiliser_objet(this.objets.length - 1,!ia);
         }
         this.actualiser_preferences_ia();
      }
      
      public function possede_objet(param1:String) : int
      {
         var _loc2_:int = 0;
         while(_loc2_ < this.objets.length)
         {
            if(this.objets[_loc2_].id == param1)
            {
               return _loc2_;
            }
            _loc2_++;
         }
         return -1;
      }
      
      public function possede_objet2(param1:String, param2:int) : int
      {
         var _loc3_:int = 0;
         while(_loc3_ < this.objets.length)
         {
            if(this.objets[_loc3_].id == param1 && this.objets[_loc3_].renforcer == param2)
            {
               return _loc3_;
            }
            _loc3_++;
         }
         return -1;
      }
      
      public function possede_projectile(param1:String) : int
      {
         var _loc2_:int = 0;
         while(_loc2_ < this.objets.length)
         {
            if((this.objets[_loc2_].donnees.category == param1 || this.objets[_loc2_].id == param1) && this.objets[_loc2_] is ObjetEquipe && ObjetEquipe(this.objets[_loc2_]).equipe)
            {
               return _loc2_;
            }
            _loc2_++;
         }
         return -1;
      }
      
      public function possede_categorie(param1:String) : Boolean
      {
         var _loc2_:Boolean = false;
         var _loc3_:int = 0;
         while(_loc3_ < this.objets.length)
         {
            if(Donnees.donnees[this.objets[_loc3_].id].category == param1)
            {
               if(!(Boolean(Donnees.donnees[this.objets[_loc3_].id].oneHand) && !_loc2_))
               {
                  return true;
               }
               _loc2_ = true;
            }
            _loc3_++;
         }
         return false;
      }
      
      public function possede_categorie_epoque(param1:String) : int
      {
         var _loc3_:int = 0;
         var _loc2_:int = -1;
         while(_loc3_ < this.objets.length)
         {
            if(Donnees.donnees[this.objets[_loc3_].id].category == param1 && Donnees.donnees[this.objets[_loc3_].id].age > _loc2_)
            {
               _loc2_ = int(Donnees.donnees[this.objets[_loc3_].id].age);
            }
            _loc3_++;
         }
         return _loc2_;
      }
      
      public function quantite_objet(param1:String) : int
      {
         var _loc2_:int = 0;
         var _loc3_:Object = null;
         for each(_loc3_ in this.objets)
         {
            if(_loc3_.id == param1)
            {
               _loc2_ += Math.max(_loc3_.quantite,1);
            }
         }
         return _loc2_;
      }
      
      public function utiliser_objet(param1:int, param2:Boolean = false) : void
      {
         var _loc3_:Boolean = false;
         var _loc4_:String = null;
         var _loc5_:Boolean = false;
         var _loc6_:int = 0;
         var _loc7_:int = 0;
         var _loc8_:* = 0;
         var _loc9_:int = 0;
         if(this.objets[param1] is ObjetEquipe)
         {
            if(this.objets[param1].equipe)
            {
               if(this.objets[param1].changeApparence)
               {
                  _loc3_ = true;
               }
               this.equiper_objet(param1,false);
            }
            else
            {
               _loc4_ = this.objets[param1].donnees.category;
               _loc5_ = Boolean(this.objets[param1].donnees.oneHand);
               _loc6_ = -1;
               _loc7_ = -1;
               _loc8_ = int(this.objets.length);
               _loc9_ = 0;
               while(_loc9_ < _loc8_)
               {
                  if(Boolean(this.objets[_loc9_] is ObjetEquipe) && Boolean(this.objets[_loc9_].equipe) && _loc9_ != param1)
                  {
                     if(this.objets[_loc9_].donnees.category == _loc4_)
                     {
                        if(_loc5_)
                        {
                           if(this.objets[_loc9_].donnees.oneHand)
                           {
                              if(this.objets[_loc9_].gauche)
                              {
                                 _loc7_ = _loc9_;
                              }
                              else
                              {
                                 _loc6_ = _loc9_;
                              }
                           }
                           else
                           {
                              if(param2)
                              {
                                 return;
                              }
                              if(this.objets[_loc9_].changeApparence)
                              {
                                 _loc3_ = true;
                              }
                              if(this.equiper_objet(_loc9_,false))
                              {
                                 if(param1 >= _loc9_)
                                 {
                                    param1--;
                                 }
                                 _loc8_--;
                              }
                           }
                        }
                        else
                        {
                           if(param2)
                           {
                              return;
                           }
                           if(this.objets[_loc9_].changeApparence)
                           {
                              _loc3_ = true;
                           }
                           if(this.equiper_objet(_loc9_,false))
                           {
                              if(param1 >= _loc9_)
                              {
                                 param1--;
                              }
                              _loc8_--;
                           }
                        }
                     }
                  }
                  _loc9_++;
               }
               if(_loc5_)
               {
                  if(_loc6_ == -1 && _loc7_ == -1)
                  {
                     this.objets[param1].gauche = false;
                  }
                  else if(_loc6_ != -1 && _loc7_ == -1)
                  {
                     this.objets[param1].gauche = true;
                  }
                  else if(_loc6_ == -1 && _loc7_ != -1)
                  {
                     this.objets[param1].gauche = false;
                  }
                  else if(_loc6_ != -1 && _loc7_ != -1)
                  {
                     if(param2)
                     {
                        return;
                     }
                     if(this.objets[_loc7_].changeApparence)
                     {
                        _loc3_ = true;
                     }
                     if(this.equiper_objet(_loc7_,false))
                     {
                        if(param1 >= _loc7_)
                        {
                           param1--;
                        }
                     }
                     this.objets[param1].gauche = true;
                  }
               }
               if(this.objets[param1].changeApparence)
               {
                  _loc3_ = true;
               }
               this.equiper_objet(param1,true);
            }
            this.actualiser_bonus();
            if(_loc3_)
            {
               this.actualiser_apparence();
            }
         }
         else if(this.objets[param1].donnees["use"])
         {
            this.utiliser_objet2(param1);
         }
      }
      
      public function utiliser_objet_equipe(param1:int, param2:Boolean) : void
      {
         var _loc3_:Boolean = false;
         var _loc4_:String = null;
         var _loc5_:Boolean = false;
         var _loc6_:int = 0;
         var _loc7_:int = 0;
         if(this.objets[param1] is ObjetEquipe)
         {
            if(this.objets[param1].equipe)
            {
               if(this.objets[param1].changeApparence)
               {
                  _loc3_ = true;
               }
               this.equiper_objet(param1,false);
            }
            else
            {
               _loc4_ = this.objets[param1].donnees.category;
               _loc5_ = Boolean(this.objets[param1].donnees.oneHand);
               _loc6_ = int(this.objets.length);
               _loc7_ = 0;
               while(_loc7_ < _loc6_)
               {
                  if(Boolean(this.objets[_loc7_] is ObjetEquipe) && Boolean(this.objets[_loc7_].equipe) && _loc7_ != param1)
                  {
                     if(this.objets[_loc7_].donnees.category == _loc4_)
                     {
                        if(_loc5_)
                        {
                           if(this.objets[_loc7_].donnees.oneHand)
                           {
                              if(this.objets[_loc7_].gauche == param2)
                              {
                                 if(this.objets[_loc7_].changeApparence)
                                 {
                                    _loc3_ = true;
                                 }
                                 this.equiper_objet(_loc7_,false);
                              }
                           }
                           else
                           {
                              if(this.objets[_loc7_].changeApparence)
                              {
                                 _loc3_ = true;
                              }
                              this.equiper_objet(_loc7_,false);
                           }
                        }
                        else
                        {
                           if(this.objets[_loc7_].changeApparence)
                           {
                              _loc3_ = true;
                           }
                           this.equiper_objet(_loc7_,false);
                        }
                     }
                  }
                  _loc7_++;
               }
               this.objets[param1].gauche = param2;
               if(this.objets[param1].changeApparence)
               {
                  _loc3_ = true;
               }
               this.equiper_objet(param1,true);
            }
            this.actualiser_bonus();
            if(_loc3_)
            {
               this.actualiser_apparence();
            }
         }
         else if(this.objets[param1].donnees["use"])
         {
            this.utiliser_objet2(param1);
         }
      }
      
      protected function equiper_objet(param1:int, param2:Boolean) : Boolean
      {
         this.objets[param1].equipe = param2;
         if(!param2 && Boolean(this.objets[param1].donnees.unequip))
         {
            return this.utiliser_objet3(param1,this.objets[param1].donnees.unequip);
         }
         return false;
      }
      
      protected function editer_quantite_objet(param1:int, param2:int) : void
      {
         this.objets[param1].quantite += param2;
      }
      
      protected function actualiser_apparence() : void
      {
         var _loc2_:Object = null;
         var _loc3_:String = null;
         var _loc4_:int = 0;
         var _loc1_:ByteArray = new ByteArray();
         _loc1_.writeObject(this.apparenceBase);
         _loc1_.position = 0;
         this.apparence = _loc1_.readObject();
         for each(_loc2_ in this.objets)
         {
            if(_loc2_ is ObjetEquipe)
            {
               if(Boolean(_loc2_.equipe) && Boolean(_loc2_.changeApparence))
               {
                  for(_loc3_ in _loc2_.donnees.appearance)
                  {
                     _loc4_ = 0;
                     while(_loc4_ < Donnees.donnees[race].pictures.length)
                     {
                        if(Donnees.donnees[race].pictures[_loc4_][_loc3_])
                        {
                           if(_loc2_.donnees.appearance[_loc3_].color)
                           {
                              this.apparence[_loc4_] = {
                                 "f":_loc2_.donnees.appearance[_loc3_].no,
                                 "c":_loc2_.donnees.appearance[_loc3_].color
                              };
                           }
                           else
                           {
                              this.apparence[_loc4_] = {"f":_loc2_.donnees.appearance[_loc3_].no};
                           }
                        }
                        _loc4_++;
                     }
                  }
               }
            }
         }
         dispatchEvent(new PersosEvent(PersosEvent.ACTUALISER_APPARENCE));
      }
      
      public function utiliser_objet2(param1:int) : void
      {
         var _loc2_:Object = this.objets[param1].donnees["use"];
         this.utiliser_objet3(param1,_loc2_);
      }
      
      private function utiliser_objet_auto(param1:Event) : void
      {
         var _loc2_:Object = param1.currentTarget.donnees["autoUse"];
         this.utiliser_objet4(_loc2_,param1.currentTarget.renforcer + 1);
      }
      
      protected function utiliser_objet3(param1:int, param2:Object) : Boolean
      {
         if(this.utiliser_objet4(param2))
         {
            if(param2.resurrect)
            {
               vie.score = Math.max(1,param2.resurrect * vie.scoreMax);
            }
            if(param2.cooldown)
            {
               this.rechargement.ajouter(param2.cooldown.id,param2.cooldown.time);
            }
            if(param2.quantity)
            {
               if(param1 < this.objets.length)
               {
                  this.supprimer_quantite_objet(param1,param2.quantity);
               }
            }
            if(param2.equip)
            {
               if(!this.objets[param1].equipe)
               {
                  this.utiliser_objet(param1);
               }
            }
            if(param2.message)
            {
               dispatchEvent(new MessageEvent(MessageEvent.MESSAGE_IMPORTANT,this.message_selon_sexe(param2.message[Donnees.langue]),ville));
            }
            if(param2.king != undefined)
            {
               this.roi = param2.king;
            }
            return true;
         }
         return false;
      }
      
      private function message_selon_sexe(param1:Object) : String
      {
         var _loc2_:String = null;
         if(param1["D"])
         {
            _loc2_ = param1["D"];
         }
         if(this.feminin)
         {
            _loc2_ = param1["F"];
         }
         else
         {
            _loc2_ = param1["M"];
         }
         _loc2_ = _loc2_.replace("[playerRace]",race);
         if(this is Joueur)
         {
            return _loc2_.replace("[playerName]",Joueur(this).nom);
         }
         return _loc2_.replace("[playerName]",race);
      }
      
      protected function utiliser_objet4(param1:Object, param2:int = 1) : Boolean
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: ArrayIndexOutOfBoundsException (null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      public function gagner_objet_temporaire(param1:String, param2:int, param3:int = 0) : void
      {
         var _loc4_:ObjetTemporaire = null;
         if(this.possede_objet2(param1,param3) != -1)
         {
            this.objets[this.possede_objet(param1)].augmenterTemps(param2);
         }
         else
         {
            _loc4_ = new ObjetTemporaire();
            _loc4_.init(param1,Donnees.donnees[param1]);
            _loc4_.tempsRestant = param2;
            _loc4_.renforcer = param3;
            this.objets.push(_loc4_);
            _loc4_.addEventListener(ObjetTemporaireEvent.DISSIPER,this.perdre_objet_temporaire);
            this.actualiser_bonus();
         }
      }
      
      protected function perdre_objet_temporaire(param1:Object) : void
      {
         var _loc2_:ObjetTemporaire = ObjetTemporaire(param1.currentTarget);
         _loc2_.removeEventListener(ObjetTemporaireEvent.DISSIPER,this.perdre_objet_temporaire);
         this.supprimer_objet(this.possede_objet(_loc2_.id));
         if(_loc2_.changeApparence)
         {
            this.actualiser_apparence();
         }
         this.actualiser_bonus();
      }
      
      public function supprimer_quantite_objet(param1:int, param2:int) : Boolean
      {
         if(this.objets[param1].quantite + param2 <= 0)
         {
            this.supprimer_objet(param1);
            return true;
         }
         this.editer_quantite_objet(param1,param2);
         return false;
      }
      
      public function supprimer_objet(param1:int) : void
      {
         if(this.objets[param1].donnees.lost)
         {
            this.parler(this.objets[param1].donnees.lost[Donnees.langue]);
         }
         this.objets[param1].removeEventListener(Event.ACTIVATE,this.utiliser_objet_auto);
         this.objets[param1].detruire();
         this.objets.splice(param1,1);
         this.actualiser_preferences_ia();
         this.iaArmesDistancesMunitionsNecessaires = true;
      }
      
      private function actualiser_preferences_ia() : void
      {
         var _loc1_:Object = null;
         this.iaArmesDistancesPreferees = new Vector.<Object>();
         this.iaArmesContactPreferees = new Vector.<Object>();
         for each(_loc1_ in this.objets)
         {
            if(_loc1_ is ObjetEquipe)
            {
               if(Donnees.donnees[_loc1_.id].category == "weapon" && (!Donnees.donnees[_loc1_.id].tag || Donnees.donnees[_loc1_.id].tag.indexOf("tool") == -1))
               {
                  if(Donnees.donnees[_loc1_.id].range >= 100)
                  {
                     this.iaArmesDistancesPreferees.push(_loc1_);
                  }
                  else
                  {
                     this.iaArmesContactPreferees.push(_loc1_);
                  }
               }
            }
         }
         this.iaArmesDistancesPreferees.sort(this.ranger_preference_objet);
         this.iaArmesContactPreferees.sort(this.ranger_preference_objet);
         IA.verifier_munitions(this);
      }
      
      private function ranger_preference_objet(param1:Object, param2:Object) : int
      {
         if(param1.donnees.age > param2.donnees.age)
         {
            return -1;
         }
         if(param1.donnees.age < param2.donnees.age)
         {
            return 1;
         }
         return 0;
      }
      
      public function actualiser_bonus(param1:Object = null) : void
      {
         var _loc2_:Boolean = false;
         var _loc6_:int = 0;
         var _loc8_:String = null;
         var _loc9_:Object = null;
         var _loc10_:Object = null;
         var _loc11_:Attaque = null;
         var _loc12_:int = 0;
         var _loc13_:Attaque = null;
         this.caracteristiquesPrimaires["health"].removeEventListener(CaracteristiquePrimaireEvent.ACTUALISER_SCORE,actualiser_vie);
         this.caracteristiquesPrimaires["health"].removeEventListener(CaracteristiquePrimaireEvent.ACTUALISER_SCORE_MAX,actualiser_vie);
         if(volant != this.volantBase)
         {
            volant = this.volantBase;
            _loc2_ = true;
         }
         if(Boolean(volantTimer) && !this.volantBase)
         {
            volantTimer.stop();
         }
         attaque.init_score(this.attaqueBase);
         effacer_attaques_supplementaires();
         attaque.tempsAttaque = intervalAttaques;
         attaque.effet = this.effetBase;
         attaque.effetLigne = attaque.son = attaque.projectile = null;
         attaque.effetArme = null;
         attaque.coutAttaque = null;
         this.attaqueBonus = attaque.delai = attaque.portee = portee = 0;
         attaque.attaquesMultiples = false;
         defense = defenseBase;
         vitesse = vitesseBase;
         var _loc3_:Number = 0;
         var _loc4_:Number = 0;
         var _loc5_:String = this.monture;
         this.monture = "";
         var _loc7_:Vector.<Attaque> = new Vector.<Attaque>();
         resistances = new Dictionary();
         for(_loc8_ in this.resistancesBase)
         {
            resistances[_loc8_] = this.resistancesBase[_loc8_];
         }
         for each(_loc9_ in this.caracteristiquesPrimaires)
         {
            _loc9_.enregistrerCoef();
            if(_loc9_.scoreMax != _loc9_.scoreMaxBase)
            {
               _loc9_.scoreMax = _loc9_.scoreMaxBase;
               _loc9_.chargerCoef();
            }
            _loc9_.scoreRegeneration = 1;
         }
         for each(_loc9_ in this.caracteristiquesSecondaires)
         {
            if(_loc9_.score != _loc9_.scoreBase)
            {
               _loc9_.score = _loc9_.scoreBase;
            }
         }
         for each(_loc9_ in this.competences)
         {
            if(_loc9_.score != _loc9_.scoreBase)
            {
               _loc9_.init();
            }
         }
         for each(_loc9_ in this.objets)
         {
            if(_loc9_ is ObjetEquipe && Boolean(_loc9_.equipe))
            {
               this.ajouter_bonus_carac_secondaire(_loc9_.donnees,_loc9_.multiplicateur);
               if(_loc9_.donnees.addItems)
               {
                  for each(_loc10_ in _loc9_.donnees.addItems)
                  {
                     this.ajouter_bonus_carac_secondaire(_loc10_,_loc9_.multiplicateur);
                  }
               }
            }
         }
         if(param1)
         {
            this.ajouter_bonus_carac_secondaire(param1);
         }
         for each(_loc9_ in this.competences)
         {
            if(_loc9_.score != _loc9_.scoreBase)
            {
               _loc9_.init();
            }
         }
         for each(_loc9_ in this.objets)
         {
            if(_loc9_ is ObjetEquipe && Boolean(_loc9_.equipe))
            {
               this.ajouter_bonus_competences(_loc9_.donnees,_loc9_.multiplicateur);
               if(_loc9_.donnees.addItems)
               {
                  for each(_loc10_ in _loc9_.donnees.addItems)
                  {
                     this.ajouter_bonus_competences(_loc10_,_loc9_.multiplicateur);
                  }
               }
            }
         }
         if(param1)
         {
            this.ajouter_bonus_competences(param1);
         }
         for each(_loc9_ in this.objets)
         {
            if(_loc9_ is ObjetEquipe && Boolean(_loc9_.equipe))
            {
               this.ajouter_bonus(_loc9_.donnees,_loc7_,_loc9_.multiplicateur,_loc9_.gauche);
               if(_loc9_.donnees.speed)
               {
                  _loc3_ = Number(_loc9_.donnees.speed);
               }
               if(_loc9_.donnees.bonusSpeed)
               {
                  _loc4_ += _loc9_.donnees.bonusSpeed;
               }
               if(_loc9_.donnees.flying)
               {
                  if(!this.volantBase)
                  {
                     volant = true;
                     _loc2_ = true;
                  }
               }
               if(_loc9_.donnees.autoWalk)
               {
                  if(!volantTimer)
                  {
                     volantTimer = new Timer(INTERVAL_DEPLACEMENT);
                     volantTimer.addEventListener(TimerEvent.TIMER,voler);
                  }
                  volantTimer.start();
               }
               if(_loc9_.donnees.mount)
               {
                  this.monture = _loc9_.id;
                  _loc6_ = int(_loc9_.donnees.mount.y);
               }
               if(_loc9_.donnees.addItems)
               {
                  for each(_loc10_ in _loc9_.donnees.addItems)
                  {
                     this.ajouter_bonus(_loc10_,_loc7_,_loc9_.gauche,_loc9_.multiplicateur);
                  }
               }
            }
         }
         if(param1)
         {
            this.ajouter_bonus(param1,_loc7_);
         }
         if(_loc7_.length > 0)
         {
            _loc12_ = (this.attaqueBase + this.attaqueBonus) / _loc7_.length;
            attaque.copier(_loc7_[0]);
            attaque.augmenter_score(_loc12_);
            if(_loc7_.length > 1)
            {
               _loc7_.shift();
               ajouter_attaques_supplementaires(_loc7_,_loc12_);
            }
         }
         else
         {
            attaque.augmenter_score(this.attaqueBonus);
            attaque.attaqueDX = 0;
            attaque.attaqueDY = -hauteur * 0.5;
         }
         attaque.demarrer();
         for each(_loc11_ in attaquesSupplementaires)
         {
            _loc11_.demarrer();
         }
         this.defenseBonus = defense;
         if(_loc3_ != 0)
         {
            vitesse = _loc3_;
         }
         vitesse += _loc4_;
         this.vitesseBonus = vitesse;
         if(this.monture != _loc5_)
         {
            dispatchEvent(new PersosEvent(PersosEvent.ACTUALISER_MONTURE));
         }
         if(_loc2_)
         {
            if(volant)
            {
               decalageY = 0;
            }
            else
            {
               decalageY = Terrain.case_DecalageY(x,y);
            }
            dispatchEvent(new PersosEvent(PersosEvent.DECALER_Y));
         }
         if(_loc6_ != 0)
         {
            attaque.attaqueDY += _loc6_;
            for each(_loc13_ in attaquesSupplementaires)
            {
               _loc13_.attaqueDY += _loc6_;
            }
         }
         this.appliquer_penalites();
         this.caracteristiquesPrimaires["health"].addEventListener(CaracteristiquePrimaireEvent.ACTUALISER_SCORE,actualiser_vie);
         this.caracteristiquesPrimaires["health"].addEventListener(CaracteristiquePrimaireEvent.ACTUALISER_SCORE_MAX,actualiser_vie);
      }
      
      public function set roi(param1:Boolean) : void
      {
         this._roi = param1;
         if(param1)
         {
            dispatchEvent(new PersosEvent(PersosEvent.ROI));
         }
         else
         {
            dispatchEvent(new PersosEvent(PersosEvent.ROI_FIN));
         }
      }
      
      private function ajouter_bonus_carac_secondaire(param1:Object, param2:Number = 1) : void
      {
         var _loc3_:String = null;
         var _loc4_:String = null;
         for(_loc3_ in param1.bonus)
         {
            if(_loc3_ != "attack" && _loc3_ != "defense")
            {
               if(this.caracteristiquesSecondaires[_loc3_])
               {
                  for(_loc4_ in param1.bonus[_loc3_])
                  {
                     if(this.competences[_loc4_])
                     {
                        this.ajouter_bonus_carac_secondaire2(_loc3_,param1.bonus[_loc3_][_loc4_] * this.competences[_loc4_].score * param2);
                     }
                  }
                  if(param1.bonus[_loc3_] is int)
                  {
                     this.ajouter_bonus_carac_secondaire2(_loc3_,param1.bonus[_loc3_] * param2);
                  }
               }
            }
         }
      }
      
      private function ajouter_bonus_carac_secondaire2(param1:String, param2:int) : void
      {
         var _loc3_:String = null;
         this.caracteristiquesSecondaires[param1].score += param2;
         for each(_loc3_ in Donnees.donnees[param1].skills)
         {
            this.competences[_loc3_].ajouter_bonus(param2);
         }
      }
      
      private function ajouter_bonus_competences(param1:Object, param2:Number = 1) : void
      {
         var _loc3_:String = null;
         var _loc4_:String = null;
         for(_loc3_ in param1.bonus)
         {
            if(this.competences[_loc3_])
            {
               for(_loc4_ in param1.bonus[_loc3_])
               {
                  if(this.competences[_loc4_])
                  {
                     this.competences[_loc3_].ajouter_bonus(param1.bonus[_loc3_][_loc4_] * this.competences[_loc4_].score * param2);
                  }
                  else if(this.caracteristiquesSecondaires[_loc4_])
                  {
                     this.competences[_loc3_].ajouter_bonus(param1.bonus[_loc3_][_loc4_] * this.caracteristiquesSecondaires[_loc4_].score * param2);
                  }
                  else if(this.caracteristiquesPrimaires[_loc4_])
                  {
                     this.competences[_loc3_].ajouter_bonus(param1.bonus[_loc3_][_loc4_] * this.caracteristiquesPrimaires[_loc4_].score * param2);
                  }
               }
               if(param1.bonus[_loc3_] is int)
               {
                  this.competences[_loc3_].ajouter_bonus(param1.bonus[_loc3_] * param2);
               }
            }
         }
      }
      
      private function ajouter_bonus(param1:Object, param2:Vector.<Attaque>, param3:Number = 1, param4:Boolean = false) : void
      {
         var _loc5_:String = null;
         var _loc6_:String = null;
         var _loc7_:String = null;
         var _loc8_:int = 0;
         var _loc9_:Boolean = false;
         var _loc10_:int = 0;
         for(_loc5_ in param1.bonus)
         {
            switch(_loc5_)
            {
               case "attack":
                  _loc9_ = true;
                  if(!param1.attackTime)
                  {
                     if(param1.bonus[_loc5_] is int)
                     {
                        this.attaqueBonus += param1.bonus[_loc5_];
                     }
                     else
                     {
                        for(_loc6_ in param1.bonus[_loc5_])
                        {
                           if(this.competences[_loc6_])
                           {
                              this.attaqueBonus += param1.bonus[_loc5_][_loc6_] * this.competences[_loc6_].score * param3;
                           }
                           else if(this.caracteristiquesSecondaires[_loc6_])
                           {
                              this.attaqueBonus += param1.bonus[_loc5_][_loc6_] * this.caracteristiquesSecondaires[_loc6_].score * param3;
                           }
                        }
                     }
                  }
                  else
                  {
                     for(_loc6_ in param1.bonus[_loc5_])
                     {
                        if(this.competences[_loc6_])
                        {
                           if(_loc9_)
                           {
                              param2.push(new Attaque());
                              _loc9_ = false;
                              param2[param2.length - 1].init_score(param1.bonus[_loc5_][_loc6_] * this.competences[_loc6_].score * param3);
                              if(param1.attackDX)
                              {
                                 param2[param2.length - 1].attaqueDX = param1.attackDX;
                              }
                              if(param1.oneHand)
                              {
                                 if(param4)
                                 {
                                    param2[param2.length - 1].attaqueDX -= largeur * 0.5;
                                 }
                                 else
                                 {
                                    param2[param2.length - 1].attaqueDX = largeur * 0.5;
                                 }
                              }
                              if(param1.attackDY)
                              {
                                 param2[param2.length - 1].attaqueDY = param1.attackDY - hauteur * 0.5;
                              }
                              else
                              {
                                 param2[param2.length - 1].attaqueDY = -hauteur * 0.5;
                              }
                              if(param1.attackDelay)
                              {
                                 param2[param2.length - 1].delai = param1.attackDelay;
                              }
                              param2[param2.length - 1].coutAttaque = JSON.parse(JSON.stringify(param1));
                              if(param2[param2.length - 1].coutAttaque.special)
                              {
                                 this.calculer_attaque_special(param2[param2.length - 1].coutAttaque.special,param1.special);
                              }
                              if(param1.attacks)
                              {
                                 param2[param2.length - 1].attaquesMultiples = true;
                                 _loc8_ = 0;
                                 while(_loc8_ < param2[param2.length - 1].coutAttaque.attacks.length)
                                 {
                                    if(param2[param2.length - 1].coutAttaque.attacks[_loc8_].special)
                                    {
                                       this.calculer_attaque_special(param2[param2.length - 1].coutAttaque.attacks[_loc8_].special,param1.attacks[_loc8_].special);
                                    }
                                    _loc8_++;
                                 }
                              }
                              if(param1.kill)
                              {
                                 param2[param2.length - 1].effetTueur = param1.kill;
                              }
                           }
                           else
                           {
                              param2[param2.length - 1].augmenter_score(param1.bonus[_loc5_][_loc6_] * this.competences[_loc6_].score * param3);
                           }
                           if(param1.damage)
                           {
                              param2[param2.length - 1].actualiser_degats(param1.damage);
                           }
                        }
                     }
                  }
                  break;
               case "defense":
                  if(param1.bonus[_loc5_] is int)
                  {
                     defense += param1.bonus[_loc5_];
                  }
                  else
                  {
                     for(_loc6_ in param1.bonus[_loc5_])
                     {
                        if(this.competences[_loc6_])
                        {
                           defense += param1.bonus[_loc5_][_loc6_] * this.competences[_loc6_].score * param3;
                        }
                        else if(this.caracteristiquesSecondaires[_loc6_])
                        {
                           defense += param1.bonus[_loc5_][_loc6_] * this.caracteristiquesSecondaires[_loc6_].score * param3;
                        }
                     }
                  }
                  break;
               case "speed":
                  vitesse += param1.bonus[_loc5_];
                  break;
               default:
                  if(this.caracteristiquesPrimaires[_loc5_])
                  {
                     for(_loc6_ in param1.bonus[_loc5_])
                     {
                        if(this.competences[_loc6_])
                        {
                           this.caracteristiquesPrimaires[_loc5_].scoreMax += param1.bonus[_loc5_][_loc6_] * this.competences[_loc6_].score * param3;
                           this.caracteristiquesPrimaires[_loc5_].chargerCoef();
                        }
                        else if(this.caracteristiquesSecondaires[_loc6_])
                        {
                           this.caracteristiquesPrimaires[_loc5_].scoreMax += param1.bonus[_loc5_][_loc6_] * this.caracteristiquesSecondaires[_loc6_].score * param3;
                           this.caracteristiquesPrimaires[_loc5_].chargerCoef();
                        }
                     }
                     if(param1.bonus[_loc5_] is int)
                     {
                        this.caracteristiquesPrimaires[_loc5_].scoreMax += param1.bonus[_loc5_] * param3;
                        this.caracteristiquesPrimaires[_loc5_].chargerCoef();
                     }
                  }
            }
         }
         for(_loc5_ in param1.bonusRegeneration)
         {
            if(this.caracteristiquesPrimaires[_loc5_])
            {
               this.caracteristiquesPrimaires[_loc5_].scoreRegeneration += param1.bonusRegeneration[_loc5_];
            }
         }
         if(param1.attackTime)
         {
            param2[param2.length - 1].tempsAttaque = param1.attackTime;
         }
         if(param1.effect)
         {
            param2[param2.length - 1].effet = param1.effect;
         }
         if(param1.effectLine)
         {
            param2[param2.length - 1].effetLigne = param1.effectLine;
         }
         if(param1.sound)
         {
            param2[param2.length - 1].son = param1.sound;
         }
         if(param1.anim)
         {
            param2[param2.length - 1].effetArme = new EffetArme(param1.id,param1.anim,param1.son);
         }
         if(param1.range)
         {
            if(param1.category == "weapon" && portee < param1.range)
            {
               portee = param1.range;
            }
            param2[param2.length - 1].portee = param1.range;
         }
         if(param1.missile)
         {
            param2[param2.length - 1].projectile = param1.missile;
         }
         if(Boolean(param1.resistance) && param1.type != "house")
         {
            for(_loc5_ in param1.resistance)
            {
               if(resistances[_loc5_])
               {
                  resistances[_loc5_] += param1.resistance[_loc5_];
               }
               else
               {
                  resistances[_loc5_] = 1 + param1.resistance[_loc5_];
               }
               if(resistances[_loc5_] < Donnees.donnees[_loc5_].min)
               {
                  resistances[_loc5_] = Donnees.donnees[_loc5_].min;
               }
            }
         }
         if(Boolean(param1.attack) && Boolean(param1.attack.costItem))
         {
            for(_loc5_ in param1.attack.costItem)
            {
               _loc10_ = this.possede_projectile(_loc5_);
               if(_loc10_ != -1)
               {
                  if(this.objets[_loc10_].donnees.ammoBonus)
                  {
                     if(this.objets[_loc10_].donnees.ammoBonus.bonus)
                     {
                        for(_loc6_ in this.objets[_loc10_].donnees.ammoBonus.bonus)
                        {
                           switch(_loc6_)
                           {
                              case "attack":
                                 for(_loc7_ in this.objets[_loc10_].donnees.ammoBonus.bonus[_loc6_])
                                 {
                                    if(this.competences[_loc7_])
                                    {
                                       param2[param2.length - 1].augmenter_score(this.objets[_loc10_].donnees.ammoBonus.bonus[_loc6_][_loc7_] * this.competences[_loc7_].score * param3);
                                    }
                                 }
                           }
                        }
                     }
                     if(this.objets[_loc10_].donnees.ammoBonus.damage)
                     {
                        param2[param2.length - 1].actualiser_degats(this.objets[_loc10_].donnees.ammoBonus.damage);
                     }
                     if(this.objets[_loc10_].donnees.ammoBonus.missile)
                     {
                        param2[param2.length - 1].projectile = this.objets[_loc10_].donnees.ammoBonus.missile;
                     }
                     if(this.objets[_loc10_].donnees.ammoBonus.special)
                     {
                        if(!param2[param2.length - 1].coutAttaque)
                        {
                           param2[param2.length - 1].coutAttaque = new Object();
                        }
                        param2[param2.length - 1].coutAttaque.special = new Object();
                        this.calculer_attaque_special(param2[param2.length - 1].coutAttaque.special,this.objets[_loc10_].donnees.ammoBonus.special);
                     }
                  }
               }
            }
         }
      }
      
      private function calculer_attaque_special(param1:Object, param2:Object) : void
      {
         var _loc3_:String = null;
         var _loc4_:String = null;
         var _loc5_:int = 0;
         for(_loc3_ in param2)
         {
            switch(_loc3_)
            {
               case "poison":
                  _loc5_ = 0;
                  for(_loc4_ in param2[_loc3_]["attack"])
                  {
                     if(this.competences[_loc4_])
                     {
                        _loc5_ += param2[_loc3_]["attack"][_loc4_] * this.competences[_loc4_].score;
                     }
                  }
                  param1[_loc3_] = {
                     "attack":_loc5_,
                     "time":param2[_loc3_]["time"]
                  };
                  break;
               case "area":
               case "chain":
                  _loc5_ = 0;
                  for(_loc4_ in param2[_loc3_]["attack"])
                  {
                     if(this.competences[_loc4_])
                     {
                        _loc5_ += param2[_loc3_]["attack"][_loc4_] * this.competences[_loc4_].score;
                     }
                  }
                  if(_loc3_ == "area")
                  {
                     param1[_loc3_] = {
                        "attack":_loc5_,
                        "range":param2[_loc3_]["range"],
                        "effect":param2[_loc3_]["effect"]
                     };
                  }
                  else
                  {
                     param1[_loc3_] = {
                        "number":param2[_loc3_]["number"],
                        "attack":_loc5_,
                        "range":param2[_loc3_]["range"],
                        "effect":param2[_loc3_]["effect"],
                        "effectLine":param2[_loc3_]["effectLine"]
                     };
                  }
                  break;
               default:
                  param1[_loc3_] = param2[_loc3_];
            }
         }
      }
      
      override protected function appliquer_penalites(param1:Event = null) : void
      {
         var _loc2_:Attaque = null;
         vitesse = this.vitesseBonus;
         defense = this.defenseBonus;
         penalites.appliquer_penalites_mobiles(this);
         attaque.score = attaque.scoreBase;
         penalites.appliquer_penalites_combattants(this);
         for each(_loc2_ in attaquesSupplementaires)
         {
            _loc2_.score = _loc2_.scoreBase;
         }
         penalites.appliquer_penalites_combattantsAvances(this);
         couleur = penalites.couleur;
      }
      
      override public function verifier_peut_attaquer(param1:Object, param2:Boolean = false, param3:Boolean = false, param4:Boolean = true) : Boolean
      {
         var _loc5_:int = 0;
         var _loc6_:String = null;
         var _loc7_:Object = null;
         if(Boolean(param1) && Boolean(param1.attack))
         {
            if(param1.attack.costItem)
            {
               for(_loc6_ in param1.attack.costItem)
               {
                  _loc5_ = this.possede_projectile(_loc6_);
                  if(_loc5_ == -1)
                  {
                     if(Boolean(param1.id) && ia)
                     {
                        this.desequiper(param1.id);
                     }
                     if(param4)
                     {
                        if(param2)
                        {
                           this.parler_depuis_donnee(Donnees.donnees[_loc6_]["zero"]);
                        }
                        else
                        {
                           this.parler_depuis_donnee(Donnees.donnees[_loc6_]["out"]);
                        }
                     }
                     return true;
                  }
                  if(!(this.objets[_loc5_] is ObjetEquipe) || !ObjetEquipe(this.objets[_loc5_]).equipe || this.objets[_loc5_].quantite < param1.attack.costItem[_loc6_])
                  {
                     if(Boolean(param1.id) && ia)
                     {
                        this.desequiper(param1.id);
                     }
                     if(param4)
                     {
                        if(this.objets[_loc5_].quantite > 1)
                        {
                           this.parler_depuis_donnee(Donnees.donnees[_loc6_]["lack"]);
                        }
                        else
                        {
                           this.parler_depuis_donnee(Donnees.donnees[_loc6_]["zero"]);
                        }
                     }
                     return true;
                  }
                  if(!param2 && !param3)
                  {
                     this.supprimer_quantite_objet(_loc5_,-param1.attack.costItem[_loc6_]);
                  }
               }
            }
            if(param1.attack.costPrimaryCharacteristic)
            {
               _loc7_ = param1.attack.costPrimaryCharacteristic;
               for(_loc6_ in _loc7_)
               {
                  if(this.caracteristiquesPrimaires[_loc6_].score < _loc7_[_loc6_])
                  {
                     if(Boolean(param1.id) && ia)
                     {
                        this.desequiper(param1.id);
                     }
                     if(param4)
                     {
                        if(this.caracteristiquesPrimaires[_loc6_].score < 1)
                        {
                           this.parler_depuis_donnee(Donnees.donnees[_loc6_]["zero"]);
                        }
                        else
                        {
                           this.parler_depuis_donnee(Donnees.donnees[_loc6_]["lack"]);
                        }
                     }
                     return true;
                  }
                  if(!param2 && !param3)
                  {
                     this.caracteristiquesPrimaires[_loc6_].score -= _loc7_[_loc6_];
                  }
               }
            }
         }
         return false;
      }
      
      public function perdre_objet(param1:String, param2:int) : void
      {
         this.supprimer_quantite_objet(this.possede_objet(param1),param2);
      }
      
      private function desequiper(param1:String) : void
      {
         var _loc2_:int = 0;
         while(_loc2_ < this.objets.length)
         {
            if(this.objets[_loc2_].id == param1 && Boolean(this.objets[_loc2_].equipe))
            {
               this.equiper_objet(_loc2_,false);
               this.actualiser_bonus();
               return;
            }
            _loc2_++;
         }
      }
      
      public function parler_depuis_donnee(param1:Object) : void
      {
         var _loc2_:Array = null;
         if(param1)
         {
            param1 = param1[Donnees.langue];
            _loc2_ = new Array();
            if(param1["D"])
            {
               _loc2_ = _loc2_.concat(param1["D"]);
            }
            if(this.feminin)
            {
               if(param1["F"])
               {
                  _loc2_ = _loc2_.concat(param1["F"]);
               }
            }
            else if(param1["M"])
            {
               _loc2_ = _loc2_.concat(param1["M"]);
            }
            this.parler(_loc2_[int(Math.random() * _loc2_.length)]);
         }
      }
      
      public function parler_aleatoire(param1:String) : void
      {
         var _loc2_:Array = null;
         if(Donnees.donnees[race].talk)
         {
            _loc2_ = Donnees.donnees[race].talk[param1][Donnees.langue];
            this.parler(_loc2_[int(Math.random() * _loc2_.length)]);
         }
      }
      
      public function parler(param1:String) : void
      {
         dispatchEvent(new BulleEvent(BulleEvent.MESSAGE,param1));
      }
      
      override public function pause() : void
      {
         var _loc1_:Object = null;
         var _loc2_:Object = null;
         if(vivant)
         {
            for each(_loc2_ in this.caracteristiquesPrimaires)
            {
               _loc2_.arreter();
            }
         }
         for each(_loc1_ in this.objets)
         {
            if(_loc1_ is ObjetAuto)
            {
               _loc1_.arreter();
            }
         }
         this.rechargement.arreter();
         super.pause();
      }
      
      override public function reprendre() : void
      {
         var _loc1_:Object = null;
         var _loc2_:Object = null;
         if(vivant)
         {
            for each(_loc2_ in this.caracteristiquesPrimaires)
            {
               _loc2_.reprendre();
            }
         }
         for each(_loc1_ in this.objets)
         {
            if(_loc1_ is ObjetAuto)
            {
               _loc1_.reprendre();
            }
         }
         this.rechargement.reprendre();
         super.reprendre();
      }
      
      public function reculer(param1:Vivant) : void
      {
         if(ia && vitesse >= vitesse && portee > 128 && portee > distance(param1) + 64)
         {
            this.reculer2(param1);
         }
      }
      
      public function reculer2(param1:Object) : Boolean
      {
         var _loc2_:Number = x - param1.x;
         var _loc3_:Number = y - param1.y;
         var _loc4_:Number = Math.abs(_loc2_) + Math.abs(_loc3_);
         var _loc5_:Number = IA.verifier_destinationX(x + _loc2_ / _loc4_ * 128);
         var _loc6_:Number = IA.verifier_destinationY(y + _loc3_ / _loc4_ * 128);
         if(Math.pow(x - _loc5_,2) + Math.pow(y - _loc6_,2) > 64)
         {
            aller(_loc5_,_loc6_);
            this.iaMemoireCible = true;
            return true;
         }
         return false;
      }
      
      override public function editer_vie(param1:int) : void
      {
         vie.score += param1;
      }
      
      public function revivre() : void
      {
         var _loc1_:Object = null;
         for each(_loc1_ in this.caracteristiquesPrimaires)
         {
            _loc1_.reprendre();
         }
         attaqueTimer.start();
         visible = true;
      }
      
      override public function mourir() : void
      {
         this.utiliser_objets_mort();
         if(!vivant)
         {
            attaqueTimer.stop();
            super.mourir();
            this.iaMemoireCible = false;
         }
      }
      
      protected function utiliser_objets_mort() : void
      {
         var _loc1_:* = 0;
         var _loc2_:int = 0;
         _loc1_ = 0;
         while(_loc1_ < this.objets.length)
         {
            if(Boolean(this.objets[_loc1_].donnees.death) && Boolean(this.objets[_loc1_].donnees.death.resurrect))
            {
               this.utiliser_objet3(_loc1_,this.objets[_loc1_].donnees.death);
               this.actualiser_bonus();
               return;
            }
            _loc1_++;
         }
         _loc1_ = 0;
         while(_loc1_ < this.objets.length)
         {
            if(this.objets[_loc1_].donnees.death)
            {
               _loc2_ = int(this.objets.length);
               if(this.utiliser_objet3(_loc1_,this.objets[_loc1_].donnees.death))
               {
                  if(_loc2_ > this.objets.length)
                  {
                     _loc1_--;
                  }
                  this.actualiser_bonus();
               }
            }
            _loc1_++;
         }
      }
      
      override public function detruire() : void
      {
         var _loc1_:String = null;
         var _loc2_:Object = null;
         super.detruire();
         this.caracteristiquesPrimaires["health"].removeEventListener(CaracteristiquePrimaireEvent.ACTUALISER_SCORE,actualiser_vie);
         this.caracteristiquesPrimaires["health"].removeEventListener(CaracteristiquePrimaireEvent.ACTUALISER_SCORE_MAX,actualiser_vie);
         for(_loc1_ in this.caracteristiquesPrimaires)
         {
            this.caracteristiquesPrimaires[_loc1_].detruire();
            this.caracteristiquesPrimaires[_loc1_] = null;
            delete this.caracteristiquesPrimaires[_loc1_];
         }
         this.caracteristiquesPrimaires = null;
         for(_loc1_ in this.caracteristiquesSecondaires)
         {
            this.caracteristiquesSecondaires[_loc1_] = null;
            delete this.caracteristiquesSecondaires[_loc1_];
         }
         this.caracteristiquesPrimaires = null;
         for(_loc1_ in this.competences)
         {
            this.competences[_loc1_] = null;
            delete this.competences[_loc1_];
         }
         this.competences = null;
         for each(_loc2_ in this.objets)
         {
            _loc2_.removeEventListener(Event.ACTIVATE,this.utiliser_objet_auto);
            _loc2_.detruire();
            _loc2_ = null;
         }
         this.objets.splice(0,this.objets.length);
         this.objets = null;
         this.apparenceBase = null;
         this.apparence = null;
         this.iaArmesDistancesPreferees = null;
         this.iaArmesContactPreferees = null;
      }
   }
}

