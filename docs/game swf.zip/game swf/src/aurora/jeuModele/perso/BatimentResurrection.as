package aurora.jeuModele.perso
{
   public class BatimentResurrection extends Batiment
   {
      
      public var resurrection:int;
      
      public var tempsResurrection:int;
      
      private var vieResurrection:Number;
      
      private var effetResurrection:String;
      
      public function BatimentResurrection()
      {
         super();
      }
      
      override public function init(param1:Object) : void
      {
         super.init(param1);
         this.resurrection = param1.resurrect;
         this.tempsResurrection = param1.resurrectTime * 1000;
         this.vieResurrection = param1.healthResurrection;
         this.effetResurrection = param1.effectResurrection;
      }
      
      public function ressusciter(param1:Object) : void
      {
         param1.vie.score = 0;
         var _loc2_:int = Math.max(1,this.vieResurrection * param1.vie.scoreMax);
         param1.editer_vie(_loc2_);
         param1.revivre();
         dispatchEvent(new EffetEvent(EffetEvent.EFFET,param1.x,param1.y - param1.hauteur * 0.5,this.effetResurrection));
         --this.resurrection;
         if(this.resurrection == 0)
         {
            mourir();
         }
      }
   }
}

