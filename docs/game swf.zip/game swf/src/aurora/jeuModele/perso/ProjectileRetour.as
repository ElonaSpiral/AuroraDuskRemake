package aurora.jeuModele.perso
{
   import flash.events.TimerEvent;
   
   public class ProjectileRetour extends Projectile
   {
      
      private var idObjet:Object;
      
      private var retour:Boolean;
      
      public function ProjectileRetour(param1:Object)
      {
         super();
         this.idObjet = param1;
      }
      
      override protected function deplacer(param1:TimerEvent) : void
      {
         var _loc2_:String = null;
         super.deplacer(param1);
         if(Boolean(visible) && Boolean(lanceur) && Boolean(lanceur.visible) && this.retour)
         {
            if(Math.pow(rayon,2) > Math.pow(lanceur.x - x,2) + Math.pow(lanceur.y - lanceur.hauteur * 0.5 - y + hauteur * 0.5,2))
            {
               for(_loc2_ in this.idObjet)
               {
                  lanceur.ajouter_objet(_loc2_,this.idObjet[_loc2_]);
               }
               mourir();
            }
         }
      }
      
      override protected function finir_deplacement(param1:TimerEvent) : void
      {
         if(!this.retour)
         {
            this.retour = true;
            dx *= -1;
            dy *= -1;
            deplacementTimer.repeatCount *= 1.1;
            deplacementTimer.reset();
            deplacementTimer.start();
         }
         else
         {
            mourir();
         }
      }
   }
}

