package aurora.jeuModele.perso.attaque
{
   import flash.events.Event;
   
   public class EffetArmeEvent extends Event
   {
      
      public static const EFFET_ARME:String = "effetArme";
      
      public var arme:String;
      
      public var anim:String;
      
      public var son:String;
      
      public var x:int;
      
      public var y:int;
      
      public var rotation:Number;
      
      public function EffetArmeEvent(param1:String, param2:String, param3:String, param4:String, param5:int, param6:int, param7:Number)
      {
         this.arme = param2;
         this.anim = param3;
         this.son = param4;
         this.x = param5;
         this.y = param6;
         this.rotation = param7;
         super(param1);
      }
      
      override public function clone() : Event
      {
         return new EffetArmeEvent(type,this.arme,this.anim,this.son,this.x,this.y,this.rotation);
      }
   }
}

