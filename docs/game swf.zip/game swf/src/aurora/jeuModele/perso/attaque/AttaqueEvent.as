package aurora.jeuModele.perso.attaque
{
   import flash.events.Event;
   
   public class AttaqueEvent extends Event
   {
      
      public static const ATTAQUER:String = "attaquer";
      
      public function AttaqueEvent(param1:String)
      {
         super(param1,bubbles,cancelable);
      }
   }
}

