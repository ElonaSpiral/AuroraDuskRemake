package aurora.jeuModele.perso.attaque
{
   public class EffetArme
   {
      
      public var arme:String;
      
      public var anim:String;
      
      public var son:String;
      
      public function EffetArme(param1:String, param2:String, param3:String)
      {
         super();
         this.arme = param1;
         this.anim = param2;
         this.son = param3;
      }
      
      public function clone() : EffetArme
      {
         return new EffetArme(this.arme,this.anim,this.son);
      }
   }
}

