package aurora.jeuModele.perso.attaque
{
   import flash.events.EventDispatcher;
   import flash.events.TimerEvent;
   import flash.utils.Timer;
   
   public class Attaque extends EventDispatcher
   {
      
      public var timerAttaque:Timer;
      
      public var no:int;
      
      public var score:int;
      
      public var scoreBase:int;
      
      public var attaqueEnCours:Boolean;
      
      public var attaqueDX:int;
      
      public var attaqueDY:int;
      
      public var effet:String;
      
      public var effetLigne:String;
      
      public var effetArme:EffetArme;
      
      public var son:String;
      
      public var portee:int;
      
      public var projectile:String;
      
      public var delai:Number = 0;
      
      public var effetTueur:Object;
      
      public var degats:Vector.<String>;
      
      public var coutAttaque:Object;
      
      public var attaquesMultiples:Boolean;
      
      private var _tempsAttaque:Number = 1000;
      
      public function Attaque()
      {
         super();
         this.timerAttaque = new Timer(1000,1);
         this.timerAttaque.addEventListener(TimerEvent.TIMER_COMPLETE,this.attaquer);
      }
      
      public static function convertir_degats(param1:Object) : Vector.<String>
      {
         var _loc3_:String = null;
         var _loc2_:Vector.<String> = new Vector.<String>();
         if(param1)
         {
            for each(_loc3_ in param1)
            {
               _loc2_.push(_loc3_);
            }
         }
         return _loc2_;
      }
      
      public function init_score(param1:int) : void
      {
         this.score = this.scoreBase = param1;
      }
      
      public function augmenter_score(param1:int) : void
      {
         this.score += param1;
         this.scoreBase += param1;
      }
      
      public function actualiser_degats(param1:Object) : void
      {
         var _loc2_:String = null;
         this.degats = new Vector.<String>();
         if(param1)
         {
            for each(_loc2_ in param1)
            {
               this.degats.push(_loc2_);
            }
         }
      }
      
      public function get tempsAttaque() : Number
      {
         return this.timerAttaque.delay * 0.001;
      }
      
      public function set tempsAttaque(param1:Number) : void
      {
         this.timerAttaque.reset();
         this._tempsAttaque = param1 * 1000;
         this.timerAttaque.delay = this._tempsAttaque;
      }
      
      private function attaquer(param1:TimerEvent) : void
      {
         this.attaqueEnCours = false;
         dispatchEvent(new AttaqueEvent(AttaqueEvent.ATTAQUER));
      }
      
      public function demarrer() : void
      {
         if(this.timerAttaque)
         {
            this.attaqueEnCours = true;
            this.timerAttaque.reset();
            this.timerAttaque.start();
         }
      }
      
      public function arreter() : void
      {
         this.timerAttaque.stop();
         this.attaqueEnCours = false;
      }
      
      public function copier(param1:Attaque) : void
      {
         var _loc2_:String = null;
         this.tempsAttaque = param1.tempsAttaque;
         this.score = param1.score;
         this.scoreBase = param1.scoreBase;
         this.attaqueDX = param1.attaqueDX;
         this.attaqueDY = param1.attaqueDY;
         this.effet = param1.effet;
         this.effetLigne = param1.effetLigne;
         if(param1.effetArme)
         {
            this.effetArme = param1.effetArme;
         }
         this.son = param1.son;
         this.portee = param1.portee;
         this.projectile = param1.projectile;
         this.delai = param1.delai;
         this.coutAttaque = param1.coutAttaque;
         this.attaquesMultiples = param1.attaquesMultiples;
         this.effetTueur = param1.effetTueur;
         this.degats = new Vector.<String>();
         for each(_loc2_ in param1.degats)
         {
            this.degats.push(_loc2_);
         }
      }
      
      public function detruire() : void
      {
         this.coutAttaque = null;
         this.timerAttaque.stop();
         this.timerAttaque.removeEventListener(TimerEvent.TIMER_COMPLETE,this.attaquer);
         this.timerAttaque = null;
         this.effetArme = null;
         this.degats.splice(0,this.degats.length);
         this.degats = null;
      }
   }
}

