package aurora.jeuModele.perso
{
   import aurora.jeuModele.perso.ressources.RessourceEvent;
   
   public class RessourceTerrain extends Perso
   {
      
      public var idCreateur:int;
      
      private var _quantite:int;
      
      public var quantiteMax:int;
      
      public var quantiteLimite:Boolean;
      
      public var production:Array;
      
      public function RessourceTerrain()
      {
         super();
      }
      
      override public function init(param1:Object) : void
      {
         super.init(param1);
         if(param1.quantity)
         {
            this.quantiteMax = this.quantite = param1.quantity;
            this.quantiteLimite = true;
         }
         this.production = param1.produce;
      }
      
      public function possede_ressource(param1:String) : Boolean
      {
         var _loc2_:Object = null;
         var _loc3_:String = null;
         for(_loc2_ in this.production)
         {
            for(_loc3_ in _loc2_.gainRessource)
            {
               if(_loc3_ == param1)
               {
                  return true;
               }
            }
         }
         return false;
      }
      
      public function ajouter_bonus(param1:Number) : void
      {
         this._quantite *= param1;
         this.quantiteMax *= param1;
      }
      
      public function get quantite() : int
      {
         return this._quantite;
      }
      
      public function set quantite(param1:int) : void
      {
         this._quantite = param1;
         if(this._quantite <= 0)
         {
            mourir();
         }
         else
         {
            dispatchEvent(new RessourceEvent(RessourceEvent.ACTUALISER_QUANTITE,String(id),this.quantite));
         }
      }
      
      override public function detruire() : void
      {
         super.detruire();
         this.production = null;
      }
   }
}

