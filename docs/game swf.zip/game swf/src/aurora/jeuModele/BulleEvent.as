package aurora.jeuModele
{
   import flash.events.Event;
   
   public class BulleEvent extends Event
   {
      
      public static const MESSAGE:String = "message";
      
      public var message:String;
      
      public var perso:Object;
      
      public function BulleEvent(param1:String, param2:String, param3:* = null)
      {
         this.message = param2;
         this.perso = param3;
         super(param1);
      }
      
      override public function clone() : Event
      {
         return new BulleEvent(type,this.message);
      }
   }
}

