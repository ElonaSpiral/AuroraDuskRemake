package aurora.jeuModele
{
   import aurora.messages.perso.MessagePersoActualiserEntier;
   import aurora.messages.perso.MessagePersoActualiserNombre;
   import aurora.messages.perso.MessagePersoActualiserTexte;
   import aurora.messages.perso.MessagePersoApparence;
   import aurora.messages.perso.MessagePersoBooleen;
   import aurora.messages.perso.MessagePersoCreer;
   import aurora.messages.perso.MessagePersoDeplacer;
   import aurora.messages.perso.MessagePersoOrienter;
   import aurora.messages.perso.MessagePersoRotation;
   import flash.concurrent.Mutex;
   import flash.events.EventDispatcher;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   
   public class InfosJoueur extends EventDispatcher
   {
      
      public var emplacementConstructionOk:ByteArray;
      
      public var emplacementConstructionX:Vector.<int>;
      
      public var emplacementConstructionY:Vector.<int>;
      
      public var emplacementConstructionLargeur:int;
      
      public var emplacementConstructionHauteur:int;
      
      private var mutex:Mutex;
      
      private var verifier_pointeur:Function;
      
      private var creationsBytes:ByteArray;
      
      private var creationsPointeur:ByteArray;
      
      private var positionsBytes:ByteArray;
      
      private var positionsPointeur:ByteArray;
      
      private var orientationBytes:ByteArray;
      
      private var orientationPointeur:ByteArray;
      
      private var rotationBytes:ByteArray;
      
      private var rotationPointeur:ByteArray;
      
      private var actualiserVieBytes:ByteArray;
      
      private var actualiserViePointeur:ByteArray;
      
      private var actualiserEtapeBytes:ByteArray;
      
      private var actualiserEtapePointeur:ByteArray;
      
      private var decalageYBytes:ByteArray;
      
      private var decalageYPointeur:ByteArray;
      
      private var actualiserFantomeBytes:ByteArray;
      
      private var actualiserFantomePointeur:ByteArray;
      
      private var actualiserVisibleBytes:ByteArray;
      
      private var actualiserVisiblePointeur:ByteArray;
      
      private var apparenceBytes:ByteArray;
      
      private var apparencePointeur:ByteArray;
      
      private var couleurBytes:ByteArray;
      
      private var couleurPointeur:ByteArray;
      
      private var montureBytes:ByteArray;
      
      private var monturePointeur:ByteArray;
      
      private var infosJoueurBytes:ByteArray;
      
      private var infosJoueurPointeur:ByteArray;
      
      private var persos:Dictionary;
      
      public var visionX1:int;
      
      public var visionX2:int;
      
      public var visionY1:int;
      
      public var visionY2:int;
      
      public var noJoueur:int;
      
      public var equipe:int;
      
      public var ville:int;
      
      private var persosPositions:Dictionary;
      
      private var messagesCreation:Dictionary;
      
      private var messagesDeplacement:Dictionary;
      
      private var messagesDecalerY:Dictionary;
      
      private var messagesOrientation:Dictionary;
      
      private var messagesRotation:Dictionary;
      
      private var messagesVie:Dictionary;
      
      private var messagesEtape:Dictionary;
      
      private var messagesCaserne:Dictionary;
      
      private var messagesFantome:Dictionary;
      
      private var messagesVisible:Dictionary;
      
      private var messagesApparence:Dictionary;
      
      private var messagesCouleur:Dictionary;
      
      private var messagesMonture:Dictionary;
      
      public function InfosJoueur(param1:int, param2:int, param3:int, param4:Mutex, param5:Function, param6:ByteArray, param7:ByteArray, param8:ByteArray, param9:ByteArray, param10:ByteArray, param11:ByteArray, param12:ByteArray, param13:ByteArray, param14:ByteArray, param15:ByteArray, param16:ByteArray, param17:ByteArray, param18:ByteArray, param19:ByteArray, param20:ByteArray, param21:ByteArray, param22:ByteArray, param23:ByteArray, param24:ByteArray, param25:ByteArray, param26:ByteArray, param27:ByteArray, param28:ByteArray, param29:ByteArray, param30:ByteArray, param31:ByteArray, param32:Dictionary)
      {
         super();
         this.noJoueur = param1;
         this.equipe = param2;
         this.ville = param3;
         this.mutex = param4;
         this.verifier_pointeur = param5;
         this.creationsBytes = param6;
         this.creationsPointeur = param7;
         this.positionsBytes = param8;
         this.positionsPointeur = param9;
         this.orientationBytes = param10;
         this.orientationPointeur = param11;
         this.rotationBytes = param12;
         this.rotationPointeur = param13;
         this.actualiserVieBytes = param14;
         this.actualiserViePointeur = param15;
         this.actualiserEtapeBytes = param16;
         this.actualiserEtapePointeur = param17;
         this.decalageYBytes = param18;
         this.decalageYPointeur = param19;
         this.actualiserFantomeBytes = param20;
         this.actualiserFantomePointeur = param21;
         this.actualiserVisibleBytes = param22;
         this.actualiserVisiblePointeur = param23;
         this.apparenceBytes = param24;
         this.apparencePointeur = param25;
         this.couleurBytes = param26;
         this.couleurPointeur = param27;
         this.montureBytes = param28;
         this.monturePointeur = param29;
         this.infosJoueurBytes = param30;
         this.infosJoueurPointeur = param31;
         this.persos = param32;
         this.persosPositions = new Dictionary();
         this.messagesCreation = new Dictionary();
         this.messagesDeplacement = new Dictionary();
         this.messagesDecalerY = new Dictionary();
         this.messagesOrientation = new Dictionary();
         this.messagesRotation = new Dictionary();
         this.messagesVie = new Dictionary();
         this.messagesEtape = new Dictionary();
         this.messagesCaserne = new Dictionary();
         this.messagesFantome = new Dictionary();
         this.messagesVisible = new Dictionary();
         this.messagesApparence = new Dictionary();
         this.messagesCouleur = new Dictionary();
         this.messagesMonture = new Dictionary();
      }
      
      public function enregistrer_emplacementConstruction(param1:Vector.<int>, param2:Vector.<int>, param3:int, param4:int) : void
      {
         this.emplacementConstructionX = param1;
         this.emplacementConstructionY = param2;
         this.emplacementConstructionLargeur = param3;
         this.emplacementConstructionHauteur = param4;
      }
      
      public function dans_vision(param1:int, param2:int) : Boolean
      {
         return param1 >= this.visionX1 && param1 <= this.visionX2 && param2 >= this.visionY1 && param2 <= this.visionY2;
      }
      
      public function actualiser_vision(param1:int, param2:int, param3:int, param4:int) : void
      {
         var _loc5_:MessagePersoCreer = null;
         var _loc6_:MessagePersoApparence = null;
         var _loc7_:MessagePersoActualiserEntier = null;
         var _loc8_:MessagePersoActualiserTexte = null;
         var _loc9_:MessagePersoDeplacer = null;
         var _loc10_:MessagePersoActualiserEntier = null;
         var _loc11_:MessagePersoOrienter = null;
         var _loc12_:MessagePersoRotation = null;
         var _loc13_:MessagePersoActualiserNombre = null;
         var _loc14_:MessagePersoActualiserEntier = null;
         var _loc15_:MessagePersoActualiserEntier = null;
         var _loc16_:MessagePersoBooleen = null;
         var _loc17_:MessagePersoBooleen = null;
         param1 -= 128;
         param3 += 128;
         param2 -= 32;
         param4 += 256;
         if(this.visionX1 != param1 || this.visionY1 != param2 || this.visionX2 != param3 || this.visionY2 != param4)
         {
            this.visionX1 = param1;
            this.visionY1 = param2;
            this.visionX2 = param3;
            this.visionY2 = param4;
            for each(_loc5_ in this.messagesCreation)
            {
               if(this.dans_vision(this.persos[_loc5_.id].x,this.persos[_loc5_.id].y))
               {
                  this.mutex.lock();
                  this.verifier_pointeur(this.creationsBytes,this.creationsPointeur);
                  this.creationsBytes.writeInt(_loc5_.id);
                  this.creationsBytes.writeUTF(_loc5_.race);
                  this.creationsBytes.writeBoolean(_loc5_.cliquable);
                  this.creationsBytes.writeBoolean(_loc5_.ennemi);
                  this.creationsBytes.writeBoolean(_loc5_.cliquableMort);
                  this.creationsBytes.writeBoolean(_loc5_.cliquableBlesse);
                  this.creationsBytes.writeBoolean(_loc5_.serviteur);
                  this.creationsBytes.writeBoolean(_loc5_.jouable);
                  this.creationsBytes.writeInt(_loc5_.x);
                  this.creationsBytes.writeInt(_loc5_.y);
                  this.creationsBytes.writeInt(_loc5_.largeur);
                  this.creationsBytes.writeInt(_loc5_.hauteur);
                  this.creationsBytes.writeUTF(_loc5_.anim);
                  this.creationsBytes.writeInt(_loc5_.decalageY);
                  this.mutex.unlock();
                  delete this.messagesCreation[_loc5_.id];
                  this.persosPositions[_loc5_.id] = {
                     "x":_loc5_.x,
                     "y":_loc5_.y
                  };
               }
            }
            for each(_loc6_ in this.messagesApparence)
            {
               if(this.dans_vision(this.persos[_loc6_.id].x,this.persos[_loc6_.id].y))
               {
                  this.mutex.lock();
                  this.verifier_pointeur(this.apparenceBytes,this.apparencePointeur);
                  this.apparenceBytes.writeInt(_loc6_.id);
                  this.apparenceBytes.writeObject(_loc6_.apparence);
                  this.mutex.unlock();
                  delete this.messagesApparence[_loc6_.id];
               }
            }
            for each(_loc7_ in this.messagesCouleur)
            {
               if(this.dans_vision(this.persos[_loc7_.id].x,this.persos[_loc7_.id].y))
               {
                  this.mutex.lock();
                  this.verifier_pointeur(this.couleurBytes,this.couleurPointeur);
                  this.couleurBytes.writeInt(_loc7_.id);
                  this.couleurBytes.writeInt(_loc7_.entier);
                  this.mutex.unlock();
                  delete this.messagesCouleur[_loc7_.id];
               }
            }
            for each(_loc8_ in this.messagesMonture)
            {
               if(this.dans_vision(this.persos[_loc8_.id].x,this.persos[_loc8_.id].y))
               {
                  this.mutex.lock();
                  this.verifier_pointeur(this.montureBytes,this.monturePointeur);
                  this.montureBytes.writeInt(_loc8_.id);
                  this.montureBytes.writeUTF(_loc8_.texte);
                  this.mutex.unlock();
                  delete this.messagesMonture[_loc8_.id];
               }
            }
            for each(_loc9_ in this.messagesDeplacement)
            {
               if(this.dans_vision(_loc9_.x,_loc9_.y))
               {
                  this.mutex.lock();
                  this.verifier_pointeur(this.positionsBytes,this.positionsPointeur);
                  this.positionsBytes.writeInt(_loc9_.id);
                  this.positionsBytes.writeInt(_loc9_.x);
                  this.positionsBytes.writeInt(_loc9_.y);
                  this.positionsBytes.writeByte(_loc9_.pas);
                  this.mutex.unlock();
                  delete this.messagesDeplacement[_loc9_.id];
                  this.persosPositions[_loc9_.id] = {
                     "x":_loc9_.x,
                     "y":_loc9_.y
                  };
               }
               else if(Boolean(this.persosPositions[_loc9_.id]) && this.dans_vision(this.persosPositions[_loc9_.id].x,this.persosPositions[_loc9_.id].y))
               {
                  this.mutex.lock();
                  this.verifier_pointeur(this.positionsBytes,this.positionsPointeur);
                  this.positionsBytes.writeInt(_loc9_.id);
                  this.positionsBytes.writeInt(_loc9_.x);
                  this.positionsBytes.writeInt(_loc9_.y);
                  this.positionsBytes.writeByte(_loc9_.pas);
                  this.mutex.unlock();
                  delete this.messagesDeplacement[_loc9_.id];
                  this.persosPositions[_loc9_.id] = {
                     "x":_loc9_.x,
                     "y":_loc9_.y
                  };
               }
            }
            for each(_loc10_ in this.messagesDecalerY)
            {
               if(this.dans_vision(this.persos[_loc10_.id].x,this.persos[_loc10_.id].y))
               {
                  this.mutex.lock();
                  this.verifier_pointeur(this.decalageYBytes,this.decalageYPointeur);
                  this.decalageYBytes.writeInt(_loc10_.id);
                  this.decalageYBytes.writeByte(_loc10_.entier);
                  this.mutex.unlock();
                  delete this.messagesDecalerY[_loc10_.id];
               }
            }
            for each(_loc11_ in this.messagesOrientation)
            {
               if(this.dans_vision(this.persos[_loc11_.id].x,this.persos[_loc11_.id].y))
               {
                  this.mutex.lock();
                  this.verifier_pointeur(this.orientationBytes,this.orientationPointeur);
                  this.orientationBytes.writeInt(_loc11_.id);
                  this.orientationBytes.writeByte(_loc11_.orientation);
                  this.mutex.unlock();
                  delete this.messagesOrientation[_loc11_.id];
               }
            }
            for each(_loc12_ in this.messagesRotation)
            {
               if(this.dans_vision(this.persos[_loc12_.id].x,this.persos[_loc12_.id].y))
               {
                  this.mutex.lock();
                  this.verifier_pointeur(this.rotationBytes,this.rotationPointeur);
                  this.rotationBytes.writeInt(_loc12_.id);
                  this.rotationBytes.writeFloat(_loc12_.rotation);
                  this.mutex.unlock();
                  delete this.messagesRotation[_loc12_.id];
               }
            }
            for each(_loc13_ in this.messagesVie)
            {
               if(this.dans_vision(this.persos[_loc13_.id].x,this.persos[_loc13_.id].y))
               {
                  this.mutex.lock();
                  this.verifier_pointeur(this.actualiserVieBytes,this.actualiserViePointeur);
                  this.actualiserVieBytes.writeInt(_loc13_.id);
                  this.actualiserVieBytes.writeFloat(_loc13_.nombre);
                  this.mutex.unlock();
                  delete this.messagesVie[_loc13_.id];
               }
            }
            for each(_loc14_ in this.messagesEtape)
            {
               if(this.dans_vision(this.persos[_loc14_.id].x,this.persos[_loc14_.id].y))
               {
                  this.mutex.lock();
                  this.verifier_pointeur(this.actualiserEtapeBytes,this.actualiserEtapePointeur);
                  this.actualiserEtapeBytes.writeInt(_loc14_.id);
                  this.actualiserEtapeBytes.writeByte(_loc14_.entier);
                  this.mutex.unlock();
                  delete this.messagesEtape[_loc14_.id];
               }
            }
            for each(_loc15_ in this.messagesCaserne)
            {
               if(this.dans_vision(this.persos[_loc15_.id].x,this.persos[_loc15_.id].y))
               {
                  this.mutex.lock();
                  this.verifier_pointeur(this.infosJoueurBytes,this.infosJoueurPointeur);
                  this.infosJoueurBytes.writeByte(41);
                  this.infosJoueurBytes.writeInt(_loc15_.id);
                  this.infosJoueurBytes.writeInt(_loc15_.entier);
                  this.mutex.unlock();
                  delete this.messagesCaserne[_loc15_.id];
               }
            }
            for each(_loc16_ in this.messagesFantome)
            {
               if(this.dans_vision(this.persos[_loc16_.id].x,this.persos[_loc16_.id].y))
               {
                  this.mutex.lock();
                  this.verifier_pointeur(this.actualiserFantomeBytes,this.actualiserFantomePointeur);
                  this.actualiserFantomeBytes.writeInt(_loc16_.id);
                  this.actualiserFantomeBytes.writeBoolean(_loc16_.booleen);
                  this.mutex.unlock();
                  delete this.messagesFantome[_loc16_.id];
               }
            }
            for each(_loc17_ in this.messagesVisible)
            {
               if(this.dans_vision(this.persos[_loc17_.id].x,this.persos[_loc17_.id].y))
               {
                  this.mutex.lock();
                  this.verifier_pointeur(this.actualiserVisibleBytes,this.actualiserVisiblePointeur);
                  this.actualiserVisibleBytes.writeInt(_loc17_.id);
                  this.actualiserVisibleBytes.writeBoolean(_loc17_.booleen);
                  this.mutex.unlock();
                  delete this.messagesVisible[_loc17_.id];
               }
            }
         }
      }
      
      public function verifier_perso(param1:int) : void
      {
         var _loc2_:MessagePersoCreer = null;
         var _loc3_:MessagePersoDeplacer = null;
         if(this.messagesCreation[param1])
         {
            _loc2_ = this.messagesCreation[param1];
            this.mutex.lock();
            this.verifier_pointeur(this.creationsBytes,this.creationsPointeur);
            this.creationsBytes.writeInt(param1);
            this.creationsBytes.writeUTF(_loc2_.race);
            this.creationsBytes.writeBoolean(_loc2_.cliquable);
            this.creationsBytes.writeBoolean(_loc2_.ennemi);
            this.creationsBytes.writeBoolean(_loc2_.cliquableMort);
            this.creationsBytes.writeBoolean(_loc2_.cliquableBlesse);
            this.creationsBytes.writeBoolean(_loc2_.serviteur);
            this.creationsBytes.writeBoolean(_loc2_.jouable);
            this.creationsBytes.writeInt(_loc2_.x);
            this.creationsBytes.writeInt(_loc2_.y);
            this.creationsBytes.writeInt(_loc2_.largeur);
            this.creationsBytes.writeInt(_loc2_.hauteur);
            this.creationsBytes.writeUTF(_loc2_.anim);
            this.creationsBytes.writeInt(-_loc2_.decalageY);
            this.mutex.unlock();
            delete this.messagesCreation[param1];
         }
         if(this.messagesApparence[param1])
         {
            this.mutex.lock();
            this.verifier_pointeur(this.apparenceBytes,this.apparencePointeur);
            this.apparenceBytes.writeInt(param1);
            this.apparenceBytes.writeObject(this.messagesApparence[param1].apparence);
            this.mutex.unlock();
            delete this.messagesApparence[param1];
         }
         if(this.messagesCouleur[param1])
         {
            this.mutex.lock();
            this.verifier_pointeur(this.couleurBytes,this.couleurPointeur);
            this.couleurBytes.writeInt(param1);
            this.couleurBytes.writeObject(this.messagesCouleur[param1].entier);
            this.mutex.unlock();
            delete this.messagesCouleur[param1];
         }
         if(this.messagesMonture[param1])
         {
            this.mutex.lock();
            this.verifier_pointeur(this.montureBytes,this.monturePointeur);
            this.montureBytes.writeInt(param1);
            this.montureBytes.writeUTF(this.messagesMonture[param1].texte);
            this.mutex.unlock();
            delete this.messagesMonture[param1];
         }
         if(this.messagesDeplacement[param1])
         {
            _loc3_ = this.messagesDeplacement[param1];
            this.mutex.lock();
            this.verifier_pointeur(this.positionsBytes,this.positionsPointeur);
            this.positionsBytes.writeInt(param1);
            this.positionsBytes.writeInt(_loc3_.x);
            this.positionsBytes.writeInt(_loc3_.y);
            this.positionsBytes.writeByte(_loc3_.pas);
            this.mutex.unlock();
            delete this.messagesDeplacement[param1];
         }
         if(this.messagesDecalerY[param1])
         {
            this.mutex.lock();
            this.verifier_pointeur(this.decalageYBytes,this.decalageYPointeur);
            this.decalageYBytes.writeInt(param1);
            this.decalageYBytes.writeByte(this.messagesDecalerY[param1].entier);
            this.mutex.unlock();
            delete this.messagesDecalerY[param1];
         }
         if(this.messagesOrientation[param1])
         {
            this.mutex.lock();
            this.verifier_pointeur(this.orientationBytes,this.orientationPointeur);
            this.orientationBytes.writeInt(param1);
            this.orientationBytes.writeByte(this.messagesOrientation[param1].orientation);
            this.mutex.unlock();
            delete this.messagesOrientation[param1];
         }
         if(this.messagesRotation[param1])
         {
            this.mutex.lock();
            this.verifier_pointeur(this.rotationBytes,this.rotationPointeur);
            this.rotationBytes.writeInt(param1);
            this.rotationBytes.writeFloat(this.messagesRotation[param1].rotation);
            this.mutex.unlock();
            delete this.messagesRotation[param1];
         }
         if(this.messagesVie[param1])
         {
            this.mutex.lock();
            this.verifier_pointeur(this.actualiserVieBytes,this.actualiserViePointeur);
            this.actualiserVieBytes.writeInt(param1);
            this.actualiserVieBytes.writeFloat(this.messagesVie[param1].nombre);
            this.mutex.unlock();
            delete this.messagesVie[param1];
         }
         if(this.messagesEtape[param1])
         {
            this.mutex.lock();
            this.verifier_pointeur(this.actualiserEtapeBytes,this.actualiserEtapePointeur);
            this.actualiserEtapeBytes.writeInt(param1);
            this.actualiserEtapeBytes.writeByte(this.messagesEtape[param1].entier);
            this.mutex.unlock();
            delete this.messagesEtape[param1];
         }
         if(this.messagesCaserne[param1])
         {
            this.mutex.lock();
            this.verifier_pointeur(this.infosJoueurBytes,this.infosJoueurPointeur);
            this.infosJoueurBytes.writeByte(41);
            this.infosJoueurBytes.writeInt(param1);
            this.infosJoueurBytes.writeInt(this.messagesCaserne[param1].entier);
            this.mutex.unlock();
            delete this.messagesCaserne[param1];
         }
         if(this.messagesFantome[param1])
         {
            this.mutex.lock();
            this.verifier_pointeur(this.actualiserFantomeBytes,this.actualiserFantomePointeur);
            this.actualiserFantomeBytes.writeInt(param1);
            this.actualiserFantomeBytes.writeBoolean(this.messagesFantome[param1].booleen);
            this.mutex.unlock();
            delete this.messagesFantome[param1];
         }
         if(this.messagesVisible[param1])
         {
            this.mutex.lock();
            this.verifier_pointeur(this.actualiserVisibleBytes,this.actualiserVisiblePointeur);
            this.actualiserVisibleBytes.writeInt(param1);
            this.actualiserVisibleBytes.writeBoolean(this.messagesVisible[param1].booleen);
            this.mutex.unlock();
            delete this.messagesVisible[param1];
         }
      }
      
      public function enregistrer_position(param1:int) : void
      {
         this.persosPositions[param1] = {
            "x":this.persos[param1].x,
            "y":this.persos[param1].y
         };
      }
      
      public function enregistrer_message_creation(param1:MessagePersoCreer) : void
      {
         this.messagesCreation[param1.id] = param1;
      }
      
      public function enregistrer_message_deplacement(param1:MessagePersoDeplacer) : void
      {
         if(this.messagesCreation[param1.id])
         {
            this.messagesCreation[param1.id].x = param1.x;
            this.messagesCreation[param1.id].y = param1.y;
         }
         else if(Boolean(this.persosPositions[param1.id]) && this.dans_vision(this.persosPositions[param1.id].x,this.persosPositions[param1.id].y))
         {
            this.mutex.lock();
            this.verifier_pointeur(this.positionsBytes,this.positionsPointeur);
            this.positionsBytes.writeInt(param1.id);
            this.positionsBytes.writeInt(param1.x);
            this.positionsBytes.writeInt(param1.y);
            this.positionsBytes.writeByte(param1.pas);
            this.mutex.unlock();
            this.persosPositions[param1.id] = {
               "x":param1.x,
               "y":param1.y
            };
         }
         else
         {
            this.messagesDeplacement[param1.id] = param1;
         }
      }
      
      public function enregistrer_message_decalageY(param1:MessagePersoActualiserEntier) : void
      {
         this.messagesDecalerY[param1.id] = param1;
      }
      
      public function enregistrer_message_orientation(param1:MessagePersoOrienter) : void
      {
         this.messagesOrientation[param1.id] = param1;
      }
      
      public function enregistrer_message_rotation(param1:MessagePersoRotation) : void
      {
         this.messagesRotation[param1.id] = param1;
      }
      
      public function enregistrer_message_vie(param1:MessagePersoActualiserNombre) : void
      {
         this.messagesVie[param1.id] = param1;
      }
      
      public function enregistrer_message_etape(param1:MessagePersoActualiserEntier) : void
      {
         this.messagesEtape[param1.id] = param1;
      }
      
      public function enregistrer_message_caserne(param1:MessagePersoActualiserEntier) : void
      {
         this.messagesCaserne[param1.id] = param1;
      }
      
      public function enregistrer_message_fantome(param1:MessagePersoBooleen) : void
      {
         this.messagesFantome[param1.id] = param1;
      }
      
      public function enregistrer_message_visible(param1:MessagePersoBooleen) : void
      {
         this.messagesVisible[param1.id] = param1;
      }
      
      public function enregistrer_message_apparence(param1:MessagePersoApparence) : void
      {
         this.messagesApparence[param1.id] = param1;
      }
      
      public function enregistrer_message_couleur(param1:MessagePersoActualiserEntier) : void
      {
         this.messagesCouleur[param1.id] = param1;
      }
      
      public function enregistrer_message_monture(param1:MessagePersoActualiserTexte) : void
      {
         this.messagesMonture[param1.id] = param1;
      }
      
      public function detruire_perso(param1:int) : void
      {
         if(this.persosPositions[param1])
         {
            delete this.persosPositions[param1];
         }
         if(this.messagesCreation[param1])
         {
            delete this.messagesCreation[param1];
         }
         else if(this.messagesDeplacement[param1])
         {
            delete this.messagesDeplacement[param1];
         }
         if(this.messagesDecalerY[param1])
         {
            delete this.messagesDecalerY[param1];
         }
         if(this.messagesOrientation[param1])
         {
            delete this.messagesOrientation[param1];
         }
         if(this.messagesRotation[param1])
         {
            delete this.messagesRotation[param1];
         }
         if(this.messagesVie[param1])
         {
            delete this.messagesVie[param1];
         }
         if(this.messagesEtape[param1])
         {
            delete this.messagesEtape[param1];
         }
         if(this.messagesCaserne[param1])
         {
            delete this.messagesCaserne[param1];
         }
         if(this.messagesFantome[param1])
         {
            delete this.messagesFantome[param1];
         }
         if(this.messagesVisible[param1])
         {
            delete this.messagesVisible[param1];
         }
         if(this.messagesApparence[param1])
         {
            delete this.messagesApparence[param1];
         }
         if(this.messagesCouleur[param1])
         {
            delete this.messagesCouleur[param1];
         }
         if(this.messagesMonture[param1])
         {
            delete this.messagesMonture[param1];
         }
      }
   }
}

