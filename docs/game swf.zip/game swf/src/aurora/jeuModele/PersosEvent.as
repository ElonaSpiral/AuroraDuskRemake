package aurora.jeuModele
{
   import flash.events.Event;
   
   public class PersosEvent extends Event
   {
      
      public static const DEMANDER_DONNEE:String = "demanderDonnee";
      
      public static const DEPLACER:String = "deplacer";
      
      public static const ORIENTER:String = "orienter";
      
      public static const ROTATION:String = "rotation";
      
      public static const DECALER_Y:String = "decalerY";
      
      public static const ACTUALISER_VIE:String = "actualiserVie";
      
      public static const ACTUALISER_ETAPE:String = "actualiserEtape";
      
      public static const ACTUALISER_APPARENCE:String = "actualiserApparence";
      
      public static const ACTUALISER_COULEUR:String = "actualiserCouleur";
      
      public static const ACTUALISER_MONTURE:String = "actualiserMonture";
      
      public static const ACTUALISER_SOLDATS:String = "actualiserSoldats";
      
      public static const EFFACER:String = "effacer";
      
      public static const VISIBLE:String = "visible";
      
      public static const FANTOME:String = "fantome";
      
      public static const DETRUIRE:String = "detruire";
      
      public static const ROI:String = "roi";
      
      public static const ROI_AUTRE:String = "roiAutre";
      
      public static const ROI_FIN:String = "roiFin";
      
      public var perso:*;
      
      public function PersosEvent(param1:String, param2:* = null)
      {
         this.perso = param2;
         super(param1);
      }
   }
}

