package aurora.jeuModele
{
   import flash.utils.Dictionary;
   
   public class Donnees
   {
      
      public static var traduction:Object;
      
      public static var nbDonnees:int;
      
      public static var donnees:Dictionary;
      
      public static var caracteristiquesPrimaires:Vector.<Object>;
      
      public static var caracteristiquesSecondaires:Vector.<Object>;
      
      public static var ressourcesTerrain:Vector.<Object>;
      
      public static var ressources:Vector.<Object>;
      
      public static var monstres:Vector.<Object>;
      
      public static var competences:Vector.<Object>;
      
      public static var centresVilles:Vector.<String>;
      
      public static var maisons:Vector.<String>;
      
      public static var toursDefense:Vector.<String>;
      
      public static var soldats:Vector.<String>;
      
      public static var batimentsResurrection:Vector.<String>;
      
      public static var racesJouables:Vector.<String>;
      
      public static var objets:Vector.<Object>;
      
      public static var epoques:Vector.<Object>;
      
      public static var terrains:Vector.<Object>;
      
      public static var peuples:Vector.<Object>;
      
      public static var iaPersonnalisees:Vector.<Object>;
      
      public static var langue:String = "";
      
      public function Donnees()
      {
         super();
      }
      
      public static function init() : void
      {
         donnees = new Dictionary();
         caracteristiquesPrimaires = new Vector.<Object>();
         caracteristiquesSecondaires = new Vector.<Object>();
         ressourcesTerrain = new Vector.<Object>();
         ressources = new Vector.<Object>();
         monstres = new Vector.<Object>();
         competences = new Vector.<Object>();
         centresVilles = new Vector.<String>();
         maisons = new Vector.<String>();
         toursDefense = new Vector.<String>();
         soldats = new Vector.<String>();
         batimentsResurrection = new Vector.<String>();
         racesJouables = new Vector.<String>();
         objets = new Vector.<Object>();
         epoques = new Vector.<Object>();
         terrains = new Vector.<Object>();
         peuples = new Vector.<Object>();
         iaPersonnalisees = new Vector.<Object>();
      }
      
      public static function ajouter_donnee(param1:Object) : void
      {
         var _loc2_:Object = null;
         var _loc3_:String = null;
         ++nbDonnees;
         donnees[param1.id] = param1;
         switch(param1.type)
         {
            case "item":
               objets.push(param1);
               break;
            case "monster":
               monstres.push(param1);
               break;
            case "skill":
               competences.push(param1);
               break;
            case "ressource":
               ressources.push(param1);
               break;
            case "landRessource":
               ressourcesTerrain.push(param1);
               break;
            case "animal":
               ressourcesTerrain.push(param1);
               break;
            case "house":
               if(Boolean(param1.build) && Boolean(param1.build.buildable))
               {
                  maisons.push(param1.id);
               }
               break;
            case "defenseTower":
            case "buildingMonster":
               if(Boolean(param1.build) && Boolean(param1.build.buildable))
               {
                  toursDefense.push(param1.id);
               }
               break;
            case "townCenter":
               centresVilles.push(param1.id);
            case "workshop":
            case "barrack":
               if(Boolean(param1.build) && Boolean(param1.build.buildable))
               {
                  for each(_loc2_ in param1.produce)
                  {
                     if(_loc2_.createCharacter)
                     {
                        for(_loc3_ in _loc2_.createCharacter)
                        {
                           if(soldats.indexOf(_loc3_) == -1)
                           {
                              soldats.push(_loc3_);
                           }
                        }
                     }
                  }
               }
               break;
            case "resurrectTower":
               if(Boolean(param1.build) && Boolean(param1.build.buildable))
               {
                  batimentsResurrection.push(param1.id);
               }
               break;
            case "ai":
               iaPersonnalisees.push(param1);
               break;
            case "playable":
               racesJouables.push(param1.id);
               break;
            case "secondaryCharacteristic":
               caracteristiquesSecondaires.push(param1);
               break;
            case "primaryCharacteristic":
               caracteristiquesPrimaires.push(param1);
               break;
            case "age":
               epoques.push(param1);
               break;
            case "ground":
               terrains.push(param1);
               break;
            case "faction":
               peuples.push(param1);
         }
      }
      
      public static function finaliser() : void
      {
         var _loc1_:Object = null;
         var _loc2_:* = 0;
         caracteristiquesPrimaires.sort(ranger);
         ressources.sort(ranger);
         epoques.sort(ranger);
         terrains.sort(ranger);
         peuples.sort(ranger);
         for each(_loc1_ in iaPersonnalisees)
         {
            _loc2_ = 0;
            while(_loc2_ < _loc1_.orders.length)
            {
               if(Boolean(_loc1_.orders[_loc2_].resurrectTower) && Boolean(donnees[_loc1_.orders[_loc2_].resurrectTower]) && (!donnees[_loc1_.orders[_loc2_].resurrectTower].build || !donnees[_loc1_.orders[_loc2_].resurrectTower].build.buildable))
               {
                  _loc1_.orders.splice(_loc2_,1);
                  _loc2_--;
               }
               if(Boolean(_loc1_.orders[_loc2_].house) && Boolean(donnees[_loc1_.orders[_loc2_].house]) && (!donnees[_loc1_.orders[_loc2_].house].build && !donnees[_loc1_.orders[_loc2_].house].build.buildable))
               {
                  _loc1_.orders.splice(_loc2_,1);
                  _loc2_--;
               }
               if(Boolean(_loc1_.orders[_loc2_].workshop) && Boolean(donnees[_loc1_.orders[_loc2_].workshop]) && (!donnees[_loc1_.orders[_loc2_].workshop].build || !donnees[_loc1_.orders[_loc2_].workshop].build.buildable))
               {
                  _loc1_.orders.splice(_loc2_,1);
                  _loc2_--;
               }
               _loc2_++;
            }
         }
      }
      
      public static function editer_mode_bac_a_sable() : void
      {
         var _loc1_:Object = null;
         for each(_loc1_ in donnees)
         {
            if(_loc1_.type == "playable")
            {
               _loc1_.speed *= 10;
            }
         }
      }
      
      public static function ranger(param1:Object, param2:Object) : int
      {
         if(param1.no < param2.no)
         {
            return -1;
         }
         if(param1.no > param2.no)
         {
            return 1;
         }
         return 0;
      }
   }
}

