package aurora.jeuModele
{
   import flash.utils.ByteArray;
   
   public class Terrain
   {
      
      public static var largeur:int;
      
      public static var hauteur:int;
      
      public static var nbCasesLargeur:int;
      
      public static var nbCasesHauteur:int;
      
      private static var casesApparences:Vector.<int>;
      
      private static var casesVitesse:Vector.<Vector.<Number>>;
      
      private static var casesConctructible:Vector.<Vector.<Boolean>>;
      
      private static var casesDecalageY:Vector.<Vector.<int>>;
      
      private static var casesEffet:Vector.<Vector.<String>>;
      
      private static var casesNiveau:Vector.<Vector.<int>>;
      
      private static var casesDenivele:Vector.<Vector.<int>>;
      
      public static var casesPersosCollisions:Vector.<Vector.<Vector.<Object>>>;
      
      public static var donnees:ByteArray;
      
      public static const largeurCase:int = 32;
      
      public static const hauteurCase:int = 32;
      
      public static const multipleLargeurCase:Number = 1 / largeurCase;
      
      public static const multipleHauteurCase:Number = 1 / hauteurCase;
      
      public function Terrain()
      {
         super();
      }
      
      public static function init(param1:ByteArray) : void
      {
         var _loc3_:int = 0;
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         Terrain.donnees = new ByteArray();
         nbCasesLargeur = param1.readInt();
         nbCasesHauteur = param1.readInt();
         Terrain.donnees.writeInt(nbCasesLargeur);
         Terrain.donnees.writeInt(nbCasesHauteur);
         var _loc2_:int = nbCasesLargeur * nbCasesHauteur;
         largeur = nbCasesLargeur * largeurCase;
         hauteur = nbCasesHauteur * hauteurCase;
         casesApparences = new Vector.<int>();
         casesVitesse = new Vector.<Vector.<Number>>();
         casesConctructible = new Vector.<Vector.<Boolean>>();
         casesDecalageY = new Vector.<Vector.<int>>();
         casesEffet = new Vector.<Vector.<String>>();
         casesNiveau = new Vector.<Vector.<int>>();
         casesDenivele = new Vector.<Vector.<int>>();
         casesPersosCollisions = new Vector.<Vector.<Vector.<Object>>>();
         var _loc6_:Vector.<Object> = Donnees.terrains;
         var _loc7_:int = 0;
         while(_loc7_ < _loc2_)
         {
            _loc5_ = param1.readByte();
            Terrain.donnees.writeByte(_loc5_);
            if(_loc3_ == 0)
            {
               casesVitesse.push(new Vector.<Number>());
               casesConctructible.push(new Vector.<Boolean>());
               casesDecalageY.push(new Vector.<int>());
               casesEffet.push(new Vector.<String>());
               casesNiveau.push(new Vector.<int>());
               casesDenivele.push(new Vector.<int>());
               casesPersosCollisions.push(new Vector.<Vector.<Object>>());
            }
            casesApparences.push(_loc5_);
            casesVitesse[_loc4_].push(_loc6_[_loc5_].speed);
            casesConctructible[_loc4_].push(_loc6_[_loc5_].buildable);
            casesDecalageY[_loc4_].push(_loc6_[_loc5_].translateY);
            casesEffet[_loc4_].push(_loc6_[_loc5_].effect);
            casesNiveau[_loc4_].push(_loc6_[_loc5_].level);
            if(_loc4_ > 0 && casesNiveau[_loc4_ - 1][_loc3_] > _loc6_[_loc5_].level)
            {
               casesDenivele[_loc4_].push((casesNiveau[_loc4_ - 1][_loc3_] - _loc6_[_loc5_].level) * hauteurCase * 0.33);
            }
            else
            {
               casesDenivele[_loc4_].push(0);
            }
            casesPersosCollisions[_loc4_].push(new Vector.<Object>());
            if(++_loc3_ >= largeur / largeurCase)
            {
               _loc3_ = 0;
               _loc4_++;
            }
            _loc7_++;
         }
      }
      
      public static function case_vitesse(param1:int, param2:int) : Number
      {
         if(param1 > 0 && param1 < largeur && param2 > 0 && param2 < hauteur)
         {
            if(casesDenivele[int(param2 / hauteurCase)][int(param1 / largeurCase)] == 0)
            {
               return casesVitesse[int(param2 / hauteurCase)][int(param1 / largeurCase)];
            }
            if(int(param2 / hauteurCase) * hauteurCase + casesDenivele[int(param2 / hauteurCase)][int(param1 / largeurCase)] < param2)
            {
               return casesVitesse[int(param2 / hauteurCase)][int(param1 / largeurCase)];
            }
            return casesVitesse[int(param2 / hauteurCase) - 1][int(param1 / largeurCase)];
         }
         return 1;
      }
      
      public static function case_constructible(param1:int, param2:int) : Boolean
      {
         if(param1 > 0 && param1 < largeur && param2 > 0 && param2 < hauteur)
         {
            return casesConctructible[int(param2 / hauteurCase)][int(param1 / largeurCase)];
         }
         return false;
      }
      
      public static function case_DecalageY(param1:int, param2:int) : int
      {
         if(param1 > 0 && param1 < largeur && param2 > 0 && param2 < hauteur)
         {
            if(casesDenivele[int(param2 / hauteurCase)][int(param1 / largeurCase)] == 0)
            {
               return casesDecalageY[int(param2 / hauteurCase)][int(param1 / largeurCase)];
            }
            if(int(param2 / hauteurCase) * hauteurCase + casesDenivele[int(param2 / hauteurCase)][int(param1 / largeurCase)] < param2)
            {
               return casesDecalageY[int(param2 / hauteurCase)][int(param1 / largeurCase)];
            }
            return casesDecalageY[int(param2 / hauteurCase) - 1][int(param1 / largeurCase)];
         }
         return 0;
      }
      
      public static function case_effet(param1:int, param2:int) : String
      {
         if(param1 > 0 && param1 < largeur && param2 > 0 && param2 < hauteur)
         {
            if(casesDenivele[int(param2 / hauteurCase)][int(param1 / largeurCase)] == 0)
            {
               return casesEffet[int(param2 / hauteurCase)][int(param1 / largeurCase)];
            }
            if(int(param2 / hauteurCase) * hauteurCase + casesDenivele[int(param2 / hauteurCase)][int(param1 / largeurCase)] < param2)
            {
               return casesEffet[int(param2 / hauteurCase)][int(param1 / largeurCase)];
            }
            return casesEffet[int(param2 / hauteurCase) - 1][int(param1 / largeurCase)];
         }
         return null;
      }
      
      public static function case_perso_collisions_effacer(param1:int, param2:int, param3:Object) : void
      {
         var _loc4_:Vector.<Object> = casesPersosCollisions[param2][param1];
         _loc4_.splice(_loc4_.indexOf(param3),1);
      }
      
      public static function case_perso_listerCollisions(param1:int, param2:int, param3:Object) : Vector.<Object>
      {
         var _loc4_:Vector.<Object> = new Vector.<Object>();
         if(param1 > 0 && param1 < nbCasesLargeur && param2 > 0 && param2 < nbCasesHauteur)
         {
            if(param2 > 1)
            {
               if(param1 > 1)
               {
                  _loc4_ = ajouter_vector_persos(_loc4_,casesPersosCollisions[param2 - 1][param1 - 1]);
               }
               _loc4_ = ajouter_vector_persos(_loc4_,casesPersosCollisions[param2 - 1][param1]);
               if(param1 + 1 < nbCasesLargeur)
               {
                  _loc4_ = ajouter_vector_persos(_loc4_,casesPersosCollisions[param2 - 1][param1 + 1]);
               }
            }
            if(param1 > 1)
            {
               _loc4_ = ajouter_vector_persos(_loc4_,casesPersosCollisions[param2][param1 - 1]);
            }
            _loc4_ = ajouter_vector_persos2(_loc4_,casesPersosCollisions[param2][param1],param3);
            if(param1 + 1 < nbCasesLargeur)
            {
               _loc4_ = ajouter_vector_persos(_loc4_,casesPersosCollisions[param2][param1 + 1]);
            }
            if(param2 + 1 < nbCasesHauteur)
            {
               if(param1 > 1)
               {
                  _loc4_ = ajouter_vector_persos(_loc4_,casesPersosCollisions[param2 + 1][param1 - 1]);
               }
               _loc4_ = ajouter_vector_persos(_loc4_,casesPersosCollisions[param2 + 1][param1]);
               if(param1 + 1 < nbCasesLargeur)
               {
                  _loc4_ = ajouter_vector_persos(_loc4_,casesPersosCollisions[param2 + 1][param1 + 1]);
               }
            }
         }
         return _loc4_;
      }
      
      private static function ajouter_vector_persos(param1:Vector.<Object>, param2:Vector.<Object>) : Vector.<Object>
      {
         var _loc3_:Object = null;
         for each(_loc3_ in param2)
         {
            param1.push(_loc3_);
         }
         return param1;
      }
      
      private static function ajouter_vector_persos2(param1:Vector.<Object>, param2:Vector.<Object>, param3:Object) : Vector.<Object>
      {
         var _loc4_:Object = null;
         for each(_loc4_ in param2)
         {
            if(_loc4_ != param3)
            {
               param1.push(_loc4_);
            }
         }
         return param1;
      }
      
      public static function emplacement_constructible(param1:int, param2:int, param3:int, param4:int) : Boolean
      {
         var _loc5_:int = 0;
         var _loc6_:int = 0;
         var _loc7_:int = 0;
         var _loc8_:int = 0;
         if(param1 < -param3 * 0.5 || param1 >= Terrain.largeur - param3 * 0.5 || param2 < param4 || param2 >= Terrain.hauteur)
         {
            return false;
         }
         _loc5_ = param2 - param4;
         _loc8_ = param2;
         while(_loc8_ >= _loc5_)
         {
            if(_loc8_ < 0)
            {
               return false;
            }
            _loc7_ = param1 - param3 * 0.5;
            _loc6_ = param1;
            while(_loc6_ >= _loc7_)
            {
               if(_loc6_ < 0)
               {
                  return false;
               }
               if(!casesConctructible[int(_loc8_ / hauteurCase)][int(_loc6_ / largeurCase)])
               {
                  return false;
               }
               _loc6_ -= largeurCase;
            }
            _loc7_ = param1 + param3 * 0.5;
            _loc6_ = param1 + largeurCase;
            while(_loc6_ <= _loc7_)
            {
               if(_loc6_ >= Terrain.largeur)
               {
                  return false;
               }
               if(!casesConctructible[int(_loc8_ / hauteurCase)][int(_loc6_ / largeurCase)])
               {
                  return false;
               }
               _loc6_ += largeurCase;
            }
            _loc8_ -= hauteurCase;
         }
         return true;
      }
      
      public static function sauvegarder(param1:ByteArray) : ByteArray
      {
         var _loc2_:int = 0;
         param1.writeInt(largeur / largeurCase);
         param1.writeInt(hauteur / hauteurCase);
         for each(_loc2_ in casesApparences)
         {
            param1.writeByte(_loc2_);
         }
         return param1;
      }
   }
}

