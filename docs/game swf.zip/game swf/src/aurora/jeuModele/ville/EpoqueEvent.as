package aurora.jeuModele.ville
{
   import flash.events.Event;
   
   public class EpoqueEvent extends Event
   {
      
      public static const ACTUALISER_TEMPS:String = "actualiserTemps";
      
      public static const ACTUALISER_NO_EPOQUE:String = "actualiserNoEpoque";
      
      public var nombre:Number;
      
      public var actualiserCentreVille:Boolean;
      
      public function EpoqueEvent(param1:String, param2:Number, param3:Boolean = false)
      {
         this.nombre = param2;
         this.actualiserCentreVille = param3;
         super(param1);
      }
   }
}

