package aurora.jeuModele.ville
{
   import aurora.jeuModele.Donnees;
   import aurora.jeuModele.vagues.VaguesActualiserEvent;
   import flash.events.EventDispatcher;
   import flash.events.TimerEvent;
   import flash.utils.Timer;
   
   public class Ville extends EventDispatcher
   {
      
      public var temps:Timer;
      
      private var _actif:Boolean;
      
      public var sansCentreVille:Boolean;
      
      public var changementEpoqueEnPause:Boolean;
      
      public var pasDerniereEpoque:Boolean;
      
      public var iaIdCentreVille:String;
      
      public var no:int;
      
      public var couleur:int;
      
      public var x:int;
      
      public var y:int;
      
      public var peuple:int;
      
      public var equipe:int;
      
      public var puissance:Number;
      
      public var epoqueDepart:int;
      
      public var epoqueActuelle:int;
      
      public var epoqueFin:int;
      
      public var vitesseChangementEpoque:Number;
      
      private var _nbVillageois:int;
      
      private var _nbVillageoisMax:int;
      
      private var _nbSoldats:int;
      
      public var nbSoldatsActifs:int;
      
      public var nbSoldatsMax:int;
      
      private var _nbMonstres:int;
      
      private var _nbMonstresActifs:int;
      
      private var _nbMonstresMax:int;
      
      public var roi:Object;
      
      public var decalageCompteur:int;
      
      public function Ville(param1:int, param2:Object, param3:int, param4:int)
      {
         super();
         this._actif = true;
         this.no = param1;
         this.x = param3;
         this.y = param4;
         if(param2.color != undefined)
         {
            this.couleur = param2.color;
         }
         else
         {
            this.couleur = -1;
         }
         this.peuple = param2.faction;
         this.equipe = param2.equip;
         if(param2.power != undefined)
         {
            this.puissance = param2.power;
         }
         else
         {
            this.puissance = 1;
         }
         if(param2.startingAge != undefined)
         {
            this.epoqueDepart = this.epoqueActuelle = Math.min(param2.startingAge,Donnees.epoques.length - 1);
         }
         if(param2.endingAge != undefined)
         {
            this.epoqueFin = Math.min(param2.endingAge,Donnees.epoques.length - 1);
         }
         else
         {
            this.epoqueFin = Donnees.epoques.length - 1;
         }
         if(param2.speedAge == undefined)
         {
            this.vitesseChangementEpoque = 1;
         }
         else
         {
            this.vitesseChangementEpoque = param2.speedAge;
         }
         if(param2.soldiersLimit)
         {
            this.nbSoldatsMax = param2.soldiersLimit;
         }
         else
         {
            this.nbSoldatsMax = 50;
         }
         if(!Donnees.peuples[this.peuple].townCenters || !param2.townCenter)
         {
            this.sansCentreVille = true;
         }
         this.pasDerniereEpoque = this.epoqueActuelle < this.epoqueFin;
         if(this.pasDerniereEpoque)
         {
            this.temps = new Timer(1500,int(Donnees.epoques[this.epoqueActuelle].time / this.vitesseChangementEpoque));
            this.temps.addEventListener(TimerEvent.TIMER,this.actualiser_temps);
            this.temps.addEventListener(TimerEvent.TIMER_COMPLETE,this.changer_epoque);
            if(this.sansCentreVille)
            {
               this.temps.start();
               this.changementEpoqueEnPause = false;
            }
            else
            {
               this.actualiser_changement_epoque();
               this.changementEpoqueEnPause = true;
            }
         }
         else
         {
            this.changementEpoqueEnPause = true;
            this.actualiser_changement_epoque();
         }
      }
      
      public function recuperer_infos() : void
      {
         dispatchEvent(new EpoqueEvent(EpoqueEvent.ACTUALISER_NO_EPOQUE,this.epoqueActuelle));
         if(this.temps)
         {
            dispatchEvent(new EpoqueEvent(EpoqueEvent.ACTUALISER_TEMPS,(this.temps.currentCount + this.decalageCompteur) / (this.temps.repeatCount + this.decalageCompteur)));
         }
      }
      
      private function actualiser_temps(param1:TimerEvent) : void
      {
         dispatchEvent(new EpoqueEvent(EpoqueEvent.ACTUALISER_TEMPS,(this.temps.currentCount + this.decalageCompteur) / (this.temps.repeatCount + this.decalageCompteur)));
      }
      
      private function changer_epoque(param1:TimerEvent = null) : void
      {
         ++this.epoqueActuelle;
         this.actualiser_changement_epoque();
         this.changementEpoqueEnPause = true;
         this.pasDerniereEpoque = this.epoqueActuelle < this.epoqueFin;
         dispatchEvent(new EpoqueEvent(EpoqueEvent.ACTUALISER_NO_EPOQUE,this.epoqueActuelle,true));
         if(this.sansCentreVille)
         {
            this.demarrer_changement_epoque();
         }
      }
      
      public function demarrer_changement_epoque() : void
      {
         if(this.pasDerniereEpoque && this.changementEpoqueEnPause)
         {
            this.changementEpoqueEnPause = false;
            this.temps.repeatCount = int(Donnees.epoques[this.epoqueActuelle].time / this.vitesseChangementEpoque);
            this.temps.reset();
            this.temps.start();
         }
      }
      
      private function actualiser_changement_epoque() : void
      {
         if(Donnees.peuples[this.peuple].townCenters)
         {
            this.iaIdCentreVille = Donnees.peuples[this.peuple].townCenters[this.epoqueActuelle];
         }
         else
         {
            this.iaIdCentreVille = null;
         }
      }
      
      public function pause() : void
      {
         if(!this.changementEpoqueEnPause)
         {
            this.temps.stop();
         }
      }
      
      public function reprendre() : void
      {
         if(!this.changementEpoqueEnPause)
         {
            this.temps.start();
         }
      }
      
      public function get actif() : Boolean
      {
         return this._actif;
      }
      
      public function set actif(param1:Boolean) : void
      {
         this._actif = param1;
         if(this._actif)
         {
            this.reprendre();
         }
         else
         {
            this.pause();
         }
      }
      
      public function get nbVillageois() : int
      {
         return this._nbVillageois;
      }
      
      public function set nbVillageois(param1:int) : void
      {
         this._nbVillageois = param1;
         dispatchEvent(new VaguesActualiserEvent(VaguesActualiserEvent.ACTUALISER_NB_VILLAGEOIS,this._nbVillageois));
      }
      
      public function get nbVillageoisMax() : int
      {
         return this._nbVillageoisMax;
      }
      
      public function set nbVillageoisMax(param1:int) : void
      {
         this._nbVillageoisMax = param1;
         dispatchEvent(new VaguesActualiserEvent(VaguesActualiserEvent.ACTUALISER_NB_VILLAGEOIS_MAX,this._nbVillageoisMax));
      }
      
      public function get nbSoldats() : int
      {
         return this._nbSoldats;
      }
      
      public function set nbSoldats(param1:int) : void
      {
         this._nbSoldats = param1;
         dispatchEvent(new VaguesActualiserEvent(VaguesActualiserEvent.ACTUALISER_NB_SOLDATS,this._nbSoldats,this.equipe));
      }
      
      public function get nbMonstresActifs() : int
      {
         return this._nbMonstresActifs;
      }
      
      public function set nbMonstresActifs(param1:int) : void
      {
         this._nbMonstresActifs = param1;
      }
      
      public function get nbMonstres() : int
      {
         return this._nbMonstres;
      }
      
      public function set nbMonstres(param1:int) : void
      {
         this._nbMonstres = param1;
         dispatchEvent(new VaguesActualiserEvent(VaguesActualiserEvent.ACTUALISER_NB_MONSTRES,this._nbMonstres));
      }
      
      public function set nbMonstresMax(param1:int) : void
      {
         this._nbMonstresMax = param1;
      }
      
      public function get nbMonstresMax() : int
      {
         return this._nbMonstresMax;
      }
      
      public function detruire() : void
      {
         this.temps.removeEventListener(TimerEvent.TIMER,this.actualiser_temps);
         this.temps.removeEventListener(TimerEvent.TIMER_COMPLETE,this.changer_epoque);
         this.temps.stop();
         this.temps = null;
      }
   }
}

