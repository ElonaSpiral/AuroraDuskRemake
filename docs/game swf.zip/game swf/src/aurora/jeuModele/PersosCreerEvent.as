package aurora.jeuModele
{
   import flash.events.Event;
   
   public class PersosCreerEvent extends Event
   {
      
      public static const CREER:String = "creer";
      
      public var perso:*;
      
      public var anim:String;
      
      public var decalageY:int;
      
      public function PersosCreerEvent(param1:String, param2:* = null, param3:String = "", param4:int = 0)
      {
         this.perso = param2;
         this.anim = param3;
         this.decalageY = param4;
         super(param1,bubbles,cancelable);
      }
   }
}

