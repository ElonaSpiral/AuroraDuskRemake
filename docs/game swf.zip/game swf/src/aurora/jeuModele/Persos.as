package aurora.jeuModele
{
   import aurora.MainJeu;
   import aurora.jeuModele.finPartie.FinPartieEvent;
   import aurora.jeuModele.perso.Animal;
   import aurora.jeuModele.perso.AnimationEvent;
   import aurora.jeuModele.perso.Artisan;
   import aurora.jeuModele.perso.Atelier;
   import aurora.jeuModele.perso.Aventurier;
   import aurora.jeuModele.perso.Batiment;
   import aurora.jeuModele.perso.BatimentCaserne;
   import aurora.jeuModele.perso.BatimentCentreVille;
   import aurora.jeuModele.perso.BatimentDonjon;
   import aurora.jeuModele.perso.BatimentMobile;
   import aurora.jeuModele.perso.BatimentOffensif;
   import aurora.jeuModele.perso.BatimentResurrection;
   import aurora.jeuModele.perso.BatimentRotatif;
   import aurora.jeuModele.perso.Combattant;
   import aurora.jeuModele.perso.CombattantAvance;
   import aurora.jeuModele.perso.CreationPersoEvent;
   import aurora.jeuModele.perso.EffetEvent;
   import aurora.jeuModele.perso.Fondations;
   import aurora.jeuModele.perso.Guerisseur;
   import aurora.jeuModele.perso.Intermediaire;
   import aurora.jeuModele.perso.Joueur;
   import aurora.jeuModele.perso.Maison;
   import aurora.jeuModele.perso.Mobile;
   import aurora.jeuModele.perso.Mur;
   import aurora.jeuModele.perso.Perso;
   import aurora.jeuModele.perso.Projectile;
   import aurora.jeuModele.perso.ProjectileAutoguide;
   import aurora.jeuModele.perso.ProjectileEvent;
   import aurora.jeuModele.perso.ProjectileRetour;
   import aurora.jeuModele.perso.RessourceMobile;
   import aurora.jeuModele.perso.RessourceTerrain;
   import aurora.jeuModele.perso.Serviteur;
   import aurora.jeuModele.perso.Soldat;
   import aurora.jeuModele.perso.SonEvent;
   import aurora.jeuModele.perso.Tresor;
   import aurora.jeuModele.perso.TresorEvent;
   import aurora.jeuModele.perso.Vivant;
   import aurora.jeuModele.perso.attaque.EffetArmeEvent;
   import aurora.jeuModele.perso.objets.ObjetEquipe;
   import aurora.jeuModele.perso.objets.ObjetTemporaire;
   import aurora.jeuModele.vagues.Vagues;
   import aurora.jeuModele.vagues.VaguesActualiserEvent;
   import aurora.jeuModele.vagues.VaguesCreerPerso;
   import aurora.jeuModele.vagues.VaguesCreerPersoEvent;
   import aurora.jeuModele.ville.EpoqueEvent;
   import aurora.jeuModele.ville.Ville;
   import aurora.messages.perso.MessagePersoOrienter;
   import flash.events.EventDispatcher;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   
   public class Persos extends EventDispatcher
   {
      
      public static var enPause:Boolean;
      
      private var vagues:Vagues;
      
      public var persos:Dictionary;
      
      public var persosCollisions:Dictionary;
      
      public var villes:Vector.<Ville>;
      
      public var ressourceTerrain:Dictionary;
      
      public var montures:Dictionary;
      
      public var combattants:Dictionary;
      
      public var batiments:Dictionary;
      
      public var batimentsDefense:Dictionary;
      
      public var batimentResurrection:Dictionary;
      
      public var batimentCaserne:Dictionary;
      
      public var donjons:Dictionary;
      
      public var centresVille:Dictionary;
      
      public var tresors:Vector.<Tresor>;
      
      public var joueur:Vector.<Joueur>;
      
      public var iaActifs:Boolean = true;
      
      public function Persos(param1:Vagues)
      {
         super();
         this.vagues = param1;
         Perso.prochaineId = 0;
         this.persos = new Dictionary();
         this.persosCollisions = new Dictionary();
         this.ressourceTerrain = new Dictionary();
         this.montures = new Dictionary();
         this.combattants = new Dictionary();
         this.batiments = new Dictionary();
         this.batimentsDefense = new Dictionary();
         this.batimentResurrection = new Dictionary();
         this.batimentCaserne = new Dictionary();
         this.donjons = new Dictionary();
         this.centresVille = new Dictionary();
         this.tresors = new Vector.<Tresor>();
         this.joueur = new Vector.<Joueur>();
      }
      
      public function init(param1:Object, param2:Array, param3:Object, param4:Object, param5:Object, param6:Object, param7:Object, param8:Object = null) : void
      {
         var _loc9_:Object = null;
         var _loc10_:* = 0;
         var _loc11_:Object = null;
         var _loc12_:int = 0;
         var _loc14_:int = 0;
         var _loc15_:int = 0;
         var _loc16_:int = 0;
         var _loc17_:String = null;
         var _loc18_:int = 0;
         var _loc19_:int = 0;
         var _loc22_:String = null;
         var _loc23_:TirageAlea = null;
         var _loc24_:Vector.<Object> = null;
         var _loc25_:int = 0;
         var _loc26_:Vector.<Object> = null;
         var _loc27_:Vector.<Artisan> = null;
         var _loc28_:Point = null;
         var _loc13_:int = int(Donnees.racesJouables.length);
         this.charger_villes(param2);
         _loc12_ = 0;
         while(_loc12_ < param2.length)
         {
            if(param2[_loc12_].x)
            {
               _loc15_ = param2[_loc12_].x * Terrain.largeurCase;
            }
            else
            {
               _loc15_ = Terrain.largeur * 0.5;
            }
            if(param2[_loc12_].y)
            {
               _loc16_ = param2[_loc12_].y * Terrain.hauteurCase;
            }
            else
            {
               _loc16_ = Terrain.hauteur * 0.5;
            }
            if(_loc12_ == 0)
            {
               for each(_loc9_ in param1)
               {
                  if(Perso.prochaineId == 0)
                  {
                     this.creer_joueur(_loc9_,_loc15_,_loc16_,0,param2[0].equip != undefined ? int(param2[0].equip) : 0);
                  }
                  else
                  {
                     this.creer_joueur(_loc9_,_loc15_ + Math.random() * 320 - 160,_loc16_ + Math.random() * 320 - 160,0,param2[0].equip != undefined ? int(param2[0].equip) : 0);
                  }
                  this.persos[Perso.prochaineId - 1].ville = 0;
               }
               _loc14_ = param2[0].characters - param1.length;
            }
            else
            {
               _loc14_ = int(param2[_loc12_].characters);
            }
            if(Donnees.peuples[param2[_loc12_].faction].dungeon)
            {
               this.creer_perso(Donnees.peuples[param2[_loc12_].faction].dungeon,true,_loc15_,_loc16_,_loc12_,param2[_loc12_].equip != undefined ? int(param2[_loc12_].equip) : int(_loc12_));
               this.persos[Perso.prochaineId - 1].init_races(this.villes[_loc12_].peuple);
               this.persos[Perso.prochaineId - 1].init_vagues(param2[_loc12_].characters);
               this.persos[Perso.prochaineId - 1].ville = _loc12_;
            }
            if(!Donnees.peuples[this.villes[_loc12_].peuple].dungeon)
            {
               _loc10_ = 0;
               while(_loc10_ < _loc14_)
               {
                  _loc17_ = null;
                  if(Boolean(_loc12_ == 0) && Boolean(param5) && param5.length > _loc10_)
                  {
                     if(param5[_loc10_].race)
                     {
                        _loc17_ = param5[_loc10_].race;
                        if(_loc17_ == "copyPlayer")
                        {
                           _loc17_ = this.persos[0].race;
                        }
                     }
                     if(param5[_loc10_].x)
                     {
                        _loc18_ = int(param5[_loc10_].x);
                     }
                     else
                     {
                        _loc18_ = Math.round(_loc15_ + Math.random() * 320 - 160);
                     }
                     if(param5[_loc10_].y)
                     {
                        _loc19_ = int(param5[_loc10_].y);
                     }
                     else
                     {
                        _loc19_ = Math.round(_loc16_ + Math.random() * 320 - 160);
                     }
                  }
                  else
                  {
                     _loc18_ = Math.round(_loc15_ + Math.random() * 320 - 160);
                     _loc19_ = Math.round(_loc16_ + Math.random() * 320 - 160);
                  }
                  if(!_loc17_)
                  {
                     if(Donnees.peuples[this.villes[_loc12_].peuple].dungeon)
                     {
                        if(Donnees.peuples[this.villes[_loc12_].peuple].races)
                        {
                           _loc24_ = new Vector.<Object>();
                           _loc25_ = 0;
                           while(_loc25_ < Donnees.peuples[this.villes[_loc12_].peuple].races.length)
                           {
                              _loc24_.push(Donnees.donnees[Donnees.peuples[this.villes[_loc12_].peuple].races[_loc25_]]);
                              _loc25_++;
                           }
                           _loc23_ = new TirageAlea(_loc24_,this.villes[_loc12_].epoqueActuelle);
                        }
                        else
                        {
                           _loc23_ = new TirageAlea(Donnees.monstres,this.villes[_loc12_].epoqueActuelle);
                        }
                        _loc17_ = _loc23_.tirage();
                     }
                     else if(Donnees.peuples[this.villes[_loc12_].peuple].races)
                     {
                        _loc17_ = Donnees.peuples[this.villes[_loc12_].peuple].races[int(Math.random() * Donnees.peuples[this.villes[_loc12_].peuple].races.length)];
                     }
                     else
                     {
                        _loc17_ = Donnees.racesJouables[int(Math.random() * _loc13_)];
                     }
                  }
                  this.creer_perso(_loc17_,true,_loc18_,_loc19_,_loc12_,param2[_loc12_].equip != undefined ? int(param2[_loc12_].equip) : int(_loc12_));
                  this.persos[Perso.prochaineId - 1].ville = _loc12_;
                  if(Boolean(_loc12_ == 0) && Boolean(param5) && param5.length > _loc10_)
                  {
                     if(param5[_loc10_].apparence)
                     {
                        this.persos[Perso.prochaineId - 1].charger_apparence(param5[_loc10_].apparence);
                     }
                     if(param5[_loc10_].life)
                     {
                        this.persos[Perso.prochaineId - 1].editer_vie(param5[_loc10_].life);
                     }
                     if(param5[_loc10_].orientation)
                     {
                        switch(param5[_loc10_].orientation)
                        {
                           case "left":
                              this.persos[Perso.prochaineId - 1].orientation = MessagePersoOrienter.GAUCHE;
                              break;
                           case "right":
                              this.persos[Perso.prochaineId - 1].orientation = MessagePersoOrienter.DROITE;
                              break;
                           case "up":
                              this.persos[Perso.prochaineId - 1].orientation = MessagePersoOrienter.HAUT;
                              break;
                           case "down":
                              this.persos[Perso.prochaineId - 1].orientation = MessagePersoOrienter.BAS;
                        }
                        this.persos[Perso.prochaineId - 1].dispatchEvent(new PersosEvent(PersosEvent.ORIENTER));
                     }
                  }
                  _loc10_++;
               }
            }
            _loc12_++;
         }
         _loc12_ = 0;
         while(_loc12_ < param2.length)
         {
            if(!Donnees.peuples[param2[_loc12_].faction].dungeon)
            {
               this.villes[_loc12_].nbVillageois = this.villes[_loc12_].nbVillageoisMax = param2[_loc12_].characters;
            }
            _loc12_++;
         }
         this.actualiser_nbMonstresMax(param4.monstersLimit ? int(param4.monstersLimit) : 50);
         var _loc20_:TirageAlea = new TirageAlea(Donnees.iaPersonnalisees);
         for each(_loc9_ in this.persos)
         {
            if(_loc9_ is Artisan && !(_loc9_ is Serviteur))
            {
               if(Donnees.iaPersonnalisees.length > 0)
               {
                  if(Donnees.peuples[this.villes[Artisan(_loc9_).ville].peuple].ais)
                  {
                     Artisan(_loc9_).personnaliser_ia(Donnees.donnees[_loc20_.tirage_selon_liste_ids(Donnees.iaPersonnalisees,Donnees.peuples[this.villes[Artisan(_loc9_).ville].peuple].ais)]);
                  }
                  else if(Math.random() > 0.4)
                  {
                     Artisan(_loc9_).personnaliser_ia(Donnees.donnees[_loc20_.tirage()]);
                  }
               }
               if(param2[Artisan(_loc9_).ville].startingResources)
               {
                  for each(_loc11_ in Artisan(_loc9_).ressources)
                  {
                     if(param2[Artisan(_loc9_).ville].startingResources is int)
                     {
                        _loc11_.quantite = param2[Artisan(_loc9_).ville].startingResources;
                     }
                     else if(!(_loc9_ is Joueur))
                     {
                        if(param2[Artisan(_loc9_).ville].startingResources[_loc11_.id])
                        {
                           _loc11_.quantite = param2[Artisan(_loc9_).ville].startingResources[_loc11_.id];
                        }
                     }
                  }
               }
            }
            if(_loc9_.equipe >= 0 && !(_loc9_ is Joueur))
            {
               _loc9_.puissance = this.villes[_loc9_.ville].puissance;
            }
         }
         if(Boolean(param7) && Boolean(param7.on))
         {
            if(param7.ai)
            {
               _loc12_ = 0;
               while(_loc12_ < param2.length)
               {
                  if(Donnees.peuples[param2[_loc12_].faction].aiKings)
                  {
                     _loc26_ = new Vector.<Object>();
                     for each(_loc9_ in Donnees.peuples[param2[_loc12_].faction].aiKings)
                     {
                        _loc26_.push(_loc9_);
                     }
                     _loc27_ = new Vector.<Artisan>();
                     for each(_loc9_ in this.persos)
                     {
                        if(_loc9_ is Artisan && _loc9_.ville == _loc12_ && !_loc9_.joueur)
                        {
                           _loc27_.push(_loc9_);
                        }
                     }
                     if(_loc27_.length)
                     {
                        _loc27_[int(Math.random() * _loc27_.length)].personnaliser_ia(Donnees.donnees[_loc26_[int(Math.random() * _loc26_.length)]]);
                     }
                  }
                  _loc12_++;
               }
            }
            if(param7.start)
            {
               this.persos[0].ajouter_objet("crown");
            }
         }
         this.actualiser_epoques();
         IA.villes = this.villes;
         IA.agressif = this.villes.length == 1;
         if(param6)
         {
            for each(_loc9_ in param6)
            {
               if(Donnees.donnees[_loc9_.id])
               {
                  if(Boolean(_loc9_.x) && Boolean(_loc9_.y))
                  {
                     _loc28_ = new Point(_loc9_.x,_loc9_.y);
                     if(_loc9_.randomXY)
                     {
                        _loc28_.x += (Math.random() * 2 - 1) * _loc9_.randomXY;
                        _loc28_.y += (Math.random() * 2 - 1) * _loc9_.randomXY;
                     }
                     else
                     {
                        if(_loc9_.randomX)
                        {
                           _loc28_.y += (Math.random() * 2 - 1) * _loc9_.randomX;
                        }
                        if(_loc9_.randomY)
                        {
                           _loc28_.y += (Math.random() * 2 - 1) * _loc9_.randomY;
                        }
                     }
                  }
                  else
                  {
                     _loc28_ = this.trouver_position_libre_construction_illimite(this.persos[_loc9_.owner],Donnees.donnees[_loc9_.id].width,Donnees.donnees[_loc9_.id].height,-2);
                  }
                  if(_loc28_)
                  {
                     if(_loc9_.prebuild)
                     {
                        MainJeu.bacASable = true;
                        this.persos[_loc9_.owner].dispatchEvent(new CreationPersoEvent(CreationPersoEvent.CREER,_loc9_.id,_loc28_.x,_loc28_.y,this.persos[_loc9_.owner].equipe,1,"",false));
                        MainJeu.bacASable = false;
                        this.persos[Perso.prochaineId - 1].construire(_loc9_.prebuild * this.persos[Perso.prochaineId - 1].constructionRestante,0);
                     }
                     else
                     {
                        this.creer_perso(_loc9_.id,Donnees.donnees[_loc9_.id].type == "buildingMonster" || Donnees.donnees[_loc9_.id].type == "monster",_loc28_.x,_loc28_.y,_loc9_.owner != undefined ? int(this.persos[_loc9_.owner].ville) : -1,_loc9_.owner != undefined ? int(this.persos[_loc9_.owner].equipe) : -1,"",_loc9_.owner);
                        if(Donnees.donnees[_loc9_.id].type == "house" && Boolean(_loc9_.owner))
                        {
                           this.persos[_loc9_.owner].maison = this.persos[Perso.prochaineId - 1];
                           this.persos[_loc9_.owner].maisonEpoque = Donnees.donnees[_loc9_.id].age;
                           this.persos[Perso.prochaineId - 1].proprietaire = _loc9_.owner;
                        }
                        if(Donnees.donnees[_loc9_.id].type != "landRessource" && Boolean(_loc9_.owner))
                        {
                           this.persos[Perso.prochaineId - 1].equipe = this.persos[_loc9_.owner].equipe;
                        }
                        if(Donnees.donnees[_loc9_.id].type == "monster")
                        {
                           if(_loc9_.owner != undefined)
                           {
                              if(this.persos[Perso.prochaineId - 1] is Soldat || this.persos[Perso.prochaineId - 1] is BatimentMobile)
                              {
                                 this.persos[Perso.prochaineId - 1].arreter();
                                 this.persos[Perso.prochaineId - 1].definir_origine(this.persos[Perso.prochaineId - 1].x,this.persos[Perso.prochaineId - 1].y,this.persos[_loc9_.owner].x,this.persos[_loc9_.owner].y);
                                 this.persos[Perso.prochaineId - 1].revenirPositionOrigine = false;
                                 this.persos[Perso.prochaineId - 1].maitre = this.persos[_loc9_.owner];
                                 if(_loc9_.order)
                                 {
                                    this.persos[Perso.prochaineId - 1].ordre = _loc9_.order;
                                 }
                              }
                              ++this.villes[this.persos[_loc9_.owner].ville].nbSoldats;
                           }
                           else
                           {
                              ++this.vagues.nbMonstres;
                              ++this.vagues.nbMonstresActifs;
                           }
                        }
                        if(Donnees.donnees[_loc9_.id].type == "animal")
                        {
                           this.persos[Perso.prochaineId - 1].equipe = -1;
                        }
                        if(_loc9_.orientation)
                        {
                           switch(_loc9_.orientation)
                           {
                              case "left":
                                 this.persos[Perso.prochaineId - 1].orientation = MessagePersoOrienter.GAUCHE;
                                 break;
                              case "right":
                                 this.persos[Perso.prochaineId - 1].orientation = MessagePersoOrienter.DROITE;
                                 break;
                              case "up":
                                 this.persos[Perso.prochaineId - 1].orientation = MessagePersoOrienter.HAUT;
                                 break;
                              case "down":
                                 this.persos[Perso.prochaineId - 1].orientation = MessagePersoOrienter.BAS;
                           }
                           this.persos[Perso.prochaineId - 1].dispatchEvent(new PersosEvent(PersosEvent.ORIENTER));
                        }
                        if(_loc9_.maxLife)
                        {
                           this.persos[Perso.prochaineId - 1].vie.score = this.persos[Perso.prochaineId - 1].vie.scoreMax = _loc9_.maxLife;
                        }
                        if(_loc9_.life)
                        {
                           this.persos[Perso.prochaineId - 1].editer_vie(_loc9_.life);
                        }
                     }
                  }
               }
            }
         }
         if(param8)
         {
            if(param8.x)
            {
               this.joueur[0].x = param8.x;
            }
            if(param8.y)
            {
               this.joueur[0].y = param8.y;
            }
            if(Boolean(param8.x) || Boolean(param8.y))
            {
               this.joueur[0].dispatchEvent(new PersosEvent(PersosEvent.DEPLACER));
            }
            if(param8.orientation)
            {
               switch(param8.orientation)
               {
                  case "left":
                     this.joueur[0].orientation = MessagePersoOrienter.GAUCHE;
                     break;
                  case "right":
                     this.joueur[0].orientation = MessagePersoOrienter.DROITE;
                     break;
                  case "up":
                     this.joueur[0].orientation = MessagePersoOrienter.HAUT;
                     break;
                  case "down":
                     this.joueur[0].orientation = MessagePersoOrienter.BAS;
               }
               this.joueur[0].dispatchEvent(new PersosEvent(PersosEvent.ORIENTER));
            }
         }
         var _loc21_:TirageAlea = new TirageAlea(Donnees.ressourcesTerrain,param2[0].endingAge);
         _loc10_ = 0;
         while(_loc10_ < param3.resources)
         {
            _loc22_ = _loc21_.tirage();
            _loc15_ = Math.random() * (Terrain.largeur - Donnees.donnees[_loc22_].height) + Donnees.donnees[_loc22_].height;
            _loc16_ = Math.random() * (Terrain.hauteur - Donnees.donnees[_loc22_].width) + Donnees.donnees[_loc22_].width * 0.5;
            if(this.position_libre_contruction(Donnees.donnees[_loc22_].width,Donnees.donnees[_loc22_].height,_loc15_,_loc16_))
            {
               this.creer_perso(_loc22_,false,_loc15_,_loc16_,-1,-1);
            }
            else
            {
               _loc10_--;
            }
            _loc10_++;
         }
         this.actualiser_nbTout();
      }
      
      public function init2(param1:Object, param2:Object, param3:Object) : void
      {
         var _loc4_:Object = null;
         var _loc5_:Object = null;
         var _loc6_:int = 0;
         if(param3)
         {
            if(param3.items)
            {
               for(_loc4_ in param3.items)
               {
                  if(Donnees.donnees[_loc4_])
                  {
                     this.persos[0].ajouter_objet(_loc4_,param3.items[_loc4_]);
                  }
               }
            }
            if(param3.save)
            {
               this.persos[0].charger_equipement(param3.save);
            }
            if(param3.resources)
            {
               for(_loc4_ in param3.resources)
               {
                  if(Donnees.donnees[_loc4_])
                  {
                     this.persos[0].ressources[_loc4_].quantite = param3.resources[_loc4_];
                  }
               }
            }
            if(param3.startingResources)
            {
               for each(_loc4_ in this.joueur[0].ressources)
               {
                  if(param3.startingResources is int)
                  {
                     _loc4_.quantite = param3.startingResources;
                  }
                  else if(param3.startingResources[_loc4_.id] != undefined)
                  {
                     _loc4_.quantite = param3.startingResources[_loc4_.id];
                  }
               }
            }
         }
         for each(_loc5_ in this.persos)
         {
            if(_loc5_ is Artisan && !(_loc5_ is Joueur))
            {
               if(param1[Artisan(_loc5_).equipe].startingItems)
               {
                  for(_loc4_ in param1[Artisan(_loc5_).equipe].startingItems)
                  {
                     if(Donnees.donnees[_loc4_])
                     {
                        _loc5_.ajouter_objet(_loc4_,param1[Artisan(_loc5_).equipe].startingItems[_loc4_]);
                     }
                  }
               }
            }
         }
         if(param2)
         {
            while(_loc6_ < param2.length)
            {
               if(param2[_loc6_].items)
               {
                  for(_loc4_ in param2[_loc6_].items)
                  {
                     if(Donnees.donnees[_loc4_])
                     {
                        this.persos[_loc6_ + 1].ajouter_objet(_loc4_,param2[_loc6_].items[_loc4_]);
                     }
                  }
               }
               _loc6_++;
            }
         }
      }
      
      private function message_perso(param1:MessageEvent) : void
      {
         dispatchEvent(new MessageEvent(MessageEvent.MESSAGE_IMPORTANT,param1.message));
      }
      
      private function creer_joueur(param1:Object, param2:Number, param3:Number, param4:int, param5:int, param6:int = 0) : void
      {
         var _loc7_:Joueur = null;
         _loc7_ = new Joueur();
         if(this.joueur.length == 0)
         {
            this.joueur.push(_loc7_);
         }
         _loc7_.joueur = true;
         _loc7_.race = param1.race;
         _loc7_.x = param2;
         _loc7_.y = param3;
         _loc7_.ville = param4;
         _loc7_.equipe = param5;
         _loc7_.init(Donnees.donnees[param1.race]);
         if(param6 > 0)
         {
            _loc7_.init_client(param6);
         }
         this.creer_perso3(_loc7_);
         if(param1.apparence)
         {
            _loc7_.charger_apparence(param1.apparence);
         }
         else
         {
            _loc7_.initialiser_apparence();
         }
         _loc7_.charger(param1);
         dispatchEvent(new PersosCreerEvent(PersosCreerEvent.CREER,_loc7_));
      }
      
      public function creer_perso(param1:String, param2:Boolean, param3:Number, param4:Number, param5:int, param6:int, param7:String = "", param8:Boolean = false, param9:int = 0) : void
      {
         var _loc10_:Object = null;
         switch(Donnees.donnees[param1].type)
         {
            case "monster":
               if(Donnees.donnees[param1].ai)
               {
                  switch(Donnees.donnees[param1].ai)
                  {
                     case "healer":
                        _loc10_ = new Guerisseur();
                        break;
                     case "servant":
                        _loc10_ = new Serviteur(this.villes[param5].epoqueActuelle);
                  }
               }
               else
               {
                  if(param8)
                  {
                     _loc10_ = new Soldat();
                  }
                  else if(Donnees.donnees[param1].attacks)
                  {
                     _loc10_ = new CombattantAvance();
                  }
                  else
                  {
                     _loc10_ = new Combattant();
                  }
                  this.persosCollisions[_loc10_.id] = _loc10_;
                  _loc10_.addEventListener(PersosEvent.DEPLACER,this.gerer_collisions);
                  this.gerer_collisions_init(_loc10_,Terrain.casesPersosCollisions);
               }
               _loc10_.ville = param5;
               _loc10_.equipe = param6;
               _loc10_.ia = param2;
               break;
            case "playable":
               _loc10_ = new Artisan();
               _loc10_.ville = param5;
               _loc10_.equipe = param6;
               _loc10_.ia = param2;
               break;
            case "landRessource":
               _loc10_ = new RessourceTerrain();
               if(Donnees.donnees[param1].mount)
               {
                  this.montures[_loc10_.id] = _loc10_;
                  break;
               }
               this.ressourceTerrain[_loc10_.id] = _loc10_;
               break;
            case "animal":
               if(Donnees.donnees[param1].produce)
               {
                  _loc10_ = new RessourceMobile();
               }
               else
               {
                  _loc10_ = new Animal();
                  _loc10_.ville = param5;
                  _loc10_.equipe = param6;
               }
               if(Donnees.donnees[param1].mount)
               {
                  this.montures[_loc10_.id] = _loc10_;
               }
               else
               {
                  this.ressourceTerrain[_loc10_.id] = _loc10_;
               }
               _loc10_.ia = true;
               break;
            case "defenseTower":
               if(Donnees.donnees[param1].rotateTower)
               {
                  _loc10_ = new BatimentRotatif();
                  _loc10_.addEventListener(PersosEvent.ROTATION,this.rotation_perso);
               }
               else
               {
                  _loc10_ = new BatimentOffensif();
               }
               _loc10_.ville = param5;
               _loc10_.equipe = param6;
               break;
            case "buildingMonster":
               _loc10_ = new BatimentMobile();
               _loc10_.ville = param5;
               _loc10_.equipe = param6;
               _loc10_.ia = param2;
               this.persosCollisions[_loc10_.id] = _loc10_;
               _loc10_.addEventListener(PersosEvent.DEPLACER,this.gerer_collisions);
               break;
            case "resurrectTower":
               _loc10_ = new BatimentResurrection();
               _loc10_.ville = param5;
               _loc10_.equipe = param6;
               this.batimentResurrection[_loc10_.id] = _loc10_;
               break;
            case "barrack":
               _loc10_ = new BatimentCaserne();
               _loc10_.ville = param5;
               _loc10_.equipe = param6;
               this.batimentCaserne[_loc10_.id] = _loc10_;
               this.ressourceTerrain[_loc10_.id] = _loc10_;
               break;
            case "workshop":
               _loc10_ = new Atelier();
               this.ressourceTerrain[_loc10_.id] = _loc10_;
               _loc10_.ville = param5;
               _loc10_.equipe = param6;
               break;
            case "item":
            case "ressource":
               _loc10_ = new Tresor();
               this.tresors.push(_loc10_);
               break;
            case "house":
               _loc10_ = new Maison();
               this.ressourceTerrain[_loc10_.id] = _loc10_;
               _loc10_.ville = param5;
               _loc10_.equipe = param6;
               break;
            case "wall":
               _loc10_ = new Mur();
               _loc10_.ville = param5;
               _loc10_.equipe = param6;
               _loc10_.x = param3;
               _loc10_.y = param4;
               this.gerer_collisions_init(_loc10_,Terrain.casesPersosCollisions);
               break;
            case "townCenter":
               _loc10_ = new BatimentCentreVille(param1,Donnees.peuples[this.villes[param5].peuple].townCenters);
               _loc10_.ville = param5;
               _loc10_.equipe = param6;
               this.centresVille[_loc10_.id] = _loc10_;
               this.batimentCaserne[_loc10_.id] = _loc10_;
               this.ressourceTerrain[_loc10_.id] = _loc10_;
               if(this.villes[param5].epoqueActuelle < this.villes[param5].epoqueFin)
               {
                  this.villes[param5].demarrer_changement_epoque();
               }
               break;
            case "dungeon":
               _loc10_ = new BatimentDonjon(this.villes[param5]);
               this.donjons[_loc10_.id] = _loc10_;
               _loc10_.ville = param5;
               _loc10_.equipe = param6;
         }
         this.creer_perso2(_loc10_,param1,param3,param4,param7,param9);
      }
      
      private function gerer_collisions_init(param1:Object, param2:Vector.<Vector.<Vector.<Object>>>) : void
      {
         var _loc3_:int = int(param1.x / Terrain.largeurCase);
         var _loc4_:int = int(param1.y / Terrain.hauteurCase);
         if(_loc3_ > 0 && _loc3_ < Terrain.nbCasesLargeur && _loc4_ > 0 && _loc4_ < Terrain.nbCasesHauteur)
         {
            param2[_loc4_][_loc3_].push(param1);
         }
         param1.caseTerrainX = _loc3_;
         param1.caseTerrainY = _loc4_;
      }
      
      private function gerer_collisions_fin(param1:Object, param2:Function) : void
      {
         var _loc3_:int = int(param1.caseTerrainX);
         var _loc4_:int = int(param1.caseTerrainY);
         if(_loc3_ > 0 && _loc3_ < Terrain.nbCasesLargeur && _loc4_ > 0 && _loc4_ < Terrain.nbCasesHauteur)
         {
            param2(_loc3_,_loc4_,param1);
         }
      }
      
      private function gerer_collisions(param1:PersosEvent) : void
      {
         var _loc3_:Vector.<Object> = null;
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         var _loc6_:int = 0;
         var _loc7_:int = 0;
         var _loc8_:int = 0;
         var _loc9_:Object = null;
         var _loc2_:Combattant = Combattant(param1.currentTarget);
         if(int(_loc2_.x / Terrain.largeurCase) != _loc2_.caseTerrainX || int(_loc2_.y / Terrain.largeurCase) != _loc2_.caseTerrainY)
         {
            this.gerer_collisions_fin(_loc2_,Terrain.case_perso_collisions_effacer);
            this.gerer_collisions_init(_loc2_,Terrain.casesPersosCollisions);
         }
         if(_loc2_.aucuneInertie)
         {
            _loc3_ = Terrain.case_perso_listerCollisions(_loc2_.caseTerrainX,_loc2_.caseTerrainY,_loc2_);
            _loc4_ = _loc2_.rayonCarre;
            _loc7_ = _loc2_.x;
            _loc8_ = _loc2_.y;
            for each(_loc9_ in _loc3_)
            {
               _loc5_ = _loc9_.x - _loc7_;
               _loc6_ = _loc9_.y - _loc8_;
               if(_loc5_ * _loc5_ + _loc6_ * _loc6_ < _loc4_)
               {
                  if(_loc9_ is Combattant)
                  {
                     _loc9_.appliquer_collision(_loc2_,2);
                  }
                  else if(_loc9_ is Mur)
                  {
                     if(_loc9_.equipe != _loc2_.equipe)
                     {
                        _loc2_.attaquer(Mur(_loc9_));
                     }
                  }
               }
            }
         }
      }
      
      private function ramasser_tresors(param1:PersosEvent) : void
      {
         var _loc3_:int = 0;
         var _loc4_:* = 0;
         var _loc5_:* = 0;
         var _loc2_:Artisan = Artisan(param1.currentTarget);
         if(_loc2_.vivant)
         {
            _loc3_ = _loc2_.rayon;
            _loc4_ = int(this.tresors.length);
            _loc5_ = 0;
            while(_loc5_ < _loc4_)
            {
               if(this.tresors[_loc5_].ramasser(_loc2_))
               {
                  this.tresors.splice(_loc5_,1);
                  _loc5_--;
                  _loc4_--;
               }
               _loc5_++;
            }
         }
      }
      
      private function creer_perso2(param1:Object, param2:String, param3:Number, param4:Number, param5:String = "", param6:int = 0) : void
      {
         param1.x = param3;
         param1.y = param4;
         param1.init(Donnees.donnees[param2]);
         this.creer_perso3(param1);
         dispatchEvent(new PersosCreerEvent(PersosCreerEvent.CREER,param1,param5,param6));
         if(param1 is Mobile || param1 is BatimentMobile)
         {
            param1.init_ia(param5 == "");
            if(param1 is Aventurier && !(param1 is Serviteur))
            {
               if(this.villes[param1.equipe].couleur != -1)
               {
                  param1.initialiser_apparence(this.villes[param1.equipe].couleur + 14);
               }
               else
               {
                  param1.initialiser_apparence(this.villes.length > 1 ? 8 - param1.equipe : -1);
               }
            }
         }
      }
      
      private function creer_perso3(param1:Object) : void
      {
         this.persos[param1.id] = param1;
         if(param1 is Mobile || param1 is BatimentMobile)
         {
            param1.addEventListener(PersosEvent.DEPLACER,this.deplacer_perso);
            param1.addEventListener(PersosEvent.DECALER_Y,this.decaler_y_perso);
            param1.addEventListener(PersosEvent.ORIENTER,this.orienter_perso);
            param1.addEventListener(PersosEvent.ACTUALISER_COULEUR,this.couleur_perso);
            param1.destinationX = param1.x;
            param1.destinationY = param1.y;
            param1.gerer_deplacement_terrain();
         }
         if(param1 is Artisan)
         {
            if(!(param1 is Serviteur))
            {
               param1.addEventListener(PersosEvent.DEPLACER,this.ramasser_tresors);
               param1.addEventListener(PersosEvent.FANTOME,this.fantome_perso);
               param1.addEventListener(PersosEvent.FANTOME,this.verifier_fin_partie);
               param1.addEventListener(PersosEvent.ACTUALISER_APPARENCE,this.apparence_perso);
               param1.addEventListener(PersosEvent.ACTUALISER_MONTURE,this.monture_perso);
               param1.addEventListener(MessageEvent.MESSAGE_IMPORTANT,this.message_perso);
            }
            param1.addEventListener(PersosEvent.VISIBLE,this.visible_perso);
            param1.addEventListener(PersosEvent.ROI,this.roi_perso);
            param1.addEventListener(BulleEvent.MESSAGE,this.actualier_bulle_perso);
         }
         if(param1 is Vivant)
         {
            param1.addEventListener(PersosEvent.ACTUALISER_VIE,this.actualier_vie_perso);
            param1.addEventListener(EffetEvent.EFFET,this.afficher_effet);
            param1.addEventListener(SonEvent.SON,this.jouer_son);
            param1.addEventListener(CreationPersoEvent.CREER,this.perso_creer_perso);
            param1.addEventListener(TresorEvent.CREER,this.creer_tresor);
         }
         if(param1 is Combattant || param1 is BatimentOffensif || param1 is BatimentMobile)
         {
            param1.addEventListener(ProjectileEvent.CREER,this.perso_creer_projectile);
            param1.addEventListener(PersosEvent.DETRUIRE,this.verifier_fin_partie);
            this.combattants[param1.id] = param1;
            if(param1 is Soldat || param1 is Serviteur)
            {
               param1.gerer_creation(Donnees.donnees[param1.race]);
            }
            param1.addEventListener(EffetArmeEvent.EFFET_ARME,this.afficher_effet_arme);
         }
         if(param1 is BatimentOffensif)
         {
            this.batimentsDefense[param1.id] = param1;
         }
         if(param1 is BatimentResurrection)
         {
            param1.addEventListener(EffetEvent.EFFET,this.afficher_effet);
            param1.addEventListener(PersosEvent.DETRUIRE,this.verifier_fin_partie);
         }
         if(param1 is BatimentDonjon)
         {
            param1.addEventListener(VaguesCreerPersoEvent.CREER_PERSO,this.ajouter_vague);
         }
         if(param1 is BatimentCentreVille)
         {
            param1.addEventListener(ProjectileEvent.CREER,this.perso_creer_projectile);
         }
         if(param1 is Fondations || param1 is Batiment || param1 is BatimentMobile)
         {
            this.batiments[param1.id] = param1;
            if(param1 is BatimentOffensif)
            {
               this.batimentsDefense[param1.id] = param1;
            }
            if(param1 is Fondations || param1 is BatimentCentreVille)
            {
               param1.addEventListener(PersosEvent.ACTUALISER_APPARENCE,this.apparence_perso);
               param1.dispatchEvent(new PersosEvent(PersosEvent.ACTUALISER_APPARENCE));
            }
         }
         param1.addEventListener(AnimationEvent.ANIMER,this.animer_perso);
         param1.addEventListener(PersosEvent.EFFACER,this.effacer_perso);
         param1.addEventListener(PersosEvent.DETRUIRE,this.detruire_perso);
      }
      
      private function creer_perso_temporaire(param1:String, param2:String, param3:Number, param4:Number, param5:Number, param6:Number, param7:int, param8:int, param9:String, param10:Object, param11:Boolean = true) : void
      {
         var _loc12_:Object = null;
         var _loc13_:String = Donnees.donnees[param2].type;
         if(_loc13_ == "workshop" || _loc13_ == "defenseTower" || _loc13_ == "buildingMonster" || _loc13_ == "resurrectTower" || _loc13_ == "house" || _loc13_ == "barrack" || _loc13_ == "wall" || _loc13_ == "townCenter")
         {
            _loc12_ = new Fondations(param3,param2,param4,param8,param9,Donnees.donnees[param2],param10);
            _loc12_.addEventListener(PersosEvent.ACTUALISER_VIE,this.actualier_vie_perso);
            _loc12_.addEventListener(PersosEvent.ACTUALISER_ETAPE,this.actualier_etape_perso);
            this.creer_perso2(_loc12_,param1,param5,param6);
            if(param11)
            {
               param10.aller_travailler(_loc12_);
            }
            if(_loc13_ == "house" && param10 is Artisan)
            {
               param10.possedeMaison = true;
               param10.maison = _loc12_;
               param10.maisonEpoque = Donnees.donnees[param2].age;
            }
         }
         else
         {
            _loc12_ = new Intermediaire(param3,param2,param4,param7,param8,param9);
            this.creer_perso2(_loc12_,param1,param5,param6);
         }
         _loc12_.addEventListener(CreationPersoEvent.CREER,this.perso_creer_perso);
         _loc12_.addEventListener(PersosEvent.EFFACER,this.effacer_perso);
         _loc12_.addEventListener(PersosEvent.DETRUIRE,this.detruire_perso);
      }
      
      private function deplacer_perso(param1:PersosEvent) : void
      {
         dispatchEvent(new PersosEvent(PersosEvent.DEPLACER,param1.currentTarget));
      }
      
      private function decaler_y_perso(param1:PersosEvent) : void
      {
         dispatchEvent(new PersosEvent(PersosEvent.DECALER_Y,param1.currentTarget));
      }
      
      private function orienter_perso(param1:PersosEvent) : void
      {
         dispatchEvent(new PersosEvent(PersosEvent.ORIENTER,param1.currentTarget));
      }
      
      private function rotation_perso(param1:PersosEvent) : void
      {
         dispatchEvent(new PersosEvent(PersosEvent.ROTATION,param1.currentTarget));
      }
      
      private function actualier_vie_perso(param1:PersosEvent) : void
      {
         dispatchEvent(new PersosEvent(PersosEvent.ACTUALISER_VIE,param1.currentTarget));
      }
      
      private function actualier_etape_perso(param1:PersosEvent) : void
      {
         dispatchEvent(new PersosEvent(PersosEvent.ACTUALISER_ETAPE,param1.currentTarget));
      }
      
      private function actualier_bulle_perso(param1:BulleEvent) : void
      {
         dispatchEvent(new BulleEvent(BulleEvent.MESSAGE,param1.message,param1.currentTarget));
      }
      
      private function verifier_fin_partie(param1:PersosEvent) : void
      {
         var _loc2_:BatimentDonjon = null;
         var _loc3_:int = 0;
         var _loc4_:int = 0;
         var _loc5_:Object = null;
         dispatchEvent(new FinPartieEvent(FinPartieEvent.VERIFIER_FIN_PARTIE));
         if(!(param1.currentTarget is Artisan) && !(param1.currentTarget is BatimentOffensif) && !(param1.currentTarget is BatimentMobile) && !(param1.currentTarget is BatimentResurrection) && !(param1.currentTarget is Soldat) && !(param1.currentTarget is Serviteur))
         {
            if(param1.currentTarget.equipe == -1)
            {
               --this.vagues.nbMonstres;
               if(this.vagues.monstresEnAttente.length > 0 && this.vagues.nbMonstresActifs < this.vagues.nbMonstresMax)
               {
                  this.creer_agresseur(this.vagues.monstresEnAttente.shift());
               }
               else
               {
                  --this.vagues.nbMonstresActifs;
               }
            }
            else if(param1.currentTarget is Artisan)
            {
               --this.villes[Artisan(param1.currentTarget).ville].nbVillageois;
            }
            else
            {
               --this.villes[param1.currentTarget.ville].nbMonstres;
               --this.villes[param1.currentTarget.ville].nbMonstresActifs;
               for each(_loc2_ in this.donjons)
               {
                  if(_loc2_.ville == param1.currentTarget.ville)
                  {
                     if(_loc2_.monstresEnAttente.length > 0 && _loc2_.compteurMonstres.nbMonstresActifs < _loc2_.compteurMonstres.nbMonstresMax)
                     {
                        this.creer_agresseur(_loc2_.monstresEnAttente.shift());
                        ++_loc2_.compteurMonstres.nbMonstresActifs;
                     }
                  }
               }
            }
         }
         if(param1.currentTarget is Soldat || param1.currentTarget is Serviteur)
         {
            _loc3_ = int(param1.currentTarget.equipe);
            _loc4_ = int(param1.currentTarget.ville);
            --this.villes[_loc3_].nbSoldats;
            --this.villes[_loc3_].nbSoldatsActifs;
            for each(_loc5_ in this.persos)
            {
               if(_loc5_ is BatimentCaserne && _loc5_.equipe == _loc3_)
               {
                  if(BatimentCaserne(_loc5_).garnison.length > 0 && this.villes[_loc3_].nbSoldatsActifs < this.villes[_loc3_].nbSoldatsMax)
                  {
                     --this.villes[_loc3_].nbSoldats;
                     if(this.persos[BatimentCaserne(_loc5_).garnison[0].maitre])
                     {
                        this.persos[BatimentCaserne(_loc5_).garnison[0].maitre].dispatchEvent(new CreationPersoEvent(CreationPersoEvent.CREER,BatimentCaserne(_loc5_).garnison[0].race,_loc5_.x,_loc5_.y,_loc4_,_loc3_,"",false));
                     }
                     else
                     {
                        _loc5_.dispatchEvent(new CreationPersoEvent(CreationPersoEvent.CREER,BatimentCaserne(_loc5_).garnison[0].race,_loc5_.x,_loc5_.y,_loc4_,_loc3_,"",false));
                     }
                     BatimentCaserne(_loc5_).garnison.shift();
                     dispatchEvent(new PersosEvent(PersosEvent.ACTUALISER_SOLDATS,_loc5_));
                     break;
                  }
               }
            }
         }
      }
      
      private function afficher_effet(param1:EffetEvent) : void
      {
         dispatchEvent(param1);
      }
      
      private function afficher_effet_arme(param1:EffetArmeEvent) : void
      {
         dispatchEvent(param1);
      }
      
      private function jouer_son(param1:SonEvent) : void
      {
         dispatchEvent(param1);
      }
      
      private function perso_creer_perso(param1:CreationPersoEvent) : void
      {
         var _loc3_:Point = null;
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         var _loc6_:Object = null;
         var _loc7_:String = null;
         var _loc8_:String = null;
         var _loc9_:Boolean = false;
         var _loc10_:int = 0;
         var _loc2_:Object = param1.currentTarget;
         if(Boolean(!(_loc2_ is Intermediaire || _loc2_ is Fondations)) && Boolean(Donnees.donnees[param1.creation].build) && Boolean(Donnees.donnees[param1.creation].build.prebuild) && !(_loc2_ is BatimentCentreVille))
         {
            if(param1.rechercheEmplacement)
            {
               _loc3_ = this.trouver_position_libre_construction(Perso(_loc2_),Donnees.donnees[param1.creation].width,Donnees.donnees[param1.creation].height,Donnees.donnees[param1.creation].type == "landRessource" || Donnees.donnees[param1.creation].type == "animal" ? 4 : -4);
               if(!_loc3_)
               {
                  if("parler" in _loc2_)
                  {
                     _loc2_.parler(Donnees.traduction.noSpace);
                  }
                  return;
               }
               _loc4_ = _loc3_.x;
               _loc5_ = _loc3_.y;
            }
            else if(MainJeu.bacASable && Donnees.donnees[param1.creation].type != "wall")
            {
               _loc4_ = param1.x;
               _loc5_ = param1.y;
            }
            else
            {
               if(!this.position_libre_contruction(Donnees.donnees[param1.creation].width,Donnees.donnees[param1.creation].height,param1.x,param1.y))
               {
                  if("parler" in _loc2_)
                  {
                     _loc2_.parler(Donnees.traduction.noSpace);
                  }
                  return;
               }
               _loc4_ = param1.x;
               _loc5_ = param1.y;
            }
            _loc6_ = Donnees.donnees[param1.creation].build.prebuild;
            this.creer_perso_temporaire(_loc6_.id,param1.creation,_loc6_.time,Donnees.donnees[param1.creation].build.bonusSkill ? Number(_loc2_.competences[Donnees.donnees[param1.creation].build.bonusSkill].coefBonus) : 1,_loc4_,_loc5_,_loc2_.ville,param1.equipe,_loc6_.anim ? _loc6_.anim : "",_loc2_);
            _loc2_.payer_cout_creation_perso(param1.creation);
            if(this.persos[Perso.prochaineId - 1] is Fondations)
            {
               this.persos[Perso.prochaineId - 1].ville = _loc2_.ville;
            }
         }
         else
         {
            if(_loc2_ is Animal)
            {
               _loc3_ = this.trouver_position_libre_construction(Perso(_loc2_),Donnees.donnees[param1.creation].width,Donnees.donnees[param1.creation].height);
               if(_loc3_)
               {
                  param1.x = _loc3_.x;
                  param1.y = _loc3_.y;
               }
            }
            _loc7_ = param1.creation;
            _loc8_ = Donnees.donnees[_loc7_].type;
            _loc9_ = _loc8_ == "monster" && (_loc2_ is Artisan || _loc2_ is Batiment);
            if(_loc9_)
            {
               ++this.villes[param1.equipe].nbSoldats;
            }
            if(Boolean(_loc2_ is Artisan && _loc2_.cibleTravail) && Boolean(_loc9_) && this.villes[param1.equipe].nbSoldatsActifs >= this.villes[param1.equipe].nbSoldatsMax)
            {
               _loc2_.cibleTravail.garnison.push({
                  "race":_loc7_,
                  "maitre":_loc2_.id
               });
               dispatchEvent(new PersosEvent(PersosEvent.ACTUALISER_SOLDATS,_loc2_.cibleTravail));
            }
            else
            {
               this.creer_perso(_loc7_,true,param1.x,param1.y,_loc2_.ville,param1.equipe,param1.anim,_loc9_);
               if(_loc9_)
               {
                  ++this.villes[param1.equipe].nbSoldatsActifs;
                  if(!(this.persos[Perso.prochaineId - 1] is Serviteur) && _loc2_ is Mobile)
                  {
                     this.persos[Perso.prochaineId - 1].init_maitre(_loc2_,this.combattants);
                  }
               }
               if(_loc8_ == "workshop" || _loc8_ == "barrack")
               {
                  if(!Donnees.donnees[this.persos[Perso.prochaineId - 1].race].title)
                  {
                     Fondations(_loc2_).createur.aller_travailler(this.persos[Perso.prochaineId - 1]);
                  }
                  else
                  {
                     _loc10_ = 0;
                     while(_loc10_ < this.joueur.length)
                     {
                        if(this.joueur[_loc10_].cibleTravail == _loc2_)
                        {
                           dispatchEvent(new PersosEvent2(PersosEvent2.CHOISIR_FABRICATION,this.persos[Perso.prochaineId - 1],_loc10_));
                        }
                        _loc10_++;
                     }
                  }
                  this.persos[Perso.prochaineId - 1].ajouter_bonus(param1.bonusCreation);
               }
               else if(_loc8_ == "animal")
               {
                  this.persos[Perso.prochaineId - 1].equipe = -1;
                  this.persos[Perso.prochaineId - 1].ajouter_bonus(param1.bonusCreation);
               }
               else if(_loc8_ == "landRessource")
               {
                  this.persos[Perso.prochaineId - 1].ajouter_bonus(param1.bonusCreation);
                  this.persos[Perso.prochaineId - 1].idCreateur = _loc2_.id;
               }
               else if(_loc8_ == "house")
               {
                  if(Fondations(_loc2_).createur is Artisan)
                  {
                     Fondations(_loc2_).createur.maison = this.persos[Perso.prochaineId - 1];
                     this.persos[Perso.prochaineId - 1].proprietaire = Fondations(_loc2_).createur.id;
                  }
               }
               else if(_loc8_ == "monster")
               {
                  if(!_loc9_)
                  {
                     if(param1.equipe == -1)
                     {
                        ++this.vagues.nbMonstres;
                        ++this.vagues.nbMonstresActifs;
                     }
                     else
                     {
                        ++this.villes[param1.equipe].nbMonstres;
                        ++this.villes[param1.equipe].nbMonstresActifs;
                     }
                  }
                  if(this.persos[Perso.prochaineId - 1] is Guerisseur)
                  {
                     this.persos[Perso.prochaineId - 1].ajouter_bonus(param1.bonusCreation);
                  }
                  if(_loc2_ is Mobile && _loc2_.orientation != 0 && this.persos[Perso.prochaineId - 1] is Soldat)
                  {
                     this.persos[Perso.prochaineId - 1].orientation = _loc2_.orientation;
                     this.persos[Perso.prochaineId - 1].dispatchEvent(new PersosEvent(PersosEvent.ORIENTER));
                  }
               }
               else if(_loc8_ == "townCenter" && _loc2_ is BatimentCentreVille)
               {
                  if(this.villes[param1.equipe].pasDerniereEpoque)
                  {
                     this.persos[Perso.prochaineId - 1].vie.scoreMax = _loc2_.vie.scoreMax;
                     this.persos[Perso.prochaineId - 1].vie.score = _loc2_.vie.score;
                  }
                  else
                  {
                     this.persos[Perso.prochaineId - 1].vie.score = _loc2_.vie.score + this.persos[Perso.prochaineId - 1].vie.scoreMax - Donnees.donnees[_loc2_.race].health;
                  }
                  if(this.persos[Perso.prochaineId - 1].vie.score < this.persos[Perso.prochaineId - 1].vie.scoreMax)
                  {
                     this.persos[Perso.prochaineId - 1].dispatchEvent(new PersosEvent(PersosEvent.ACTUALISER_VIE));
                  }
                  this.persos[Perso.prochaineId - 1].copier_ressources(_loc2_);
               }
               if(_loc2_ is Fondations)
               {
                  if(_loc2_.createur is Artisan && _loc2_.createur.iaConstruireBatiment == _loc7_)
                  {
                     _loc2_.createur.iaConstruireBatiment = "";
                  }
                  this.persos[Perso.prochaineId - 1].charger_vie(Fondations(_loc2_).vie.score);
               }
            }
         }
      }
      
      public function perso_detruire_perso(param1:Object, param2:int) : void
      {
         var _loc3_:Mur = null;
         if(Boolean(param2 > 0) && Boolean(this.persos[param2]) && param1.equipe == this.persos[param2].equipe)
         {
            Tresor.piller_batiment(this.persos[param2]);
            this.persos[param2].mourir();
         }
         else if(!param1.detruire_batiment())
         {
            _loc3_ = IA.trouver_mur_proche_allie(param1);
            if(_loc3_)
            {
               Tresor.piller_batiment(_loc3_);
               _loc3_.mourir();
            }
         }
      }
      
      private function trouver_position_libre_construction_illimite(param1:Perso, param2:int, param3:int, param4:int = 4) : Point
      {
         return this.trouver_position_libre_construction2(param1,param2,param3,32,(Terrain.largeur + Terrain.hauteur) / 8,param4);
      }
      
      private function trouver_position_libre_construction(param1:Perso, param2:int, param3:int, param4:int = 4) : Point
      {
         var _loc5_:int = param1 is Joueur ? 4 : 32;
         var _loc6_:int = param1 is Joueur ? 1024 : 128;
         return this.trouver_position_libre_construction2(param1,param2,param3,_loc5_,_loc6_,param4);
      }
      
      private function trouver_position_libre_construction2(param1:Perso, param2:int, param3:int, param4:int, param5:int, param6:int = 0) : Point
      {
         var _loc10_:int = 0;
         var _loc11_:int = 0;
         var _loc12_:int = 0;
         var _loc13_:int = 0;
         var _loc14_:int = 0;
         var _loc7_:Number = param1.x;
         var _loc8_:Number = param1.y + param6;
         var _loc9_:Number = param1.rayon;
         if(this.position_libre_contruction(param2,param3,_loc7_,_loc8_))
         {
            return new Point(_loc7_,_loc8_);
         }
         _loc10_ = 0;
         _loc11_ = 0;
         _loc12_ = 0;
         switch(int(Math.random() * 4))
         {
            case 0:
               _loc14_ = 0;
               _loc13_ = param4;
               break;
            case 1:
               _loc14_ = param4;
               _loc13_ = 0;
               break;
            case 2:
               _loc14_ = 0;
               _loc13_ = -param4;
               break;
            case 3:
               _loc14_ = -param4;
               _loc13_ = 0;
         }
         continue loop0;
      }
      
      public function position_libre_contruction(param1:int, param2:int, param3:int, param4:int) : Boolean
      {
         var _loc5_:Perso = null;
         if(!Terrain.emplacement_constructible(param3,param4,param1,param2))
         {
            return false;
         }
         for each(_loc5_ in this.persos)
         {
            if(_loc5_ is RessourceTerrain || _loc5_ is Batiment || _loc5_ is BatimentMobile || _loc5_ is Intermediaire || _loc5_ is Fondations)
            {
               if(param3 + param1 * 0.5 + _loc5_.largeur * 0.5 >= _loc5_.x && param3 <= _loc5_.x + param1 * 0.5 + _loc5_.largeur * 0.5 && param4 + _loc5_.hauteur >= _loc5_.y && param4 <= _loc5_.y + param2)
               {
                  return false;
               }
            }
         }
         return true;
      }
      
      public function nombre_persos(param1:String) : int
      {
         var _loc2_:int = 0;
         var _loc3_:Object = null;
         for each(_loc3_ in this.persos)
         {
            if(_loc3_.race == param1)
            {
               if(_loc3_ is Vivant)
               {
                  if(_loc3_.vivant)
                  {
                     _loc2_++;
                  }
               }
               else if(_loc3_.visible)
               {
                  _loc2_++;
               }
            }
         }
         return _loc2_;
      }
      
      private function perso_creer_projectile(param1:ProjectileEvent) : void
      {
         var _loc2_:Object = null;
         var _loc4_:Number = NaN;
         var _loc3_:Object = param1.lanceur;
         if(Boolean(param1.special) && Boolean(param1.special.selfGuided))
         {
            _loc2_ = new ProjectileAutoguide();
            this.creer_perso2(_loc2_,param1.projectile,param1.x,param1.y,param1.delai ? "pop" : "",param1.decalageY);
            _loc2_.addEventListener(PersosEvent.ROTATION,this.rotation_perso);
            _loc2_.addEventListener(PersosEvent.DEPLACER,this.deplacer_perso);
            _loc2_.lanceur = _loc3_;
            _loc2_.equipe = _loc3_.equipe;
            _loc2_.noAttaque = param1.no;
            _loc2_.copier_degats(param1.degats);
            _loc2_.transperce = param1.special.pierce;
            _loc2_.animFin = param1.special.endingAnim;
            _loc2_.penalite = param1.special.penality;
            _loc2_.special = param1.special;
            _loc2_.lancer(_loc3_.cibleCombat,param1.attaque,param1.portee,param1.special.fixedAngle ? param1.special.fixedAngle : param1.special.angle + Math.atan2(_loc3_.cibleCombat.y - _loc3_.cibleCombat.hauteur * 0.5 - param1.y,_loc3_.cibleCombat.x - param1.x),param1.special.selfGuided,param1.delai);
         }
         else
         {
            if(Boolean(param1.special) && Boolean(param1.special.back))
            {
               _loc2_ = new ProjectileRetour(param1.special.back);
            }
            else
            {
               _loc2_ = new Projectile();
            }
            this.creer_perso2(_loc2_,param1.projectile,param1.x,param1.y,param1.delai ? "pop" : "",param1.decalageY);
            _loc2_.addEventListener(PersosEvent.ROTATION,this.rotation_perso);
            _loc2_.addEventListener(PersosEvent.DEPLACER,this.deplacer_perso);
            _loc2_.lanceur = _loc3_;
            _loc2_.equipe = _loc3_.equipe;
            _loc2_.noAttaque = param1.no;
            _loc2_.copier_degats(param1.degats);
            if(param1.special)
            {
               _loc2_.transperce = param1.special.pierce || param1.special.special && param1.special.special.pierce;
               _loc2_.animFin = param1.special.endingAnim;
               _loc2_.penalite = param1.special.penality;
               _loc2_.special = param1.special;
            }
            _loc4_ = 0;
            if(param1.special)
            {
               if(param1.special.angle)
               {
                  _loc4_ = Number(param1.special.angle);
               }
               else if(param1.special.angleRND)
               {
                  _loc4_ = (Math.random() - 0.5) * param1.special.angleRND;
               }
            }
            _loc2_.aller(_loc3_.cibleCombat,param1.attaque,param1.portee,_loc4_,param1.delai);
         }
      }
      
      private function creer_tresor(param1:TresorEvent) : void
      {
         var _loc2_:Tresor = new Tresor();
         this.creer_perso2(_loc2_,param1.creation,IA.verifier_destinationX(param1.x),IA.verifier_destinationY(param1.y),"loot");
         _loc2_.quantite = param1.quantite;
         _loc2_.renforce = param1.renforce;
         this.tresors.push(_loc2_);
      }
      
      public function ajouter_vague(param1:VaguesCreerPersoEvent) : void
      {
         var _loc3_:VaguesCreerPerso = null;
         var _loc4_:Object = null;
         var _loc5_:Object = null;
         var _loc2_:Vector.<VaguesCreerPerso> = param1.vaguesCreerPerso;
         if(_loc2_.length)
         {
            for each(_loc3_ in _loc2_)
            {
               this.creer_agresseur(_loc3_);
            }
            if(param1.currentTarget is Vagues)
            {
               switch(param1.currentTarget.origine)
               {
                  case 1:
                     dispatchEvent(new MessageEvent(MessageEvent.MESSAGE_ALERTE,Donnees.traduction.waveComingUp));
                     break;
                  case 2:
                     dispatchEvent(new MessageEvent(MessageEvent.MESSAGE_ALERTE,Donnees.traduction.waveComingDown));
                     break;
                  case 3:
                     dispatchEvent(new MessageEvent(MessageEvent.MESSAGE_ALERTE,Donnees.traduction.waveComingLeft));
                     break;
                  case 4:
                     dispatchEvent(new MessageEvent(MessageEvent.MESSAGE_ALERTE,Donnees.traduction.waveComingRight));
               }
            }
            this.actualiser_nbMonstres();
         }
         else if(param1.currentTarget is BatimentDonjon)
         {
            for each(_loc5_ in this.combattants)
            {
               if(Boolean(_loc5_ is Combattant && !_loc5_.enCombat && _loc5_.equipe == param1.currentTarget.equipe) && Boolean(_loc5_.vivant) && Boolean(_loc5_.ia) && !(_loc5_ is Artisan))
               {
                  if(!_loc4_)
                  {
                     _loc4_ = IA.trouver_ennemi_proche(_loc5_);
                  }
                  if(!_loc4_)
                  {
                     break;
                  }
                  _loc5_.aller(_loc4_.x,_loc4_.y);
               }
            }
         }
      }
      
      private function creer_agresseur(param1:VaguesCreerPerso) : void
      {
         var _loc2_:Object = null;
         if(Donnees.donnees[param1.race].attacks)
         {
            _loc2_ = new CombattantAvance();
         }
         else
         {
            _loc2_ = new Combattant();
         }
         _loc2_.ia = true;
         _loc2_.equipe = param1.equipe;
         _loc2_.ville = param1.ville;
         this.creer_perso2(_loc2_,param1.race,param1.x,param1.y);
         if(param1.equipe >= 0)
         {
            _loc2_.puissance = this.villes[param1.equipe].puissance;
         }
         else
         {
            _loc2_.puissance = this.vagues.puissance;
         }
         _loc2_.addEventListener(PersosEvent.DEPLACER,this.gerer_collisions);
         this.persosCollisions[_loc2_.id] = _loc2_;
         _loc2_.aller(param1.destinationX,param1.destinationY);
      }
      
      public function fantome_perso(param1:PersosEvent) : void
      {
         dispatchEvent(new PersosEvent(PersosEvent.FANTOME,param1.currentTarget));
         if(param1.currentTarget.fantome)
         {
            --this.villes[param1.currentTarget.ville].nbVillageois;
         }
         else
         {
            ++this.villes[param1.currentTarget.ville].nbVillageois;
         }
      }
      
      public function visible_perso(param1:PersosEvent) : void
      {
         dispatchEvent(new PersosEvent(PersosEvent.VISIBLE,param1.currentTarget));
      }
      
      private function roi_perso(param1:PersosEvent) : void
      {
         this.villes[param1.currentTarget.ville].roi = param1.currentTarget;
         param1.currentTarget.addEventListener(PersosEvent.ROI_FIN,this.roi_fin_perso);
         dispatchEvent(new PersosEvent(PersosEvent.ROI_AUTRE,param1.currentTarget));
      }
      
      private function roi_fin_perso(param1:PersosEvent) : void
      {
         param1.currentTarget.removeEventListener(PersosEvent.ROI_FIN,this.roi_fin_perso);
         this.villes[param1.currentTarget.ville].roi = null;
         dispatchEvent(new PersosEvent(PersosEvent.ROI_FIN,param1.currentTarget));
      }
      
      public function apparence_perso(param1:PersosEvent) : void
      {
         dispatchEvent(new PersosEvent(PersosEvent.ACTUALISER_APPARENCE,param1.currentTarget));
      }
      
      public function couleur_perso(param1:PersosEvent) : void
      {
         dispatchEvent(new PersosEvent(PersosEvent.ACTUALISER_COULEUR,param1.currentTarget));
      }
      
      public function monture_perso(param1:PersosEvent) : void
      {
         dispatchEvent(new PersosEvent(PersosEvent.ACTUALISER_MONTURE,param1.currentTarget));
      }
      
      public function animer_perso(param1:AnimationEvent) : void
      {
         dispatchEvent(new AnimationEvent(AnimationEvent.ANIMER,param1.animation,param1.currentTarget.id));
      }
      
      public function effacer_perso(param1:PersosEvent) : void
      {
         dispatchEvent(new PersosEvent(PersosEvent.EFFACER,param1.currentTarget));
      }
      
      private function actualiser_epoque(param1:EpoqueEvent) : void
      {
         var _loc5_:Object = null;
         var _loc6_:BatimentDonjon = null;
         var _loc7_:Vector.<BatimentCentreVille> = null;
         var _loc8_:BatimentCentreVille = null;
         var _loc2_:Ville = Ville(param1.currentTarget);
         var _loc3_:int = _loc2_.no;
         var _loc4_:int = _loc2_.epoqueActuelle;
         for each(_loc5_ in this.combattants)
         {
            if(_loc5_ is Artisan && _loc5_.ville == _loc3_)
            {
               Artisan(_loc5_).epoque = _loc4_;
               Artisan(_loc5_).iaConstruireBatiment = "";
               Artisan(_loc5_).iaConstruireSoldat = "";
               Artisan(_loc5_).iaConstruireObjet = "";
               Artisan(_loc5_).iaEquipementAuMax = false;
               IA.recycler_equipement(Artisan(_loc5_));
            }
         }
         for each(_loc6_ in this.donjons)
         {
            if(_loc6_.ville == _loc3_)
            {
               _loc6_.epoque = _loc4_;
            }
         }
         if(param1.actualiserCentreVille)
         {
            _loc7_ = new Vector.<BatimentCentreVille>();
            for each(_loc8_ in this.centresVille)
            {
               if(_loc8_.ville == _loc3_)
               {
                  _loc7_.push(_loc8_);
               }
            }
            for each(_loc8_ in _loc7_)
            {
               _loc8_.passer_epoque_suivante(_loc2_.pasDerniereEpoque);
            }
         }
      }
      
      private function actualiser_epoques() : void
      {
         var _loc1_:Object = null;
         var _loc2_:BatimentDonjon = null;
         for each(_loc1_ in this.combattants)
         {
            if(_loc1_ is Artisan)
            {
               Artisan(_loc1_).epoque = this.villes[Artisan(_loc1_).ville].epoqueActuelle;
            }
         }
         for each(_loc2_ in this.donjons)
         {
            _loc2_.epoque = this.villes[_loc2_.ville].epoqueActuelle;
         }
      }
      
      public function actualiser_nbTout() : void
      {
         this.actualiser_nbVillageois();
         this.actualiser_nbVillageoisMax();
         this.actualiser_nbSoldats();
         this.actualiser_nbSoldatsMax();
         this.actualiser_nbMonstres();
         var _loc1_:int = 0;
         while(_loc1_ < this.villes.length)
         {
            this.villes[_loc1_].addEventListener(VaguesActualiserEvent.ACTUALISER_NB_VILLAGEOIS,this.actualiser_nbVillageois);
            this.villes[_loc1_].addEventListener(VaguesActualiserEvent.ACTUALISER_NB_VILLAGEOIS_MAX,this.actualiser_nbVillageoisMax);
            this.villes[_loc1_].addEventListener(VaguesActualiserEvent.ACTUALISER_NB_SOLDATS,this.actualiser_nbSoldats);
            this.villes[_loc1_].addEventListener(VaguesActualiserEvent.ACTUALISER_NB_MONSTRES,this.actualiser_nbMonstres);
            _loc1_++;
         }
      }
      
      public function actualiser_nbMonstresMax(param1:int) : void
      {
         var _loc2_:int = 0;
         var _loc3_:BatimentDonjon = null;
         var _loc4_:BatimentDonjon = null;
         this.vagues.nbMonstresMax = param1;
         for each(_loc3_ in this.donjons)
         {
            _loc2_++;
         }
         for each(_loc4_ in this.donjons)
         {
            _loc4_.compteurMonstres.nbMonstresMax = param1 / _loc2_;
         }
      }
      
      public function actualiser_nbVillageois(param1:* = null) : void
      {
         dispatchEvent(new VaguesActualiserEvent(VaguesActualiserEvent.ACTUALISER_NB_VILLAGEOIS));
         dispatchEvent(new VaguesActualiserEvent(VaguesActualiserEvent.ACTUALISER_NB_MONSTRES));
      }
      
      public function actualiser_nbVillageoisMax(param1:* = null) : void
      {
         dispatchEvent(new VaguesActualiserEvent(VaguesActualiserEvent.ACTUALISER_NB_VILLAGEOIS_MAX));
      }
      
      public function actualiser_nbMonstres(param1:* = null) : void
      {
         dispatchEvent(new VaguesActualiserEvent(VaguesActualiserEvent.ACTUALISER_NB_MONSTRES));
      }
      
      public function actualiser_nbSoldats(param1:* = null) : void
      {
         dispatchEvent(new VaguesActualiserEvent(VaguesActualiserEvent.ACTUALISER_NB_SOLDATS));
      }
      
      public function actualiser_nbSoldatsMax(param1:* = null) : void
      {
         dispatchEvent(new VaguesActualiserEvent(VaguesActualiserEvent.ACTUALISER_NB_SOLDATS_MAX));
      }
      
      public function nbMonstres(param1:int) : int
      {
         var _loc2_:int = 0;
         var _loc3_:int = 0;
         while(_loc3_ < this.villes.length)
         {
            if(this.villes[_loc3_].equipe != param1)
            {
               _loc2_ += this.villes[_loc3_].nbVillageois;
               _loc2_ += this.villes[_loc3_].nbMonstres;
            }
            _loc3_++;
         }
         return _loc2_;
      }
      
      public function pause() : void
      {
         var _loc1_:Object = null;
         var _loc2_:Ville = null;
         enPause = true;
         for each(_loc1_ in this.persos)
         {
            _loc1_.pause();
         }
         for each(_loc2_ in this.villes)
         {
            _loc2_.pause();
         }
      }
      
      public function reprendre() : void
      {
         var _loc1_:Object = null;
         var _loc2_:Ville = null;
         enPause = false;
         for each(_loc1_ in this.persos)
         {
            _loc1_.reprendre();
         }
         for each(_loc2_ in this.villes)
         {
            _loc2_.reprendre();
         }
      }
      
      public function pause_ia() : void
      {
         var _loc1_:Object = null;
         for each(_loc1_ in this.persos)
         {
            if((_loc1_ is Artisan || _loc1_ is Soldat || _loc1_ is Combattant) && _loc1_ != this.joueur[0])
            {
               _loc1_.arreter();
               _loc1_.ia = false;
               if(_loc1_.iaTimer)
               {
                  _loc1_.arreter_ia();
               }
            }
         }
         this.iaActifs = false;
      }
      
      public function reprendre_ia() : void
      {
         var _loc1_:Object = null;
         for each(_loc1_ in this.persos)
         {
            if((_loc1_ is Artisan || _loc1_ is Soldat || _loc1_ is Combattant) && _loc1_ != this.joueur[0])
            {
               _loc1_.ia = true;
               _loc1_.init_ia(true);
            }
         }
         this.iaActifs = true;
      }
      
      public function charger_villes(param1:Object) : void
      {
         var _loc2_:Object = null;
         this.villes = new Vector.<Ville>();
         for each(_loc2_ in param1)
         {
            if(_loc2_.faction == null)
            {
               _loc2_.faction = 0;
            }
            else if(_loc2_.faction == -1)
            {
               _loc2_.faction = int(Donnees.peuples.length * Math.random());
            }
            else if(_loc2_.faction == -2)
            {
               _loc2_.faction = 0;
               _loc2_.characters = 0;
            }
            if(Boolean(_loc2_.x) && Boolean(_loc2_.y))
            {
               this.villes.push(new Ville(this.villes.length,_loc2_,_loc2_.x * Terrain.largeurCase,_loc2_.y * Terrain.hauteurCase));
            }
            else
            {
               this.villes.push(new Ville(this.villes.length,_loc2_,Terrain.largeur * 0.5,Terrain.hauteur * 0.5));
            }
            this.villes[this.villes.length - 1].addEventListener(EpoqueEvent.ACTUALISER_NO_EPOQUE,this.actualiser_epoque);
         }
      }
      
      public function charger_persos(param1:ByteArray, param2:Object, param3:Array, param4:Object) : void
      {
         var _loc5_:String = null;
         var _loc6_:int = 0;
         var _loc7_:int = 0;
         var _loc8_:int = 0;
         var _loc9_:int = 0;
         var _loc10_:String = null;
         var _loc11_:Boolean = false;
         var _loc12_:Number = NaN;
         var _loc13_:Number = NaN;
         var _loc14_:int = 0;
         var _loc15_:int = 0;
         var _loc16_:int = 0;
         var _loc17_:int = 0;
         var _loc18_:Boolean = false;
         var _loc19_:int = 0;
         var _loc20_:Object = null;
         var _loc21_:String = null;
         var _loc22_:int = 0;
         var _loc23_:int = 0;
         _loc8_ = param1.readInt();
         _loc6_ = 0;
         for(; _loc6_ < _loc8_; _loc6_++)
         {
            _loc5_ = param1.readUTF();
            _loc10_ = param1.readUTF();
            _loc11_ = param1.readBoolean();
            _loc12_ = param1.readDouble();
            _loc13_ = param1.readDouble();
            switch(_loc5_)
            {
               case "folk":
                  _loc14_ = param1.readInt();
                  _loc15_ = param1.readInt();
                  _loc16_ = param1.readInt();
                  _loc17_ = param1.readInt();
                  _loc18_ = param1.readBoolean();
                  if(_loc6_ < param2.length && _loc15_ == 0)
                  {
                     this.creer_joueur(param2[_loc6_],_loc12_,_loc13_,_loc15_,_loc14_);
                     _loc23_++;
                  }
                  else
                  {
                     this.creer_perso(_loc10_,_loc18_,_loc12_,_loc13_,_loc15_,_loc14_);
                     this.persos[Perso.prochaineId - 1].puissance = this.villes[_loc14_].puissance;
                  }
                  this.persos[Perso.prochaineId - 1].ville = _loc15_;
                  if(_loc17_ != 0)
                  {
                     this.persos[Perso.prochaineId - 1].orientation = _loc17_;
                     this.persos[Perso.prochaineId - 1].dispatchEvent(new PersosEvent(PersosEvent.ORIENTER));
                  }
                  this.persos[Perso.prochaineId - 1].gerer_deplacement_terrain();
                  if(_loc6_ >= param2.length)
                  {
                     this.persos[Perso.prochaineId - 1].charger_apparence(param1.readObject());
                  }
                  else
                  {
                     param1.readObject();
                  }
                  _loc9_ = param1.readInt();
                  _loc7_ = 0;
                  while(_loc7_ < _loc9_)
                  {
                     this.persos[Perso.prochaineId - 1].caracteristiquesPrimaires[param1.readUTF()].coef = param1.readDouble();
                     _loc7_++;
                  }
                  _loc9_ = param1.readInt();
                  _loc7_ = 0;
                  while(_loc7_ < _loc9_)
                  {
                     this.persos[Perso.prochaineId - 1].ressources[param1.readUTF()].quantite = param1.readInt();
                     _loc7_++;
                  }
                  _loc9_ = param1.readInt();
                  _loc7_ = 0;
                  while(_loc7_ < _loc9_)
                  {
                     switch(param1.readInt())
                     {
                        case 0:
                           _loc21_ = param1.readUTF();
                           if(!Donnees.donnees[_loc21_] || !Donnees.donnees[_loc21_].perk)
                           {
                              this.persos[Perso.prochaineId - 1].ajouter_objet2(_loc21_,param1.readInt());
                              this.persos[Perso.prochaineId - 1].objets[this.persos[Perso.prochaineId - 1].objets.length - 1].renforcer = param1.readInt();
                           }
                           else
                           {
                              param1.readInt();
                              param1.readInt();
                           }
                           break;
                        case 1:
                           _loc21_ = param1.readUTF();
                           if(!Donnees.donnees[_loc21_] || !Donnees.donnees[_loc21_].perk)
                           {
                              this.persos[Perso.prochaineId - 1].ajouter_objet2(_loc21_,param1.readInt());
                              this.persos[Perso.prochaineId - 1].objets[this.persos[Perso.prochaineId - 1].objets.length - 1].equipe = param1.readBoolean();
                              this.persos[Perso.prochaineId - 1].objets[this.persos[Perso.prochaineId - 1].objets.length - 1].gauche = param1.readBoolean();
                              this.persos[Perso.prochaineId - 1].objets[this.persos[Perso.prochaineId - 1].objets.length - 1].renforcer = param1.readInt();
                           }
                           else
                           {
                              param1.readInt();
                              param1.readBoolean();
                              param1.readBoolean();
                              param1.readInt();
                           }
                           break;
                        case 2:
                           _loc21_ = param1.readUTF();
                           if(!Donnees.donnees[_loc21_] || !Donnees.donnees[_loc21_].perk)
                           {
                              this.persos[Perso.prochaineId - 1].gagner_objet_temporaire(_loc21_,param1.readInt());
                              this.persos[Perso.prochaineId - 1].objets[this.persos[Perso.prochaineId - 1].objets.length - 1].equipe = param1.readBoolean();
                              this.persos[Perso.prochaineId - 1].objets[this.persos[Perso.prochaineId - 1].objets.length - 1].gauche = param1.readBoolean();
                              this.persos[Perso.prochaineId - 1].objets[this.persos[Perso.prochaineId - 1].objets.length - 1].renforcer = param1.readInt();
                           }
                           else
                           {
                              param1.readInt();
                              param1.readBoolean();
                              param1.readBoolean();
                              param1.readInt();
                           }
                     }
                     _loc7_++;
                  }
                  this.persos[Perso.prochaineId - 1].actualiser_bonus();
                  break;
               case "mons":
                  _loc14_ = param1.readInt();
                  _loc15_ = param1.readInt();
                  _loc16_ = param1.readInt();
                  _loc17_ = param1.readInt();
                  _loc18_ = param1.readBoolean();
                  this.creer_perso(_loc10_,_loc18_,_loc12_,_loc13_,_loc15_,_loc14_);
                  if(_loc14_ >= 0)
                  {
                     this.persos[Perso.prochaineId - 1].puissance = this.villes[_loc14_].puissance;
                  }
                  if(_loc17_ != 0)
                  {
                     this.persos[Perso.prochaineId - 1].orientation = _loc17_;
                     this.persos[Perso.prochaineId - 1].dispatchEvent(new PersosEvent(PersosEvent.ORIENTER));
                  }
                  this.persos[Perso.prochaineId - 1].gerer_deplacement_terrain();
                  this.persos[Perso.prochaineId - 1].charger_vie(_loc16_);
                  break;
               case "sold":
               case "heal":
                  _loc14_ = param1.readInt();
                  _loc15_ = param1.readInt();
                  _loc16_ = param1.readInt();
                  _loc17_ = param1.readInt();
                  _loc18_ = param1.readBoolean();
                  this.creer_perso(_loc10_,_loc18_,_loc12_,_loc13_,_loc15_,_loc14_,"",true);
                  if(_loc14_ >= 0)
                  {
                     this.persos[Perso.prochaineId - 1].puissance = this.villes[_loc14_].puissance;
                  }
                  if(_loc17_ != 0)
                  {
                     this.persos[Perso.prochaineId - 1].orientation = _loc17_;
                     this.persos[Perso.prochaineId - 1].dispatchEvent(new PersosEvent(PersosEvent.ORIENTER));
                  }
                  this.persos[Perso.prochaineId - 1].gerer_deplacement_terrain();
                  this.persos[Perso.prochaineId - 1].ordre = param1.readInt();
                  this.persos[Perso.prochaineId - 1].origineX = param1.readInt();
                  this.persos[Perso.prochaineId - 1].origineY = param1.readInt();
                  this.persos[Perso.prochaineId - 1].origineOrientation = param1.readInt();
                  this.persos[Perso.prochaineId - 1].revenirPositionOrigine = param1.readBoolean();
                  _loc22_ = param1.readInt();
                  if(this.persos[_loc22_])
                  {
                     this.persos[Perso.prochaineId - 1].maitre = this.persos[_loc22_];
                  }
                  this.persos[Perso.prochaineId - 1].maitreDecalageX = param1.readInt();
                  this.persos[Perso.prochaineId - 1].maitreDecalageY = param1.readInt();
                  if(_loc5_ == "heal")
                  {
                     this.persos[Perso.prochaineId - 1].scoreGuerison = param1.readInt();
                  }
                  this.persos[Perso.prochaineId - 1].charger_vie(_loc16_);
                  break;
               case "ress":
                  this.creer_perso(_loc10_,true,_loc12_,_loc13_,0,0);
                  this.persos[Perso.prochaineId - 1].quantite = param1.readInt();
                  if(this.persos[Perso.prochaineId - 1])
                  {
                     this.persos[Perso.prochaineId - 1].quantiteMax = param1.readInt();
                     break;
                  }
                  param1.readInt();
                  break;
               case "resm":
                  _loc14_ = param1.readInt();
                  _loc15_ = param1.readInt();
                  _loc16_ = param1.readInt();
                  _loc17_ = param1.readInt();
                  _loc18_ = param1.readBoolean();
                  this.creer_perso(_loc10_,true,_loc12_,_loc13_,_loc15_,_loc14_);
                  this.persos[Perso.prochaineId - 1].quantite = param1.readInt();
                  if(this.persos[Perso.prochaineId - 1])
                  {
                     this.persos[Perso.prochaineId - 1].quantiteMax = param1.readInt();
                     if(_loc17_ != 0)
                     {
                        this.persos[Perso.prochaineId - 1].orientation = _loc17_;
                        this.persos[Perso.prochaineId - 1].dispatchEvent(new PersosEvent(PersosEvent.ORIENTER));
                     }
                     this.persos[Perso.prochaineId - 1].gerer_deplacement_terrain();
                     this.persos[Perso.prochaineId - 1].charger_vie(_loc16_);
                     break;
                  }
                  param1.readInt();
                  break;
               case "anim":
                  _loc14_ = param1.readInt();
                  _loc15_ = param1.readInt();
                  _loc16_ = param1.readInt();
                  _loc17_ = param1.readInt();
                  _loc18_ = param1.readBoolean();
                  this.creer_perso(_loc10_,true,_loc12_,_loc13_,_loc15_,_loc14_);
                  this.persos[Perso.prochaineId - 1].ajouter_bonus(param1.readDouble());
                  if(_loc17_ != 0)
                  {
                     this.persos[Perso.prochaineId - 1].orientation = _loc17_;
                     this.persos[Perso.prochaineId - 1].dispatchEvent(new PersosEvent(PersosEvent.ORIENTER));
                  }
                  this.persos[Perso.prochaineId - 1].gerer_deplacement_terrain();
                  this.persos[Perso.prochaineId - 1].charger_vie(_loc16_);
                  break;
               case "fond":
                  _loc14_ = param1.readInt();
                  _loc15_ = param1.readInt();
                  _loc16_ = param1.readInt();
                  this.creer_perso_temporaire(_loc10_,param1.readUTF(),param1.readDouble(),param1.readDouble(),_loc12_,_loc13_,_loc15_,_loc14_,param1.readUTF(),this.persos[param1.readInt()],false);
                  this.persos[Perso.prochaineId - 1].construire(param1.readInt(),0);
                  this.persos[Perso.prochaineId - 1].ville = _loc15_;
                  this.persos[Perso.prochaineId - 1].charger_vie(_loc16_);
                  break;
               case "work":
               case "hous":
               case "barr":
               case "town":
                  _loc14_ = param1.readInt();
                  _loc15_ = param1.readInt();
                  _loc16_ = param1.readInt();
                  this.creer_perso(_loc10_,true,_loc12_,_loc13_,_loc15_,_loc14_);
                  if(this.persos[Perso.prochaineId - 1])
                  {
                     this.persos[Perso.prochaineId - 1]._quantite = param1.readInt();
                     this.persos[Perso.prochaineId - 1].quantiteMax = param1.readInt();
                     this.persos[Perso.prochaineId - 1].charger_vie(_loc16_);
                  }
                  else
                  {
                     param1.readInt();
                     param1.readInt();
                  }
                  _loc9_ = param1.readInt();
                  _loc7_ = 0;
                  while(_loc7_ < _loc9_)
                  {
                     this.persos[Perso.prochaineId - 1].etapes[param1.readUTF()] = param1.readInt();
                     _loc7_++;
                  }
                  if(_loc5_ != "work")
                  {
                     _loc9_ = param1.readInt();
                     _loc7_ = 0;
                     while(_loc7_ < _loc9_)
                     {
                        this.persos[Perso.prochaineId - 1].garnison.push({
                           "race":param1.readUTF(),
                           "maitre":param1.readInt()
                        });
                        this.villes[_loc15_].nbSoldats += this.persos[Perso.prochaineId - 1].garnison.length;
                        _loc7_++;
                     }
                     if(_loc5_ == "hous")
                     {
                        _loc19_ = param1.readInt();
                        if(Boolean(this.persos[_loc19_]) && this.persos[_loc19_] is Artisan)
                        {
                           this.persos[_loc19_].maison = this.persos[Perso.prochaineId - 1];
                           this.persos[Perso.prochaineId - 1].proprietaire = _loc19_;
                        }
                        break;
                     }
                     if(_loc5_ == "town")
                     {
                        this.persos[Perso.prochaineId - 1].creation = param1.readUTF();
                        this.persos[Perso.prochaineId - 1].travailDuree = param1.readDouble();
                        if(param1.readBoolean())
                        {
                           this.persos[Perso.prochaineId - 1].passer_epoque_suivante(true);
                           this.persos[Perso.prochaineId - 1].construire(param1.readInt(),0);
                        }
                        else
                        {
                           param1.readInt();
                        }
                        _loc9_ = param1.readInt();
                        _loc7_ = 0;
                        while(_loc7_ < _loc9_)
                        {
                           this.persos[Perso.prochaineId - 1].ressources[param1.readUTF()].quantite = param1.readInt();
                           _loc7_++;
                        }
                     }
                  }
                  break;
               case "towe":
               case "dung":
                  _loc14_ = param1.readInt();
                  _loc15_ = param1.readInt();
                  _loc16_ = param1.readInt();
                  this.creer_perso(_loc10_,true,_loc12_,_loc13_,_loc15_,_loc14_);
                  if(this.persos[Perso.prochaineId - 1] is BatimentDonjon)
                  {
                     BatimentDonjon(this.persos[Perso.prochaineId - 1]).init_races(this.villes[_loc15_].peuple);
                  }
                  this.persos[Perso.prochaineId - 1].puissance = this.villes[_loc14_].puissance;
                  this.persos[Perso.prochaineId - 1].charger_vie(_loc16_);
                  if(_loc5_ == "dung")
                  {
                     this.persos[Perso.prochaineId - 1].nbMonstresParVagues = param1.readInt();
                  }
                  if(this.persos[Perso.prochaineId - 1] is BatimentRotatif)
                  {
                     this.persos[Perso.prochaineId - 1].rotation = param1.readInt();
                     this.persos[Perso.prochaineId - 1].dispatchEvent(new PersosEvent(PersosEvent.ROTATION));
                  }
                  break;
               case "gole":
                  _loc14_ = param1.readInt();
                  _loc15_ = param1.readInt();
                  _loc16_ = param1.readInt();
                  _loc17_ = param1.readInt();
                  _loc18_ = param1.readBoolean();
                  this.creer_perso(_loc10_,true,_loc12_,_loc13_,_loc15_,_loc14_);
                  this.persos[Perso.prochaineId - 1].ordre = param1.readInt();
                  this.persos[Perso.prochaineId - 1].revenirPositionOrigine = param1.readBoolean();
                  if(_loc17_ != 0)
                  {
                     this.persos[Perso.prochaineId - 1].orientation = _loc17_;
                     this.persos[Perso.prochaineId - 1].dispatchEvent(new PersosEvent(PersosEvent.ORIENTER));
                  }
                  this.persos[Perso.prochaineId - 1].gerer_deplacement_terrain();
                  this.persos[Perso.prochaineId - 1].charger_vie(_loc16_);
                  break;
               case "resu":
                  _loc14_ = param1.readInt();
                  _loc15_ = param1.readInt();
                  _loc16_ = param1.readInt();
                  this.creer_perso(_loc10_,true,_loc12_,_loc13_,_loc15_,_loc14_);
                  this.persos[Perso.prochaineId - 1].resurrection = param1.readInt();
                  this.persos[Perso.prochaineId - 1].charger_vie(_loc16_);
                  break;
               case "wall":
                  _loc14_ = param1.readInt();
                  _loc15_ = param1.readInt();
                  _loc16_ = param1.readInt();
                  this.creer_perso(_loc10_,true,_loc12_,_loc13_,_loc15_,_loc14_);
                  this.persos[Perso.prochaineId - 1].charger_vie(_loc16_);
                  break;
               case "inte":
                  this.creer_perso_temporaire(_loc10_,param1.readUTF(),param1.readInt(),param1.readDouble(),_loc12_,_loc13_,param1.readInt(),param1.readInt(),param1.readUTF(),null);
                  break;
               case "loot":
                  this.creer_tresor(new TresorEvent(TresorEvent.CREER,_loc10_,_loc12_,_loc13_,param1.readInt(),param1.readInt()));
                  break;
               case "miss":
               case "misa":
                  if(_loc5_ == "misa")
                  {
                     _loc20_ = new ProjectileAutoguide();
                  }
                  else
                  {
                     _loc20_ = new Projectile();
                  }
                  this.creer_perso2(_loc20_,_loc10_,_loc12_,_loc13_);
                  _loc20_.addEventListener(PersosEvent.ROTATION,this.rotation_perso);
                  _loc20_.addEventListener(PersosEvent.DEPLACER,this.deplacer_perso);
                  _loc20_.equipe = param1.readInt();
                  _loc20_.rotation = param1.readDouble();
                  _loc20_.dx = param1.readDouble();
                  _loc20_.dy = param1.readDouble();
                  _loc20_.l = param1.readDouble();
                  _loc20_.init_deplacement(param1.readInt());
                  _loc20_.attaque = param1.readInt();
                  _loc20_.degats = new Vector.<String>();
                  _loc9_ = param1.readByte();
                  _loc7_ = 0;
                  while(_loc7_ < _loc9_)
                  {
                     _loc20_.degats.push(param1.readUTF());
                     _loc7_++;
                  }
                  _loc20_.transperce = param1.readBoolean();
                  _loc20_.animFin = param1.readUTF();
                  if(_loc5_ == "misa")
                  {
                     _loc20_.vitesseRotationBase = _loc20_.vitesseRotation = param1.readDouble();
                  }
                  _loc20_.dispatchEvent(new PersosEvent(PersosEvent.ROTATION));
            }
            if(this.persos[Perso.prochaineId - 1] is Mobile)
            {
               this.persos[Perso.prochaineId - 1].destinationX = this.persos[Perso.prochaineId - 1].x;
               this.persos[Perso.prochaineId - 1].destinationY = this.persos[Perso.prochaineId - 1].y;
            }
            if(!(_loc5_ == "folk" || _loc5_ == "mons" || _loc5_ == "sold" || _loc5_ == "heal"))
            {
               continue;
            }
            if(this.persos[Perso.prochaineId - 1].equipe == -1)
            {
               ++this.vagues.nbMonstres;
               ++this.vagues.nbMonstresActifs;
               continue;
            }
            switch(_loc5_)
            {
               case "folk":
                  ++this.villes[_loc15_].nbVillageois;
                  ++this.villes[_loc15_].nbVillageoisMax;
                  break;
               case "mons":
                  ++this.villes[_loc15_].nbMonstres;
                  break;
               case "sold":
               case "heal":
                  ++this.villes[_loc15_].nbSoldats;
                  ++this.villes[_loc15_].nbSoldatsActifs;
            }
         }
         _loc8_ = param1.readInt();
         _loc6_ = 0;
         while(_loc6_ < _loc8_)
         {
            this.villes[_loc6_].x = param1.readInt();
            this.villes[_loc6_].y = param1.readInt();
            if(param3[_loc6_].soldiersLimit)
            {
               this.villes[_loc6_].nbSoldatsMax = param3[_loc6_].soldiersLimit;
            }
            else
            {
               this.villes[_loc6_].nbSoldatsMax = 50;
            }
            this.villes[_loc6_].epoqueActuelle = param1.readInt();
            this.villes[_loc6_].pasDerniereEpoque = this.villes[_loc6_].epoqueActuelle < param3[_loc6_].endingAge;
            if(this.villes[_loc6_].temps)
            {
               this.villes[_loc6_].decalageCompteur = param1.readInt();
               this.villes[_loc6_].temps.repeatCount = int(Donnees.epoques[this.villes[_loc6_].epoqueActuelle].time / this.villes[_loc6_].vitesseChangementEpoque) - this.villes[_loc6_].decalageCompteur;
            }
            if(param1.readBoolean() || Boolean(this.villes[_loc6_].epoqueActuelle >= param3[_loc6_].endingAge) && Boolean(this.villes[_loc6_].temps))
            {
               this.villes[_loc6_].changementEpoqueEnPause = true;
               this.villes[_loc6_].decalageCompteur = 0;
               if(this.villes[_loc6_].temps)
               {
                  this.villes[_loc6_].temps.stop();
               }
            }
            _loc6_++;
         }
         this.actualiser_epoques();
         _loc8_ = param1.readInt();
         this.actualiser_nbMonstresMax(param4.monstersLimit ? int(param4.monstersLimit) : 50);
         _loc6_ = 0;
         while(_loc6_ < _loc8_)
         {
            this.vagues.monstresEnAttente.push(new VaguesCreerPerso(param1.readUTF(),param1.readInt(),param1.readInt(),param1.readInt(),param1.readInt(),param1.readInt()));
            ++this.vagues.nbMonstres;
            _loc6_++;
         }
         _loc6_ = _loc23_;
         while(_loc6_ < param2.length)
         {
            this.creer_joueur(param2[_loc6_],this.villes[this.villes.length - 1].x + Math.random() * 320 - 160,this.villes[this.villes.length - 1].x + Math.random() * 320 - 160,this.villes.length - 1,this.villes[this.villes.length - 1].equipe);
            ++this.villes[this.villes.length - 1].nbVillageois;
            ++this.villes[this.villes.length - 1].nbVillageoisMax;
            _loc6_++;
         }
         for each(_loc20_ in this.persos)
         {
            if(_loc20_ is Soldat || _loc20_ is Serviteur)
            {
               ++this.villes[_loc20_.ville].nbSoldats;
            }
            else if(_loc20_ is Aventurier)
            {
               _loc6_ = 0;
               while(_loc6_ < _loc20_.objets.length)
               {
                  _loc21_ = _loc20_.objets[_loc6_].id;
                  if(Boolean(Donnees.donnees[_loc21_].gain) && Boolean(Donnees.donnees[_loc21_].gain.king))
                  {
                     _loc20_.roi = true;
                  }
                  _loc6_++;
               }
            }
         }
         this.actualiser_nbTout();
      }
      
      public function sauvegarder_persos(param1:ByteArray) : ByteArray
      {
         var _loc2_:Object = null;
         var _loc3_:Object = null;
         var _loc4_:int = 0;
         var _loc5_:Ville = null;
         var _loc6_:VaguesCreerPerso = null;
         for each(_loc2_ in this.persos)
         {
            _loc4_++;
         }
         param1.writeInt(_loc4_);
         for each(_loc2_ in this.persos)
         {
            if(_loc2_ is Artisan)
            {
               param1.writeUTF("folk");
            }
            else if(_loc2_ is RessourceTerrain)
            {
               param1.writeUTF("ress");
            }
            else if(_loc2_ is RessourceMobile)
            {
               param1.writeUTF("resm");
            }
            else if(_loc2_ is Animal)
            {
               param1.writeUTF("anim");
            }
            else if(_loc2_ is Fondations)
            {
               param1.writeUTF("fond");
            }
            else if(_loc2_ is Maison)
            {
               param1.writeUTF("hous");
            }
            else if(_loc2_ is BatimentCentreVille)
            {
               param1.writeUTF("town");
            }
            else if(_loc2_ is BatimentCaserne)
            {
               param1.writeUTF("barr");
            }
            else if(_loc2_ is Mur)
            {
               param1.writeUTF("wall");
            }
            else if(_loc2_ is Atelier)
            {
               param1.writeUTF("work");
            }
            else if(_loc2_ is BatimentDonjon)
            {
               param1.writeUTF("dung");
            }
            else if(_loc2_ is BatimentOffensif)
            {
               param1.writeUTF("towe");
            }
            else if(_loc2_ is BatimentMobile)
            {
               param1.writeUTF("gole");
            }
            else if(_loc2_ is BatimentResurrection)
            {
               param1.writeUTF("resu");
            }
            else if(_loc2_ is Intermediaire)
            {
               param1.writeUTF("inte");
            }
            else if(_loc2_ is Guerisseur)
            {
               param1.writeUTF("heal");
            }
            else if(_loc2_ is Soldat)
            {
               param1.writeUTF("sold");
            }
            else if(_loc2_ is Combattant)
            {
               param1.writeUTF("mons");
            }
            else if(_loc2_ is Tresor)
            {
               param1.writeUTF("loot");
            }
            else if(_loc2_ is ProjectileAutoguide)
            {
               param1.writeUTF("misa");
            }
            else if(_loc2_ is Projectile)
            {
               param1.writeUTF("miss");
            }
            param1.writeUTF(_loc2_.race);
            param1.writeBoolean(_loc2_.visible);
            param1.writeDouble(_loc2_.x);
            param1.writeDouble(_loc2_.y);
            if(_loc2_ is Vivant)
            {
               param1.writeInt(_loc2_.equipe);
               param1.writeInt(_loc2_.ville);
               param1.writeInt(_loc2_.vie.score);
            }
            if(_loc2_ is Mobile)
            {
               param1.writeInt(_loc2_.orientation);
               param1.writeBoolean(_loc2_.ia);
            }
            if(_loc2_ is Artisan)
            {
               param1.writeObject(_loc2_.apparenceBase);
               _loc4_ = 0;
               for each(_loc3_ in _loc2_.caracteristiquesPrimaires)
               {
                  if(_loc3_.score < _loc3_.scoreMax)
                  {
                     _loc4_++;
                  }
               }
               param1.writeInt(_loc4_);
               for each(_loc3_ in _loc2_.caracteristiquesPrimaires)
               {
                  if(_loc3_.score < _loc3_.scoreMax)
                  {
                     param1.writeUTF(_loc3_.id);
                     param1.writeDouble(_loc3_.coef);
                  }
               }
               _loc4_ = 0;
               for each(_loc3_ in _loc2_.ressources)
               {
                  if(_loc3_.quantite > 0)
                  {
                     _loc4_++;
                  }
               }
               param1.writeInt(_loc4_);
               for each(_loc3_ in _loc2_.ressources)
               {
                  if(_loc3_.quantite > 0)
                  {
                     param1.writeUTF(_loc3_.id);
                     param1.writeInt(_loc3_.quantite);
                  }
               }
               _loc4_ = int(_loc2_.objets.length);
               param1.writeInt(_loc4_);
               for each(_loc3_ in _loc2_.objets)
               {
                  if(_loc3_ is ObjetTemporaire)
                  {
                     param1.writeInt(2);
                  }
                  else if(_loc3_ is ObjetEquipe)
                  {
                     param1.writeInt(1);
                  }
                  else
                  {
                     param1.writeInt(0);
                  }
                  param1.writeUTF(_loc3_.id);
                  if(_loc3_ is ObjetTemporaire)
                  {
                     param1.writeInt(_loc3_.timer.repeatCount - _loc3_.timer.currentCount);
                     param1.writeBoolean(_loc3_.equipe);
                     param1.writeBoolean(_loc3_.gauche);
                  }
                  else
                  {
                     param1.writeInt(_loc3_.quantite);
                     if(_loc3_ is ObjetEquipe)
                     {
                        param1.writeBoolean(_loc3_.equipe);
                        param1.writeBoolean(_loc3_.gauche);
                     }
                  }
                  param1.writeInt(_loc3_.renforcer);
               }
            }
            if(_loc2_ is Animal)
            {
               param1.writeDouble(_loc2_.bonusCreation);
            }
            if(_loc2_ is Fondations)
            {
               param1.writeUTF(_loc2_.creation);
               param1.writeDouble(_loc2_.travailDuree * 0.001);
               param1.writeDouble(_loc2_.bonusCreation);
               param1.writeUTF(_loc2_.anim);
               param1.writeInt(_loc2_.createur.id);
               param1.writeInt(_loc2_.tempsConstruction);
            }
            if(_loc2_ is Atelier)
            {
               param1.writeInt(_loc2_.quantite);
               param1.writeInt(_loc2_.quantiteMax);
               param1.writeInt(_loc2_.nombre_etapes());
               for(_loc3_ in _loc2_.etapes)
               {
                  param1.writeUTF(String(_loc3_));
                  param1.writeInt(_loc2_.etapes[_loc3_]);
               }
               if(_loc2_ is BatimentCaserne)
               {
                  param1.writeInt(_loc2_.garnison.length);
                  for each(_loc3_ in _loc2_.garnison)
                  {
                     param1.writeUTF(String(_loc3_.race));
                     param1.writeInt(int(_loc3_.maitre));
                  }
                  if(_loc2_ is Maison)
                  {
                     param1.writeInt(_loc2_.proprietaire);
                  }
                  else if(_loc2_ is BatimentCentreVille)
                  {
                     param1.writeUTF(_loc2_.creation ? _loc2_.creation : "");
                     param1.writeDouble(_loc2_.travailDuree * 0.001);
                     param1.writeBoolean(_loc2_.ameliorationEnCours);
                     param1.writeInt(_loc2_.tempsConstruction);
                     _loc4_ = 0;
                     for each(_loc3_ in _loc2_.ressources)
                     {
                        if(_loc3_.quantite > 0)
                        {
                           _loc4_++;
                        }
                     }
                     param1.writeInt(_loc4_);
                     for each(_loc3_ in _loc2_.ressources)
                     {
                        if(_loc3_.quantite > 0)
                        {
                           param1.writeUTF(_loc3_.id);
                           param1.writeInt(_loc3_.quantite);
                        }
                     }
                  }
               }
            }
            if(_loc2_ is BatimentMobile)
            {
               param1.writeInt(_loc2_.ordre);
               param1.writeBoolean(_loc2_.revenirPositionOrigine);
            }
            if(_loc2_ is BatimentResurrection)
            {
               param1.writeInt(_loc2_.resurrection);
            }
            if(_loc2_ is BatimentDonjon)
            {
               param1.writeInt(_loc2_.nbMonstresParVagues);
            }
            if(_loc2_ is BatimentRotatif)
            {
               param1.writeInt(_loc2_.rotation);
            }
            if(_loc2_ is Intermediaire)
            {
               param1.writeUTF(_loc2_.creation);
               param1.writeInt(_loc2_.timer.repeatCount - _loc2_.timer.currentCount);
               param1.writeDouble(_loc2_.bonusCreation);
               param1.writeInt(_loc2_.ville);
               param1.writeInt(_loc2_.equipe);
               param1.writeUTF(_loc2_.anim);
            }
            if(_loc2_ is RessourceTerrain)
            {
               param1.writeInt(_loc2_.quantite);
               param1.writeInt(_loc2_.quantiteMax);
            }
            if(_loc2_ is RessourceMobile)
            {
               param1.writeInt(_loc2_.quantite);
               param1.writeInt(_loc2_.quantiteMax);
            }
            if(_loc2_ is Soldat)
            {
               param1.writeInt(_loc2_.ordre);
               param1.writeInt(_loc2_.origineX);
               param1.writeInt(_loc2_.origineY);
               param1.writeInt(_loc2_.origineOrientation);
               param1.writeBoolean(_loc2_.revenirPositionOrigine);
               if(_loc2_.maitre)
               {
                  param1.writeInt(_loc2_.maitre.id);
               }
               else
               {
                  param1.writeInt(-1);
               }
               param1.writeInt(_loc2_.maitreDecalageX);
               param1.writeInt(_loc2_.maitreDecalageY);
               if(_loc2_ is Guerisseur)
               {
                  param1.writeInt(_loc2_.scoreGuerison);
               }
            }
            if(_loc2_ is Projectile)
            {
               param1.writeInt(_loc2_.equipe);
               param1.writeDouble(_loc2_.rotation);
               param1.writeDouble(_loc2_.dx);
               param1.writeDouble(_loc2_.dy);
               param1.writeDouble(_loc2_.l);
               param1.writeInt(_loc2_.deplacementTimer.repeatCount - _loc2_.deplacementTimer.currentCount);
               param1.writeInt(_loc2_.attaque);
               param1.writeByte(_loc2_.degats.length);
               _loc4_ = 0;
               while(_loc4_ < _loc2_.degats.length)
               {
                  param1.writeUTF(_loc2_.degats[_loc4_]);
                  _loc4_++;
               }
               param1.writeBoolean(_loc2_.transperce);
               param1.writeUTF(_loc2_.animFin ? _loc2_.animFin : "");
               if(_loc2_ is ProjectileAutoguide)
               {
                  param1.writeDouble(_loc2_.vitesseRotationBase);
               }
            }
            if(_loc2_ is Tresor)
            {
               param1.writeInt(_loc2_.quantite);
               param1.writeInt(_loc2_.renforce);
            }
         }
         param1.writeInt(this.villes.length);
         for each(_loc5_ in this.villes)
         {
            param1.writeInt(_loc5_.x);
            param1.writeInt(_loc5_.y);
            param1.writeInt(_loc5_.epoqueActuelle);
            if(_loc5_.temps)
            {
               param1.writeInt(_loc5_.temps.currentCount);
            }
            param1.writeBoolean(_loc5_.changementEpoqueEnPause);
         }
         param1.writeInt(this.vagues.monstresEnAttente.length);
         for each(_loc6_ in this.vagues.monstresEnAttente)
         {
            param1.writeUTF(_loc6_.race);
            param1.writeInt(_loc6_.x);
            param1.writeInt(_loc6_.y);
            param1.writeInt(_loc6_.destinationX);
            param1.writeInt(_loc6_.destinationY);
            param1.writeInt(_loc6_.equipe);
         }
         return param1;
      }
      
      public function sauvegarder_bac_a_sable(param1:ByteArray) : ByteArray
      {
         var _loc2_:Object = null;
         var _loc3_:Object = null;
         for each(_loc2_ in this.persos)
         {
            if(!(_loc2_ is Joueur))
            {
               _loc3_ = new Object();
               _loc3_.id = _loc2_.race;
               _loc3_.x = _loc2_.x;
               _loc3_.y = _loc2_.y;
               param1.writeObject(_loc3_);
            }
         }
         return param1;
      }
      
      public function detruire_perso(param1:PersosEvent) : void
      {
         var _loc3_:Object = null;
         var _loc2_:* = param1.currentTarget;
         if(_loc2_ is Fondations && _loc2_.createur is Artisan)
         {
            if(_loc2_.createur.maison == _loc2_)
            {
               _loc2_.createur.possedeMaison = false;
               _loc2_.createur.maison = null;
            }
         }
         else if(_loc2_ is Maison && this.persos[_loc2_.proprietaire] is Artisan)
         {
            this.persos[_loc2_.proprietaire].possedeMaison = false;
            this.persos[_loc2_.proprietaire].maison = null;
         }
         if(_loc2_ is Maison || _loc2_ is BatimentOffensif)
         {
            for each(_loc3_ in this.combattants)
            {
               if(_loc3_ is Artisan)
               {
                  if(!Artisan(_loc3_).visible && Artisan(_loc3_).batimentEntrer == _loc2_)
                  {
                     Artisan(_loc3_).sortir();
                  }
               }
            }
         }
         if(_loc2_ is BatimentCaserne)
         {
            this.villes[_loc2_.equipe].nbSoldats -= _loc2_.garnison.length;
            this.villes[_loc2_.equipe].nbSoldatsActifs -= _loc2_.garnison.length;
         }
         _loc2_.removeEventListener(PersosEvent.DEPLACER,this.deplacer_perso);
         _loc2_.removeEventListener(PersosEvent.DEPLACER,this.ramasser_tresors);
         if(_loc2_.hasEventListener(PersosEvent.DEPLACER))
         {
            _loc2_.removeEventListener(PersosEvent.DEPLACER,this.gerer_collisions);
            this.gerer_collisions_fin(_loc2_,Terrain.case_perso_collisions_effacer);
         }
         else if(_loc2_ is Mur)
         {
            this.gerer_collisions_fin(_loc2_,Terrain.case_perso_collisions_effacer);
         }
         _loc2_.removeEventListener(PersosEvent.DECALER_Y,this.decaler_y_perso);
         _loc2_.removeEventListener(PersosEvent.ORIENTER,this.orienter_perso);
         _loc2_.removeEventListener(PersosEvent.ROTATION,this.rotation_perso);
         _loc2_.removeEventListener(PersosEvent.VISIBLE,this.visible_perso);
         _loc2_.removeEventListener(PersosEvent.ACTUALISER_APPARENCE,this.apparence_perso);
         _loc2_.removeEventListener(PersosEvent.ACTUALISER_COULEUR,this.couleur_perso);
         _loc2_.removeEventListener(PersosEvent.ACTUALISER_MONTURE,this.monture_perso);
         _loc2_.removeEventListener(CreationPersoEvent.CREER,this.perso_creer_perso);
         _loc2_.removeEventListener(PersosEvent.ACTUALISER_VIE,this.actualier_vie_perso);
         _loc2_.removeEventListener(PersosEvent.ACTUALISER_ETAPE,this.actualier_etape_perso);
         _loc2_.removeEventListener(BulleEvent.MESSAGE,this.actualier_bulle_perso);
         _loc2_.removeEventListener(TresorEvent.CREER,this.creer_tresor);
         _loc2_.removeEventListener(EffetEvent.EFFET,this.afficher_effet);
         _loc2_.removeEventListener(SonEvent.SON,this.jouer_son);
         _loc2_.removeEventListener(EffetArmeEvent.EFFET_ARME,this.afficher_effet_arme);
         _loc2_.removeEventListener(ProjectileEvent.CREER,this.perso_creer_projectile);
         _loc2_.removeEventListener(AnimationEvent.ANIMER,this.animer_perso);
         _loc2_.removeEventListener(PersosEvent.EFFACER,this.effacer_perso);
         _loc2_.removeEventListener(PersosEvent.FANTOME,this.fantome_perso);
         _loc2_.removeEventListener(PersosEvent.DETRUIRE,this.detruire_perso);
         _loc2_.removeEventListener(PersosEvent.ROI,this.roi_perso);
         _loc2_.removeEventListener(PersosEvent.ROI_FIN,this.roi_fin_perso);
         _loc2_.removeEventListener(MessageEvent.MESSAGE_IMPORTANT,this.message_perso);
         if(this.persos[_loc2_.id])
         {
            delete this.persos[_loc2_.id];
         }
         if(this.persosCollisions[_loc2_.id])
         {
            delete this.persosCollisions[_loc2_.id];
         }
         if(this.combattants[_loc2_.id])
         {
            delete this.combattants[_loc2_.id];
         }
         if(this.ressourceTerrain[_loc2_.id])
         {
            delete this.ressourceTerrain[_loc2_.id];
         }
         else if(this.montures[_loc2_.id])
         {
            delete this.montures[_loc2_.id];
         }
         if(this.batiments[_loc2_.id])
         {
            delete this.batiments[_loc2_.id];
         }
         if(this.batimentsDefense[_loc2_.id])
         {
            delete this.batimentsDefense[_loc2_.id];
         }
         if(this.batimentResurrection[_loc2_.id])
         {
            delete this.batimentResurrection[_loc2_.id];
         }
         if(this.batimentCaserne[_loc2_.id])
         {
            delete this.batimentCaserne[_loc2_.id];
         }
         if(this.centresVille[_loc2_.id])
         {
            delete this.centresVille[_loc2_.id];
         }
         if(this.donjons[_loc2_.id])
         {
            _loc2_.removeEventListener(VaguesCreerPersoEvent.CREER_PERSO,this.ajouter_vague);
            delete this.donjons[_loc2_.id];
         }
         _loc2_ = null;
      }
      
      public function ajouter_nouveau_joueur(param1:int, param2:int, param3:Object, param4:Array, param5:Object) : int
      {
         var _loc7_:Object = null;
         this.creer_joueur(param3,this.villes[param1].x + Math.random() * 320 - 160,this.villes[param1].y + Math.random() * 320 - 160,param1,this.villes[param1].equipe,param2);
         var _loc6_:Joueur = this.persos[Perso.prochaineId - 1];
         ++this.villes[param1].nbVillageois;
         ++this.villes[param1].nbVillageoisMax;
         if(param5)
         {
            _loc6_.charger_equipement(param5);
         }
         else
         {
            for each(_loc7_ in _loc6_.ressources)
            {
               if(param4[_loc6_.equipe].startingResources is int)
               {
                  _loc7_.quantite = param4[_loc6_.equipe].startingResources;
               }
            }
         }
         if(enPause)
         {
            this.persos[Perso.prochaineId - 1].pause();
         }
         return Perso.prochaineId - 1;
      }
      
      public function supprimer_joueur(param1:Joueur) : void
      {
         if(param1.vivant)
         {
            --this.villes[param1.ville].nbVillageois;
         }
         --this.villes[param1.ville].nbVillageoisMax;
         param1.dispatchEvent(new PersosEvent(PersosEvent.EFFACER));
         param1.detruire();
      }
      
      public function supprimer_perso(param1:Object) : void
      {
         var _loc2_:int = 0;
         if(param1 is Artisan && !(param1 is Serviteur))
         {
            if(param1.vivant)
            {
               --this.villes[param1.ville].nbVillageois;
            }
            --this.villes[param1.ville].nbVillageoisMax;
         }
         else if(param1 is Tresor)
         {
            _loc2_ = 0;
            while(_loc2_ < this.tresors.length)
            {
               if(this.tresors[_loc2_] == param1)
               {
                  this.tresors.splice(_loc2_,1);
                  break;
               }
               _loc2_++;
            }
            param1.addEventListener(PersosEvent.EFFACER,this.effacer_perso);
         }
         param1.dispatchEvent(new PersosEvent(PersosEvent.EFFACER));
         param1.detruire();
      }
      
      public function recuperer_persos() : void
      {
      }
      
      public function detruire() : void
      {
         this.vagues = null;
      }
   }
}

