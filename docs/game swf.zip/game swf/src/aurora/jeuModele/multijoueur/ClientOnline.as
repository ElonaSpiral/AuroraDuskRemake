package aurora.jeuModele.multijoueur
{
   import flash.events.Event;
   import flash.events.EventDispatcher;
   import flash.events.NetStatusEvent;
   import flash.events.TimerEvent;
   import flash.net.NetConnection;
   import flash.net.NetStream;
   import flash.utils.ByteArray;
   import flash.utils.Timer;
   
   public class ClientOnline extends EventDispatcher
   {
      
      private var adresseServeur:String;
      
      private var timerNouvelEssai:Timer;
      
      public var numero:int;
      
      private var netCon:NetConnection;
      
      private var myID:String;
      
      private var farID:String;
      
      private var sendStreamPrincipal:NetStream;
      
      private var messageReceived_serveur:Function;
      
      private var envoyer_terrain:Function;
      
      private var message_normal:Function;
      
      public var sendStream:NetStream;
      
      public var receiveStream:NetStream;
      
      public var noPersos:Vector.<int>;
      
      public var clientBuffer:ByteArray;
      
      public function ClientOnline(param1:String, param2:NetStream, param3:Function, param4:Function, param5:Function)
      {
         var timerNouvelEssai:Timer = null;
         var STRATUS_SERVER:String = param1;
         var sendStreamPrincipal:NetStream = param2;
         var messageReceived_serveur:Function = param3;
         var envoyer_terrain:Function = param4;
         var message_normal:Function = param5;
         super();
         this.sendStreamPrincipal = sendStreamPrincipal;
         this.messageReceived_serveur = messageReceived_serveur;
         this.envoyer_terrain = envoyer_terrain;
         this.message_normal = message_normal;
         this.noPersos = new Vector.<int>();
         try
         {
            this.netCon = new NetConnection();
            this.netCon.addEventListener(NetStatusEvent.NET_STATUS,this.netStatusHandler);
            this.netCon.connect(STRATUS_SERVER);
         }
         catch(error:Error)
         {
            adresseServeur = STRATUS_SERVER;
            timerNouvelEssai = new Timer(1000,1);
            timerNouvelEssai.addEventListener(TimerEvent.TIMER_COMPLETE,reessayer);
            timerNouvelEssai.start();
         }
      }
      
      private function reessayer(param1:TimerEvent) : void
      {
         var timerNouvelEssai:Timer = null;
         var e:TimerEvent = param1;
         try
         {
            if(this.netCon)
            {
               this.netCon.removeEventListener(NetStatusEvent.NET_STATUS,this.netStatusHandler);
            }
            this.netCon = new NetConnection();
            this.netCon.addEventListener(NetStatusEvent.NET_STATUS,this.netStatusHandler);
            this.netCon.connect(this.adresseServeur);
         }
         catch(error:Error)
         {
            timerNouvelEssai = new Timer(1000,1);
            timerNouvelEssai.addEventListener(TimerEvent.TIMER_COMPLETE,reessayer);
            timerNouvelEssai.start();
         }
      }
      
      private function netStatusHandler(param1:NetStatusEvent) : void
      {
         switch(param1.info.code)
         {
            case "NetConnection.Connect.Success":
               this.myID = this.netCon.nearID;
               this.sendStream = new NetStream(this.netCon,NetStream.DIRECT_CONNECTIONS);
               this.sendStream.addEventListener(NetStatusEvent.NET_STATUS,this.sendStatusHandler);
               this.sendStream.publish("chat");
               break;
            case "NetStream.Connect.Success":
               break;
            case "NetStream.Connect.Closed":
               this.onDisconnect();
         }
      }
      
      private function sendStatusHandler(param1:NetStatusEvent) : void
      {
         var tempClient:Object = null;
         var buffer:ByteArray = null;
         var e:NetStatusEvent = param1;
         if(e.info.code == "NetStream.Play.Start")
         {
            if(this.receiveStream == null)
            {
               this.farID = e.target.peerStreams[0].farID;
               try
               {
                  this.receiveStream = new NetStream(this.netCon,this.farID);
                  tempClient = new Object();
                  tempClient.messageReceived = this.messageReceived;
                  this.receiveStream.client = tempClient;
                  this.receiveStream.addEventListener(NetStatusEvent.NET_STATUS,this.receiveStatusHandler);
                  this.receiveStream.play("chat");
               }
               catch(error:Error)
               {
               }
            }
         }
         else if(e.info.code == "NetStream.Publish.Start")
         {
            buffer = new ByteArray();
            buffer.writeUTF(this.myID);
            this.sendStreamPrincipal.send("messageReceived",buffer);
         }
      }
      
      private function receiveStatusHandler(param1:NetStatusEvent) : void
      {
         if(param1.info.code == "NetStream.Play.Start")
         {
         }
      }
      
      public function messageReceived(param1:ByteArray) : void
      {
         this.messageReceived_serveur(this,param1);
      }
      
      private function onDisconnect() : void
      {
         dispatchEvent(new Event(Event.CLOSE));
      }
      
      public function ajouter_joueur(param1:int) : void
      {
         this.noPersos.push(param1);
      }
      
      public function supprimer_joueur(param1:int) : void
      {
         var _loc2_:int = 0;
         while(_loc2_ < this.noPersos.length)
         {
            if(this.noPersos[_loc2_] == param1)
            {
               this.noPersos.splice(_loc2_,1);
               break;
            }
            _loc2_++;
         }
      }
      
      public function dispose() : void
      {
         this.sendStreamPrincipal = null;
         this.messageReceived_serveur = null;
         this.envoyer_terrain = null;
         this.message_normal = null;
         if(this.sendStream)
         {
            this.sendStream.removeEventListener(NetStatusEvent.NET_STATUS,this.sendStatusHandler);
            this.sendStream.close();
            this.sendStream = null;
         }
         if(this.receiveStream)
         {
            this.receiveStream.removeEventListener(NetStatusEvent.NET_STATUS,this.receiveStatusHandler);
            this.receiveStream.close();
            this.receiveStream = null;
         }
         if(this.netCon)
         {
            this.netCon.removeEventListener(NetStatusEvent.NET_STATUS,this.netStatusHandler);
            this.netCon.close();
            this.netCon = null;
         }
         this.noPersos.splice(0,this.noPersos.length);
         this.noPersos = null;
      }
   }
}

