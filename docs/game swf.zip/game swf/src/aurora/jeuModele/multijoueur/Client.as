package aurora.jeuModele.multijoueur
{
   import flash.events.Event;
   import flash.events.EventDispatcher;
   import flash.events.ProgressEvent;
   import flash.net.Socket;
   import flash.utils.ByteArray;
   
   public class Client extends EventDispatcher
   {
      
      public var numero:int;
      
      public var socket:Socket;
      
      public var noPersos:Vector.<int>;
      
      public var clientBuffer:ByteArray;
      
      public function Client(param1:Socket)
      {
         super();
         this.socket = param1;
         this.clientBuffer = new ByteArray();
         param1.addEventListener(ProgressEvent.SOCKET_DATA,this.onClientSocketData);
         param1.addEventListener(Event.CLOSE,this.onDisconnect);
         this.noPersos = new Vector.<int>();
      }
      
      private function onClientSocketData(param1:ProgressEvent) : void
      {
         dispatchEvent(param1.clone());
      }
      
      private function onDisconnect(param1:Event) : void
      {
         dispatchEvent(param1.clone());
      }
      
      public function ajouter_joueur(param1:int) : void
      {
         this.noPersos.push(param1);
      }
      
      public function supprimer_joueur(param1:int) : void
      {
         var _loc2_:int = 0;
         while(_loc2_ < this.noPersos.length)
         {
            if(this.noPersos[_loc2_] == param1)
            {
               this.noPersos.splice(_loc2_,1);
               break;
            }
            _loc2_++;
         }
      }
      
      public function dispose() : void
      {
         this.socket.removeEventListener(ProgressEvent.SOCKET_DATA,this.onClientSocketData);
         this.socket.removeEventListener(Event.CLOSE,this.onDisconnect);
         this.socket.close();
         this.socket = null;
         this.noPersos.splice(0,this.noPersos.length);
         this.noPersos = null;
      }
   }
}

