package aurora.jeuModele.evenements
{
   import flash.events.Event;
   
   public class EvenementEvent extends Event
   {
      
      public static const ENVOYER:String = "envoyer";
      
      public static const TAG:String = "tag";
      
      public var infos:Object;
      
      public function EvenementEvent(param1:String, param2:Object)
      {
         this.infos = param2;
         super(param1);
      }
   }
}

