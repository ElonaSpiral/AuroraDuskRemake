package aurora.jeuModele.evenements
{
   import aurora.jeuModele.Donnees;
   import aurora.jeuModele.IA;
   import aurora.jeuModele.Persos;
   import aurora.jeuModele.PersosEvent;
   import aurora.jeuModele.finPartie.FinPartie;
   import aurora.jeuModele.finPartie.FinPartieEvent;
   import aurora.jeuModele.perso.Artisan;
   import aurora.jeuModele.perso.Fondations;
   import aurora.jeuModele.perso.Joueur;
   import aurora.jeuModele.perso.Mobile;
   import aurora.jeuModele.perso.Perso;
   import aurora.jeuModele.perso.Vivant;
   import aurora.jeuModele.vagues.Vagues;
   import aurora.messages.perso.MessagePersoOrienter;
   import flash.events.EventDispatcher;
   import flash.events.TimerEvent;
   import flash.utils.Dictionary;
   import flash.utils.Timer;
   
   public class Evenement extends EventDispatcher
   {
      
      private var donnees:Object;
      
      public var actif:Boolean;
      
      public var retarde:Boolean;
      
      public var termine:Boolean;
      
      private var conditions:Vector.<Object>;
      
      private var consequences:Vector.<Object>;
      
      private var persos:Persos;
      
      private var vagues:Vagues;
      
      private var finPartie:FinPartie;
      
      private var langue:String;
      
      private var tags:Dictionary;
      
      public var besoinVerifierPosition:Boolean;
      
      public var besoinVerifierRessources:Boolean;
      
      public var besoinVerifierMaison:Boolean;
      
      public var besoinVerifierObjets:Boolean;
      
      public var besoinVerifierPersos:Boolean;
      
      public var besoinVerifierNbPersos:Boolean;
      
      public var besoinVerifierNbMonstres:Boolean;
      
      public var besoinVerifierEpoque:Boolean;
      
      public var evenementsAuto:Timer;
      
      public function Evenement(param1:Object, param2:Persos, param3:Vagues, param4:FinPartie, param5:String, param6:Dictionary)
      {
         var _loc7_:Object = null;
         var _loc8_:Object = null;
         super();
         this.actif = param1.enabled == undefined || param1.enabled == true;
         this.termine = param1.finished == true;
         this.conditions = new Vector.<Object>();
         this.consequences = new Vector.<Object>();
         for each(_loc7_ in param1.causes)
         {
            if(_loc7_.position)
            {
               this.besoinVerifierPosition = true;
            }
            if(_loc7_.playerResource)
            {
               this.besoinVerifierRessources = true;
            }
            if(_loc7_.playerHouse)
            {
               this.besoinVerifierMaison = true;
            }
            if(_loc7_.playerItem)
            {
               this.besoinVerifierObjets = true;
            }
            if(Boolean(_loc7_.inGame) || Boolean(_loc7_.inGame1))
            {
               this.besoinVerifierPersos = true;
            }
            if(_loc7_.aliveCharacters)
            {
               this.besoinVerifierNbPersos = true;
            }
            if(Boolean(_loc7_.aliveMonsters) || Boolean(_loc7_.currentMonsters))
            {
               this.besoinVerifierNbMonstres = true;
            }
            if(_loc7_.age)
            {
               this.besoinVerifierEpoque = true;
            }
            this.conditions.push(_loc7_);
         }
         for each(_loc8_ in param1.events)
         {
            this.consequences.push(_loc8_);
         }
         this.donnees = param1;
         this.persos = param2;
         this.vagues = param3;
         this.finPartie = param4;
         this.langue = param5;
         this.tags = param6;
      }
      
      public function verifier_tout(param1:Boolean = false) : Boolean
      {
         if(param1 && !this.actif)
         {
            return true;
         }
         if(!this.actif)
         {
            return false;
         }
         if(this.conditions.length == 0)
         {
            return true;
         }
         if(!this.verifier_tags())
         {
            return false;
         }
         if(!this.verifier_position())
         {
            return false;
         }
         if(!this.verifier_ressources())
         {
            return false;
         }
         if(!this.verifier_maison())
         {
            return false;
         }
         if(!this.verifier_objets())
         {
            return false;
         }
         if(!this.verifier_persos())
         {
            return false;
         }
         if(!this.verifier_nbPersos())
         {
            return false;
         }
         if(!this.verifier_nbMonstres())
         {
            return false;
         }
         if(!this.verifier_epoque())
         {
            return false;
         }
         return true;
      }
      
      public function verifier_tags() : Boolean
      {
         var _loc1_:Object = null;
         if(!this.actif)
         {
            return false;
         }
         for each(_loc1_ in this.conditions)
         {
            if(_loc1_.tag != undefined && !this.tags[_loc1_.tag])
            {
               return false;
            }
         }
         return true;
      }
      
      public function verifier_position() : Boolean
      {
         var _loc1_:Object = null;
         if(!this.actif)
         {
            return false;
         }
         for each(_loc1_ in this.conditions)
         {
            if(_loc1_.position)
            {
               if(!this.persos.persos[_loc1_.position["no"]])
               {
                  return false;
               }
               if(_loc1_.position["x<"])
               {
                  if(this.persos.persos[_loc1_.position["no"]].x > _loc1_.position["x<"])
                  {
                     return false;
                  }
               }
               else if(_loc1_.position["x>"])
               {
                  if(this.persos.persos[_loc1_.position["no"]].x < _loc1_.position["x>"])
                  {
                     return false;
                  }
               }
               else if(_loc1_.position["x="])
               {
                  if(this.persos.persos[_loc1_.position["no"]].x == _loc1_.position["x="])
                  {
                     return false;
                  }
               }
               if(_loc1_.position["y<"])
               {
                  if(this.persos.persos[_loc1_.position["no"]].y > _loc1_.position["y<"])
                  {
                     return false;
                  }
               }
               else if(_loc1_.position["y>"])
               {
                  if(this.persos.persos[_loc1_.position["no"]].y < _loc1_.position["y>"])
                  {
                     return false;
                  }
               }
               else if(_loc1_.position["y="])
               {
                  if(this.persos.persos[_loc1_.position["no"]].y == _loc1_.position["y="])
                  {
                     return false;
                  }
               }
            }
         }
         return true;
      }
      
      public function verifier_ressources() : Boolean
      {
         var _loc1_:Object = null;
         var _loc2_:String = null;
         if(!this.actif)
         {
            return false;
         }
         for each(_loc1_ in this.conditions)
         {
            if(_loc1_.playerResource)
            {
               for(_loc2_ in _loc1_.playerResource)
               {
                  if(this.persos.joueur[0].ressources[_loc2_].quantite < _loc1_.playerResource[_loc2_])
                  {
                     return false;
                  }
               }
            }
         }
         return true;
      }
      
      public function verifier_maison() : Boolean
      {
         var _loc1_:Object = null;
         if(!this.actif)
         {
            return false;
         }
         for each(_loc1_ in this.conditions)
         {
            if(_loc1_.playerHouse)
            {
               if(!this.persos.joueur[0].maison || this.persos.joueur[0].maison is Fondations)
               {
                  return false;
               }
            }
         }
         return true;
      }
      
      public function verifier_objets() : Boolean
      {
         var _loc1_:Object = null;
         var _loc2_:String = null;
         if(!this.actif)
         {
            return false;
         }
         for each(_loc1_ in this.conditions)
         {
            if(_loc1_.playerItem)
            {
               for(_loc2_ in _loc1_.playerItem)
               {
                  if(this.persos.joueur[0].quantite_objet(_loc2_) < _loc1_.playerItem[_loc2_])
                  {
                     return false;
                  }
               }
            }
         }
         return true;
      }
      
      public function verifier_persos() : Boolean
      {
         var _loc1_:String = null;
         var _loc2_:Object = null;
         var _loc3_:String = null;
         if(!this.actif)
         {
            return false;
         }
         for each(_loc2_ in this.conditions)
         {
            if(_loc2_.inGame)
            {
               for(_loc1_ in _loc2_.inGame)
               {
                  if(_loc2_.inGame[_loc1_] is int)
                  {
                     if(this.persos.nombre_persos(_loc1_) < _loc2_.inGame[_loc1_])
                     {
                        return false;
                     }
                  }
                  else
                  {
                     for(_loc3_ in _loc2_.inGame[_loc1_])
                     {
                        switch(_loc3_)
                        {
                           case "=":
                              if(this.persos.nombre_persos(_loc1_) != _loc2_.inGame[_loc1_][_loc3_])
                              {
                                 return false;
                              }
                              break;
                           case ">=":
                              if(this.persos.nombre_persos(_loc1_) < _loc2_.inGame[_loc1_][_loc3_])
                              {
                                 return false;
                              }
                              break;
                           case "<=":
                              if(this.persos.nombre_persos(_loc1_) > _loc2_.inGame[_loc1_][_loc3_])
                              {
                                 return false;
                              }
                              break;
                           case ">":
                              if(this.persos.nombre_persos(_loc1_) <= _loc2_.inGame[_loc1_][_loc3_])
                              {
                                 return false;
                              }
                              break;
                           default:
                              if(this.persos.nombre_persos(_loc1_) >= _loc2_.inGame[_loc1_][_loc3_])
                              {
                                 return false;
                              }
                        }
                     }
                  }
               }
            }
            if(_loc2_.inGame1)
            {
               var _loc6_:int = 0;
               var _loc7_:* = _loc2_.inGame1;
               loop3:
               while(true)
               {
                  for(_loc1_ in _loc7_)
                  {
                     if(_loc2_.inGame1[_loc1_] is int)
                     {
                        if(this.persos.nombre_persos(_loc1_) >= _loc2_.inGame1[_loc1_])
                        {
                           return true;
                        }
                        continue loop3;
                     }
                     switch(_loc2_.inGame1[_loc1_])
                     {
                        case "=":
                           if(this.persos.nombre_persos(_loc1_) == _loc2_.inGame1[_loc1_])
                           {
                              return true;
                           }
                           break;
                        case ">=":
                           if(this.persos.nombre_persos(_loc1_) >= _loc2_.inGame1[_loc1_])
                           {
                              return true;
                           }
                           break;
                        case "<=":
                           if(this.persos.nombre_persos(_loc1_) <= _loc2_.inGame1[_loc1_])
                           {
                              return true;
                           }
                           break;
                        case ">":
                           if(this.persos.nombre_persos(_loc1_) > _loc2_.inGame1[_loc1_])
                           {
                              return true;
                           }
                           break;
                        default:
                           if(this.persos.nombre_persos(_loc1_) >= _loc2_.inGame1[_loc1_])
                           {
                              break loop3;
                           }
                     }
                  }
                  return false;
               }
               return true;
            }
         }
         return true;
      }
      
      public function verifier_nbPersos() : Boolean
      {
         var _loc1_:Object = null;
         var _loc2_:String = null;
         if(!this.actif)
         {
            return false;
         }
         for each(_loc1_ in this.conditions)
         {
            if(_loc1_.aliveCharacters)
            {
               for(_loc2_ in _loc1_.aliveCharacters)
               {
                  switch(_loc2_)
                  {
                     case "=":
                        return this.persos.villes[0].nbVillageois == _loc1_.aliveCharacters[_loc2_];
                     case ">=":
                        return this.persos.villes[0].nbVillageois >= _loc1_.aliveCharacters[_loc2_];
                     case "<=":
                        return this.persos.villes[0].nbVillageois <= _loc1_.aliveCharacters[_loc2_];
                     case ">":
                        return this.persos.villes[0].nbVillageois > _loc1_.aliveCharacters[_loc2_];
                     case "<":
                        return this.persos.villes[0].nbVillageois < _loc1_.aliveCharacters[_loc2_];
                  }
               }
            }
         }
         return true;
      }
      
      public function verifier_nbMonstres() : Boolean
      {
         var _loc1_:Object = null;
         var _loc2_:String = null;
         var _loc3_:String = null;
         if(!this.actif)
         {
            return false;
         }
         for each(_loc1_ in this.conditions)
         {
            if(_loc1_.aliveMonsters)
            {
               for(_loc2_ in _loc1_.aliveMonsters)
               {
                  switch(_loc2_)
                  {
                     case "=":
                        return this.vagues.nbMonstres + (this.vagues ? this.vagues.nombre_de_monstres_restants() : 0) + this.persos.nbMonstres(this.persos.villes[0].equipe) == _loc1_.aliveMonsters[_loc2_];
                     case ">=":
                        return this.vagues.nbMonstres + (this.vagues ? this.vagues.nombre_de_monstres_restants() : 0) + this.persos.nbMonstres(this.persos.villes[0].equipe) >= _loc1_.aliveMonsters[_loc2_];
                     case "<=":
                        return this.vagues.nbMonstres + (this.vagues ? this.vagues.nombre_de_monstres_restants() : 0) + this.persos.nbMonstres(this.persos.villes[0].equipe) <= _loc1_.aliveMonsters[_loc2_];
                     case ">":
                        return this.vagues.nbMonstres + (this.vagues ? this.vagues.nombre_de_monstres_restants() : 0) + this.persos.nbMonstres(this.persos.villes[0].equipe) > _loc1_.aliveMonsters[_loc2_];
                     case "<":
                        return this.vagues.nbMonstres + (this.vagues ? this.vagues.nombre_de_monstres_restants() : 0) + this.persos.nbMonstres(this.persos.villes[0].equipe) < _loc1_.aliveMonsters[_loc2_];
                  }
               }
            }
            if(_loc1_.currentMonsters)
            {
               for(_loc3_ in _loc1_.currentMonsters)
               {
                  switch(_loc3_)
                  {
                     case "=":
                        return this.vagues.nbMonstres == _loc1_.currentMonsters[_loc3_];
                     case ">=":
                        return this.vagues.nbMonstres >= _loc1_.currentMonsters[_loc3_];
                     case "<=":
                        return this.vagues.nbMonstres <= _loc1_.currentMonsters[_loc3_];
                     case ">":
                        return this.vagues.nbMonstres > _loc1_.currentMonsters[_loc3_];
                     case "<":
                        return this.vagues.nbMonstres < _loc1_.currentMonsters[_loc3_];
                  }
               }
            }
         }
         return true;
      }
      
      public function verifier_epoque() : Boolean
      {
         var _loc1_:Object = null;
         if(!this.actif)
         {
            return false;
         }
         for each(_loc1_ in this.conditions)
         {
            if(_loc1_.age)
            {
               return this.persos.joueur[0].epoque == _loc1_.age;
            }
         }
         return true;
      }
      
      public function recuperer_evenement(param1:TimerEvent = null) : Object
      {
         var _loc3_:Object = null;
         var _loc4_:String = null;
         var _loc5_:Timer = null;
         var _loc6_:Object = null;
         var _loc7_:Object = null;
         var _loc8_:Object = null;
         var _loc9_:Object = null;
         var _loc10_:String = null;
         var _loc11_:int = 0;
         var _loc12_:int = 0;
         var _loc13_:int = 0;
         var _loc14_:int = 0;
         var _loc15_:int = 0;
         var _loc16_:int = 0;
         var _loc17_:int = 0;
         var _loc18_:Object = null;
         var _loc19_:String = null;
         var _loc20_:String = null;
         var _loc21_:String = null;
         var _loc22_:String = null;
         var _loc23_:String = null;
         var _loc24_:String = null;
         var _loc2_:Object = new Object();
         if(!param1 && !this.termine)
         {
            for each(_loc3_ in this.consequences)
            {
               for(_loc4_ in _loc3_)
               {
                  switch(_loc4_)
                  {
                     case "delay":
                        this.retarde = true;
                        _loc5_ = new Timer(_loc3_["delay"] * 1000,1);
                        _loc5_.addEventListener(TimerEvent.TIMER_COMPLETE,this.recuperer_evenement);
                        _loc5_.start();
                        return null;
                  }
               }
            }
         }
         for each(_loc3_ in this.consequences)
         {
            for(_loc4_ in _loc3_)
            {
               switch(_loc4_)
               {
                  case "game":
                     for each(_loc6_ in _loc3_["game"])
                     {
                        switch(_loc6_)
                        {
                           case "disable_ai":
                              this.persos.pause_ia();
                              break;
                           case "enable_ai":
                              this.persos.reprendre_ia();
                              break;
                           case "disable_ai_autoMove":
                              if(this.evenementsAuto)
                              {
                                 this.evenementsAuto.removeEventListener(TimerEvent.TIMER,this.evenement_auto);
                                 this.evenementsAuto.stop();
                                 this.evenementsAuto = null;
                              }
                              break;
                           case "enable_ai_autoMove":
                              this.evenementsAuto = new Timer(50);
                              this.evenementsAuto.addEventListener(TimerEvent.TIMER,this.evenement_auto);
                              this.evenementsAuto.start();
                              break;
                           case "disable_wave":
                              if(this.vagues)
                              {
                                 this.vagues.actif = false;
                              }
                              break;
                           case "enable_wave":
                              if(this.vagues)
                              {
                                 this.vagues.actif = true;
                              }
                              break;
                           case "disable_age":
                              this.persos.villes[0].actif = false;
                              break;
                           case "enable_age":
                              this.persos.villes[0].actif = true;
                              break;
                           case "enable_victory":
                              this.finPartie.nePasVerifierGagne = false;
                              break;
                           case "disable_victory":
                              this.finPartie.nePasVerifierGagne = true;
                              break;
                           case "enable_playerDeathLosing":
                              this.finPartie.perduSiJoueurMort = true;
                              break;
                           case "disable_playerDeathLosing":
                              this.finPartie.perduSiJoueurMort = false;
                              break;
                           case "victory":
                              this.persos.dispatchEvent(new FinPartieEvent(FinPartieEvent.GAGNER_DIRECT));
                              break;
                           default:
                              if(!(_loc6_ is String))
                              {
                                 if(_loc6_["killPlayer"] != undefined)
                                 {
                                    this.persos.persos[_loc6_["killPlayer"]].vie.score = 0;
                                 }
                                 else if(_loc6_["wave_direction"] != undefined)
                                 {
                                    this.vagues.direction = _loc6_["wave_direction"];
                                 }
                              }
                        }
                     }
               }
            }
         }
         for each(_loc3_ in this.consequences)
         {
            for(_loc4_ in _loc3_)
            {
               switch(_loc4_)
               {
                  case "actions":
                     if((this.actif || this.retarde) && !this.termine)
                     {
                        for each(_loc9_ in _loc3_["actions"])
                        {
                           for(_loc10_ in _loc9_)
                           {
                              switch(_loc10_)
                              {
                                 case "move":
                                    this.gerer_evenement_move(_loc9_);
                                    break;
                                 case "turn":
                                    switch(_loc9_["turn"]["orientation"])
                                    {
                                       case "up":
                                          this.persos.persos[_loc9_["turn"]["no"]].orientation = MessagePersoOrienter.HAUT;
                                          break;
                                       case "down":
                                          this.persos.persos[_loc9_["turn"]["no"]].orientation = MessagePersoOrienter.BAS;
                                          break;
                                       case "left":
                                          this.persos.persos[_loc9_["turn"]["no"]].orientation = MessagePersoOrienter.GAUCHE;
                                          break;
                                       case "right":
                                          this.persos.persos[_loc9_["turn"]["no"]].orientation = MessagePersoOrienter.DROITE;
                                    }
                                    this.persos.persos[_loc9_["turn"]["no"]].dispatchEvent(new PersosEvent(PersosEvent.ORIENTER));
                                    break;
                                 case "attackNearest":
                                    this.gerer_evenement_attaquer_proche(_loc9_);
                                    break;
                                 case "attack":
                                    _loc7_ = this.persos.persos[_loc9_["attack"]["nb"]];
                                    _loc8_ = this.persos.persos[_loc9_["attack"]["to"]];
                                    if(_loc8_)
                                    {
                                       _loc7_.attaquer(_loc8_);
                                       _loc7_.preparer_attaques();
                                    }
                                    break;
                                 case "speak":
                                    this.persos.persos[_loc9_["speak"]["no"]].parler_depuis_donnee(_loc9_["speak"]["text"]);
                                    break;
                                 case "speakToPlayer":
                                    if(_loc9_["speakToPlayer"]["text"][Donnees.langue]["D"])
                                    {
                                       this.persos.persos[_loc9_["speakToPlayer"]["no"]].parler(_loc9_["speakToPlayer"]["text"][Donnees.langue]["D"]);
                                    }
                                    else if(this.persos.joueur[0].feminin)
                                    {
                                       this.persos.persos[_loc9_["speakToPlayer"]["no"]].parler(_loc9_["speakToPlayer"]["text"][Donnees.langue]["F"]);
                                    }
                                    else
                                    {
                                       this.persos.persos[_loc9_["speakToPlayer"]["no"]].parler(_loc9_["speakToPlayer"]["text"][Donnees.langue]["M"]);
                                    }
                                    break;
                                 case "locate":
                                    if(_loc9_["locate"]["x"])
                                    {
                                       this.persos.persos[_loc9_["locate"]["no"]].x = _loc9_["locate"]["x"];
                                    }
                                    if(_loc9_["locate"]["y"])
                                    {
                                       this.persos.persos[_loc9_["locate"]["no"]].y = _loc9_["locate"]["y"];
                                    }
                                    this.actif = false;
                                    this.persos.persos[_loc9_["locate"]["no"]].dispatchEvent(new PersosEvent(PersosEvent.DEPLACER));
                                    this.actif = true;
                                    break;
                                 case "ai":
                                    this.gerer_evenement_ia(_loc9_);
                                    break;
                                 case "life":
                                    if(_loc9_["life"]["value"])
                                    {
                                       if(!this.persos.persos[_loc9_["life"]["no"]].vivant)
                                       {
                                          this.persos.persos[_loc9_["life"]["no"]].vie.score = this.persos.persos[_loc9_["life"]["no"]].vie.scoreMax;
                                          this.persos.persos[_loc9_["life"]["no"]].revivre();
                                       }
                                    }
                                    else if(this.persos.persos[_loc9_["life"]["no"]].vivant)
                                    {
                                       this.persos.persos[_loc9_["life"]["no"]].vie.score = 0;
                                       this.persos.persos[_loc9_["life"]["no"]].mourir();
                                    }
                                    break;
                                 case "destroy":
                                    this.gerer_evenement_suppression(_loc9_["destroy"]);
                                    break;
                                 case "destroyAll":
                                    this.gerer_evenement_suppression_tous(_loc9_["destroyAll"]);
                                    break;
                                 case "gain":
                                    if(Donnees.donnees[_loc9_["gain"]["id"]].type == "item")
                                    {
                                       if(_loc9_["gain"]["time"])
                                       {
                                          this.persos.persos[_loc9_["gain"]["no"]].gagner_objet_temporaire(_loc9_["gain"]["id"],_loc9_["gain"]["time"]);
                                       }
                                       else
                                       {
                                          this.persos.persos[_loc9_["gain"]["no"]].ajouter_objet(_loc9_["gain"]["id"]);
                                       }
                                    }
                                    break;
                                 case "create":
                                    if(_loc9_["create"]["many"])
                                    {
                                       _loc11_ = int(_loc9_["create"]["x"]);
                                       _loc12_ = int(_loc9_["create"]["y"]);
                                       _loc13_ = int(_loc9_["create"]["many"].number);
                                       _loc14_ = int(_loc9_["create"]["many"].step);
                                       if(_loc9_["create"].owner != undefined)
                                       {
                                          _loc15_ = int(this.persos.persos[_loc9_["create"].owner].ville);
                                          _loc16_ = int(this.persos.persos[_loc9_["create"].owner].equipe);
                                       }
                                       else
                                       {
                                          _loc15_ = -1;
                                          _loc16_ = -1;
                                       }
                                       _loc17_ = 0;
                                       while(_loc17_ < _loc13_)
                                       {
                                          this.persos.creer_perso(_loc9_["create"]["id"],true,_loc11_,_loc12_,_loc15_,_loc16_);
                                          _loc11_ += _loc14_;
                                          if((_loc17_ + 1) % _loc9_["create"]["many"].width == 0)
                                          {
                                             _loc12_ += _loc14_;
                                             _loc11_ = int(_loc9_["create"]["x"]);
                                          }
                                          if(_loc9_["create"]["orientation"])
                                          {
                                             switch(_loc9_["create"]["orientation"])
                                             {
                                                case "left":
                                                   this.persos.persos[Perso.prochaineId - 1].orientation = MessagePersoOrienter.GAUCHE;
                                                   break;
                                                case "right":
                                                   this.persos.persos[Perso.prochaineId - 1].orientation = MessagePersoOrienter.DROITE;
                                                   break;
                                                case "up":
                                                   this.persos.persos[Perso.prochaineId - 1].orientation = MessagePersoOrienter.HAUT;
                                                   break;
                                                case "down":
                                                   this.persos.persos[Perso.prochaineId - 1].orientation = MessagePersoOrienter.BAS;
                                             }
                                             this.persos.persos[Perso.prochaineId - 1].dispatchEvent(new PersosEvent(PersosEvent.ORIENTER));
                                          }
                                          if(_loc9_["create"]["order"])
                                          {
                                             this.persos.persos[Perso.prochaineId - 1].ordre = _loc9_["create"]["order"];
                                          }
                                          _loc17_++;
                                       }
                                       if(Donnees.donnees[_loc9_["create"]["id"]].type == "monster")
                                       {
                                          this.vagues.nbMonstres += _loc13_;
                                          this.vagues.nbMonstresActifs += _loc13_;
                                       }
                                    }
                                    else
                                    {
                                       this.persos.creer_perso(_loc9_["create"]["id"],true,_loc9_["create"]["x"],_loc9_["create"]["y"],-1,-1);
                                       if(_loc9_["create"]["orientation"])
                                       {
                                          switch(_loc9_["create"]["orientation"])
                                          {
                                             case "left":
                                                this.persos.persos[Perso.prochaineId - 1].orientation = MessagePersoOrienter.GAUCHE;
                                                break;
                                             case "right":
                                                this.persos.persos[Perso.prochaineId - 1].orientation = MessagePersoOrienter.DROITE;
                                                break;
                                             case "up":
                                                this.persos.persos[Perso.prochaineId - 1].orientation = MessagePersoOrienter.HAUT;
                                                break;
                                             case "down":
                                                this.persos.persos[Perso.prochaineId - 1].orientation = MessagePersoOrienter.BAS;
                                          }
                                          this.persos.persos[Perso.prochaineId - 1].dispatchEvent(new PersosEvent(PersosEvent.ORIENTER));
                                       }
                                       if(Donnees.donnees[_loc9_["create"]["id"]].type == "monster")
                                       {
                                          ++this.vagues.nbMonstres;
                                          ++this.vagues.nbMonstresActifs;
                                       }
                                    }
                                    if(!this.persos.iaActifs)
                                    {
                                       this.persos.pause_ia();
                                    }
                              }
                           }
                        }
                     }
                     break;
                  case "speech":
                     if(this.actif || this.retarde)
                     {
                        _loc2_["speech"] = new Array();
                        for each(_loc18_ in _loc3_[_loc4_])
                        {
                           if(_loc18_.name[this.langue] == "[playerName]")
                           {
                              _loc19_ = this.persos.joueur[0].nom;
                           }
                           else if(_loc18_.name[this.langue] is String)
                           {
                              _loc19_ = _loc18_.name[this.langue];
                           }
                           else
                           {
                              for(_loc23_ in _loc18_.name[this.langue])
                              {
                                 switch(_loc23_)
                                 {
                                    case "M":
                                       if(!this.persos.joueur[0].feminin)
                                       {
                                          _loc19_ = _loc18_.name[this.langue][_loc23_];
                                       }
                                       break;
                                    case "F":
                                       if(this.persos.joueur[0].feminin)
                                       {
                                          _loc19_ = _loc18_.name[this.langue][_loc23_];
                                       }
                                 }
                              }
                           }
                           for(_loc21_ in _loc18_.text[this.langue])
                           {
                              switch(_loc21_)
                              {
                                 case "M":
                                    if(!this.persos.joueur[0].feminin)
                                    {
                                       _loc20_ = _loc18_.text[this.langue][_loc21_];
                                    }
                                    break;
                                 case "F":
                                    if(this.persos.joueur[0].feminin)
                                    {
                                       _loc20_ = _loc18_.text[this.langue][_loc21_];
                                    }
                                    break;
                                 case "D":
                                    _loc20_ = _loc18_.text[this.langue][_loc21_];
                              }
                           }
                           if(_loc18_.display)
                           {
                              if(_loc18_.display is String)
                              {
                                 _loc22_ = _loc18_.display;
                              }
                              else
                              {
                                 for(_loc24_ in _loc18_.display)
                                 {
                                    switch(_loc24_)
                                    {
                                       case "M":
                                          if(!this.persos.joueur[0].feminin)
                                          {
                                             _loc22_ = _loc18_.display[_loc24_];
                                          }
                                          break;
                                       case "F":
                                          if(this.persos.joueur[0].feminin)
                                          {
                                             _loc22_ = _loc18_.display[_loc24_];
                                          }
                                    }
                                 }
                              }
                           }
                           else
                           {
                              _loc22_ = "";
                           }
                           _loc20_ = _loc20_.replace("[playerName]",this.persos.joueur[0].nom);
                           _loc20_ = _loc20_.replace("[playerRace]",Donnees.donnees[this.persos.joueur[0].race].name[this.langue]);
                           if(_loc18_.bubble != undefined)
                           {
                              if(_loc18_.display != undefined)
                              {
                                 _loc2_["speech"].push({
                                    "name":_loc19_,
                                    "text":_loc20_,
                                    "bubble":_loc18_.bubble,
                                    "display":_loc18_.display
                                 });
                              }
                              else
                              {
                                 _loc2_["speech"].push({
                                    "name":_loc19_,
                                    "text":_loc20_,
                                    "bubble":_loc18_.bubble
                                 });
                              }
                           }
                           else
                           {
                              _loc2_["speech"].push({
                                 "name":_loc19_,
                                 "text":_loc20_
                              });
                           }
                           if(_loc22_)
                           {
                              _loc2_["speech"][_loc2_["speech"].length - 1]["display"] = _loc22_;
                           }
                           if(_loc18_.bg)
                           {
                              _loc2_["speech"][_loc2_["speech"].length - 1]["bg"] = _loc18_.bg;
                           }
                           if(_loc18_.anim)
                           {
                              _loc2_["speech"][_loc2_["speech"].length - 1]["anim"] = _loc18_.anim;
                           }
                           if(_loc18_.tag)
                           {
                              _loc2_["speech"][_loc2_["speech"].length - 1]["tag"] = _loc18_.tag;
                           }
                           if(_loc18_.endTag)
                           {
                              _loc2_["speech"][_loc2_["speech"].length - 1]["endTag"] = _loc18_.endTag;
                           }
                           if(_loc18_.scrolling)
                           {
                              _loc2_["speech"][_loc2_["speech"].length - 1]["scrolling"] = _loc18_.scrolling;
                           }
                           if(_loc18_.color)
                           {
                              _loc2_["speech"][_loc2_["speech"].length - 1]["color"] = _loc18_.color;
                           }
                           if(_loc18_.music)
                           {
                              _loc2_["speech"][_loc2_["speech"].length - 1]["music"] = _loc18_.music;
                           }
                           if(_loc18_.sound)
                           {
                              _loc2_["speech"][_loc2_["speech"].length - 1]["sound"] = _loc18_.sound;
                           }
                        }
                     }
                     else if(this.termine)
                     {
                        for each(_loc18_ in _loc3_[_loc4_])
                        {
                           if(_loc18_.tag)
                           {
                              this.tags[_loc18_.tag] = true;
                           }
                           if(_loc18_.endTag)
                           {
                              this.tags[_loc18_.endTag] = true;
                           }
                        }
                     }
                     break;
                  case "goal":
                     _loc2_["goal"] = new Array();
                     _loc2_["goal"].push(_loc3_["goal"][this.langue]);
                     break;
                  case "message":
                     if(this.actif || this.retarde)
                     {
                        _loc2_["message"] = new Array();
                        _loc2_["message"].push(_loc3_["message"][this.langue]);
                     }
                     break;
                  case "help":
                     _loc2_["help"] = new Object();
                     _loc2_["help"].display = this.actif;
                     _loc2_["help"].title = _loc3_["help"]["title"][this.langue];
                     _loc2_["help"].text = _loc3_["help"]["text"][this.langue];
                     _loc2_["help"].image = _loc3_["help"]["image"];
                     break;
                  case "delay":
                     break;
                  default:
                     _loc2_[_loc4_] = new Array();
                     _loc2_[_loc4_].push(_loc3_[_loc4_]);
               }
            }
         }
         if(this.retarde)
         {
            dispatchEvent(new EvenementEvent(EvenementEvent.ENVOYER,_loc2_));
            this.retarde = false;
         }
         this.termine = this.donnees.finished = true;
         return _loc2_;
      }
      
      private function evenement_auto(param1:TimerEvent) : void
      {
         var _loc2_:Object = null;
         if(!Persos.enPause)
         {
            for each(_loc2_ in this.persos.persos)
            {
               if(_loc2_ is Artisan && !(_loc2_ is Joueur))
               {
                  if(Math.random() < 0.001)
                  {
                     IA.gerer_mobile(Mobile(_loc2_));
                  }
               }
            }
         }
      }
      
      public function gerer_evenement_move(param1:Object) : void
      {
         var _loc2_:Array = null;
         var _loc3_:int = 0;
         var _loc4_:Number = NaN;
         var _loc5_:int = 0;
         if(String(param1["move"]["no"]).indexOf("-") != -1)
         {
            _loc2_ = String(param1["move"]["no"]).split("-");
            _loc3_ = int(_loc2_[1]);
            _loc4_ = Number(param1["move"]["speed"]);
            _loc5_ = int(_loc2_[0]);
            while(_loc5_ <= _loc3_)
            {
               if(Boolean(this.persos.persos[_loc5_]) && this.persos.persos[_loc5_] is Mobile)
               {
                  this.gerer_evenement_move2(this.persos.persos[_loc5_],param1["move"]["x"],param1["move"]["y"],_loc4_);
               }
               _loc5_++;
            }
         }
         else if(Boolean(this.persos.persos[param1["move"]["no"]]) && this.persos.persos[param1["move"]["no"]] is Mobile)
         {
            this.gerer_evenement_move2(this.persos.persos[param1["move"]["no"]],param1["move"]["x"],param1["move"]["y"],Number(param1["move"]["speed"]));
         }
      }
      
      public function gerer_evenement_move2(param1:Mobile, param2:String = null, param3:String = null, param4:Number = NaN) : void
      {
         if(param1)
         {
            if(Boolean(param2) && (param2.indexOf("+") != -1 || param2.indexOf("-") != -1))
            {
               this.gerer_evenement_move3(param1,param1.x + int(param2),param3);
            }
            else if(param2)
            {
               this.gerer_evenement_move3(param1,int(param2),param3);
            }
            else
            {
               this.gerer_evenement_move3(param1,param1.x,param3);
            }
            if(!isNaN(param4))
            {
               param1.vitesse = param4;
            }
         }
      }
      
      public function gerer_evenement_move3(param1:Mobile, param2:int, param3:String = null) : void
      {
         if(Boolean(param3) && (param3.indexOf("+") != -1 || param3.indexOf("-") != -1))
         {
            param1.aller(param2,param1.y + int(param3));
         }
         else if(param3)
         {
            param1.aller(param2,int(param3));
         }
         else
         {
            param1.aller(param2,param1.y);
         }
      }
      
      private function gerer_evenement_attaquer_proche(param1:Object) : void
      {
         var _loc2_:Array = null;
         var _loc3_:int = 0;
         var _loc4_:int = 0;
         if(String(param1["attackNearest"]).indexOf("-") != -1)
         {
            _loc2_ = String(param1["attackNearest"]).split("-");
            _loc3_ = int(_loc2_[1]);
            _loc4_ = int(_loc2_[0]);
            while(_loc4_ <= _loc3_)
            {
               this.gerer_evenement_attaquer_proche2(this.persos.persos[_loc4_]);
               _loc4_++;
            }
         }
         else if(param1["attackNearest"] == "last")
         {
            this.gerer_evenement_attaquer_proche2(this.persos.persos[Perso.prochaineId - 1]);
         }
         else
         {
            this.gerer_evenement_attaquer_proche2(this.persos.persos[param1["attackNearest"]]);
         }
      }
      
      private function gerer_evenement_attaquer_proche2(param1:Object) : void
      {
         var _loc2_:Object = IA.trouver_ennemi_proche(param1);
         if(_loc2_)
         {
            param1.attaquer(_loc2_);
            param1.preparer_attaques();
         }
      }
      
      public function gerer_evenement_ia(param1:Object) : void
      {
         var _loc2_:Array = null;
         var _loc3_:int = 0;
         var _loc4_:Boolean = false;
         var _loc5_:int = 0;
         if(String(param1["ai"]["no"]).indexOf("-") != -1)
         {
            _loc2_ = String(param1["ai"]["no"]).split("-");
            _loc3_ = int(_loc2_[1]);
            _loc4_ = Boolean(param1["ai"]["value"]);
            _loc5_ = int(_loc2_[0]);
            while(_loc5_ <= _loc3_)
            {
               this.gerer_evenement_ia2(this.persos.persos[_loc5_],_loc4_);
               _loc5_++;
            }
         }
         else
         {
            this.gerer_evenement_ia2(this.persos.persos[param1["ai"]["no"]],param1["ai"]["value"]);
         }
      }
      
      public function gerer_evenement_ia2(param1:Mobile, param2:Boolean) : void
      {
         param1.ia = false;
         if(param1.iaTimer)
         {
            param1.arreter_ia();
         }
      }
      
      private function gerer_evenement_suppression(param1:Object, param2:Boolean = false) : void
      {
         var _loc3_:Array = null;
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         if(String(param1["no"]).indexOf("-") != -1)
         {
            _loc3_ = String(param1["no"]).split("-");
            _loc4_ = int(_loc3_[1]);
            _loc5_ = int(_loc3_[0]);
            while(_loc5_ <= _loc4_)
            {
               this.gerer_evenement_suppression2(this.persos.persos[_loc5_],param2);
               _loc5_++;
            }
         }
         else
         {
            this.gerer_evenement_suppression2(this.persos.persos[param1["no"]],param2);
         }
      }
      
      private function gerer_evenement_suppression2(param1:Vivant, param2:Boolean = false) : void
      {
         if(param1)
         {
            this.actif = false;
            if(param2)
            {
               param1.charger_vie(0);
            }
            else
            {
               this.persos.supprimer_perso(param1);
            }
            this.actif = true;
         }
      }
      
      private function gerer_evenement_suppression_tous(param1:String) : void
      {
         var _loc2_:Object = null;
         for each(_loc2_ in this.persos.persos)
         {
            if(_loc2_.race == param1)
            {
               this.actif = false;
               this.persos.supprimer_perso(_loc2_);
               this.actif = true;
            }
         }
      }
      
      public function detruire() : void
      {
         if(this.evenementsAuto)
         {
            this.evenementsAuto.removeEventListener(TimerEvent.TIMER,this.evenement_auto);
            this.evenementsAuto.stop();
            this.evenementsAuto = null;
         }
         this.conditions = null;
         this.consequences = null;
         this.persos = null;
      }
   }
}

