package aurora.jeuModele.evenements
{
   import aurora.jeuModele.Persos;
   import aurora.jeuModele.finPartie.FinPartie;
   import aurora.jeuModele.vagues.Vagues;
   import flash.events.EventDispatcher;
   import flash.utils.Dictionary;
   
   public class Evenements extends EventDispatcher
   {
      
      private var donnees:Object;
      
      private var evenements:Vector.<Evenement>;
      
      public var besoinVerifierPosition:Boolean;
      
      public var besoinVerifierRessources:Boolean;
      
      public var besoinVerifierMaison:Boolean;
      
      public var besoinVerifierObjets:Boolean;
      
      public var besoinVerifierPersos:Boolean;
      
      public var besoinVerifierNbPersos:Boolean;
      
      public var besoinVerifierNbMonstres:Boolean;
      
      public var besoinVerifierEpoque:Boolean;
      
      public var tags:Dictionary;
      
      public function Evenements()
      {
         super();
      }
      
      public function init(param1:Object, param2:Persos, param3:Vagues, param4:FinPartie, param5:String) : void
      {
         var _loc6_:Object = null;
         var _loc7_:Evenement = null;
         this.donnees = param1;
         this.evenements = new Vector.<Evenement>();
         this.tags = new Dictionary();
         for each(_loc6_ in param1)
         {
            this.evenements.push(new Evenement(_loc6_,param2,param3,param4,param5,this.tags));
            this.evenements[this.evenements.length - 1].addEventListener(EvenementEvent.ENVOYER,this.envoyer_evenement);
         }
         for each(_loc7_ in this.evenements)
         {
            if(_loc7_.besoinVerifierPosition)
            {
               this.besoinVerifierPosition = true;
            }
            if(_loc7_.besoinVerifierRessources)
            {
               this.besoinVerifierRessources = true;
            }
            if(_loc7_.besoinVerifierMaison)
            {
               this.besoinVerifierMaison = true;
            }
            if(_loc7_.besoinVerifierObjets)
            {
               this.besoinVerifierObjets = true;
            }
            if(_loc7_.besoinVerifierPersos)
            {
               this.besoinVerifierPersos = true;
            }
            if(_loc7_.besoinVerifierNbPersos)
            {
               this.besoinVerifierNbPersos = true;
            }
            if(_loc7_.besoinVerifierNbMonstres)
            {
               this.besoinVerifierNbMonstres = true;
            }
            if(_loc7_.besoinVerifierEpoque)
            {
               this.besoinVerifierEpoque = true;
            }
         }
         this.verifier_tout(true);
      }
      
      public function envoyer_evenement(param1:EvenementEvent) : void
      {
         dispatchEvent(new EvenementEvent(EvenementEvent.ENVOYER,param1.infos));
      }
      
      public function gerer_tag(param1:String) : void
      {
         this.tags[param1] = true;
         this.verifier_tout(false,true);
      }
      
      public function verifier_tout(param1:Boolean = false, param2:Boolean = false) : void
      {
         var _loc3_:Evenement = null;
         for each(_loc3_ in this.evenements)
         {
            if(_loc3_.verifier_tout(param1))
            {
               dispatchEvent(new EvenementEvent(EvenementEvent.ENVOYER,_loc3_.recuperer_evenement()));
               _loc3_.actif = false;
               this.donnees[this.evenements.indexOf(_loc3_)].enabled = false;
               if(!param1 && !param2)
               {
                  break;
               }
            }
         }
      }
      
      public function verifer_position(param1:* = null) : void
      {
         var _loc2_:Evenement = null;
         for each(_loc2_ in this.evenements)
         {
            if(_loc2_.besoinVerifierPosition && _loc2_.verifier_position())
            {
               dispatchEvent(new EvenementEvent(EvenementEvent.ENVOYER,_loc2_.recuperer_evenement()));
               _loc2_.actif = false;
               this.donnees[this.evenements.indexOf(_loc2_)].enabled = false;
               break;
            }
         }
      }
      
      public function verifier_ressources(param1:* = null) : void
      {
         var _loc2_:Evenement = null;
         for each(_loc2_ in this.evenements)
         {
            if(_loc2_.besoinVerifierRessources && _loc2_.verifier_ressources())
            {
               dispatchEvent(new EvenementEvent(EvenementEvent.ENVOYER,_loc2_.recuperer_evenement()));
               _loc2_.actif = false;
               this.donnees[this.evenements.indexOf(_loc2_)].enabled = false;
               break;
            }
         }
      }
      
      public function verifier_maison(param1:* = null) : void
      {
         var _loc2_:Evenement = null;
         for each(_loc2_ in this.evenements)
         {
            if(_loc2_.besoinVerifierMaison && _loc2_.verifier_maison())
            {
               dispatchEvent(new EvenementEvent(EvenementEvent.ENVOYER,_loc2_.recuperer_evenement()));
               _loc2_.actif = false;
               this.donnees[this.evenements.indexOf(_loc2_)].enabled = false;
               break;
            }
         }
      }
      
      public function verifier_objets(param1:* = null) : void
      {
         var _loc2_:Evenement = null;
         for each(_loc2_ in this.evenements)
         {
            if(_loc2_.besoinVerifierObjets && _loc2_.verifier_objets())
            {
               dispatchEvent(new EvenementEvent(EvenementEvent.ENVOYER,_loc2_.recuperer_evenement()));
               _loc2_.actif = false;
               this.donnees[this.evenements.indexOf(_loc2_)].enabled = false;
               break;
            }
         }
      }
      
      public function verifier_persos(param1:* = null) : void
      {
         var _loc2_:Evenement = null;
         for each(_loc2_ in this.evenements)
         {
            if(_loc2_.besoinVerifierPersos && _loc2_.verifier_persos() && _loc2_.verifier_tags())
            {
               dispatchEvent(new EvenementEvent(EvenementEvent.ENVOYER,_loc2_.recuperer_evenement()));
               _loc2_.actif = false;
               this.donnees[this.evenements.indexOf(_loc2_)].enabled = false;
               break;
            }
         }
      }
      
      public function verifier_nbPersos(param1:* = null) : void
      {
         var _loc2_:Evenement = null;
         for each(_loc2_ in this.evenements)
         {
            if(_loc2_.besoinVerifierNbPersos && _loc2_.verifier_nbPersos())
            {
               dispatchEvent(new EvenementEvent(EvenementEvent.ENVOYER,_loc2_.recuperer_evenement()));
               _loc2_.actif = false;
               this.donnees[this.evenements.indexOf(_loc2_)].enabled = false;
               break;
            }
         }
      }
      
      public function verifier_nbMonstres(param1:* = null) : void
      {
         var _loc2_:Evenement = null;
         for each(_loc2_ in this.evenements)
         {
            if(_loc2_.besoinVerifierNbMonstres && _loc2_.verifier_nbMonstres())
            {
               dispatchEvent(new EvenementEvent(EvenementEvent.ENVOYER,_loc2_.recuperer_evenement()));
               _loc2_.actif = false;
               this.donnees[this.evenements.indexOf(_loc2_)].enabled = false;
               break;
            }
         }
      }
      
      public function verifier_epoque(param1:* = null) : void
      {
         var _loc2_:Evenement = null;
         for each(_loc2_ in this.evenements)
         {
            if(_loc2_.besoinVerifierEpoque && _loc2_.verifier_epoque())
            {
               dispatchEvent(new EvenementEvent(EvenementEvent.ENVOYER,_loc2_.recuperer_evenement()));
               _loc2_.actif = false;
               this.donnees[this.evenements.indexOf(_loc2_)].enabled = false;
               break;
            }
         }
      }
      
      public function detruire() : void
      {
         while(this.evenements.length > 0)
         {
            this.evenements[0].removeEventListener(EvenementEvent.ENVOYER,this.envoyer_evenement);
            this.evenements[0] = null;
            this.evenements.splice(0,1);
         }
         this.evenements = null;
         this.donnees = null;
         this.tags = null;
      }
   }
}

