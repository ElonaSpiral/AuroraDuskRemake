package aurora.jeuModele
{
   import flash.events.Event;
   
   public class MessageEvent extends Event
   {
      
      public static const MESSAGE_DEBUG:String = "messageDebug";
      
      public static const MESSAGE_NORMAL:String = "messageNormal";
      
      public static const MESSAGE_ALERTE:String = "messageAlerte";
      
      public static const MESSAGE_IMPORTANT:String = "messageImportant";
      
      public var message:String;
      
      public var ville:int;
      
      public function MessageEvent(param1:String, param2:String, param3:int = -1)
      {
         this.message = param2;
         this.ville = param3;
         super(param1);
      }
      
      override public function clone() : Event
      {
         return new MessageEvent(type,this.message);
      }
   }
}

