package aurora
{
   import aurora.commun.SauvegardeGlobale;
   import aurora.jeuModele.BulleEvent;
   import aurora.jeuModele.Donnees;
   import aurora.jeuModele.IA;
   import aurora.jeuModele.InfosJoueur;
   import aurora.jeuModele.MessageEvent;
   import aurora.jeuModele.Persos;
   import aurora.jeuModele.PersosCreerEvent;
   import aurora.jeuModele.PersosEvent;
   import aurora.jeuModele.PersosEvent2;
   import aurora.jeuModele.Terrain;
   import aurora.jeuModele.evenements.EvenementEvent;
   import aurora.jeuModele.evenements.Evenements;
   import aurora.jeuModele.finPartie.FinPartie;
   import aurora.jeuModele.finPartie.FinPartieEvent;
   import aurora.jeuModele.multijoueur.Multijoueur;
   import aurora.jeuModele.perso.Animal;
   import aurora.jeuModele.perso.AnimationEvent;
   import aurora.jeuModele.perso.Artisan;
   import aurora.jeuModele.perso.Atelier;
   import aurora.jeuModele.perso.Aventurier;
   import aurora.jeuModele.perso.Batiment;
   import aurora.jeuModele.perso.BatimentCaserne;
   import aurora.jeuModele.perso.BatimentCentreVille;
   import aurora.jeuModele.perso.BatimentMobile;
   import aurora.jeuModele.perso.BatimentResurrection;
   import aurora.jeuModele.perso.BatimentRotatif;
   import aurora.jeuModele.perso.CibleEvent;
   import aurora.jeuModele.perso.Combattant;
   import aurora.jeuModele.perso.EffetEvent;
   import aurora.jeuModele.perso.Fondations;
   import aurora.jeuModele.perso.Joueur;
   import aurora.jeuModele.perso.Mobile;
   import aurora.jeuModele.perso.Mur;
   import aurora.jeuModele.perso.Perso;
   import aurora.jeuModele.perso.Projectile;
   import aurora.jeuModele.perso.RessourceMobile;
   import aurora.jeuModele.perso.RessourceTerrain;
   import aurora.jeuModele.perso.Serviteur;
   import aurora.jeuModele.perso.Soldat;
   import aurora.jeuModele.perso.SonEvent;
   import aurora.jeuModele.perso.Vivant;
   import aurora.jeuModele.perso.attaque.EffetArmeEvent;
   import aurora.jeuModele.perso.bestaire.BestiaireEvent;
   import aurora.jeuModele.perso.caracteristiquesPrimaires.CaracteristiquePrimaireEvent;
   import aurora.jeuModele.perso.caracteristiquesSecondaires.CaracteristiqueSecondaireEvent;
   import aurora.jeuModele.perso.competences.CompetenceEvent;
   import aurora.jeuModele.perso.joueur.JaugeEvent;
   import aurora.jeuModele.perso.joueur.JoueurEvent;
   import aurora.jeuModele.perso.objets.ObjetEvent;
   import aurora.jeuModele.perso.rechargements.RechargementJoueurEvent;
   import aurora.jeuModele.perso.ressources.RessourceEvent;
   import aurora.jeuModele.vagues.Vagues;
   import aurora.jeuModele.vagues.VaguesActualiserEvent;
   import aurora.jeuModele.vagues.VaguesCreerPersoEvent;
   import aurora.jeuModele.ville.EpoqueEvent;
   import aurora.messages.MessageDebug;
   import aurora.messages.MessagesInit;
   import aurora.messages.joueur.MessageJoueurUtiliserObjet;
   import aurora.messages.perso.MessagePersoActualiserEntier;
   import aurora.messages.perso.MessagePersoActualiserNombre;
   import aurora.messages.perso.MessagePersoActualiserTexte;
   import aurora.messages.perso.MessagePersoApparence;
   import aurora.messages.perso.MessagePersoBooleen;
   import aurora.messages.perso.MessagePersoCreer;
   import aurora.messages.perso.MessagePersoDeplacer;
   import aurora.messages.perso.MessagePersoOrienter;
   import aurora.messages.perso.MessagePersoRotation;
   import flash.concurrent.Mutex;
   import flash.display.Sprite;
   import flash.events.Event;
   import flash.events.TimerEvent;
   import flash.system.MessageChannel;
   import flash.system.Worker;
   import flash.utils.ByteArray;
   import flash.utils.Timer;
   import flash.utils.getTimer;
   
   public class MainJeu extends Sprite
   {
      
      public static var bacASable:Boolean = false;
      
      public static var sauvegardeEditeur:Boolean = SauvegardeGlobale.sauvegardeEditeur;
      
      public var persos:Persos;
      
      private var vagues:Vagues;
      
      private var finPartie:FinPartie;
      
      private var terrain:Terrain;
      
      private var infosJoueurs:Vector.<InfosJoueur>;
      
      private var ancienTemps:int;
      
      private var actif:Boolean;
      
      private var actionsJoueurBytes:ByteArray;
      
      private var actionsJoueurPointeur:ByteArray;
      
      private var creationsBytes:Vector.<ByteArray>;
      
      private var creationsPointeur:Vector.<ByteArray>;
      
      public var mutex:Mutex;
      
      private var positionsBytes:Vector.<ByteArray>;
      
      private var positionsPointeur:Vector.<ByteArray>;
      
      private var orientationBytes:Vector.<ByteArray>;
      
      private var orientationPointeur:Vector.<ByteArray>;
      
      private var decalageYBytes:Vector.<ByteArray>;
      
      private var decalageYPointeur:Vector.<ByteArray>;
      
      private var rotationBytes:Vector.<ByteArray>;
      
      private var rotationPointeur:Vector.<ByteArray>;
      
      private var actualiserVieBytes:Vector.<ByteArray>;
      
      private var actualiserViePointeur:Vector.<ByteArray>;
      
      private var actualiserEtapeBytes:Vector.<ByteArray>;
      
      private var actualiserEtapePointeur:Vector.<ByteArray>;
      
      private var messagePersoChoisirFabrication:MessageChannel;
      
      private var actualiserBulleBytes:Vector.<ByteArray>;
      
      private var actualiserBullePointeur:Vector.<ByteArray>;
      
      private var actualiserFantomeBytes:Vector.<ByteArray>;
      
      private var actualiserFantomePointeur:Vector.<ByteArray>;
      
      private var actualiserVisibleBytes:Vector.<ByteArray>;
      
      private var actualiserVisiblePointeur:Vector.<ByteArray>;
      
      private var apparenceBytes:Vector.<ByteArray>;
      
      private var apparencePointeur:Vector.<ByteArray>;
      
      private var couleurBytes:Vector.<ByteArray>;
      
      private var couleurPointeur:Vector.<ByteArray>;
      
      private var montureBytes:Vector.<ByteArray>;
      
      private var monturePointeur:Vector.<ByteArray>;
      
      private var animerBytes:Vector.<ByteArray>;
      
      private var animerPointeur:Vector.<ByteArray>;
      
      private var detruireBytes:Vector.<ByteArray>;
      
      private var detruirePointeur:Vector.<ByteArray>;
      
      private var effetsBytes:Vector.<ByteArray>;
      
      private var effetsPointeur:Vector.<ByteArray>;
      
      private var effetsArmeBytes:Vector.<ByteArray>;
      
      private var infosJoueurBytes:Vector.<ByteArray>;
      
      private var infosJoueurPointeur:Vector.<ByteArray>;
      
      private var dernierTempsPrincipale:int;
      
      private var pauseEnRetard:Boolean;
      
      public var config:Object;
      
      private var sauvegarde:ByteArray;
      
      private var nbDonnnees:int;
      
      private var evenements:Evenements;
      
      public var nbJoueurs:int = 1;
      
      private var timerSauverPerso:Timer;
      
      private var client:Boolean;
      
      public function MainJeu()
      {
         super();
         this.init();
      }
      
      private function init() : void
      {
         MessagesInit.init();
         Donnees.init();
         this.actionsJoueurBytes = Worker.current.getSharedProperty("actionsJoueurBytes");
         if(!this.actionsJoueurBytes)
         {
            this.actionsJoueurBytes = new ByteArray();
         }
         this.actionsJoueurPointeur = Worker.current.getSharedProperty("actionsJoueurPointeur");
         if(!this.actionsJoueurPointeur)
         {
            this.actionsJoueurPointeur = new ByteArray();
         }
         this.creationsBytes = new Vector.<ByteArray>();
         this.creationsPointeur = new Vector.<ByteArray>();
         this.creationsBytes.push(Worker.current.getSharedProperty("creationsBytes"));
         if(!this.creationsBytes.length)
         {
            this.creationsBytes.push(new ByteArray());
         }
         this.creationsPointeur.push(Worker.current.getSharedProperty("creationsPointeur"));
         if(!this.creationsPointeur.length)
         {
            this.creationsPointeur.push(new ByteArray());
         }
         this.mutex = Worker.current.getSharedProperty("mutex");
         if(!this.mutex)
         {
            this.mutex = new Mutex();
         }
         this.positionsBytes = new Vector.<ByteArray>();
         this.positionsPointeur = new Vector.<ByteArray>();
         this.positionsBytes.push(Worker.current.getSharedProperty("positionsBytes"));
         if(!this.positionsBytes.length)
         {
            this.positionsBytes.push(new ByteArray());
         }
         this.positionsPointeur.push(Worker.current.getSharedProperty("positionsPointeur"));
         if(!this.positionsPointeur.length)
         {
            this.positionsPointeur.push(new ByteArray());
         }
         this.orientationBytes = new Vector.<ByteArray>();
         this.orientationPointeur = new Vector.<ByteArray>();
         this.orientationBytes.push(Worker.current.getSharedProperty("orientationBytes"));
         if(!this.orientationBytes.length)
         {
            this.orientationBytes.push(new ByteArray());
         }
         this.orientationPointeur.push(Worker.current.getSharedProperty("orientationPointeur"));
         if(!this.orientationPointeur.length)
         {
            this.orientationPointeur.push(new ByteArray());
         }
         this.decalageYBytes = new Vector.<ByteArray>();
         this.decalageYPointeur = new Vector.<ByteArray>();
         this.decalageYBytes.push(Worker.current.getSharedProperty("decalageYBytes"));
         if(!this.decalageYBytes.length)
         {
            this.decalageYBytes.push(new ByteArray());
         }
         this.decalageYPointeur.push(Worker.current.getSharedProperty("decalageYPointeur"));
         if(!this.decalageYPointeur.length)
         {
            this.decalageYPointeur.push(new ByteArray());
         }
         this.rotationBytes = new Vector.<ByteArray>();
         this.rotationPointeur = new Vector.<ByteArray>();
         this.rotationBytes.push(Worker.current.getSharedProperty("rotationBytes"));
         if(!this.rotationBytes.length)
         {
            this.rotationBytes.push(new ByteArray());
         }
         this.rotationPointeur.push(Worker.current.getSharedProperty("rotationPointeur"));
         if(!this.rotationPointeur.length)
         {
            this.rotationPointeur.push(new ByteArray());
         }
         this.actualiserVieBytes = new Vector.<ByteArray>();
         this.actualiserViePointeur = new Vector.<ByteArray>();
         this.actualiserVieBytes.push(Worker.current.getSharedProperty("actualiserVieBytes"));
         if(!this.actualiserVieBytes.length)
         {
            this.actualiserVieBytes.push(new ByteArray());
         }
         this.actualiserViePointeur.push(Worker.current.getSharedProperty("actualiserViePointeur"));
         if(!this.actualiserViePointeur.length)
         {
            this.actualiserViePointeur.push(new ByteArray());
         }
         this.actualiserEtapeBytes = new Vector.<ByteArray>();
         this.actualiserEtapePointeur = new Vector.<ByteArray>();
         this.actualiserEtapeBytes.push(Worker.current.getSharedProperty("actualiserEtapeBytes"));
         if(!this.actualiserEtapeBytes.length)
         {
            this.actualiserEtapeBytes.push(new ByteArray());
         }
         this.actualiserEtapePointeur.push(Worker.current.getSharedProperty("actualiserEtapePointeur"));
         if(!this.actualiserEtapePointeur.length)
         {
            this.actualiserEtapePointeur.push(new ByteArray());
         }
         this.messagePersoChoisirFabrication = Worker.current.getSharedProperty("messagePersoChoisirFabrication") as MessageChannel;
         this.actualiserBulleBytes = new Vector.<ByteArray>();
         this.actualiserBullePointeur = new Vector.<ByteArray>();
         this.actualiserBulleBytes.push(Worker.current.getSharedProperty("actualiserBulleBytes"));
         if(!this.actualiserBulleBytes.length)
         {
            this.actualiserBulleBytes.push(new ByteArray());
         }
         this.actualiserBullePointeur.push(Worker.current.getSharedProperty("actualiserBullePointeur"));
         if(!this.actualiserBullePointeur.length)
         {
            this.actualiserBullePointeur.push(new ByteArray());
         }
         this.actualiserFantomeBytes = new Vector.<ByteArray>();
         this.actualiserFantomePointeur = new Vector.<ByteArray>();
         this.actualiserFantomeBytes.push(Worker.current.getSharedProperty("actualiserFantomeBytes"));
         if(!this.actualiserFantomeBytes.length)
         {
            this.actualiserFantomeBytes.push(new ByteArray());
         }
         this.actualiserFantomePointeur.push(Worker.current.getSharedProperty("actualiserFantomePointeur"));
         if(!this.actualiserFantomePointeur.length)
         {
            this.actualiserFantomePointeur.push(new ByteArray());
         }
         this.actualiserVisibleBytes = new Vector.<ByteArray>();
         this.actualiserVisiblePointeur = new Vector.<ByteArray>();
         this.actualiserVisibleBytes.push(Worker.current.getSharedProperty("actualiserVisibleBytes"));
         if(!this.actualiserVisibleBytes.length)
         {
            this.actualiserVisibleBytes.push(new ByteArray());
         }
         this.actualiserVisiblePointeur.push(Worker.current.getSharedProperty("actualiserVisiblePointeur"));
         if(!this.actualiserVisiblePointeur.length)
         {
            this.actualiserVisiblePointeur.push(new ByteArray());
         }
         this.apparenceBytes = new Vector.<ByteArray>();
         this.apparencePointeur = new Vector.<ByteArray>();
         this.apparenceBytes.push(Worker.current.getSharedProperty("apparenceBytes"));
         if(!this.apparenceBytes.length)
         {
            this.apparenceBytes.push(new ByteArray());
         }
         this.apparencePointeur.push(Worker.current.getSharedProperty("apparencePointeur"));
         if(!this.apparencePointeur.length)
         {
            this.apparencePointeur.push(new ByteArray());
         }
         this.couleurBytes = new Vector.<ByteArray>();
         this.couleurPointeur = new Vector.<ByteArray>();
         this.couleurBytes.push(Worker.current.getSharedProperty("couleurBytes"));
         if(!this.couleurBytes.length)
         {
            this.couleurBytes.push(new ByteArray());
         }
         this.couleurPointeur.push(Worker.current.getSharedProperty("couleurPointeur"));
         if(!this.couleurPointeur.length)
         {
            this.couleurPointeur.push(new ByteArray());
         }
         this.montureBytes = new Vector.<ByteArray>();
         this.monturePointeur = new Vector.<ByteArray>();
         this.montureBytes.push(Worker.current.getSharedProperty("montureBytes"));
         if(!this.montureBytes.length)
         {
            this.montureBytes.push(new ByteArray());
         }
         this.monturePointeur.push(Worker.current.getSharedProperty("monturePointeur"));
         if(!this.monturePointeur.length)
         {
            this.monturePointeur.push(new ByteArray());
         }
         this.animerBytes = new Vector.<ByteArray>();
         this.animerPointeur = new Vector.<ByteArray>();
         this.animerBytes.push(Worker.current.getSharedProperty("animerBytes"));
         if(!this.animerBytes.length)
         {
            this.animerBytes.push(new ByteArray());
         }
         this.animerPointeur.push(Worker.current.getSharedProperty("animerPointeur"));
         if(!this.animerPointeur.length)
         {
            this.animerPointeur.push(new ByteArray());
         }
         this.detruireBytes = new Vector.<ByteArray>();
         this.detruirePointeur = new Vector.<ByteArray>();
         this.detruireBytes.push(Worker.current.getSharedProperty("detruireBytes"));
         if(!this.detruireBytes.length)
         {
            this.detruireBytes.push(new ByteArray());
         }
         this.detruirePointeur.push(Worker.current.getSharedProperty("detruirePointeur"));
         if(!this.detruirePointeur.length)
         {
            this.detruirePointeur.push(new ByteArray());
         }
         this.effetsBytes = new Vector.<ByteArray>();
         this.effetsBytes.push(Worker.current.getSharedProperty("effetsBytes"));
         if(!this.effetsBytes.length)
         {
            this.effetsBytes.push(new ByteArray());
         }
         this.effetsPointeur = new Vector.<ByteArray>();
         this.effetsPointeur.push(Worker.current.getSharedProperty("effetsPointeur"));
         if(!this.effetsPointeur.length)
         {
            this.effetsPointeur.push(new ByteArray());
         }
         this.effetsArmeBytes = new Vector.<ByteArray>();
         this.effetsArmeBytes.push(Worker.current.getSharedProperty("effetsArmeBytes"));
         if(!this.effetsArmeBytes.length)
         {
            this.effetsArmeBytes.push(new ByteArray());
         }
         this.infosJoueurBytes = new Vector.<ByteArray>();
         this.infosJoueurPointeur = new Vector.<ByteArray>();
         this.infosJoueurBytes.push(Worker.current.getSharedProperty("infosJoueurBytes"));
         if(!this.infosJoueurBytes.length)
         {
            this.infosJoueurBytes.push(new ByteArray());
         }
         this.infosJoueurPointeur.push(Worker.current.getSharedProperty("infosJoueurPointeur"));
         if(!this.infosJoueurPointeur.length)
         {
            this.infosJoueurPointeur.push(new ByteArray());
         }
         addEventListener(Event.ENTER_FRAME,this.demarrer2);
      }
      
      private function demarrer2(param1:Event) : void
      {
         var _loc2_:Object = null;
         var _loc3_:* = 0;
         var _loc4_:int = 0;
         this.mutex.lock();
         this.actionsJoueurBytes.position = 0;
         this.actionsJoueurPointeur.position = 0;
         if(this.actionsJoueurPointeur.bytesAvailable)
         {
            _loc3_ = this.actionsJoueurPointeur.readInt();
            while(_loc3_ > 0)
            {
               _loc3_--;
               switch(this.actionsJoueurBytes.readByte())
               {
                  case 0:
                     this.config = this.actionsJoueurBytes.readObject();
                     this.nbDonnnees = this.actionsJoueurBytes.readInt();
                     if(this.actionsJoueurBytes.readBoolean())
                     {
                        this.sauvegarde = new ByteArray();
                        this.actionsJoueurBytes.readBytes(this.sauvegarde,0,this.actionsJoueurBytes.readInt());
                     }
                     break;
                  case 1:
                     Donnees.ajouter_donnee(this.actionsJoueurBytes.readObject());
                     break;
                  case 2:
                     Donnees.langue = String(this.actionsJoueurBytes.readUTF());
                     Donnees.finaliser();
                     break;
                  case 3:
                     Donnees.traduction = this.actionsJoueurBytes.readObject();
                     break;
                  case 4:
                     this.recevoir_donnee_terrain();
                     break;
                  case -1:
                     Multijoueur.init(this,this.actionsJoueurBytes.readUTF(),this.actionsJoueurBytes.readUTF(),this.actionsJoueurBytes.readInt(),this.actionsJoueurBytes.readBoolean(),this.actionsJoueurBytes.readInt());
                     break;
                  case -2:
                     Multijoueur.init_client(this,this.actionsJoueurBytes.readUTF(),this.actionsJoueurBytes.readInt());
                     this.client = true;
                     break;
                  case -3:
                     this.config = this.actionsJoueurBytes.readObject();
                     _loc4_ = 0;
                     while(_loc4_ < this.config.persos.length)
                     {
                        Multijoueur.envoyer_joueur(this.config.team ? int(this.config.team) : 0,this.config.persos[_loc4_]);
                        _loc4_++;
                     }
                     removeEventListener(Event.ENTER_FRAME,this.demarrer2);
                     this.actif = false;
                     addEventListener(Event.ENTER_FRAME,this.jouer_client);
                     this.pause2();
               }
            }
         }
         this.actionsJoueurBytes.clear();
         this.actionsJoueurPointeur.position = 0;
         this.actionsJoueurPointeur.writeInt(0);
         this.mutex.unlock();
         if(!this.config || !this.config.towns)
         {
            return;
         }
         if(Donnees.nbDonnees < this.nbDonnnees)
         {
            return;
         }
         if(Donnees.langue == "")
         {
            return;
         }
         if(!Donnees.traduction)
         {
            return;
         }
         removeEventListener(Event.ENTER_FRAME,this.demarrer2);
         if(bacASable)
         {
            Donnees.editer_mode_bac_a_sable();
         }
         if(!(Boolean(this.config.world) && Boolean(this.vagues)))
         {
            if(this.config.waves.count > 0)
            {
               this.vagues = new Vagues();
               this.vagues.init_data(this.config);
            }
            else
            {
               this.vagues = new Vagues();
               this.vagues.init_data(this.config);
            }
         }
         this.vagues.addEventListener(VaguesActualiserEvent.ACTUALISER_NB_MONSTRES,this.actualiser_nb_monstres);
         this.persos = new Persos(this.vagues);
         this.infosJoueurs = new Vector.<InfosJoueur>();
         this.infosJoueurs.push(new InfosJoueur(0,this.config.towns[0].equip,0,this.mutex,this.verifier_pointeur,this.creationsBytes[0],this.creationsPointeur[0],this.positionsBytes[0],this.positionsPointeur[0],this.orientationBytes[0],this.orientationPointeur[0],this.rotationBytes[0],this.rotationPointeur[0],this.actualiserVieBytes[0],this.actualiserViePointeur[0],this.actualiserEtapeBytes[0],this.actualiserEtapePointeur[0],this.decalageYBytes[0],this.decalageYPointeur[0],this.actualiserFantomeBytes[0],this.actualiserFantomePointeur[0],this.actualiserVisibleBytes[0],this.actualiserVisiblePointeur[0],this.apparenceBytes[0],this.apparencePointeur[0],this.couleurBytes[0],this.couleurPointeur[0],this.montureBytes[0],this.monturePointeur[0],this.infosJoueurBytes[0],this.infosJoueurPointeur[0],this.persos.persos));
         this.persos.addEventListener(PersosCreerEvent.CREER,this.creer_perso);
         this.persos.addEventListener(PersosEvent.DEPLACER,this.deplacer_perso);
         this.persos.addEventListener(PersosEvent.DECALER_Y,this.decaler_y_perso);
         this.persos.addEventListener(PersosEvent.ORIENTER,this.orienter_perso);
         this.persos.addEventListener(PersosEvent.ROTATION,this.rotation_perso);
         this.persos.addEventListener(PersosEvent.ACTUALISER_VIE,this.actualiser_vie_perso);
         this.persos.addEventListener(PersosEvent.ACTUALISER_ETAPE,this.actualiser_etape_perso);
         this.persos.addEventListener(PersosEvent2.CHOISIR_FABRICATION,this.actualiser_choixFabrication);
         this.persos.addEventListener(BulleEvent.MESSAGE,this.actualiser_bulle_perso);
         this.persos.addEventListener(PersosEvent.ACTUALISER_SOLDATS,this.actualiser_caserne_perso);
         this.persos.addEventListener(PersosEvent.FANTOME,this.fantome_perso);
         this.persos.addEventListener(PersosEvent.VISIBLE,this.visible_perso);
         this.persos.addEventListener(PersosEvent.ACTUALISER_APPARENCE,this.apparence_perso);
         this.persos.addEventListener(PersosEvent.ACTUALISER_COULEUR,this.couleur_perso);
         this.persos.addEventListener(PersosEvent.ACTUALISER_MONTURE,this.monture_perso);
         this.persos.addEventListener(AnimationEvent.ANIMER,this.animer_perso);
         this.persos.addEventListener(PersosEvent.EFFACER,this.detruire_perso);
         this.persos.addEventListener(PersosEvent.ROI_AUTRE,this.roi_perso);
         this.persos.addEventListener(PersosEvent.ROI_FIN,this.roi_perso);
         this.persos.addEventListener(FinPartieEvent.GAGNER_DIRECT,this.gagner_direct);
         this.persos.addEventListener(FinPartieEvent.VERIFIER_FIN_PARTIE,this.verifier_perdu);
         this.persos.addEventListener(VaguesActualiserEvent.ACTUALISER_NB_VILLAGEOIS,this.actualiser_nb_villageois);
         this.persos.addEventListener(VaguesActualiserEvent.ACTUALISER_NB_VILLAGEOIS_MAX,this.actualiser_nb_villageois_max);
         this.persos.addEventListener(VaguesActualiserEvent.ACTUALISER_NB_MONSTRES,this.actualiser_nb_monstres);
         this.persos.addEventListener(VaguesActualiserEvent.ACTUALISER_NB_SOLDATS,this.actualiser_nb_soldats);
         this.persos.addEventListener(VaguesActualiserEvent.ACTUALISER_NB_SOLDATS_MAX,this.actualiser_nb_soldats_max);
         this.persos.addEventListener(EffetEvent.EFFET,this.afficher_effet);
         this.persos.addEventListener(SonEvent.SON,this.jouer_son);
         this.persos.addEventListener(EffetArmeEvent.EFFET_ARME,this.afficher_effet_arme);
         this.persos.addEventListener(MessageEvent.MESSAGE_NORMAL,this.message_normal);
         this.persos.addEventListener(MessageEvent.MESSAGE_ALERTE,this.message_alerte);
         this.persos.addEventListener(MessageEvent.MESSAGE_IMPORTANT,this.message_important3);
         IA.init0();
         if(this.config.world)
         {
            this.charger(this.config.persos,this.config.towns,this.config.waves,this.config.world);
         }
         else
         {
            this.persos.init(this.config.persos,this.config.towns,this.config.land,this.config.waves,this.config.characters,this.config.prebuild,this.config.king,this.config.player);
         }
         IA.init(this.persos.persos,this.persos.ressourceTerrain,this.persos.montures,this.persos.combattants,this.persos.tresors,this.persos.batiments,this.persos.batimentsDefense,this.persos.batimentResurrection,this.persos.batimentCaserne,this.persos.centresVille,this.terrain);
         if(!this.config.world)
         {
            this.persos.init2(this.config.towns,this.config.characters,this.config.player);
         }
         this.joueur_changer_controle(0);
         if(Boolean(this.compteur_nombre_ennemis(0)) || Boolean(this.config.waves && this.config.waves.count > 0) || this.config.towns.length > 1)
         {
            this.persos.addEventListener(FinPartieEvent.VERIFIER_FIN_PARTIE,this.verifier_gagne);
         }
         this.persos.villes[this.persos.joueur[0].ville].addEventListener(EpoqueEvent.ACTUALISER_NO_EPOQUE,this.actualiser_numeroEpoque);
         this.persos.villes[this.persos.joueur[0].ville].addEventListener(EpoqueEvent.ACTUALISER_TEMPS,this.actualiser_tempsEpoque);
         this.persos.villes[this.persos.joueur[0].ville].recuperer_infos();
         this.vagues.addEventListener(VaguesActualiserEvent.ACTUALISER_NO_VAGUE,this.actualiser_numeroVague);
         this.vagues.addEventListener(VaguesActualiserEvent.ACTUALISER_NB_VAGUES,this.actualiser_nombreVagues);
         this.vagues.addEventListener(VaguesActualiserEvent.ACTUALISER_TEMPS,this.actualiser_tempsVague);
         this.vagues.addEventListener(VaguesCreerPersoEvent.CREER_PERSO,this.persos.ajouter_vague);
         this.vagues.init();
         this.finPartie = new FinPartie(this.vagues,this.persos.combattants,this.persos.batimentResurrection,this.persos.donjons);
         this.infosJoueurs[0].actualiser_vision(this.persos.joueur[0].x - 640,this.persos.joueur[0].y - 360,this.persos.joueur[0].x + 640,this.persos.joueur[0].y + 360);
         if(this.config.events)
         {
            this.evenements = new Evenements();
            this.evenements.addEventListener(EvenementEvent.ENVOYER,this.envoyer_evenement);
            this.evenements.init(this.config.events,this.persos,this.vagues,this.finPartie,Donnees.langue);
            if(this.evenements.besoinVerifierPosition)
            {
               this.persos.addEventListener(PersosEvent.DEPLACER,this.evenements.verifer_position);
            }
            if(this.evenements.besoinVerifierRessources)
            {
               for each(_loc2_ in this.persos.joueur[0].ressources)
               {
                  _loc2_.addEventListener(RessourceEvent.ACTUALISER_QUANTITE,this.evenements.verifier_ressources);
               }
            }
            if(this.evenements.besoinVerifierMaison)
            {
               this.persos.joueur[0].addEventListener(JoueurEvent.ACTUALISER_INFOS,this.evenements.verifier_maison);
            }
            if(this.evenements.besoinVerifierObjets)
            {
               this.persos.joueur[0].addEventListener(ObjetEvent.INFOS_OBJET,this.evenements.verifier_objets);
            }
            if(this.evenements.besoinVerifierPersos)
            {
               this.persos.addEventListener(PersosCreerEvent.CREER,this.evenements.verifier_persos);
               this.persos.addEventListener(PersosEvent.EFFACER,this.evenements.verifier_persos);
            }
            if(this.evenements.besoinVerifierNbPersos)
            {
               this.persos.addEventListener(VaguesActualiserEvent.ACTUALISER_NB_VILLAGEOIS,this.evenements.verifier_nbPersos);
            }
            if(this.evenements.besoinVerifierNbMonstres)
            {
               this.vagues.addEventListener(VaguesActualiserEvent.ACTUALISER_NB_MONSTRES,this.evenements.verifier_nbMonstres);
               this.persos.addEventListener(VaguesActualiserEvent.ACTUALISER_NB_MONSTRES,this.evenements.verifier_nbMonstres);
               this.persos.addEventListener(VaguesActualiserEvent.ACTUALISER_NB_VILLAGEOIS,this.evenements.verifier_nbMonstres);
            }
            if(this.evenements.besoinVerifierEpoque)
            {
               this.persos.villes[this.persos.joueur[0].equipe].addEventListener(EpoqueEvent.ACTUALISER_NO_EPOQUE,this.evenements.verifier_epoque);
            }
         }
         this.actif = false;
         addEventListener(Event.ENTER_FRAME,this.jouer);
         this.pause2();
         if(!this.config.general || !this.config.general.noSave)
         {
            this.timerSauverPerso = new Timer(300000);
            this.timerSauverPerso.addEventListener(TimerEvent.TIMER,this.sauvegarder_joueur);
            this.timerSauverPerso.start();
         }
      }
      
      private function envoyer_evenement(param1:EvenementEvent) : void
      {
         if(param1.infos)
         {
            this.mutex.lock();
            this.verifier_pointeur(this.infosJoueurBytes[0],this.infosJoueurPointeur[0]);
            this.infosJoueurBytes[0].writeByte(38);
            this.infosJoueurBytes[0].writeObject(param1.infos);
            this.mutex.unlock();
         }
      }
      
      private function jouer(param1:Event = null) : void
      {
         var _loc3_:int = 0;
         this.mutex.lock();
         this.actionsJoueurBytes.position = 0;
         this.actionsJoueurPointeur.position = 0;
         var _loc2_:int = this.actionsJoueurPointeur.readInt();
         this.gerer_actions_joueur(this.actionsJoueurBytes);
         this.actionsJoueurBytes.clear();
         this.actionsJoueurPointeur.position = 0;
         this.actionsJoueurPointeur.writeInt(0);
         this.mutex.unlock();
         if(this.actif && !this.pauseEnRetard)
         {
            _loc3_ = getTimer();
            Mobile.MULTIPLICATEUR_VITESSE = Math.max(1,Math.min((_loc3_ - this.ancienTemps) * 0.01,4)) * 1.1;
            if(_loc3_ - this.dernierTempsPrincipale > 250 && param1 != null)
            {
               this.pauseEnRetard = true;
               this.pause2();
            }
            this.ancienTemps = _loc3_;
         }
      }
      
      private function jouer_client(param1:Event = null) : void
      {
         this.mutex.lock();
         this.actionsJoueurBytes.position = 0;
         this.actionsJoueurPointeur.position = 0;
         var _loc2_:int = this.actionsJoueurPointeur.readInt();
         if(_loc2_ > 0)
         {
            Multijoueur.envoyer_actions(this.actionsJoueurBytes);
         }
         this.actionsJoueurBytes.clear();
         this.actionsJoueurPointeur.position = 0;
         this.actionsJoueurPointeur.writeInt(0);
         this.mutex.unlock();
      }
      
      private function jouer_serveur(param1:Event = null) : void
      {
         var _loc2_:int = 0;
         this.mutex.lock();
         var _loc3_:int = 1;
         while(_loc3_ < this.nbJoueurs)
         {
            this.creationsPointeur[_loc3_].position = 0;
            _loc2_ = this.creationsPointeur[_loc3_].readInt();
            if(_loc2_ > 0)
            {
               Multijoueur.envoyer_infos_client(_loc3_ - 1,-4,_loc2_,this.creationsBytes[_loc3_]);
               this.creationsBytes[_loc3_].clear();
               this.creationsPointeur[_loc3_].clear();
               this.creationsPointeur[_loc3_].writeInt(0);
            }
            this.positionsPointeur[_loc3_].position = 0;
            _loc2_ = this.positionsPointeur[_loc3_].readInt();
            if(_loc2_ > 0)
            {
               Multijoueur.envoyer_infos_client(_loc3_ - 1,-5,_loc2_,this.positionsBytes[_loc3_]);
               this.positionsBytes[_loc3_].clear();
               this.positionsPointeur[_loc3_].clear();
               this.positionsPointeur[_loc3_].writeInt(0);
            }
            this.orientationPointeur[_loc3_].position = 0;
            _loc2_ = this.orientationPointeur[_loc3_].readInt();
            if(_loc2_ > 0)
            {
               Multijoueur.envoyer_infos_client(_loc3_ - 1,-6,_loc2_,this.orientationBytes[_loc3_]);
               this.orientationBytes[_loc3_].clear();
               this.orientationPointeur[_loc3_].clear();
               this.orientationPointeur[_loc3_].writeInt(0);
            }
            this.rotationPointeur[_loc3_].position = 0;
            _loc2_ = this.rotationPointeur[_loc3_].readInt();
            if(_loc2_ > 0)
            {
               Multijoueur.envoyer_infos_client(_loc3_ - 1,-8,_loc2_,this.rotationBytes[_loc3_]);
               this.rotationBytes[_loc3_].clear();
               this.rotationPointeur[_loc3_].clear();
               this.rotationPointeur[_loc3_].writeInt(0);
            }
            this.actualiserViePointeur[_loc3_].position = 0;
            _loc2_ = this.actualiserViePointeur[_loc3_].readInt();
            if(_loc2_ > 0)
            {
               Multijoueur.envoyer_infos_client(_loc3_ - 1,-9,_loc2_,this.actualiserVieBytes[_loc3_]);
               this.actualiserVieBytes[_loc3_].clear();
               this.actualiserViePointeur[_loc3_].clear();
               this.actualiserViePointeur[_loc3_].writeInt(0);
            }
            this.actualiserEtapePointeur[_loc3_].position = 0;
            _loc2_ = this.actualiserEtapePointeur[_loc3_].readInt();
            if(_loc2_ > 0)
            {
               Multijoueur.envoyer_infos_client(_loc3_ - 1,-10,_loc2_,this.actualiserEtapeBytes[_loc3_]);
               this.actualiserEtapeBytes[_loc3_].clear();
               this.actualiserEtapePointeur[_loc3_].clear();
               this.actualiserEtapePointeur[_loc3_].writeInt(0);
            }
            this.actualiserBullePointeur[_loc3_].position = 0;
            _loc2_ = this.actualiserBullePointeur[_loc3_].readInt();
            if(_loc2_ > 0)
            {
               Multijoueur.envoyer_infos_client(_loc3_ - 1,-11,_loc2_,this.actualiserBulleBytes[_loc3_]);
               this.actualiserBulleBytes[_loc3_].clear();
               this.actualiserBullePointeur[_loc3_].clear();
               this.actualiserBullePointeur[_loc3_].writeInt(0);
            }
            this.actualiserFantomePointeur[_loc3_].position = 0;
            _loc2_ = this.actualiserFantomePointeur[_loc3_].readInt();
            if(_loc2_ > 0)
            {
               Multijoueur.envoyer_infos_client(_loc3_ - 1,-12,_loc2_,this.actualiserFantomeBytes[_loc3_]);
               this.actualiserFantomeBytes[_loc3_].clear();
               this.actualiserFantomePointeur[_loc3_].clear();
               this.actualiserFantomePointeur[_loc3_].writeInt(0);
            }
            this.actualiserVisiblePointeur[_loc3_].position = 0;
            _loc2_ = this.actualiserVisiblePointeur[_loc3_].readInt();
            if(_loc2_ > 0)
            {
               Multijoueur.envoyer_infos_client(_loc3_ - 1,-13,_loc2_,this.actualiserVisibleBytes[_loc3_]);
               this.actualiserVisibleBytes[_loc3_].clear();
               this.actualiserVisiblePointeur[_loc3_].clear();
               this.actualiserVisiblePointeur[_loc3_].writeInt(0);
            }
            this.apparencePointeur[_loc3_].position = 0;
            _loc2_ = this.apparencePointeur[_loc3_].readInt();
            if(_loc2_ > 0)
            {
               Multijoueur.envoyer_infos_client(_loc3_ - 1,-14,_loc2_,this.apparenceBytes[_loc3_]);
               this.apparenceBytes[_loc3_].clear();
               this.apparencePointeur[_loc3_].clear();
               this.apparencePointeur[_loc3_].writeInt(0);
            }
            this.couleurPointeur[_loc3_].position = 0;
            _loc2_ = this.couleurPointeur[_loc3_].readInt();
            if(_loc2_ > 0)
            {
               Multijoueur.envoyer_infos_client(_loc3_ - 1,-15,_loc2_,this.couleurBytes[_loc3_]);
               this.couleurBytes[_loc3_].clear();
               this.couleurPointeur[_loc3_].clear();
               this.couleurPointeur[_loc3_].writeInt(0);
            }
            this.monturePointeur[_loc3_].position = 0;
            _loc2_ = this.monturePointeur[_loc3_].readInt();
            if(_loc2_ > 0)
            {
               Multijoueur.envoyer_infos_client(_loc3_ - 1,-16,_loc2_,this.montureBytes[_loc3_]);
               this.montureBytes[_loc3_].clear();
               this.monturePointeur[_loc3_].clear();
               this.monturePointeur[_loc3_].writeInt(0);
            }
            this.decalageYPointeur[_loc3_].position = 0;
            _loc2_ = this.decalageYPointeur[_loc3_].readInt();
            if(_loc2_ > 0)
            {
               Multijoueur.envoyer_infos_client(_loc3_ - 1,-7,_loc2_,this.decalageYBytes[_loc3_]);
               this.decalageYBytes[_loc3_].clear();
               this.decalageYPointeur[_loc3_].clear();
               this.decalageYPointeur[_loc3_].writeInt(0);
            }
            this.animerPointeur[_loc3_].position = 0;
            _loc2_ = this.animerPointeur[_loc3_].readInt();
            if(_loc2_ > 0)
            {
               Multijoueur.envoyer_infos_client(_loc3_ - 1,-17,_loc2_,this.animerBytes[_loc3_]);
               this.animerBytes[_loc3_].clear();
               this.animerPointeur[_loc3_].clear();
               this.animerPointeur[_loc3_].writeInt(0);
            }
            this.detruirePointeur[_loc3_].position = 0;
            _loc2_ = this.detruirePointeur[_loc3_].readInt();
            if(_loc2_ > 0)
            {
               Multijoueur.envoyer_infos_client(_loc3_ - 1,-18,_loc2_,this.detruireBytes[_loc3_]);
               this.detruireBytes[_loc3_].clear();
               this.detruirePointeur[_loc3_].clear();
               this.detruirePointeur[_loc3_].writeInt(0);
            }
            this.effetsPointeur[_loc3_].position = 0;
            _loc2_ = this.effetsPointeur[_loc3_].readInt();
            if(_loc2_ > 0)
            {
               Multijoueur.envoyer_infos_client(_loc3_ - 1,-19,_loc2_,this.effetsBytes[_loc3_]);
               this.effetsBytes[_loc3_].clear();
               this.effetsPointeur[_loc3_].clear();
               this.effetsPointeur[_loc3_].writeInt(0);
            }
            if(this.effetsArmeBytes[_loc3_].length)
            {
               Multijoueur.envoyer_infos_client(_loc3_ - 1,-20,_loc2_,this.effetsArmeBytes[_loc3_]);
               this.effetsArmeBytes[_loc3_].clear();
            }
            this.infosJoueurPointeur[_loc3_].position = 0;
            _loc2_ = this.infosJoueurPointeur[_loc3_].readInt();
            if(_loc2_ > 0)
            {
               Multijoueur.envoyer_infos_client_direct(_loc3_ - 1,this.infosJoueurBytes[_loc3_]);
               this.infosJoueurBytes[_loc3_].clear();
               this.infosJoueurPointeur[_loc3_].clear();
               this.infosJoueurPointeur[_loc3_].writeInt(0);
            }
            _loc3_++;
         }
         this.mutex.unlock();
      }
      
      public function gerer_actions_joueur(param1:ByteArray, param2:int = 0) : void
      {
         var actionsJoueurBytes:ByteArray = null;
         var actionsJoueurBytes2:ByteArray = param1;
         var noJoueur:int = param2;
         try
         {
            if(actionsJoueurBytes2.bytesAvailable)
            {
               actionsJoueurBytes = new ByteArray();
               actionsJoueurBytes.writeBytes(actionsJoueurBytes2);
               actionsJoueurBytes.position = 0;
               while(actionsJoueurBytes.bytesAvailable)
               {
                  switch(actionsJoueurBytes.readByte())
                  {
                     case 0:
                        this.joueur_vision(actionsJoueurBytes.readInt(),actionsJoueurBytes.readInt(),actionsJoueurBytes.readInt(),actionsJoueurBytes.readInt(),noJoueur);
                        break;
                     case 4:
                        this.recevoir_donnee_terrain();
                        break;
                     case 5:
                        this.joueur_deplacer(actionsJoueurBytes.readInt(),actionsJoueurBytes.readInt(),actionsJoueurBytes.readInt(),noJoueur);
                        break;
                     case 6:
                        this.joueur_perso_aller(actionsJoueurBytes.readInt(),actionsJoueurBytes.readInt(),noJoueur);
                        break;
                     case 7:
                        this.joueur_rentrer_maison(actionsJoueurBytes.readInt());
                        break;
                     case 8:
                        this.joueur_demolir_maison(actionsJoueurBytes.readInt());
                        break;
                     case 9:
                        this.joueur_perso_creer(actionsJoueurBytes.readInt(),actionsJoueurBytes.readUTF());
                        break;
                     case 10:
                        this.joueur_objet_creer(actionsJoueurBytes.readInt(),actionsJoueurBytes.readInt(),actionsJoueurBytes.readInt(),actionsJoueurBytes.readBoolean(),actionsJoueurBytes.readInt());
                        break;
                     case 11:
                        this.joueur_attaquer_ennemi_proche(actionsJoueurBytes.readInt());
                        break;
                     case 12:
                        this.joueur_revivre(actionsJoueurBytes.readInt());
                        break;
                     case 13:
                        this.joueur_ressource_utiliser(actionsJoueurBytes.readInt(),actionsJoueurBytes.readUTF(),actionsJoueurBytes.readInt());
                        break;
                     case 14:
                        this.joueur_objet_utiliser(actionsJoueurBytes.readInt(),actionsJoueurBytes.readByte(),actionsJoueurBytes.readInt(),actionsJoueurBytes.readBoolean());
                        break;
                     case 15:
                        this.joueur_recuperer_caracteristiquePrimaire(actionsJoueurBytes.readInt(),actionsJoueurBytes.readUTF());
                        break;
                     case 16:
                        this.joueur_actualiser(actionsJoueurBytes.readInt());
                        break;
                     case 17:
                        this.joueur_verifier_emplacement(actionsJoueurBytes,noJoueur);
                        break;
                     case 18:
                        this.joueur_valider_emplacement(actionsJoueurBytes);
                        break;
                     case 19:
                        this.joueur_donner_ordre(actionsJoueurBytes);
                        break;
                     case 20:
                        this.joueur_mode_auto(actionsJoueurBytes.readInt(),actionsJoueurBytes.readBoolean());
                        break;
                     case 21:
                        this.joueur_detruire(actionsJoueurBytes.readInt(),actionsJoueurBytes.readInt());
                        break;
                     case 22:
                        this.actualiser_frame();
                        break;
                     case 23:
                        this.pause();
                        break;
                     case 24:
                        this.reprendre();
                        break;
                     case 25:
                        this.sauvegarder();
                        break;
                     case 26:
                        this.envoyer_vague();
                        break;
                     case 27:
                        if(noJoueur == 0)
                        {
                           this.quitter();
                        }
                        else
                        {
                           this.sauvegarder_joueurs(noJoueur);
                           this.quitter2(noJoueur);
                        }
                        break;
                     case 28:
                        this.joueur_changer_controle(actionsJoueurBytes.readInt(),true);
                        break;
                     case 29:
                        this.joueur_assister(actionsJoueurBytes.readInt(),actionsJoueurBytes.readInt(),noJoueur);
                        break;
                     case 30:
                        this.joueur_donner_objet(actionsJoueurBytes.readInt(),actionsJoueurBytes.readInt(),actionsJoueurBytes.readInt(),actionsJoueurBytes.readInt());
                        break;
                     case 31:
                        this.joueur_donner_ressource(actionsJoueurBytes.readInt(),actionsJoueurBytes.readInt(),actionsJoueurBytes.readUTF(),actionsJoueurBytes.readInt());
                        break;
                     case 32:
                        this.joueur_recuperer_caracteristiquePrimaire_Auto(actionsJoueurBytes.readInt(),actionsJoueurBytes.readUTF(),actionsJoueurBytes.readBoolean());
                        break;
                     case 33:
                        Multijoueur.ajouter_joueur(noJoueur,actionsJoueurBytes.readByte(),actionsJoueurBytes.readObject());
                        break;
                     case 34:
                        Multijoueur.quitter_joueur(noJoueur,actionsJoueurBytes.readInt());
                        break;
                     case 35:
                        this.joueur_choisir_ia(actionsJoueurBytes.readInt(),actionsJoueurBytes.readObject());
                        if(actionsJoueurBytes.readBoolean())
                        {
                           this.sauvegarder_joueurs(noJoueur);
                        }
                        break;
                     case 36:
                        this.evenements.gerer_tag(actionsJoueurBytes.readUTF());
                        break;
                     case 38:
                        Multijoueur.exclure_joueur(actionsJoueurBytes.readInt());
                        break;
                     case 39:
                        this.joueur_entrepot_ressource(actionsJoueurBytes.readBoolean(),actionsJoueurBytes.readInt(),actionsJoueurBytes.readUTF(),actionsJoueurBytes.readInt());
                        break;
                     case 40:
                        this.joueur_perso_reparer(actionsJoueurBytes.readInt(),actionsJoueurBytes.readInt(),noJoueur);
                        break;
                     case 41:
                        this.envoyer_message(actionsJoueurBytes.readInt(),actionsJoueurBytes.readUTF(),actionsJoueurBytes.readUTF());
                  }
               }
            }
         }
         catch(error:Error)
         {
         }
      }
      
      private function joueur_changer_controle(param1:int, param2:Boolean = false, param3:int = 0) : void
      {
         var _loc4_:Object = null;
         if(this.persos.joueur.length > param3 && Boolean(this.persos.joueur[param3].vie))
         {
            this.persos.joueur[param3].vie.removeEventListener(CaracteristiquePrimaireEvent.ACTUALISER_SCORE,this.actualiser_infosCaracteristiquePrimaireScore);
            this.persos.joueur[param3].vie.removeEventListener(CaracteristiquePrimaireEvent.ACTUALISER_SCORE_MAX,this.actualiser_infosCaracteristiquePrimaireScoreMax);
            for each(_loc4_ in this.persos.joueur[param3].caracteristiquesPrimaires)
            {
               _loc4_.removeEventListener(CaracteristiquePrimaireEvent.ACTUALISER_SCORE,this.actualiser_infosCaracteristiquePrimaireScore);
               _loc4_.removeEventListener(CaracteristiquePrimaireEvent.ACTUALISER_SCORE_BASE,this.actualiser_infosCaracteristiquePrimaireScoreBase);
               _loc4_.removeEventListener(CaracteristiquePrimaireEvent.ACTUALISER_RECUPERATION,this.actualiser_infosCaracteristiquePrimaireRecuparation);
               _loc4_.removeEventListener(CaracteristiquePrimaireEvent.ACTUALISER_SCORE_MAX,this.actualiser_infosCaracteristiquePrimaireScoreMax);
               _loc4_.removeEventListener(CaracteristiquePrimaireEvent.ACTUALISER_XP,this.actualiser_infosCaracteristiquePrimaireXp);
               _loc4_.removeEventListener(CaracteristiquePrimaireEvent.ACTUALISER_XP_MIN,this.actualiser_infosCaracteristiquePrimaireXpMin);
               _loc4_.removeEventListener(CaracteristiquePrimaireEvent.ACTUALISER_XP_MAX,this.actualiser_infosCaracteristiquePrimaireXpMax);
               _loc4_.removeEventListener(CaracteristiquePrimaireEvent.GAIN_NIVEAU,this.afficher_gain_niveau);
            }
            for each(_loc4_ in this.persos.joueur[param3].caracteristiquesSecondaires)
            {
               _loc4_.removeEventListener(CaracteristiqueSecondaireEvent.ACTUALISER_SCORE,this.actualiser_infosCaracteristiqueSecondaireScore);
               _loc4_.removeEventListener(CaracteristiqueSecondaireEvent.ACTUALISER_SCORE_BASE,this.actualiser_infosCaracteristiqueSecondaireScoreBase);
               _loc4_.removeEventListener(CaracteristiqueSecondaireEvent.ACTUALISER_XP,this.actualiser_infosCaracteristiqueSecondaireXp);
               _loc4_.removeEventListener(CaracteristiqueSecondaireEvent.ACTUALISER_XP_MIN,this.actualiser_infosCaracteristiqueSecondaireXpMin);
               _loc4_.removeEventListener(CaracteristiqueSecondaireEvent.ACTUALISER_XP_MAX,this.actualiser_infosCaracteristiqueSecondaireXpMax);
               _loc4_.removeEventListener(CaracteristiqueSecondaireEvent.GAIN_NIVEAU,this.afficher_gain_niveau);
            }
            for each(_loc4_ in this.persos.joueur[param3].competences)
            {
               _loc4_.removeEventListener(CompetenceEvent.ACTUALISER_SCORE_INFO,this.actualiser_infosCompetenceScore);
               _loc4_.removeEventListener(CompetenceEvent.ACTUALISER_SCORE_BASE,this.actualiser_infosCompetenceScoreBase);
               _loc4_.removeEventListener(CompetenceEvent.ACTUALISER_XP,this.actualiser_infosCompetenceXp);
               _loc4_.removeEventListener(CompetenceEvent.ACTUALISER_XP_MIN,this.actualiser_infosCompetenceXpMin);
               _loc4_.removeEventListener(CompetenceEvent.ACTUALISER_XP_MAX,this.actualiser_infosCompetenceXpMax);
               _loc4_.removeEventListener(CompetenceEvent.GAIN_NIVEAU,this.afficher_gain_niveau);
            }
            for each(_loc4_ in this.persos.joueur[param3].ressources)
            {
               _loc4_.removeEventListener(RessourceEvent.ACTUALISER_QUANTITE,this.actualiser_infosRessourceQuantite);
               _loc4_.removeEventListener(RessourceEvent.ACTUALISER_QUANTITE_MAX,this.actualiser_infosRessourceQuantiteMax);
            }
            this.persos.joueur[param3].removeEventListener(RessourceEvent.ACTUALISER_ENTREPOT,this.actualiser_infosEntrepotQuantite);
            this.persos.joueur[param3].removeEventListener(JaugeEvent.ACTUALISER_JAUGE_TRAVAIL,this.actualiser_jauge_travail);
            this.persos.joueur[param3].removeEventListener(ObjetEvent.INFOS_OBJET,this.objets_infos);
            this.persos.joueur[param3].rechargement.removeEventListener(RechargementJoueurEvent.ACTUALISER_TEMPS,this.rechargement_infos);
            this.persos.joueur[param3].removeEventListener(JoueurEvent.ACTUALISER_INFOS,this.actualiser_infos_joueur);
            this.persos.joueur[param3].removeEventListener(CibleEvent.ACTUALISER_CIBLE,this.actualiser_cible_joueur);
            this.persos.joueur[param3].removeEventListener(CibleEvent.ACTUALISER_QUANTITE,this.actualiser_cible_quantite_joueur);
            this.persos.joueur[param3].bestiaire.removeEventListener(BestiaireEvent.ACTUALISER_NOMBRE,this.actualiser_infosBestiaireNombre);
            this.persos.joueur[param3].removeEventListener(SonEvent.SON_TRAVAIL,this.jouer_son_travail);
         }
         if(this.persos.persos[param1])
         {
            this.persos.joueur[param3] = this.persos.persos[param1];
            this.persos.joueur[param3].vie.addEventListener(CaracteristiquePrimaireEvent.ACTUALISER_SCORE,this.actualiser_infosCaracteristiquePrimaireScore);
            this.persos.joueur[param3].vie.addEventListener(CaracteristiquePrimaireEvent.ACTUALISER_SCORE_MAX,this.actualiser_infosCaracteristiquePrimaireScoreMax);
            for each(_loc4_ in this.persos.joueur[param3].caracteristiquesPrimaires)
            {
               _loc4_.addEventListener(CaracteristiquePrimaireEvent.ACTUALISER_SCORE,this.actualiser_infosCaracteristiquePrimaireScore);
               _loc4_.addEventListener(CaracteristiquePrimaireEvent.ACTUALISER_SCORE_BASE,this.actualiser_infosCaracteristiquePrimaireScoreBase);
               _loc4_.addEventListener(CaracteristiquePrimaireEvent.ACTUALISER_RECUPERATION,this.actualiser_infosCaracteristiquePrimaireRecuparation);
               _loc4_.addEventListener(CaracteristiquePrimaireEvent.ACTUALISER_SCORE_MAX,this.actualiser_infosCaracteristiquePrimaireScoreMax);
               _loc4_.addEventListener(CaracteristiquePrimaireEvent.ACTUALISER_XP,this.actualiser_infosCaracteristiquePrimaireXp);
               _loc4_.addEventListener(CaracteristiquePrimaireEvent.ACTUALISER_XP_MIN,this.actualiser_infosCaracteristiquePrimaireXpMin);
               _loc4_.addEventListener(CaracteristiquePrimaireEvent.ACTUALISER_XP_MAX,this.actualiser_infosCaracteristiquePrimaireXpMax);
               _loc4_.addEventListener(CaracteristiquePrimaireEvent.GAIN_NIVEAU,this.afficher_gain_niveau);
            }
            for each(_loc4_ in this.persos.joueur[param3].caracteristiquesSecondaires)
            {
               _loc4_.addEventListener(CaracteristiqueSecondaireEvent.ACTUALISER_SCORE,this.actualiser_infosCaracteristiqueSecondaireScore);
               _loc4_.addEventListener(CaracteristiqueSecondaireEvent.ACTUALISER_SCORE_BASE,this.actualiser_infosCaracteristiqueSecondaireScoreBase);
               _loc4_.addEventListener(CaracteristiqueSecondaireEvent.ACTUALISER_XP,this.actualiser_infosCaracteristiqueSecondaireXp);
               _loc4_.addEventListener(CaracteristiqueSecondaireEvent.ACTUALISER_XP_MIN,this.actualiser_infosCaracteristiqueSecondaireXpMin);
               _loc4_.addEventListener(CaracteristiqueSecondaireEvent.ACTUALISER_XP_MAX,this.actualiser_infosCaracteristiqueSecondaireXpMax);
               _loc4_.addEventListener(CaracteristiqueSecondaireEvent.GAIN_NIVEAU,this.afficher_gain_niveau);
            }
            for each(_loc4_ in this.persos.joueur[param3].competences)
            {
               _loc4_.addEventListener(CompetenceEvent.ACTUALISER_SCORE_INFO,this.actualiser_infosCompetenceScore);
               _loc4_.addEventListener(CompetenceEvent.ACTUALISER_SCORE_BASE,this.actualiser_infosCompetenceScoreBase);
               _loc4_.addEventListener(CompetenceEvent.ACTUALISER_XP,this.actualiser_infosCompetenceXp);
               _loc4_.addEventListener(CompetenceEvent.ACTUALISER_XP_MIN,this.actualiser_infosCompetenceXpMin);
               _loc4_.addEventListener(CompetenceEvent.ACTUALISER_XP_MAX,this.actualiser_infosCompetenceXpMax);
               _loc4_.addEventListener(CompetenceEvent.GAIN_NIVEAU,this.afficher_gain_niveau);
            }
            for each(_loc4_ in this.persos.joueur[param3].ressources)
            {
               _loc4_.addEventListener(RessourceEvent.ACTUALISER_QUANTITE,this.actualiser_infosRessourceQuantite);
               _loc4_.addEventListener(RessourceEvent.ACTUALISER_QUANTITE_MAX,this.actualiser_infosRessourceQuantiteMax);
            }
            this.persos.joueur[param3].addEventListener(RessourceEvent.ACTUALISER_ENTREPOT,this.actualiser_infosEntrepotQuantite);
            this.persos.joueur[param3].addEventListener(JaugeEvent.ACTUALISER_JAUGE_TRAVAIL,this.actualiser_jauge_travail);
            this.persos.joueur[param3].addEventListener(ObjetEvent.INFOS_OBJET,this.objets_infos);
            this.persos.joueur[param3].rechargement.addEventListener(RechargementJoueurEvent.ACTUALISER_TEMPS,this.rechargement_infos);
            this.persos.joueur[param3].addEventListener(JoueurEvent.ACTUALISER_INFOS,this.actualiser_infos_joueur);
            this.persos.joueur[param3].addEventListener(CibleEvent.ACTUALISER_CIBLE,this.actualiser_cible_joueur);
            this.persos.joueur[param3].addEventListener(CibleEvent.ACTUALISER_QUANTITE,this.actualiser_cible_quantite_joueur);
            this.persos.joueur[param3].bestiaire.addEventListener(BestiaireEvent.ACTUALISER_NOMBRE,this.actualiser_infosBestiaireNombre);
            this.persos.joueur[param3].addEventListener(SonEvent.SON_TRAVAIL,this.jouer_son_travail);
            if(param2)
            {
               this.joueur_actualiser(param1);
            }
         }
      }
      
      private function joueur_assister(param1:int, param2:int, param3:int) : void
      {
         if(this.persos.persos[param2].travaille)
         {
            this.joueur_perso_aller(param1,this.persos.persos[param2].cibleTravail.id,param3);
         }
      }
      
      private function joueur_donner_objet(param1:int, param2:int, param3:int, param4:int) : void
      {
         if(Boolean(this.persos.persos[param1].vivant) && Boolean(this.persos.persos[param2].vivant))
         {
            this.persos.persos[param1].donner_objet(this.persos.persos[param2],param3,param4);
         }
      }
      
      private function joueur_donner_ressource(param1:int, param2:int, param3:String, param4:int) : void
      {
         if(Boolean(this.persos.persos[param1].vivant) && Boolean(this.persos.persos[param2].vivant))
         {
            this.persos.persos[param1].donner_ressource(this.persos.persos[param2],param3,param4);
         }
      }
      
      private function joueur_entrepot_ressource(param1:Boolean, param2:int, param3:String, param4:int) : void
      {
         if(this.persos.persos[param2].vivant)
         {
            this.persos.persos[param2].entrepot_ressource(param1,param3,param4);
         }
      }
      
      private function sauvegarder_joueur(param1:TimerEvent) : void
      {
         var _loc2_:int = 0;
         while(_loc2_ < this.nbJoueurs)
         {
            this.sauvegarder_joueurs(_loc2_);
            _loc2_++;
         }
      }
      
      private function sauvegarder_joueurs(param1:int) : void
      {
         var _loc2_:Object = null;
         for each(_loc2_ in this.persos.persos)
         {
            if(_loc2_ is Joueur)
            {
               if(_loc2_.noJoueur == param1)
               {
                  this.mutex.lock();
                  this.verifier_pointeur(this.infosJoueurBytes[param1],this.infosJoueurPointeur[param1]);
                  this.infosJoueurBytes[param1].writeByte(42);
                  this.infosJoueurBytes[param1].writeUTF(_loc2_.nom);
                  this.infosJoueurBytes[param1].writeObject(_loc2_.sauvegarder());
                  this.mutex.unlock();
               }
            }
         }
      }
      
      private function statistiques_joueurs(param1:int) : Object
      {
         var _loc3_:Object = null;
         var _loc2_:Object = new Object();
         if(this.persos)
         {
            for each(_loc3_ in this.persos.persos)
            {
               if(_loc3_ is Joueur)
               {
                  if(_loc3_.noJoueur == param1)
                  {
                     _loc2_[_loc3_.nom] = _loc3_.statistiques();
                  }
               }
            }
         }
         return _loc2_;
      }
      
      private function joueur_deplacer(param1:int, param2:int, param3:int, param4:int) : void
      {
         var _loc5_:Object = null;
         if(this.actif)
         {
            _loc5_ = this.persos.persos[param1];
            if(_loc5_ is Soldat || _loc5_ is BatimentMobile)
            {
               _loc5_.definir_origine(param2,param3,this.persos.joueur[0].x,this.persos.joueur[0].y);
               if(_loc5_.ordre == Soldat.ORDRE_PATROUILLE)
               {
                  _loc5_.ordre = Soldat.ORDRE_DEFENSE;
               }
               _loc5_.suitOrdre = true;
               this.persos.joueur[param4].parler_aleatoire("move");
            }
            _loc5_.aller(param2,param3);
         }
      }
      
      private function joueur_perso_aller(param1:int, param2:int, param3:int) : void
      {
         var _loc4_:Object = null;
         var _loc5_:Object = null;
         if(this.actif)
         {
            _loc4_ = this.persos.persos[param1];
            _loc5_ = this.persos.persos[param2];
            if(_loc4_.vivant)
            {
               if(_loc5_ is Vivant)
               {
                  if(_loc5_.equipe == _loc4_.equipe && _loc4_ is Artisan)
                  {
                     if(_loc5_ is Fondations)
                     {
                        _loc4_.aller_travailler(_loc5_);
                     }
                     else if(_loc5_ is Atelier)
                     {
                        if(_loc5_ is BatimentCentreVille)
                        {
                           _loc4_.aller_batiment(_loc5_);
                        }
                        else
                        {
                           _loc4_.aller_travailler(_loc5_);
                        }
                     }
                     else if(_loc5_ is Batiment || _loc5_ is BatimentMobile)
                     {
                        if(_loc5_.reparable)
                        {
                           _loc4_.aller_reparer(_loc5_);
                        }
                        else
                        {
                           _loc4_.aller_batiment(_loc5_);
                        }
                     }
                     else if(_loc5_ is Animal)
                     {
                        _loc4_.attaquer(_loc5_);
                        _loc4_.suitOrdre = true;
                     }
                     else if(_loc5_ is RessourceMobile)
                     {
                        _loc4_.aller_travailler(_loc5_);
                        if(_loc4_ is Serviteur)
                        {
                           _loc4_.memoriser_ordre_travail(_loc5_);
                        }
                     }
                  }
                  else if(_loc5_ is RessourceMobile && _loc4_ is Artisan)
                  {
                     _loc4_.aller_travailler(_loc5_);
                     if(_loc4_ is Serviteur)
                     {
                        _loc4_.memoriser_ordre_travail(_loc5_);
                     }
                  }
                  else if(_loc5_.equipe != _loc4_.equipe)
                  {
                     if(_loc4_ is Soldat || _loc4_ is BatimentMobile)
                     {
                        if(_loc5_ is Batiment)
                        {
                           this.persos.joueur[param3].parler_aleatoire("destroy");
                        }
                        else
                        {
                           this.persos.joueur[param3].parler_aleatoire("attack");
                        }
                     }
                     _loc4_.attaquer(_loc5_);
                     _loc4_.suitOrdre = true;
                  }
               }
               else if(_loc5_ is RessourceTerrain && _loc4_ is Artisan)
               {
                  _loc4_.aller_travailler(_loc5_);
                  if(_loc4_ is Serviteur)
                  {
                     _loc4_.memoriser_ordre_travail(_loc5_);
                  }
               }
            }
            else if(_loc5_ is BatimentResurrection && _loc4_ is Artisan)
            {
               _loc4_.aller_travailler(_loc5_);
            }
            _loc4_ = null;
            _loc5_ = null;
         }
      }
      
      private function joueur_perso_reparer(param1:int, param2:int, param3:int) : void
      {
         var _loc4_:Object = null;
         var _loc5_:Object = null;
         if(this.actif)
         {
            _loc4_ = this.persos.persos[param1];
            _loc5_ = this.persos.persos[param2];
            if(Boolean(_loc4_.vivant) && ((Boolean(_loc5_ is Batiment || _loc5_ is BatimentMobile)) && Boolean(_loc5_.reparable) || Boolean(_loc5_ is BatimentCentreVille) && Boolean(_loc5_.ameliorationEnCours)))
            {
               _loc4_.aller_reparer(_loc5_);
            }
            _loc4_ = null;
            _loc5_ = null;
         }
      }
      
      private function joueur_rentrer_maison(param1:int) : void
      {
         var _loc2_:Object = null;
         if(this.actif)
         {
            _loc2_ = this.persos.persos[param1];
            if(_loc2_.vivant)
            {
               _loc2_.rentrer_maison();
            }
            _loc2_ = null;
         }
      }
      
      private function joueur_demolir_maison(param1:int) : void
      {
         var _loc2_:Object = null;
         if(this.actif)
         {
            _loc2_ = this.persos.persos[param1];
            if(_loc2_.vivant)
            {
               _loc2_.demolir_maison();
            }
            _loc2_ = null;
         }
      }
      
      private function joueur_perso_creer(param1:int, param2:String) : void
      {
         var _loc3_:Object = null;
         if(this.actif)
         {
            _loc3_ = this.persos.persos[param1];
            if(_loc3_.vivant)
            {
               _loc3_.creer_perso(param2);
            }
            _loc3_ = null;
         }
      }
      
      private function joueur_objet_creer(param1:int, param2:int, param3:int, param4:Boolean, param5:int) : void
      {
         var _loc6_:Object = null;
         if(this.actif)
         {
            _loc6_ = this.persos.persos[param1];
            if(_loc6_.vivant)
            {
               if(param4)
               {
                  _loc6_.ameliorer_objet(param2,param3);
               }
               else if(param5 > 0)
               {
                  _loc6_.renforcer_objet(param2,param5);
               }
               else if(this.persos.persos[param2])
               {
                  _loc6_.creer_objet(this.persos.persos[param2],param3);
               }
            }
            _loc6_ = null;
         }
      }
      
      private function joueur_attaquer_ennemi_proche(param1:int) : void
      {
         var _loc2_:Object = null;
         var _loc3_:Object = null;
         if(this.actif)
         {
            _loc2_ = this.persos.persos[param1];
            if(_loc2_.vivant)
            {
               _loc3_ = IA.trouver_ennemi_proche(_loc2_);
               if(_loc3_)
               {
                  _loc2_.attaquer(_loc3_);
               }
               else
               {
                  _loc2_.parler(Donnees.traduction.noTarget);
               }
            }
            _loc2_ = null;
         }
      }
      
      private function joueur_revivre(param1:int) : void
      {
         var _loc2_:Object = null;
         var _loc3_:Boolean = false;
         if(this.actif)
         {
            _loc2_ = this.persos.persos[param1];
            if(!_loc2_.vivant)
            {
               _loc3_ = IA.trouver_batimentResurrection(Artisan(_loc2_));
               if(!_loc3_)
               {
                  _loc2_.parler(Donnees.traduction.noResurrect);
               }
            }
            _loc2_ = null;
         }
      }
      
      private function joueur_ressource_utiliser(param1:int, param2:String, param3:int) : void
      {
         var _loc4_:Object = null;
         if(this.actif)
         {
            _loc4_ = this.persos.persos[param1];
            if(_loc4_.vivant)
            {
               _loc4_.utiliser_ressource(param2,param3);
            }
            _loc4_ = null;
         }
      }
      
      private function joueur_objet_utiliser(param1:int, param2:int, param3:int, param4:Boolean) : void
      {
         var _loc5_:Object = null;
         if(this.actif)
         {
            _loc5_ = this.persos.persos[param1];
            if(_loc5_.vivant)
            {
               switch(param2)
               {
                  case MessageJoueurUtiliserObjet.ACTION_RACCOURCI:
                     _loc5_.utiliser_objet(param3);
                     break;
                  case MessageJoueurUtiliserObjet.ACTION_UTILISER:
                     _loc5_.utiliser_objet_equipe(param3,param4);
                     break;
                  case MessageJoueurUtiliserObjet.ACTION_RECYCLER:
                     _loc5_.recycler_objet(param3,param4);
                     break;
                  case MessageJoueurUtiliserObjet.ACTION_VENDRE:
                     _loc5_.vendre_objet(param3,param4);
                     break;
                  case MessageJoueurUtiliserObjet.ACTION_DETRUIRE:
                     _loc5_.supprimer_objet(param3);
               }
            }
            _loc5_ = null;
         }
      }
      
      private function joueur_recuperer_caracteristiquePrimaire(param1:int, param2:String) : void
      {
         var _loc3_:Object = null;
         if(this.actif)
         {
            _loc3_ = this.persos.persos[param1];
            if(_loc3_.vivant)
            {
               IA.recuperer_caracteristiquePrimaire(Artisan(_loc3_),param2);
            }
            _loc3_ = null;
         }
      }
      
      private function joueur_recuperer_caracteristiquePrimaire_Auto(param1:int, param2:String, param3:Boolean) : void
      {
         Joueur(this.persos.persos[param1]).caracteristiquesPrimaires[param2].recuperationAuto = param3;
      }
      
      private function joueur_actualiser(param1:int) : void
      {
         this.persos.persos[param1].recuperer_infos();
      }
      
      private function joueur_verifier_emplacement(param1:ByteArray, param2:int) : void
      {
         var _loc3_:Boolean = param1.readBoolean();
         var _loc4_:Vector.<int> = new Vector.<int>();
         var _loc5_:Vector.<int> = new Vector.<int>();
         var _loc6_:int = param1.readInt();
         var _loc7_:int = 0;
         while(_loc7_ < _loc6_)
         {
            _loc4_.push(param1.readInt());
            _loc5_.push(param1.readInt());
            _loc7_++;
         }
         var _loc8_:int = param1.readInt();
         var _loc9_:int = param1.readInt();
         if(this.actif)
         {
            this.infosJoueurs[param2].enregistrer_emplacementConstruction(_loc4_,_loc5_,_loc8_,_loc9_);
            this.verifier_emplacement2(param2);
            this.infosJoueurs[param2].addEventListener(Event.ENTER_FRAME,this.verifier_emplacement);
         }
         else
         {
            this.infosJoueurs[param2].removeEventListener(Event.ENTER_FRAME,this.verifier_emplacement);
         }
      }
      
      private function joueur_valider_emplacement(param1:ByteArray) : void
      {
         var _loc2_:Object = this.persos.persos[param1.readInt()];
         var _loc3_:int = param1.readInt();
         var _loc4_:int = 0;
         while(_loc4_ < _loc3_)
         {
            if(Boolean(_loc2_.vivant) && this.actif)
            {
               _loc2_.creer_persoXY(param1.readUTF(),param1.readInt(),param1.readInt());
            }
            else
            {
               param1.readUTF();
               param1.readInt();
               param1.readInt();
            }
            _loc4_++;
         }
         _loc2_ = null;
      }
      
      private function joueur_donner_ordre(param1:ByteArray) : void
      {
         var _loc5_:Object = null;
         var _loc2_:Object = this.persos.persos[param1.readInt()];
         var _loc3_:int = param1.readByte();
         var _loc4_:int = param1.readInt();
         var _loc6_:int = 0;
         while(_loc6_ < _loc4_)
         {
            if(this.actif)
            {
               _loc5_ = this.persos.persos[param1.readInt()];
               if(_loc5_ is Soldat || _loc5_ is BatimentMobile)
               {
                  _loc5_.ordre = _loc3_;
                  if(_loc3_ == 0)
                  {
                     _loc5_.maitre = _loc2_;
                  }
               }
            }
            else
            {
               param1.readInt();
            }
            _loc6_++;
         }
      }
      
      private function joueur_mode_auto(param1:int, param2:Boolean) : void
      {
         if(param2)
         {
            this.persos.persos[param1].ia = true;
            if(this.actif)
            {
               this.persos.persos[param1].init_ia(false);
            }
         }
         else
         {
            this.persos.persos[param1].ia = false;
            this.persos.persos[param1].arreter_ia();
         }
      }
      
      private function joueur_choisir_ia(param1:int, param2:Object) : void
      {
         this.persos.persos[param1].personnaliser_ia(param2);
      }
      
      private function joueur_detruire(param1:int, param2:int) : void
      {
         this.persos.perso_detruire_perso(this.persos.persos[param1],param2);
      }
      
      private function joueur_vision(param1:int, param2:int, param3:int, param4:int, param5:int = 0) : void
      {
         this.infosJoueurs[param5].actualiser_vision(param1,param2,param3,param4);
      }
      
      private function verifier_emplacement(param1:Event) : void
      {
         this.verifier_emplacement2(param1.currentTarget.noJoueur);
      }
      
      private function verifier_emplacement2(param1:int) : void
      {
         var _loc4_:int = 0;
         var _loc2_:ByteArray = new ByteArray();
         var _loc3_:int = 0;
         while(_loc3_ < this.infosJoueurs[param1].emplacementConstructionX.length)
         {
            _loc2_.writeBoolean(this.persos.joueur[param1].vivant && this.persos.position_libre_contruction(this.infosJoueurs[param1].emplacementConstructionLargeur,this.infosJoueurs[param1].emplacementConstructionHauteur,this.infosJoueurs[param1].emplacementConstructionX[_loc3_],this.infosJoueurs[param1].emplacementConstructionY[_loc3_]));
            _loc3_++;
         }
         if(this.infosJoueurs[param1].emplacementConstructionOk != _loc2_)
         {
            this.mutex.lock();
            this.verifier_pointeur(this.infosJoueurBytes[param1],this.infosJoueurPointeur[param1]);
            this.infosJoueurBytes[param1].writeByte(36);
            this.infosJoueurBytes[param1].writeInt(this.infosJoueurs[param1].emplacementConstructionX.length);
            _loc4_ = 0;
            while(_loc4_ < this.infosJoueurs[param1].emplacementConstructionX.length)
            {
               this.infosJoueurBytes[param1].writeBoolean(this.persos.joueur[param1].vivant && this.persos.position_libre_contruction(this.infosJoueurs[param1].emplacementConstructionLargeur,this.infosJoueurs[param1].emplacementConstructionHauteur,this.infosJoueurs[param1].emplacementConstructionX[_loc4_],this.infosJoueurs[param1].emplacementConstructionY[_loc4_]));
               _loc4_++;
            }
            this.mutex.unlock();
            this.infosJoueurs[param1].emplacementConstructionOk = _loc2_;
         }
      }
      
      private function recevoir_donnee_terrain() : void
      {
         var _loc1_:ByteArray = new ByteArray();
         this.actionsJoueurBytes.readBytes(_loc1_,0,this.actionsJoueurBytes.readInt());
         this.terrain = new Terrain();
         Terrain.init(_loc1_);
      }
      
      private function afficher_gain_niveau(param1:*) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         if(param1 is CompetenceEvent)
         {
            this.message_normal(Donnees.traduction.levelUpSkill + " \'" + String(Donnees.donnees[param1.id].name[Donnees.langue]).toUpperCase() + "\' (" + param1.score + ")",_loc2_);
         }
         else
         {
            this.message_normal(Donnees.traduction.levelUpCharacteristic + " \'" + String(Donnees.donnees[param1.id].name[Donnees.langue]).toUpperCase() + "\' (" + param1.score + ")",_loc2_);
         }
      }
      
      public function message_normal(param1:String, param2:int = 0) : void
      {
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[param2],this.infosJoueurPointeur[param2]);
         this.infosJoueurBytes[param2].writeByte(35);
         this.infosJoueurBytes[param2].writeByte(MessageDebug.MESSAGE_NORMAL);
         this.infosJoueurBytes[param2].writeUTF(param1);
         this.mutex.unlock();
      }
      
      public function message_normal_a_tous(param1:String) : void
      {
         var _loc2_:int = 0;
         while(_loc2_ < this.nbJoueurs)
         {
            this.message_normal(param1,_loc2_);
            _loc2_++;
         }
      }
      
      public function message_alerte(param1:MessageEvent) : void
      {
         this.mutex.lock();
         var _loc2_:int = 0;
         while(_loc2_ < this.nbJoueurs)
         {
            this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
            this.infosJoueurBytes[_loc2_].writeByte(35);
            this.infosJoueurBytes[_loc2_].writeByte(MessageDebug.MESSAGE_ALERTE);
            this.infosJoueurBytes[_loc2_].writeUTF(param1.message);
            _loc2_++;
         }
         this.mutex.unlock();
      }
      
      public function message_alerte2(param1:String, param2:int) : void
      {
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[param2],this.infosJoueurPointeur[param2]);
         this.infosJoueurBytes[param2].writeByte(35);
         this.infosJoueurBytes[param2].writeByte(MessageDebug.MESSAGE_ALERTE);
         this.infosJoueurBytes[param2].writeUTF(param1);
         this.mutex.unlock();
      }
      
      public function message_important(param1:String) : void
      {
         this.mutex.lock();
         var _loc2_:int = 0;
         while(_loc2_ < this.nbJoueurs)
         {
            this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
            this.infosJoueurBytes[_loc2_].writeByte(35);
            this.infosJoueurBytes[_loc2_].writeByte(MessageDebug.MESSAGE_IMPORTANT);
            this.infosJoueurBytes[_loc2_].writeUTF(param1);
            _loc2_++;
         }
         this.mutex.unlock();
      }
      
      public function message_important2(param1:String, param2:int) : void
      {
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[param2],this.infosJoueurPointeur[param2]);
         this.infosJoueurBytes[param2].writeByte(35);
         this.infosJoueurBytes[param2].writeByte(MessageDebug.MESSAGE_IMPORTANT);
         this.infosJoueurBytes[param2].writeUTF(param1);
         this.mutex.unlock();
      }
      
      public function message_important3(param1:MessageEvent) : void
      {
         this.mutex.lock();
         var _loc2_:int = 0;
         while(_loc2_ < this.nbJoueurs)
         {
            if(param1.ville == -1 || this.infosJoueurs[_loc2_].ville == param1.ville)
            {
               this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
               this.infosJoueurBytes[_loc2_].writeByte(35);
               this.infosJoueurBytes[_loc2_].writeByte(MessageDebug.MESSAGE_IMPORTANT);
               this.infosJoueurBytes[_loc2_].writeUTF(param1.message);
            }
            _loc2_++;
         }
         this.mutex.unlock();
      }
      
      private function verifier_pointeur(param1:ByteArray, param2:ByteArray) : void
      {
         var _loc3_:int = 0;
         param2.position = 0;
         if(param2.bytesAvailable)
         {
            _loc3_ = param2.readInt();
         }
         param2.position = 0;
         param2.writeInt(_loc3_ + 1);
         if(_loc3_ == 0)
         {
            param1.position = 0;
         }
      }
      
      private function creer_perso(param1:PersosCreerEvent) : void
      {
         var _loc4_:Boolean = false;
         var _loc5_:Boolean = false;
         var _loc6_:Boolean = false;
         var _loc7_:Boolean = false;
         var _loc8_:Boolean = false;
         var _loc9_:Boolean = false;
         var _loc2_:Perso = param1.perso;
         var _loc3_:String = Donnees.donnees[_loc2_.race].type;
         var _loc10_:int = 0;
         while(_loc10_ < this.nbJoueurs)
         {
            _loc4_ = _loc2_ is Vivant && Vivant(_loc2_).equipe != this.infosJoueurs[_loc10_].equipe || (_loc3_ == "monster" || _loc3_ == "landRessource" || _loc3_ == "animal" || _loc2_ is Fondations || _loc2_ is Batiment && _loc3_ != "wall") && !(_loc2_ is BatimentResurrection) && !(_loc2_ is Soldat);
            _loc5_ = (_loc2_ is Combattant || _loc2_ is Batiment || _loc2_ is Fondations) && Object(_loc2_).equipe != this.infosJoueurs[_loc10_].equipe;
            _loc6_ = _loc2_ is BatimentResurrection && BatimentResurrection(_loc2_).equipe == this.infosJoueurs[_loc10_].equipe;
            _loc7_ = (_loc2_ is BatimentMobile || _loc2_ is Mur) && Object(_loc2_).equipe == this.infosJoueurs[_loc10_].equipe;
            _loc8_ = ((_loc2_ is Soldat || _loc2_ is BatimentMobile) && !(_loc2_ is Artisan) || _loc2_ is Serviteur) && Combattant(_loc2_).equipe == this.infosJoueurs[_loc10_].equipe;
            _loc9_ = _loc2_ is Joueur && Joueur(_loc2_).noJoueur == _loc10_;
            if(this.infosJoueurs[_loc10_].dans_vision(_loc2_.x,_loc2_.y))
            {
               this.mutex.lock();
               this.verifier_pointeur(this.creationsBytes[_loc10_],this.creationsPointeur[_loc10_]);
               this.creationsBytes[_loc10_].writeInt(_loc2_.id);
               this.creationsBytes[_loc10_].writeUTF(_loc2_.race);
               this.creationsBytes[_loc10_].writeBoolean(_loc4_);
               this.creationsBytes[_loc10_].writeBoolean(_loc5_);
               this.creationsBytes[_loc10_].writeBoolean(_loc6_);
               this.creationsBytes[_loc10_].writeBoolean(_loc7_);
               this.creationsBytes[_loc10_].writeBoolean(_loc8_);
               this.creationsBytes[_loc10_].writeBoolean(_loc9_);
               this.creationsBytes[_loc10_].writeInt(_loc2_.x);
               this.creationsBytes[_loc10_].writeInt(_loc2_.y);
               if(Donnees.donnees[_loc2_.race].visualWidth)
               {
                  this.creationsBytes[_loc10_].writeInt(Donnees.donnees[_loc2_.race].visualWidth);
               }
               else
               {
                  this.creationsBytes[_loc10_].writeInt(_loc2_.largeur);
               }
               if(Donnees.donnees[_loc2_.race].visualHeight)
               {
                  this.creationsBytes[_loc10_].writeInt(Donnees.donnees[_loc2_.race].visualHeight);
               }
               else
               {
                  this.creationsBytes[_loc10_].writeInt(_loc2_.hauteur);
               }
               this.creationsBytes[_loc10_].writeUTF(param1.anim);
               this.creationsBytes[_loc10_].writeInt(-param1.decalageY);
               this.mutex.unlock();
               this.infosJoueurs[_loc10_].enregistrer_position(_loc2_.id);
            }
            else
            {
               this.infosJoueurs[_loc10_].enregistrer_message_creation(new MessagePersoCreer(_loc2_.id,_loc2_.race,_loc4_,_loc5_,_loc6_,_loc7_,_loc8_,_loc9_,_loc2_.x,_loc2_.y,Donnees.donnees[_loc2_.race].visualWidth ? int(Donnees.donnees[_loc2_.race].visualWidth) : _loc2_.largeur,Donnees.donnees[_loc2_.race].visualHeight ? int(Donnees.donnees[_loc2_.race].visualHeight) : _loc2_.hauteur,param1.anim,param1.decalageY));
            }
            if(_loc2_ is Joueur)
            {
               this.mutex.lock();
               this.verifier_pointeur(this.infosJoueurBytes[_loc10_],this.infosJoueurPointeur[_loc10_]);
               this.infosJoueurBytes[_loc10_].writeByte(47);
               this.infosJoueurBytes[_loc10_].writeInt(_loc2_.id);
               this.infosJoueurBytes[_loc10_].writeUTF(Joueur(_loc2_).nom);
               this.mutex.unlock();
            }
            _loc10_++;
         }
      }
      
      private function deplacer_perso(param1:PersosEvent) : void
      {
         var _loc2_:Object = param1.perso;
         var _loc3_:int = 0;
         while(_loc3_ < this.nbJoueurs)
         {
            if(this.infosJoueurs[_loc3_].dans_vision(_loc2_.x,_loc2_.y))
            {
               this.infosJoueurs[_loc3_].verifier_perso(_loc2_.id);
               this.mutex.lock();
               this.verifier_pointeur(this.positionsBytes[_loc3_],this.positionsPointeur[_loc3_]);
               this.positionsBytes[_loc3_].writeInt(_loc2_.id);
               this.positionsBytes[_loc3_].writeInt(Math.round(_loc2_.x));
               this.positionsBytes[_loc3_].writeInt(Math.round(_loc2_.y));
               this.positionsBytes[_loc3_].writeByte(_loc2_.pas);
               this.mutex.unlock();
               this.infosJoueurs[_loc3_].enregistrer_position(_loc2_.id);
            }
            else
            {
               this.infosJoueurs[_loc3_].enregistrer_message_deplacement(new MessagePersoDeplacer(_loc2_.id,Math.round(_loc2_.x),Math.round(_loc2_.y),_loc2_.pas));
            }
            _loc3_++;
         }
         _loc2_ = null;
      }
      
      private function decaler_y_perso(param1:PersosEvent) : void
      {
         var _loc2_:Mobile = param1.perso;
         var _loc3_:int = 0;
         while(_loc3_ < this.nbJoueurs)
         {
            if(this.infosJoueurs[_loc3_].dans_vision(_loc2_.x,_loc2_.y))
            {
               this.mutex.lock();
               this.verifier_pointeur(this.decalageYBytes[_loc3_],this.decalageYPointeur[_loc3_]);
               this.decalageYBytes[_loc3_].writeInt(_loc2_.id);
               this.decalageYBytes[_loc3_].writeByte(_loc2_.decalageY);
               this.mutex.unlock();
            }
            else
            {
               this.infosJoueurs[_loc3_].enregistrer_message_decalageY(new MessagePersoActualiserEntier(_loc2_.id,_loc2_.decalageY));
            }
            _loc3_++;
         }
         _loc2_ = null;
      }
      
      private function orienter_perso(param1:PersosEvent) : void
      {
         this.orienter_perso2(param1.perso);
      }
      
      private function orienter_perso2(param1:Mobile) : void
      {
         var _loc2_:int = 0;
         while(_loc2_ < this.nbJoueurs)
         {
            if(this.infosJoueurs[_loc2_].dans_vision(param1.x,param1.y))
            {
               this.mutex.lock();
               this.verifier_pointeur(this.orientationBytes[_loc2_],this.orientationPointeur[_loc2_]);
               this.orientationBytes[_loc2_].writeInt(param1.id);
               this.orientationBytes[_loc2_].writeByte(param1.orientation);
               this.mutex.unlock();
            }
            else
            {
               this.infosJoueurs[_loc2_].enregistrer_message_orientation(new MessagePersoOrienter(param1.id,param1.orientation));
            }
            _loc2_++;
         }
      }
      
      private function rotation_perso(param1:PersosEvent) : void
      {
         var _loc2_:Object = param1.perso;
         var _loc3_:int = 0;
         while(_loc3_ < this.nbJoueurs)
         {
            if(this.infosJoueurs[_loc3_].dans_vision(_loc2_.x,_loc2_.y))
            {
               this.mutex.lock();
               this.verifier_pointeur(this.rotationBytes[_loc3_],this.rotationPointeur[_loc3_]);
               this.rotationBytes[_loc3_].writeInt(_loc2_.id);
               this.rotationBytes[_loc3_].writeFloat(_loc2_.rotation);
               this.mutex.unlock();
            }
            else
            {
               this.infosJoueurs[_loc3_].enregistrer_message_rotation(new MessagePersoRotation(_loc2_.id,_loc2_.rotation));
            }
            _loc3_++;
         }
         _loc2_ = null;
      }
      
      private function actualiser_vie_perso(param1:PersosEvent) : void
      {
         var _loc2_:Vivant = param1.perso;
         var _loc3_:int = 0;
         while(_loc3_ < this.nbJoueurs)
         {
            if(this.infosJoueurs[_loc3_].dans_vision(_loc2_.x,_loc2_.y))
            {
               this.mutex.lock();
               this.verifier_pointeur(this.actualiserVieBytes[_loc3_],this.actualiserViePointeur[_loc3_]);
               this.actualiserVieBytes[_loc3_].writeInt(_loc2_.id);
               this.actualiserVieBytes[_loc3_].writeFloat(_loc2_.vie.coef);
               this.mutex.unlock();
            }
            else
            {
               this.infosJoueurs[_loc3_].enregistrer_message_vie(new MessagePersoActualiserNombre(_loc2_.id,_loc2_.vie.coef));
            }
            _loc3_++;
         }
         _loc2_ = null;
      }
      
      private function actualiser_etape_perso(param1:PersosEvent) : void
      {
         var _loc2_:Object = param1.perso;
         var _loc3_:int = 0;
         while(_loc3_ < this.nbJoueurs)
         {
            if(this.infosJoueurs[_loc3_].dans_vision(_loc2_.x,_loc2_.y))
            {
               this.mutex.lock();
               this.verifier_pointeur(this.actualiserEtapeBytes[_loc3_],this.actualiserEtapePointeur[_loc3_]);
               this.actualiserEtapeBytes[_loc3_].writeInt(_loc2_.id);
               this.actualiserEtapeBytes[_loc3_].writeByte(_loc2_.etape);
               this.mutex.unlock();
            }
            else
            {
               this.infosJoueurs[_loc3_].enregistrer_message_etape(new MessagePersoActualiserEntier(_loc2_.id,_loc2_.etape));
            }
            _loc3_++;
         }
         _loc2_ = null;
      }
      
      private function actualiser_choixFabrication(param1:PersosEvent2) : void
      {
         var _loc2_:Object = param1.perso;
         var _loc3_:int = param1.noJoueur;
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc3_],this.infosJoueurPointeur[_loc3_]);
         this.infosJoueurBytes[_loc3_].writeByte(40);
         this.infosJoueurBytes[_loc3_].writeInt(_loc2_.id);
         this.infosJoueurBytes[_loc3_].writeUTF(_loc2_.race);
         this.mutex.unlock();
         _loc2_ = null;
      }
      
      private function actualiser_bulle_perso(param1:BulleEvent) : void
      {
         var _loc2_:Object = param1.perso;
         var _loc3_:int = 0;
         while(_loc3_ < this.nbJoueurs)
         {
            if(this.infosJoueurs[_loc3_].dans_vision(_loc2_.x,_loc2_.y))
            {
               this.mutex.lock();
               this.verifier_pointeur(this.actualiserBulleBytes[_loc3_],this.actualiserBullePointeur[_loc3_]);
               this.actualiserBulleBytes[_loc3_].writeInt(_loc2_.id);
               this.actualiserBulleBytes[_loc3_].writeUTF(param1.message);
               this.mutex.unlock();
            }
            _loc3_++;
         }
         _loc2_ = null;
      }
      
      private function actualiser_caserne_perso(param1:PersosEvent) : void
      {
         var _loc2_:Object = param1.perso;
         var _loc3_:int = 0;
         while(_loc3_ < this.nbJoueurs)
         {
            if(this.infosJoueurs[_loc3_].dans_vision(_loc2_.x,_loc2_.y))
            {
               this.mutex.lock();
               this.verifier_pointeur(this.infosJoueurBytes[_loc3_],this.infosJoueurPointeur[_loc3_]);
               this.infosJoueurBytes[_loc3_].writeByte(41);
               this.infosJoueurBytes[_loc3_].writeInt(_loc2_.id);
               this.infosJoueurBytes[_loc3_].writeInt(_loc2_.garnison.length);
               this.mutex.unlock();
            }
            else
            {
               this.infosJoueurs[_loc3_].enregistrer_message_caserne(new MessagePersoActualiserEntier(_loc2_.id,_loc2_.garnison.length));
            }
            _loc3_++;
         }
         _loc2_ = null;
      }
      
      private function fantome_perso(param1:PersosEvent) : void
      {
         var _loc2_:Object = param1.perso;
         var _loc3_:int = 0;
         while(_loc3_ < this.nbJoueurs)
         {
            if(_loc2_.equipe == this.persos.joueur[_loc3_].equipe)
            {
               if(_loc2_ == this.persos.joueur[_loc3_])
               {
                  if(_loc2_.fantome)
                  {
                     if(this.persos.joueur[_loc3_].feminin)
                     {
                        this.message_alerte2(Donnees.traduction.deathF,_loc3_);
                     }
                     else
                     {
                        this.message_alerte2(Donnees.traduction.deathM,_loc3_);
                     }
                  }
                  else if(this.persos.joueur[_loc3_].feminin)
                  {
                     this.message_important2(Donnees.traduction.resurrectionF,_loc3_);
                  }
                  else
                  {
                     this.message_important2(Donnees.traduction.resurrectionM,_loc3_);
                  }
               }
               if(this.infosJoueurs[_loc3_].dans_vision(_loc2_.x,_loc2_.y))
               {
                  this.mutex.lock();
                  this.verifier_pointeur(this.actualiserFantomeBytes[_loc3_],this.actualiserFantomePointeur[_loc3_]);
                  this.actualiserFantomeBytes[_loc3_].writeInt(_loc2_.id);
                  this.actualiserFantomeBytes[_loc3_].writeBoolean(_loc2_.fantome);
                  this.mutex.unlock();
               }
               else
               {
                  this.infosJoueurs[_loc3_].enregistrer_message_fantome(new MessagePersoBooleen(_loc2_.id,_loc2_.fantome));
               }
            }
            else
            {
               this.visible_perso2(_loc2_,_loc3_,!_loc2_.fantome);
            }
            _loc3_++;
         }
         _loc2_ = null;
      }
      
      private function visible_perso(param1:PersosEvent) : void
      {
         var _loc3_:Boolean = false;
         var _loc2_:Object = param1.perso;
         var _loc4_:int = 0;
         while(_loc4_ < this.nbJoueurs)
         {
            if(_loc2_.equipe == this.infosJoueurs[_loc4_].equipe)
            {
               _loc3_ = Boolean(_loc2_.visible);
            }
            else
            {
               _loc3_ = Boolean(_loc2_.visible) && (_loc2_ is Artisan ? !_loc2_.fantome : true);
            }
            this.visible_perso2(_loc2_,_loc4_,_loc3_);
            _loc4_++;
         }
         _loc2_ = null;
      }
      
      private function visible_perso2(param1:Object, param2:int, param3:Boolean) : void
      {
         if(this.infosJoueurs[param2].dans_vision(param1.x,param1.y))
         {
            this.mutex.lock();
            this.verifier_pointeur(this.actualiserVisibleBytes[param2],this.actualiserVisiblePointeur[param2]);
            this.actualiserVisibleBytes[param2].writeInt(param1.id);
            this.actualiserVisibleBytes[param2].writeBoolean(param3);
            this.mutex.unlock();
         }
         else
         {
            this.infosJoueurs[param2].enregistrer_message_visible(new MessagePersoBooleen(param1.id,param3));
         }
      }
      
      private function apparence_perso(param1:PersosEvent) : void
      {
         var _loc2_:Object = param1.perso;
         var _loc3_:int = 0;
         while(_loc3_ < this.nbJoueurs)
         {
            if(_loc2_ is Aventurier || _loc2_.equipe == this.infosJoueurs[_loc3_].equipe)
            {
               if(this.infosJoueurs[_loc3_].dans_vision(_loc2_.x,_loc2_.y))
               {
                  this.mutex.lock();
                  this.verifier_pointeur(this.apparenceBytes[_loc3_],this.apparencePointeur[_loc3_]);
                  this.apparenceBytes[_loc3_].writeInt(_loc2_.id);
                  this.apparenceBytes[_loc3_].writeObject(_loc2_.apparence);
                  this.mutex.unlock();
               }
               else
               {
                  this.infosJoueurs[_loc3_].enregistrer_message_apparence(new MessagePersoApparence(_loc2_.id,_loc2_.apparence));
               }
            }
            _loc3_++;
         }
         _loc2_ = null;
      }
      
      private function couleur_perso(param1:PersosEvent) : void
      {
         var _loc2_:Object = param1.perso;
         var _loc3_:int = 0;
         while(_loc3_ < this.nbJoueurs)
         {
            if(this.infosJoueurs[_loc3_].dans_vision(_loc2_.x,_loc2_.y))
            {
               this.mutex.lock();
               this.verifier_pointeur(this.couleurBytes[_loc3_],this.couleurPointeur[_loc3_]);
               this.couleurBytes[_loc3_].writeInt(_loc2_.id);
               this.couleurBytes[_loc3_].writeInt(_loc2_.couleur);
               this.mutex.unlock();
            }
            else
            {
               this.infosJoueurs[_loc3_].enregistrer_message_couleur(new MessagePersoActualiserEntier(_loc2_.id,_loc2_.couleur));
            }
            _loc3_++;
         }
         _loc2_ = null;
      }
      
      private function monture_perso(param1:PersosEvent) : void
      {
         var _loc2_:Object = param1.perso;
         var _loc3_:int = 0;
         while(_loc3_ < this.nbJoueurs)
         {
            if(this.infosJoueurs[_loc3_].dans_vision(_loc2_.x,_loc2_.y))
            {
               this.mutex.lock();
               this.verifier_pointeur(this.montureBytes[_loc3_],this.monturePointeur[_loc3_]);
               this.montureBytes[_loc3_].writeInt(_loc2_.id);
               this.montureBytes[_loc3_].writeUTF(_loc2_.monture);
               this.mutex.unlock();
            }
            else
            {
               this.infosJoueurs[_loc3_].enregistrer_message_monture(new MessagePersoActualiserTexte(_loc2_.id,_loc2_.monture));
            }
            _loc3_++;
         }
         _loc2_ = null;
      }
      
      private function animer_perso(param1:AnimationEvent) : void
      {
         var _loc2_:int = 0;
         while(_loc2_ < this.nbJoueurs)
         {
            if(this.infosJoueurs[_loc2_].dans_vision(this.persos.persos[param1.id].x,this.persos.persos[param1.id].y))
            {
               this.mutex.lock();
               this.verifier_pointeur(this.animerBytes[_loc2_],this.animerPointeur[_loc2_]);
               this.animerBytes[_loc2_].writeInt(param1.id);
               this.animerBytes[_loc2_].writeUTF(param1.animation);
               this.mutex.unlock();
            }
            _loc2_++;
         }
      }
      
      private function detruire_perso(param1:PersosEvent) : void
      {
         var _loc2_:int = int(param1.perso.id);
         var _loc3_:int = 0;
         while(_loc3_ < this.nbJoueurs)
         {
            this.mutex.lock();
            this.verifier_pointeur(this.detruireBytes[_loc3_],this.detruirePointeur[_loc3_]);
            this.detruireBytes[_loc3_].writeInt(_loc2_);
            this.mutex.unlock();
            this.infosJoueurs[_loc3_].detruire_perso(_loc2_);
            _loc3_++;
         }
      }
      
      private function afficher_effet(param1:EffetEvent) : void
      {
         var _loc2_:int = 0;
         while(_loc2_ < this.nbJoueurs)
         {
            if(this.infosJoueurs[_loc2_].dans_vision(param1.x,param1.y))
            {
               this.mutex.lock();
               this.verifier_pointeur(this.effetsBytes[_loc2_],this.effetsPointeur[_loc2_]);
               this.effetsBytes[_loc2_].writeInt(param1.x);
               this.effetsBytes[_loc2_].writeInt(param1.y);
               this.effetsBytes[_loc2_].writeUTF(param1.effet);
               this.effetsBytes[_loc2_].writeFloat(Boolean(param1.effet) && Boolean(Donnees.donnees[param1.effet].sound) ? 1 : 0);
               this.effetsBytes[_loc2_].writeFloat(param1.rotation);
               this.effetsBytes[_loc2_].writeInt(param1.score);
               this.effetsBytes[_loc2_].writeFloat(param1.echelleX);
               this.effetsBytes[_loc2_].writeFloat(param1.echelleY);
               this.mutex.unlock();
            }
            _loc2_++;
         }
      }
      
      private function afficher_effet_arme(param1:EffetArmeEvent) : void
      {
         var _loc2_:int = 0;
         while(_loc2_ < this.nbJoueurs)
         {
            if(this.infosJoueurs[_loc2_].dans_vision(param1.x,param1.y))
            {
               this.mutex.lock();
               if(this.effetsArmeBytes[_loc2_].length == 0)
               {
                  this.effetsArmeBytes[_loc2_].position = 0;
               }
               this.effetsArmeBytes[_loc2_].writeUTF(param1.arme);
               this.effetsArmeBytes[_loc2_].writeUTF(param1.anim);
               this.effetsArmeBytes[_loc2_].writeUTF(param1.son ? param1.son : "");
               this.effetsArmeBytes[_loc2_].writeInt(param1.x);
               this.effetsArmeBytes[_loc2_].writeInt(param1.y);
               this.effetsArmeBytes[_loc2_].writeFloat(param1.rotation);
               this.mutex.unlock();
            }
            _loc2_++;
         }
      }
      
      private function jouer_son(param1:SonEvent) : void
      {
         var _loc2_:int = 0;
         while(_loc2_ < this.nbJoueurs)
         {
            if(this.infosJoueurs[_loc2_].dans_vision(param1.x,param1.y))
            {
               this.mutex.lock();
               this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
               this.infosJoueurBytes[_loc2_].writeByte(37);
               this.infosJoueurBytes[_loc2_].writeUTF(param1.son);
               this.mutex.unlock();
            }
            _loc2_++;
         }
      }
      
      private function jouer_son_travail(param1:SonEvent) : void
      {
         var _loc2_:int = 0;
         while(_loc2_ < this.nbJoueurs)
         {
            if(this.persos.joueur[_loc2_] == param1.currentTarget)
            {
               this.mutex.lock();
               this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
               this.infosJoueurBytes[_loc2_].writeByte(37);
               this.infosJoueurBytes[_loc2_].writeUTF(param1.son);
               this.mutex.unlock();
            }
            _loc2_++;
         }
      }
      
      private function actualiser_infosCaracteristiquePrimaireScore(param1:CaracteristiquePrimaireEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(0);
         this.infosJoueurBytes[_loc2_].writeUTF(param1.id);
         this.infosJoueurBytes[_loc2_].writeInt(param1.score);
         this.mutex.unlock();
      }
      
      private function actualiser_infosCaracteristiquePrimaireScoreBase(param1:CaracteristiquePrimaireEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(1);
         this.infosJoueurBytes[_loc2_].writeUTF(param1.id);
         this.infosJoueurBytes[_loc2_].writeInt(param1.score);
         this.mutex.unlock();
      }
      
      private function actualiser_infosCaracteristiquePrimaireRecuparation(param1:CaracteristiquePrimaireEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(2);
         this.infosJoueurBytes[_loc2_].writeUTF(param1.id);
         this.infosJoueurBytes[_loc2_].writeInt(param1.score);
         this.mutex.unlock();
      }
      
      private function actualiser_infosCaracteristiquePrimaireScoreMax(param1:CaracteristiquePrimaireEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(3);
         this.infosJoueurBytes[_loc2_].writeUTF(param1.id);
         this.infosJoueurBytes[_loc2_].writeInt(param1.score);
         this.mutex.unlock();
      }
      
      private function actualiser_infosCaracteristiquePrimaireXp(param1:CaracteristiquePrimaireEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(4);
         this.infosJoueurBytes[_loc2_].writeUTF(param1.id);
         this.infosJoueurBytes[_loc2_].writeInt(param1.score);
         this.mutex.unlock();
      }
      
      private function actualiser_infosCaracteristiquePrimaireXpMin(param1:CaracteristiquePrimaireEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(5);
         this.infosJoueurBytes[_loc2_].writeUTF(param1.id);
         this.infosJoueurBytes[_loc2_].writeInt(param1.score);
         this.mutex.unlock();
      }
      
      private function actualiser_infosCaracteristiquePrimaireXpMax(param1:CaracteristiquePrimaireEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(6);
         this.infosJoueurBytes[_loc2_].writeUTF(param1.id);
         this.infosJoueurBytes[_loc2_].writeInt(param1.score);
         this.mutex.unlock();
      }
      
      private function actualiser_infosCaracteristiqueSecondaireScore(param1:CaracteristiqueSecondaireEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(7);
         this.infosJoueurBytes[_loc2_].writeUTF(param1.id);
         this.infosJoueurBytes[_loc2_].writeInt(param1.score);
         this.mutex.unlock();
      }
      
      private function actualiser_infosCaracteristiqueSecondaireScoreBase(param1:CaracteristiqueSecondaireEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(8);
         this.infosJoueurBytes[_loc2_].writeUTF(param1.id);
         this.infosJoueurBytes[_loc2_].writeInt(param1.score);
         this.mutex.unlock();
      }
      
      private function actualiser_infosCaracteristiqueSecondaireXp(param1:CaracteristiqueSecondaireEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(9);
         this.infosJoueurBytes[_loc2_].writeUTF(param1.id);
         this.infosJoueurBytes[_loc2_].writeInt(param1.score);
         this.mutex.unlock();
      }
      
      private function actualiser_infosCaracteristiqueSecondaireXpMin(param1:CaracteristiqueSecondaireEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(10);
         this.infosJoueurBytes[_loc2_].writeUTF(param1.id);
         this.infosJoueurBytes[_loc2_].writeInt(param1.score);
         this.mutex.unlock();
      }
      
      private function actualiser_infosCaracteristiqueSecondaireXpMax(param1:CaracteristiqueSecondaireEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(11);
         this.infosJoueurBytes[_loc2_].writeUTF(param1.id);
         this.infosJoueurBytes[_loc2_].writeInt(param1.score);
         this.mutex.unlock();
      }
      
      private function actualiser_infosCompetenceScore(param1:CompetenceEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(12);
         this.infosJoueurBytes[_loc2_].writeUTF(param1.id);
         this.infosJoueurBytes[_loc2_].writeInt(param1.score);
         this.mutex.unlock();
      }
      
      private function actualiser_infosCompetenceScoreBase(param1:CompetenceEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(13);
         this.infosJoueurBytes[_loc2_].writeUTF(param1.id);
         this.infosJoueurBytes[_loc2_].writeInt(param1.score);
         this.mutex.unlock();
      }
      
      private function actualiser_infosCompetenceXp(param1:CompetenceEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(14);
         this.infosJoueurBytes[_loc2_].writeUTF(param1.id);
         this.infosJoueurBytes[_loc2_].writeInt(param1.score);
         this.mutex.unlock();
      }
      
      private function actualiser_infosCompetenceXpMin(param1:CompetenceEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(15);
         this.infosJoueurBytes[_loc2_].writeUTF(param1.id);
         this.infosJoueurBytes[_loc2_].writeInt(param1.score);
         this.mutex.unlock();
      }
      
      private function actualiser_infosCompetenceXpMax(param1:CompetenceEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(16);
         this.infosJoueurBytes[_loc2_].writeUTF(param1.id);
         this.infosJoueurBytes[_loc2_].writeInt(param1.score);
         this.mutex.unlock();
      }
      
      private function actualiser_infosRessourceQuantite(param1:RessourceEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(17);
         this.infosJoueurBytes[_loc2_].writeUTF(param1.id);
         this.infosJoueurBytes[_loc2_].writeInt(param1.quantite);
         this.mutex.unlock();
      }
      
      private function actualiser_infosRessourceQuantiteMax(param1:RessourceEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(18);
         this.infosJoueurBytes[_loc2_].writeUTF(param1.id);
         this.infosJoueurBytes[_loc2_].writeInt(param1.quantite);
         this.mutex.unlock();
      }
      
      private function actualiser_infosEntrepotQuantite(param1:RessourceEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(53);
         this.infosJoueurBytes[_loc2_].writeUTF(param1.id);
         this.infosJoueurBytes[_loc2_].writeInt(param1.quantite);
         this.mutex.unlock();
      }
      
      private function actualiser_jauge_travail(param1:JaugeEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(19);
         this.infosJoueurBytes[_loc2_].writeInt(param1.id);
         this.infosJoueurBytes[_loc2_].writeFloat(param1.coef);
         this.mutex.unlock();
      }
      
      private function objets_infos(param1:ObjetEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(20);
         this.infosJoueurBytes[_loc2_].writeInt(param1.currentTarget.id);
         this.infosJoueurBytes[_loc2_].writeInt(param1.action);
         this.infosJoueurBytes[_loc2_].writeInt(param1.id);
         this.infosJoueurBytes[_loc2_].writeInt(param1.deltaQuantite);
         this.infosJoueurBytes[_loc2_].writeObject(param1.donnnes);
         this.mutex.unlock();
      }
      
      private function rechargement_infos(param1:RechargementJoueurEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(21);
         this.infosJoueurBytes[_loc2_].writeUTF(param1.id);
         this.infosJoueurBytes[_loc2_].writeInt(param1.temps);
         this.mutex.unlock();
      }
      
      private function actualiser_infos_joueur(param1:JoueurEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(22);
         this.infosJoueurBytes[_loc2_].writeInt(param1.typeInfo);
         this.infosJoueurBytes[_loc2_].writeUTF(param1.infos);
         this.mutex.unlock();
      }
      
      private function actualiser_cible_joueur(param1:CibleEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(23);
         this.infosJoueurBytes[_loc2_].writeInt(param1.typeCible);
         this.infosJoueurBytes[_loc2_].writeInt(param1.cibleX);
         this.infosJoueurBytes[_loc2_].writeInt(param1.cibleY);
         this.mutex.unlock();
      }
      
      private function actualiser_cible_quantite_joueur(param1:CibleEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(24);
         this.infosJoueurBytes[_loc2_].writeInt(param1.typeCible);
         this.infosJoueurBytes[_loc2_].writeInt(param1.cibleX);
         this.infosJoueurBytes[_loc2_].writeInt(param1.cibleY);
         this.mutex.unlock();
      }
      
      private function actualiser_infosBestiaireNombre(param1:BestiaireEvent) : void
      {
         var _loc2_:int = int(param1.currentTarget.noJoueur);
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
         this.infosJoueurBytes[_loc2_].writeByte(25);
         this.infosJoueurBytes[_loc2_].writeUTF(param1.id);
         this.infosJoueurBytes[_loc2_].writeInt(param1.nombre);
         this.mutex.unlock();
      }
      
      private function actualiser_tempsVague(param1:VaguesActualiserEvent) : void
      {
         this.mutex.lock();
         var _loc2_:int = 0;
         while(_loc2_ < this.nbJoueurs)
         {
            this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
            this.infosJoueurBytes[_loc2_].writeByte(26);
            this.infosJoueurBytes[_loc2_].writeInt(param1.nombre);
            _loc2_++;
         }
         this.mutex.unlock();
      }
      
      private function actualiser_numeroVague(param1:VaguesActualiserEvent) : void
      {
         this.mutex.lock();
         var _loc2_:int = 0;
         while(_loc2_ < this.nbJoueurs)
         {
            this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
            this.infosJoueurBytes[_loc2_].writeByte(27);
            this.infosJoueurBytes[_loc2_].writeInt(param1.nombre);
            _loc2_++;
         }
         this.mutex.unlock();
      }
      
      private function actualiser_nombreVagues(param1:VaguesActualiserEvent) : void
      {
         this.mutex.lock();
         var _loc2_:int = 0;
         while(_loc2_ < this.nbJoueurs)
         {
            this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
            this.infosJoueurBytes[_loc2_].writeByte(28);
            this.infosJoueurBytes[_loc2_].writeInt(param1.nombre);
            _loc2_++;
         }
         this.mutex.unlock();
      }
      
      private function actualiser_tempsEpoque(param1:EpoqueEvent) : void
      {
         this.mutex.lock();
         var _loc2_:int = 0;
         while(_loc2_ < this.nbJoueurs)
         {
            if(this.infosJoueurs[_loc2_].ville == param1.currentTarget.no)
            {
               this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
               this.infosJoueurBytes[_loc2_].writeByte(29);
               this.infosJoueurBytes[_loc2_].writeFloat(param1.nombre);
            }
            _loc2_++;
         }
         this.mutex.unlock();
      }
      
      private function actualiser_numeroEpoque(param1:EpoqueEvent) : void
      {
         var _loc2_:int = param1.nombre;
         this.mutex.lock();
         var _loc3_:int = 0;
         while(_loc3_ < this.nbJoueurs)
         {
            if(this.infosJoueurs[_loc3_].ville == param1.currentTarget.no)
            {
               this.verifier_pointeur(this.infosJoueurBytes[_loc3_],this.infosJoueurPointeur[_loc3_]);
               this.infosJoueurBytes[_loc3_].writeByte(30);
               this.infosJoueurBytes[_loc3_].writeInt(_loc2_);
               if(_loc2_ > this.persos.villes[this.infosJoueurs[_loc3_].ville].epoqueDepart && _loc2_ < Donnees.epoques.length)
               {
                  this.message_important2(Donnees.epoques[_loc2_].message[Donnees.langue],_loc3_);
               }
            }
            _loc3_++;
         }
         this.mutex.unlock();
         if(this.vagues)
         {
            this.vagues.epoque = _loc2_;
         }
      }
      
      private function verifier_gagne(param1:FinPartieEvent) : void
      {
         addEventListener(Event.ENTER_FRAME,this.verifier_gagne2);
      }
      
      private function verifier_gagne2(param1:Event) : void
      {
         removeEventListener(Event.ENTER_FRAME,this.verifier_gagne2);
         var _loc2_:int = 0;
         while(_loc2_ < this.nbJoueurs)
         {
            if(Boolean(this.finPartie) && this.finPartie.verifier_gagne(this.persos.joueur[_loc2_]))
            {
               this.gagner_direct(null,_loc2_);
            }
            _loc2_++;
         }
      }
      
      private function gagner_direct(param1:FinPartieEvent = null, param2:int = 0) : void
      {
         var _loc3_:int = 0;
         if(this.finPartie)
         {
            if(param1)
            {
               _loc3_ = 0;
               while(_loc3_ < this.nbJoueurs)
               {
                  this.mutex.lock();
                  this.verifier_pointeur(this.infosJoueurBytes[_loc3_],this.infosJoueurPointeur[_loc3_]);
                  this.infosJoueurBytes[_loc3_].writeByte(31);
                  this.infosJoueurBytes[_loc3_].writeBoolean(true);
                  this.mutex.unlock();
                  _loc3_++;
               }
            }
            else
            {
               this.mutex.lock();
               this.verifier_pointeur(this.infosJoueurBytes[param2],this.infosJoueurPointeur[param2]);
               this.infosJoueurBytes[param2].writeByte(31);
               this.infosJoueurBytes[param2].writeBoolean(true);
               this.mutex.unlock();
            }
         }
         this.persos.removeEventListener(FinPartieEvent.VERIFIER_FIN_PARTIE,this.verifier_gagne);
         this.persos.removeEventListener(FinPartieEvent.GAGNER_DIRECT,this.gagner_direct);
      }
      
      private function verifier_perdu(param1:FinPartieEvent) : void
      {
         addEventListener(Event.ENTER_FRAME,this.verifier_perdu2);
      }
      
      private function verifier_perdu2(param1:Event) : void
      {
         removeEventListener(Event.ENTER_FRAME,this.verifier_perdu2);
         var _loc2_:int = 0;
         while(_loc2_ < this.nbJoueurs)
         {
            if(Boolean(this.finPartie) && this.finPartie.verifier_perdu(this.persos.joueur[_loc2_]))
            {
               this.mutex.lock();
               this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
               this.infosJoueurBytes[_loc2_].writeByte(31);
               this.infosJoueurBytes[_loc2_].writeBoolean(false);
               this.mutex.unlock();
               this.persos.removeEventListener(FinPartieEvent.VERIFIER_FIN_PARTIE,this.verifier_perdu);
            }
            _loc2_++;
         }
      }
      
      private function actualiser_nb_villageois(param1:VaguesActualiserEvent) : void
      {
         this.mutex.lock();
         var _loc2_:int = 0;
         while(_loc2_ < this.nbJoueurs)
         {
            this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
            this.infosJoueurBytes[_loc2_].writeByte(32);
            this.infosJoueurBytes[_loc2_].writeInt(this.compteur_nombre_allies(this.infosJoueurs[_loc2_].equipe));
            _loc2_++;
         }
         this.mutex.unlock();
      }
      
      private function actualiser_nb_villageois_max(param1:VaguesActualiserEvent) : void
      {
         this.mutex.lock();
         var _loc2_:int = 0;
         while(_loc2_ < this.nbJoueurs)
         {
            this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
            this.infosJoueurBytes[_loc2_].writeByte(33);
            this.infosJoueurBytes[_loc2_].writeInt(this.compteur_nombre_allies_max(this.infosJoueurs[_loc2_].equipe));
            _loc2_++;
         }
         this.mutex.unlock();
      }
      
      private function actualiser_nb_monstres(param1:VaguesActualiserEvent) : void
      {
         this.mutex.lock();
         var _loc2_:int = 0;
         while(_loc2_ < this.nbJoueurs)
         {
            this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
            this.infosJoueurBytes[_loc2_].writeByte(34);
            this.infosJoueurBytes[_loc2_].writeInt(this.compteur_nombre_ennemis(this.infosJoueurs[_loc2_].equipe));
            _loc2_++;
         }
         this.mutex.unlock();
      }
      
      private function actualiser_nb_soldats(param1:VaguesActualiserEvent) : void
      {
         this.mutex.lock();
         var _loc2_:int = 0;
         while(_loc2_ < this.nbJoueurs)
         {
            if(param1.equipe == -1)
            {
               this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
               this.infosJoueurBytes[_loc2_].writeByte(48);
               this.infosJoueurBytes[_loc2_].writeInt(this.persos.villes[this.infosJoueurs[_loc2_].ville].nbSoldats);
            }
            else if(this.infosJoueurs[_loc2_].equipe == param1.equipe)
            {
               this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
               this.infosJoueurBytes[_loc2_].writeByte(48);
               this.infosJoueurBytes[_loc2_].writeInt(param1.nombre);
            }
            _loc2_++;
         }
         this.mutex.unlock();
      }
      
      private function actualiser_nb_soldats_max(param1:VaguesActualiserEvent) : void
      {
         this.mutex.lock();
         var _loc2_:int = 0;
         while(_loc2_ < this.nbJoueurs)
         {
            if(param1.equipe == -1)
            {
               this.actualiser_nb_soldats_max2(_loc2_,this.persos.villes[this.infosJoueurs[_loc2_].ville].nbSoldatsMax);
            }
            else if(this.infosJoueurs[_loc2_].equipe == param1.equipe)
            {
               this.actualiser_nb_soldats_max2(_loc2_,param1.nombre);
            }
            _loc2_++;
         }
         this.mutex.unlock();
      }
      
      private function actualiser_nb_soldats_max2(param1:int, param2:int) : void
      {
         this.verifier_pointeur(this.infosJoueurBytes[param1],this.infosJoueurPointeur[param1]);
         this.infosJoueurBytes[param1].writeByte(49);
         this.infosJoueurBytes[param1].writeInt(param2);
      }
      
      public function ajouter_joueur_multijoueur(param1:int, param2:String, param3:int) : void
      {
         this.verifier_pointeur(this.infosJoueurBytes[0],this.infosJoueurPointeur[0]);
         this.infosJoueurBytes[0].writeByte(50);
         this.infosJoueurBytes[0].writeByte(0);
         this.infosJoueurBytes[0].writeInt(param1);
         this.infosJoueurBytes[0].writeUTF(param2);
         this.infosJoueurBytes[0].writeInt(param3);
      }
      
      public function supprimer_joueur_multijoueur(param1:int) : void
      {
         this.verifier_pointeur(this.infosJoueurBytes[0],this.infosJoueurPointeur[0]);
         this.infosJoueurBytes[0].writeByte(50);
         this.infosJoueurBytes[0].writeByte(1);
         this.infosJoueurBytes[0].writeInt(param1);
      }
      
      public function actualiser_cle_serveur(param1:String) : void
      {
         this.verifier_pointeur(this.infosJoueurBytes[0],this.infosJoueurPointeur[0]);
         this.infosJoueurBytes[0].writeByte(51);
         this.infosJoueurBytes[0].writeUTF(param1);
      }
      
      private function roi_perso(param1:PersosEvent) : void
      {
         var _loc2_:int = 0;
         while(_loc2_ < this.nbJoueurs)
         {
            if(this.infosJoueurs[_loc2_].ville == param1.perso.ville)
            {
               this.mutex.lock();
               this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
               this.infosJoueurBytes[_loc2_].writeByte(54);
               this.infosJoueurBytes[_loc2_].writeBoolean(param1.type == PersosEvent.ROI_AUTRE);
               this.mutex.unlock();
            }
            _loc2_++;
         }
      }
      
      private function afficher_debug(param1:String) : void
      {
         this.mutex.lock();
         var _loc2_:int = 0;
         while(_loc2_ < this.nbJoueurs)
         {
            this.verifier_pointeur(this.infosJoueurBytes[_loc2_],this.infosJoueurPointeur[_loc2_]);
            this.infosJoueurBytes[_loc2_].writeByte(35);
            this.infosJoueurBytes[_loc2_].writeByte(0);
            this.infosJoueurBytes[_loc2_].writeUTF(param1);
            _loc2_++;
         }
         this.mutex.unlock();
      }
      
      public function editer_infosJoueur(param1:ByteArray) : void
      {
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[0],this.infosJoueurPointeur[0]);
         this.infosJoueurBytes[0].writeBytes(param1);
         this.mutex.unlock();
      }
      
      private function actualiser_frame() : void
      {
         this.dernierTempsPrincipale = getTimer();
         if(this.actif && this.pauseEnRetard)
         {
            this.pauseEnRetard = false;
            this.reprendre2();
         }
      }
      
      private function pause(param1:Event = null) : void
      {
         if(this.actif)
         {
            this.actif = false;
            this.pause2();
         }
      }
      
      private function pause2() : void
      {
         if(this.persos)
         {
            this.persos.pause();
         }
         if(this.vagues)
         {
            this.vagues.pause();
         }
         if(this.timerSauverPerso)
         {
            this.timerSauverPerso.stop();
         }
      }
      
      private function reprendre(param1:Event = null) : void
      {
         if(!this.actif)
         {
            this.actif = true;
            this.reprendre2();
         }
      }
      
      private function reprendre2() : void
      {
         this.ancienTemps = getTimer();
         Mobile.MULTIPLICATEUR_VITESSE = 1;
         if(this.persos)
         {
            this.persos.reprendre();
         }
         if(this.vagues)
         {
            this.vagues.reprendre();
         }
         if(this.timerSauverPerso)
         {
            this.timerSauverPerso.start();
         }
      }
      
      private function envoyer_vague(param1:Event = null) : void
      {
         this.vagues.envoyer_supplementaire();
      }
      
      private function envoyer_message(param1:int, param2:String, param3:String) : void
      {
         this.persos.persos[param1].parler("*" + param3);
         this.message_normal_a_tous(param2.toUpperCase() + " : " + param3);
      }
      
      private function charger(param1:Object, param2:Array, param3:Object, param4:String) : void
      {
         this.sauvegarde.readByte();
         while(this.sauvegarde.bytesAvailable > 0)
         {
            switch(this.sauvegarde.readUTF())
            {
               case "conf":
                  this.config = this.sauvegarde.readObject();
                  this.config.world = param4;
                  this.persos.charger_villes(this.config.towns);
                  IA.villes = this.persos.villes;
                  break;
               case "land":
                  Terrain.init(this.sauvegarde);
                  break;
               case "char":
                  this.persos.charger_persos(this.sauvegarde,param1,param2,param3);
                  break;
               case "wave":
                  if(!this.vagues)
                  {
                     this.vagues = new Vagues();
                  }
                  this.vagues.init_data(this.config);
                  this.vagues.charger(this.sauvegarde);
            }
         }
         this.sauvegarde.clear();
         this.sauvegarde = null;
      }
      
      private function sauvegarder(param1:Event = null) : void
      {
         var _loc2_:ByteArray = null;
         if(sauvegardeEditeur)
         {
            _loc2_ = new ByteArray();
            this.persos.sauvegarder_bac_a_sable(_loc2_);
            this.mutex.lock();
            this.verifier_pointeur(this.infosJoueurBytes[0],this.infosJoueurPointeur[0]);
            this.infosJoueurBytes[0].writeByte(39);
            this.infosJoueurBytes[0].writeInt(_loc2_.length);
            this.infosJoueurBytes[0].writeBytes(_loc2_);
            this.mutex.unlock();
         }
         else
         {
            _loc2_ = new ByteArray();
            _loc2_.writeByte(9);
            _loc2_.writeUTF("conf");
            _loc2_.writeObject(this.config);
            _loc2_.writeUTF("land");
            _loc2_ = Terrain.sauvegarder(_loc2_);
            _loc2_.writeUTF("char");
            this.persos.sauvegarder_persos(_loc2_);
            if(this.vagues)
            {
               _loc2_.writeUTF("wave");
               this.vagues.sauvegarder(_loc2_);
            }
            this.mutex.lock();
            this.verifier_pointeur(this.infosJoueurBytes[0],this.infosJoueurPointeur[0]);
            this.infosJoueurBytes[0].writeByte(39);
            this.infosJoueurBytes[0].writeInt(_loc2_.length);
            this.infosJoueurBytes[0].writeBytes(_loc2_);
            this.mutex.unlock();
         }
      }
      
      public function ajouter_joueur(param1:int, param2:int) : void
      {
         var _loc4_:Perso = null;
         var _loc5_:String = null;
         var _loc6_:Boolean = false;
         var _loc7_:Boolean = false;
         var _loc8_:Boolean = false;
         var _loc9_:Boolean = false;
         var _loc10_:Boolean = false;
         var _loc11_:Boolean = false;
         this.mutex.lock();
         this.creationsBytes.push(new ByteArray());
         this.creationsPointeur.push(new ByteArray());
         this.creationsPointeur[this.nbJoueurs].writeInt(0);
         this.positionsBytes.push(new ByteArray());
         this.positionsPointeur.push(new ByteArray());
         this.positionsPointeur[this.nbJoueurs].writeInt(0);
         this.orientationBytes.push(new ByteArray());
         this.orientationPointeur.push(new ByteArray());
         this.orientationPointeur[this.nbJoueurs].writeInt(0);
         this.decalageYBytes.push(new ByteArray());
         this.decalageYPointeur.push(new ByteArray());
         this.decalageYPointeur[this.nbJoueurs].writeInt(0);
         this.rotationBytes.push(new ByteArray());
         this.rotationPointeur.push(new ByteArray());
         this.rotationPointeur[this.nbJoueurs].writeInt(0);
         this.actualiserVieBytes.push(new ByteArray());
         this.actualiserViePointeur.push(new ByteArray());
         this.actualiserViePointeur[this.nbJoueurs].writeInt(0);
         this.actualiserEtapeBytes.push(new ByteArray());
         this.actualiserEtapePointeur.push(new ByteArray());
         this.actualiserEtapePointeur[this.nbJoueurs].writeInt(0);
         this.actualiserBulleBytes.push(new ByteArray());
         this.actualiserBullePointeur.push(new ByteArray());
         this.actualiserBullePointeur[this.nbJoueurs].writeInt(0);
         this.actualiserFantomeBytes.push(new ByteArray());
         this.actualiserFantomePointeur.push(new ByteArray());
         this.actualiserFantomePointeur[this.nbJoueurs].writeInt(0);
         this.actualiserVisibleBytes.push(new ByteArray());
         this.actualiserVisiblePointeur.push(new ByteArray());
         this.actualiserVisiblePointeur[this.nbJoueurs].writeInt(0);
         this.apparenceBytes.push(new ByteArray());
         this.apparencePointeur.push(new ByteArray());
         this.apparencePointeur[this.nbJoueurs].writeInt(0);
         this.couleurBytes.push(new ByteArray());
         this.couleurPointeur.push(new ByteArray());
         this.couleurPointeur[this.nbJoueurs].writeInt(0);
         this.montureBytes.push(new ByteArray());
         this.monturePointeur.push(new ByteArray());
         this.monturePointeur[this.nbJoueurs].writeInt(0);
         this.animerBytes.push(new ByteArray());
         this.animerPointeur.push(new ByteArray());
         this.animerPointeur[this.nbJoueurs].writeInt(0);
         this.detruireBytes.push(new ByteArray());
         this.detruirePointeur.push(new ByteArray());
         this.detruirePointeur[this.nbJoueurs].writeInt(0);
         this.effetsBytes.push(new ByteArray());
         this.effetsPointeur.push(new ByteArray());
         this.effetsPointeur[this.nbJoueurs].writeInt(0);
         this.effetsArmeBytes.push(new ByteArray());
         this.infosJoueurBytes.push(new ByteArray());
         this.infosJoueurPointeur.push(new ByteArray());
         this.infosJoueurPointeur[this.nbJoueurs].writeInt(0);
         if(this.vagues)
         {
            this.verifier_pointeur(this.infosJoueurBytes[this.nbJoueurs],this.infosJoueurPointeur[this.nbJoueurs]);
            this.infosJoueurBytes[this.nbJoueurs].writeByte(27);
            this.infosJoueurBytes[this.nbJoueurs].writeInt(this.vagues.noVague);
            this.verifier_pointeur(this.infosJoueurBytes[this.nbJoueurs],this.infosJoueurPointeur[this.nbJoueurs]);
            this.infosJoueurBytes[this.nbJoueurs].writeByte(28);
            this.infosJoueurBytes[this.nbJoueurs].writeInt(this.vagues.nombreVagues);
         }
         this.mutex.unlock();
         this.infosJoueurs.push(new InfosJoueur(this.nbJoueurs,this.config.towns[param2].equip,param2,this.mutex,this.verifier_pointeur,this.creationsBytes[this.nbJoueurs],this.creationsPointeur[this.nbJoueurs],this.positionsBytes[this.nbJoueurs],this.positionsPointeur[this.nbJoueurs],this.orientationBytes[this.nbJoueurs],this.orientationPointeur[this.nbJoueurs],this.rotationBytes[this.nbJoueurs],this.rotationPointeur[this.nbJoueurs],this.actualiserVieBytes[this.nbJoueurs],this.actualiserViePointeur[this.nbJoueurs],this.actualiserEtapeBytes[this.nbJoueurs],this.actualiserEtapePointeur[this.nbJoueurs],this.decalageYBytes[this.nbJoueurs],this.decalageYPointeur[this.nbJoueurs],this.actualiserFantomeBytes[this.nbJoueurs],this.actualiserFantomePointeur[this.nbJoueurs],this.actualiserVisibleBytes[this.nbJoueurs],this.actualiserVisiblePointeur[this.nbJoueurs],this.apparenceBytes[this.nbJoueurs],this.apparencePointeur[this.nbJoueurs],this.couleurBytes[this.nbJoueurs],this.couleurPointeur[this.nbJoueurs]
         ,this.montureBytes[this.nbJoueurs],this.monturePointeur[this.nbJoueurs],this.infosJoueurBytes[this.nbJoueurs],this.infosJoueurPointeur[this.nbJoueurs],this.persos.persos));
         if(this.nbJoueurs == 1)
         {
            addEventListener(Event.ENTER_FRAME,this.jouer_serveur);
         }
         var _loc3_:int = this.infosJoueurs[this.nbJoueurs].equipe;
         ++this.nbJoueurs;
         for each(_loc4_ in this.persos.persos)
         {
            _loc5_ = Donnees.donnees[_loc4_.race].type;
            _loc6_ = _loc4_ is Vivant && Vivant(_loc4_).equipe != _loc3_ || (_loc5_ == "monster" || _loc5_ == "landRessource" || _loc5_ == "animal" || _loc4_ is Fondations || _loc4_ is Batiment && _loc5_ != "wall") && !(_loc4_ is BatimentResurrection) && !(_loc4_ is Soldat);
            _loc7_ = (_loc4_ is Combattant || _loc4_ is Batiment || _loc4_ is Fondations) && Object(_loc4_).equipe != _loc3_;
            _loc8_ = _loc4_ is BatimentResurrection && BatimentResurrection(_loc4_).equipe == _loc3_;
            _loc9_ = (_loc4_ is BatimentMobile || _loc4_ is Mur) && Object(_loc4_).equipe == _loc3_;
            _loc10_ = _loc4_ is Combattant && !(_loc4_ is Artisan) && Combattant(_loc4_).equipe == _loc3_;
            _loc11_ = _loc4_ is Joueur && _loc4_.id == param1;
            if(_loc4_.id == param1)
            {
               this.mutex.lock();
               this.actualiser_nb_soldats_max2(this.nbJoueurs - 1,this.persos.villes[Joueur(_loc4_).equipe].nbSoldatsMax);
               this.verifier_pointeur(this.creationsBytes[this.nbJoueurs - 1],this.creationsPointeur[this.nbJoueurs - 1]);
               this.creationsBytes[this.nbJoueurs - 1].writeInt(_loc4_.id);
               this.creationsBytes[this.nbJoueurs - 1].writeUTF(_loc4_.race);
               this.creationsBytes[this.nbJoueurs - 1].writeBoolean(_loc6_);
               this.creationsBytes[this.nbJoueurs - 1].writeBoolean(_loc7_);
               this.creationsBytes[this.nbJoueurs - 1].writeBoolean(_loc8_);
               this.creationsBytes[this.nbJoueurs - 1].writeBoolean(_loc9_);
               this.creationsBytes[this.nbJoueurs - 1].writeBoolean(_loc10_);
               this.creationsBytes[this.nbJoueurs - 1].writeBoolean(_loc11_);
               this.creationsBytes[this.nbJoueurs - 1].writeInt(_loc4_.x);
               this.creationsBytes[this.nbJoueurs - 1].writeInt(_loc4_.y);
               if(Donnees.donnees[_loc4_.race].visualWidth)
               {
                  this.creationsBytes[this.nbJoueurs - 1].writeInt(Donnees.donnees[_loc4_.race].visualWidth);
               }
               else
               {
                  this.creationsBytes[this.nbJoueurs - 1].writeInt(_loc4_.largeur);
               }
               if(Donnees.donnees[_loc4_.race].visualHeight)
               {
                  this.creationsBytes[this.nbJoueurs - 1].writeInt(Donnees.donnees[_loc4_.race].visualHeight);
               }
               else
               {
                  this.creationsBytes[this.nbJoueurs - 1].writeInt(_loc4_.hauteur);
               }
               this.creationsBytes[this.nbJoueurs - 1].writeUTF("");
               this.creationsBytes[this.nbJoueurs - 1].writeInt(0);
               this.verifier_pointeur(this.apparenceBytes[this.nbJoueurs - 1],this.apparencePointeur[this.nbJoueurs - 1]);
               this.apparenceBytes[this.nbJoueurs - 1].writeInt(_loc4_.id);
               this.apparenceBytes[this.nbJoueurs - 1].writeObject(Aventurier(_loc4_).apparence);
               this.mutex.unlock();
               this.persos.joueur.push(Joueur(_loc4_));
               this.infosJoueurs[this.nbJoueurs - 1].actualiser_vision(this.persos.joueur[this.nbJoueurs - 1].x - 640,this.persos.joueur[this.nbJoueurs - 1].y - 360,this.persos.joueur[this.nbJoueurs - 1].x + 640,this.persos.joueur[this.nbJoueurs - 1].y + 360);
               this.joueur_changer_controle(param1,false,this.nbJoueurs - 1);
               this.persos.dispatchEvent(new VaguesActualiserEvent(VaguesActualiserEvent.ACTUALISER_NB_MONSTRES,this.compteur_nombre_ennemis(Joueur(_loc4_).equipe)));
               this.persos.dispatchEvent(new VaguesActualiserEvent(VaguesActualiserEvent.ACTUALISER_NB_VILLAGEOIS,this.compteur_nombre_allies(Joueur(_loc4_).equipe)));
               this.persos.dispatchEvent(new VaguesActualiserEvent(VaguesActualiserEvent.ACTUALISER_NB_VILLAGEOIS_MAX,this.compteur_nombre_allies_max(Joueur(_loc4_).equipe)));
               this.persos.villes[_loc3_].addEventListener(EpoqueEvent.ACTUALISER_NO_EPOQUE,this.actualiser_numeroEpoque);
               this.persos.villes[_loc3_].addEventListener(EpoqueEvent.ACTUALISER_TEMPS,this.actualiser_tempsEpoque);
               this.persos.villes[_loc3_].recuperer_infos();
            }
            else
            {
               this.infosJoueurs[this.nbJoueurs - 1].enregistrer_message_creation(new MessagePersoCreer(_loc4_.id,_loc4_.race,_loc6_,_loc7_,_loc8_,_loc9_,_loc10_,_loc11_,_loc4_.x,_loc4_.y,Donnees.donnees[_loc4_.race].visualWidth ? int(Donnees.donnees[_loc4_.race].visualWidth) : _loc4_.largeur,Donnees.donnees[_loc4_.race].visualHeight ? int(Donnees.donnees[_loc4_.race].visualHeight) : _loc4_.hauteur));
               if(_loc4_ is Aventurier)
               {
                  this.infosJoueurs[this.nbJoueurs - 1].enregistrer_message_apparence(new MessagePersoApparence(_loc4_.id,Aventurier(_loc4_).apparence));
               }
               if(_loc4_ is Mobile)
               {
                  if(Mobile(_loc4_).decalageY != 0)
                  {
                     this.infosJoueurs[this.nbJoueurs - 1].enregistrer_message_decalageY(new MessagePersoActualiserEntier(_loc4_.id,Mobile(_loc4_).decalageY));
                  }
                  if(Mobile(_loc4_).orientation != MessagePersoOrienter.DEFAUT)
                  {
                     this.infosJoueurs[this.nbJoueurs - 1].enregistrer_message_orientation(new MessagePersoOrienter(_loc4_.id,Mobile(_loc4_).orientation));
                  }
               }
               if((_loc4_ is Projectile || _loc4_ is BatimentRotatif) && Object(_loc4_).rotation != 0)
               {
                  this.infosJoueurs[this.nbJoueurs - 1].enregistrer_message_rotation(new MessagePersoRotation(_loc4_.id,Object(_loc4_).rotation));
               }
               if(_loc4_ is Vivant && Vivant(_loc4_).vie.coef < 1)
               {
                  this.infosJoueurs[this.nbJoueurs - 1].enregistrer_message_vie(new MessagePersoActualiserNombre(_loc4_.id,Vivant(_loc4_).vie.coef));
               }
               if(_loc4_ is Fondations && Boolean(Fondations(_loc4_).etape))
               {
                  this.infosJoueurs[this.nbJoueurs - 1].enregistrer_message_etape(new MessagePersoActualiserEntier(_loc4_.id,Fondations(_loc4_).etape));
                  this.infosJoueurs[this.nbJoueurs - 1].enregistrer_message_apparence(new MessagePersoApparence(_loc4_.id,Fondations(_loc4_).apparence));
               }
               if(_loc4_ is BatimentCaserne && Boolean(BatimentCaserne(_loc4_).garnison.length))
               {
                  this.infosJoueurs[this.nbJoueurs - 1].enregistrer_message_caserne(new MessagePersoActualiserEntier(_loc4_.id,BatimentCaserne(_loc4_).garnison.length));
               }
               if(_loc4_ is Artisan && Artisan(_loc4_).fantome)
               {
                  this.infosJoueurs[this.nbJoueurs - 1].enregistrer_message_fantome(new MessagePersoBooleen(_loc4_.id,true));
               }
               if(!_loc4_.visible)
               {
                  this.infosJoueurs[this.nbJoueurs - 1].enregistrer_message_visible(new MessagePersoBooleen(_loc4_.id,false));
               }
               if(_loc4_ is Aventurier && Boolean(Aventurier(_loc4_).monture))
               {
                  this.infosJoueurs[this.nbJoueurs - 1].enregistrer_message_monture(new MessagePersoActualiserTexte(_loc4_.id,Aventurier(_loc4_).monture));
               }
            }
            if(_loc4_ is Joueur)
            {
               this.mutex.lock();
               this.verifier_pointeur(this.infosJoueurBytes[this.nbJoueurs - 1],this.infosJoueurPointeur[this.nbJoueurs - 1]);
               this.infosJoueurBytes[this.nbJoueurs - 1].writeByte(47);
               this.infosJoueurBytes[this.nbJoueurs - 1].writeInt(_loc4_.id);
               this.infosJoueurBytes[this.nbJoueurs - 1].writeUTF(Joueur(_loc4_).nom);
               this.mutex.unlock();
            }
         }
      }
      
      private function compteur_nombre_allies(param1:int) : int
      {
         var _loc2_:int = 0;
         var _loc3_:int = 0;
         while(_loc3_ < this.persos.villes.length)
         {
            if(this.persos.villes[_loc3_].equipe == param1)
            {
               _loc2_ += this.persos.villes[_loc3_].nbVillageois;
            }
            _loc3_++;
         }
         return _loc2_;
      }
      
      private function compteur_nombre_allies_max(param1:int) : int
      {
         var _loc2_:int = 0;
         var _loc3_:int = 0;
         while(_loc3_ < this.persos.villes.length)
         {
            if(this.persos.villes[_loc3_].equipe == param1)
            {
               _loc2_ += this.persos.villes[_loc3_].nbVillageoisMax;
            }
            _loc3_++;
         }
         return _loc2_;
      }
      
      private function compteur_nombre_ennemis(param1:int) : int
      {
         var _loc2_:int = 0;
         if(this.vagues)
         {
            _loc2_ += this.vagues.nbMonstres;
         }
         return int(_loc2_ + this.persos.nbMonstres(param1));
      }
      
      public function supprimer_joueur(param1:int) : void
      {
         this.mutex.lock();
         this.creationsBytes.splice(param1,1);
         this.creationsPointeur.splice(param1,1);
         this.positionsBytes.splice(param1,1);
         this.positionsPointeur.splice(param1,1);
         this.orientationBytes.splice(param1,1);
         this.orientationPointeur.splice(param1,1);
         this.decalageYBytes.splice(param1,1);
         this.decalageYPointeur.splice(param1,1);
         this.rotationBytes.splice(param1,1);
         this.rotationPointeur.splice(param1,1);
         this.actualiserVieBytes.splice(param1,1);
         this.actualiserViePointeur.splice(param1,1);
         this.actualiserEtapeBytes.splice(param1,1);
         this.actualiserEtapePointeur.splice(param1,1);
         this.actualiserBulleBytes.splice(param1,1);
         this.actualiserBullePointeur.splice(param1,1);
         this.actualiserFantomeBytes.splice(param1,1);
         this.actualiserFantomePointeur.splice(param1,1);
         this.actualiserVisibleBytes.splice(param1,1);
         this.actualiserVisiblePointeur.splice(param1,1);
         this.apparenceBytes.splice(param1,1);
         this.apparencePointeur.splice(param1,1);
         this.couleurBytes.splice(param1,1);
         this.couleurPointeur.splice(param1,1);
         this.montureBytes.splice(param1,1);
         this.monturePointeur.splice(param1,1);
         this.animerBytes.splice(param1,1);
         this.animerPointeur.splice(param1,1);
         this.detruireBytes.splice(param1,1);
         this.detruirePointeur.splice(param1,1);
         this.effetsBytes.splice(param1,1);
         this.effetsPointeur.splice(param1,1);
         this.effetsArmeBytes.splice(param1,1);
         this.mutex.unlock();
         this.infosJoueurs.splice(param1,1);
         --this.nbJoueurs;
         this.joueur_changer_controle(-1,false,param1);
         this.persos.joueur.splice(param1,1);
         if(this.nbJoueurs == 1)
         {
            removeEventListener(Event.ENTER_FRAME,this.jouer_serveur);
         }
      }
      
      public function erreur_critique(param1:String) : void
      {
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[0],this.infosJoueurPointeur[0]);
         this.infosJoueurBytes[0].writeByte(46);
         this.infosJoueurBytes[0].writeUTF(param1);
         this.mutex.unlock();
         this.quitter();
      }
      
      public function quitter(param1:Event = null) : void
      {
         if(this.persos)
         {
            this.sauvegarder_joueurs(0);
            this.persos.detruire();
         }
         this.quitter2();
         if(this.persos)
         {
            this.persos.removeEventListener(FinPartieEvent.VERIFIER_FIN_PARTIE,this.verifier_gagne);
            this.persos.removeEventListener(FinPartieEvent.GAGNER_DIRECT,this.gagner_direct);
            this.persos.pause();
         }
         if(this.vagues)
         {
            this.vagues.pause();
         }
         if(this.timerSauverPerso)
         {
            this.timerSauverPerso.stop();
         }
         removeEventListener(Event.ENTER_FRAME,this.jouer);
         if(this.vagues)
         {
            this.vagues.removeEventListener(VaguesActualiserEvent.ACTUALISER_NO_VAGUE,this.actualiser_numeroVague);
            this.vagues.removeEventListener(VaguesActualiserEvent.ACTUALISER_NB_VAGUES,this.actualiser_nombreVagues);
            this.vagues.removeEventListener(VaguesActualiserEvent.ACTUALISER_TEMPS,this.actualiser_tempsVague);
            this.vagues.removeEventListener(VaguesActualiserEvent.ACTUALISER_NB_MONSTRES,this.actualiser_nb_monstres);
            this.vagues.detruire();
            this.vagues = null;
         }
         if(this.timerSauverPerso)
         {
            this.timerSauverPerso.removeEventListener(TimerEvent.TIMER,this.sauvegarder_joueur);
            this.timerSauverPerso.stop();
            this.timerSauverPerso = null;
         }
         if(this.finPartie)
         {
            this.finPartie.detruire();
         }
         this.finPartie = null;
         Multijoueur.detruire();
      }
      
      private function quitter2(param1:int = 0) : void
      {
         var _loc2_:Object = null;
         var _loc3_:Object = null;
         this.mutex.lock();
         this.verifier_pointeur(this.infosJoueurBytes[param1],this.infosJoueurPointeur[param1]);
         this.infosJoueurBytes[param1].writeByte(43);
         if(!this.config.general || !this.config.general.noSave)
         {
            if(this.persos)
            {
               for each(_loc3_ in this.persos.persos)
               {
                  if(_loc3_ is Joueur && _loc3_.noJoueur == param1)
                  {
                     _loc2_ = _loc3_.sauvegarder_equipement();
                  }
               }
            }
            this.infosJoueurBytes[param1].writeObject(this.statistiques_joueurs(param1));
            this.infosJoueurBytes[param1].writeObject(_loc2_);
         }
         else
         {
            this.infosJoueurBytes[param1].writeObject(null);
            this.infosJoueurBytes[param1].writeObject(null);
         }
         this.mutex.unlock();
      }
   }
}

