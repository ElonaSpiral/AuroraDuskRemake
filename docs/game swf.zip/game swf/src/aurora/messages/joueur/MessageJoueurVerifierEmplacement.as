package aurora.messages.joueur
{
   public class MessageJoueurVerifierEmplacement
   {
      
      public var actif:Boolean;
      
      public var x:Vector.<int>;
      
      public var y:Vector.<int>;
      
      public var largeur:int;
      
      public var hauteur:int;
      
      public function MessageJoueurVerifierEmplacement(param1:Boolean = true, param2:Vector.<int> = null, param3:Vector.<int> = null, param4:int = 0, param5:int = 0)
      {
         super();
         this.actif = param1;
         this.x = param2;
         this.y = param3;
         this.largeur = param4;
         this.hauteur = param5;
      }
   }
}

