package aurora.messages.joueur
{
   import flash.utils.ByteArray;
   
   public class MessageJoueurValiderEmplacement
   {
      
      public var id:int;
      
      public var creations:ByteArray;
      
      public var x:Vector.<int>;
      
      public var y:Vector.<int>;
      
      public function MessageJoueurValiderEmplacement(param1:int = 0, param2:ByteArray = null, param3:Vector.<int> = null, param4:Vector.<int> = null)
      {
         super();
         this.id = param1;
         this.creations = param2;
         this.x = param3;
         this.y = param4;
      }
   }
}

