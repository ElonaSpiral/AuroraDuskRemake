package aurora.messages.joueur
{
   public class MessageJoueurVision
   {
      
      public var x1:int;
      
      public var y1:int;
      
      public var x2:int;
      
      public var y2:int;
      
      public function MessageJoueurVision(param1:int = 0, param2:int = 0, param3:int = 0, param4:int = 0)
      {
         super();
         this.x1 = param1;
         this.y1 = param2;
         this.x2 = param3;
         this.y2 = param4;
      }
   }
}

