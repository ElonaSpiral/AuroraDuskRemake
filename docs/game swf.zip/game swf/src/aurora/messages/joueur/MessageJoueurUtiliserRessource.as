package aurora.messages.joueur
{
   public class MessageJoueurUtiliserRessource
   {
      
      public var id:int;
      
      public var ressource:String;
      
      public var quantite:Number;
      
      public function MessageJoueurUtiliserRessource(param1:int = 0, param2:String = "", param3:int = 0)
      {
         super();
         this.id = param1;
         this.ressource = param2;
         this.quantite = param3;
      }
   }
}

