package aurora.messages.joueur
{
   public class MessageJoueurDeplacer
   {
      
      public var id:int;
      
      public var x:Number;
      
      public var y:Number;
      
      public function MessageJoueurDeplacer(param1:int = 0, param2:Number = 0, param3:Number = 0)
      {
         super();
         this.id = param1;
         this.x = param2;
         this.y = param3;
      }
   }
}

