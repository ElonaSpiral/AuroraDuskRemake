package aurora.messages.joueur
{
   import flash.utils.ByteArray;
   
   public class MessageJoueurDonnerOrdre
   {
      
      public static const ORDRE_SUIVRE:int = 0;
      
      public static const ORDRE_AGRESSIF:int = 1;
      
      public static const ORDRE_DEFENSIF:int = 2;
      
      public static const ORDRE_PATROUILLE:int = 3;
      
      public static const ORDRE_ARRET:int = 4;
      
      public var ordre:int;
      
      public var soldats:ByteArray;
      
      public function MessageJoueurDonnerOrdre(param1:int = 0, param2:ByteArray = null)
      {
         super();
         this.ordre = param1;
         this.soldats = param2;
      }
   }
}

