package aurora.messages.joueur
{
   public class MessageJoueurRecupererCaracteristiquePrimaire
   {
      
      public var id:int;
      
      public var carac:String;
      
      public function MessageJoueurRecupererCaracteristiquePrimaire(param1:int = 0, param2:String = "")
      {
         super();
         this.id = param1;
         this.carac = param2;
      }
   }
}

