package aurora.messages.joueur
{
   public class MessageJoueurUtiliserObjet
   {
      
      public static const ACTION_RACCOURCI:int = -1;
      
      public static const ACTION_UTILISER:int = 0;
      
      public static const ACTION_DONNER:int = 7;
      
      public static const ACTION_DONNER_TOUT:int = 8;
      
      public static const ACTION_DEPOSER:int = 1;
      
      public static const ACTION_DETRUIRE:int = 2;
      
      public static const ACTION_VENDRE:int = 3;
      
      public static const ACTION_EQUIPER_GAUCHE:int = 4;
      
      public static const ACTION_AMELIORER:int = 5;
      
      public static const ACTION_RENFORCER:int = 9;
      
      public static const ACTION_RECYCLER:int = 6;
      
      public var id:int;
      
      public var action:int;
      
      public var idObjet:int;
      
      public var gauche:Boolean;
      
      public function MessageJoueurUtiliserObjet(param1:int = 0, param2:int = 0, param3:int = 0, param4:Boolean = false)
      {
         super();
         this.id = param1;
         this.action = param2;
         this.idObjet = param3;
         this.gauche = param4;
      }
   }
}

