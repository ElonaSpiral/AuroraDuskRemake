package aurora.messages.joueur
{
   public class MessageJoueurCible
   {
      
      public static const ACTION_ARRET:int = 0;
      
      public static const ACTION_DEPLACEMENT:int = 1;
      
      public static const ACTION_TRAVAIL:int = 2;
      
      public static const ACTION_CHASSE:int = 3;
      
      public static const ACTION_ATTAQUE:int = 4;
      
      public static const ACTION_BOSS:int = 5;
      
      public var type:int;
      
      public var cibleX:Number;
      
      public var cibleY:Number;
      
      public function MessageJoueurCible(param1:int = 0, param2:Number = 0, param3:Number = 0)
      {
         super();
         this.type = param1;
         this.cibleX = param2;
         this.cibleY = param3;
      }
   }
}

