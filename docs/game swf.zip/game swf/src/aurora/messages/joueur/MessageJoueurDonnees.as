package aurora.messages.joueur
{
   public class MessageJoueurDonnees
   {
      
      public static const NOM:int = 3;
      
      public static const NIVEAU:int = 5;
      
      public static const RACE:int = 4;
      
      public static const ATTAQUE:int = 0;
      
      public static const DEFENSE:int = 1;
      
      public static const VITESSE:int = 2;
      
      public static const MAISON:int = 6;
      
      public static const FINI_MAISON:int = 8;
      
      public static const DANS_MAISON:int = 7;
      
      public static const RESISTANCES:int = 9;
      
      public static const DANS_ENTREPOT:int = 10;
      
      public static const ROI:int = 11;
      
      public static const ROI_AUTRE:int = 12;
      
      public static const ROI_FIN:int = 13;
      
      public var typeInfos:int;
      
      public var infos:String;
      
      public function MessageJoueurDonnees(param1:int = 0, param2:String = "")
      {
         super();
         this.typeInfos = param1;
         this.infos = param2;
      }
   }
}

