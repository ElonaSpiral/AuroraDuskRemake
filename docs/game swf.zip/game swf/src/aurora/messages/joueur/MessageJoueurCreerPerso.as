package aurora.messages.joueur
{
   public class MessageJoueurCreerPerso
   {
      
      public var id:int;
      
      public var creation:String;
      
      public function MessageJoueurCreerPerso(param1:int = 0, param2:String = "")
      {
         super();
         this.id = param1;
         this.creation = param2;
      }
   }
}

