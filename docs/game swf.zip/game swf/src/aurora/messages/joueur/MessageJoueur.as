package aurora.messages.joueur
{
   public class MessageJoueur
   {
      
      public var id:int;
      
      public function MessageJoueur(param1:int = 0)
      {
         super();
         this.id = param1;
      }
   }
}

