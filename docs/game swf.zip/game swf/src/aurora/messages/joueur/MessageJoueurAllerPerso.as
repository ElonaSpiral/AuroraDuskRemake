package aurora.messages.joueur
{
   public class MessageJoueurAllerPerso
   {
      
      public var id:int;
      
      public var cibleId:int;
      
      public function MessageJoueurAllerPerso(param1:int = 0, param2:int = 0)
      {
         super();
         this.id = param1;
         this.cibleId = param2;
      }
   }
}

