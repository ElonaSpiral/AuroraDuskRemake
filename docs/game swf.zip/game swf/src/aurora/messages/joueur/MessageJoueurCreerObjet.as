package aurora.messages.joueur
{
   public class MessageJoueurCreerObjet
   {
      
      public var id:int;
      
      public var atelier:int;
      
      public var choix:int;
      
      public var amelioration:Boolean;
      
      public function MessageJoueurCreerObjet(param1:int = 0, param2:int = 0, param3:int = 0, param4:Boolean = false)
      {
         super();
         this.id = param1;
         this.atelier = param2;
         this.choix = param3;
         this.amelioration = param4;
      }
   }
}

