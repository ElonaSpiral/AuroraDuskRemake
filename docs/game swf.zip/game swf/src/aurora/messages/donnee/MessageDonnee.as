package aurora.messages.donnee
{
   public class MessageDonnee
   {
      
      public var donnee:Object;
      
      public function MessageDonnee(param1:Object = null)
      {
         super();
         this.donnee = param1;
      }
   }
}

