package aurora.messages.infos
{
   public class MessageInfosScore
   {
      
      public var id:String;
      
      public var score:int;
      
      public function MessageInfosScore(param1:String = "", param2:int = 0)
      {
         super();
         this.id = param1;
         this.score = param2;
      }
   }
}

