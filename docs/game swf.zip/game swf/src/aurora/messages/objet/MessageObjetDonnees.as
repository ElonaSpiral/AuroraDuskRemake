package aurora.messages.objet
{
   public class MessageObjetDonnees
   {
      
      public static const AJOUTER:int = 0;
      
      public static const ACTUALISER:int = 1;
      
      public static const EQUIPER:int = 2;
      
      public static const DESEQUIPER:int = 3;
      
      public static const QUANTITE:int = 4;
      
      public static const DUREE:int = 6;
      
      public static const RECHARGEMENT:int = 7;
      
      public static const SUPPRIMER:int = 5;
      
      public var action:int;
      
      public var id:int;
      
      public var deltaQuantite:int;
      
      public var donnees:Object;
      
      public function MessageObjetDonnees(param1:int = 0, param2:int = 0, param3:int = 0, param4:Object = null)
      {
         super();
         this.action = param1;
         this.id = param2;
         this.deltaQuantite = param3;
         this.donnees = param4;
      }
   }
}

