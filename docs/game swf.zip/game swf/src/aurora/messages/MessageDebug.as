package aurora.messages
{
   public class MessageDebug
   {
      
      public static const MESSAGE_DEBUG:int = 0;
      
      public static const MESSAGE_NORMAL:int = 1;
      
      public static const MESSAGE_IMPORTANT:int = 2;
      
      public static const MESSAGE_ALERTE:int = 3;
      
      public var texte:String;
      
      public var type:int;
      
      public function MessageDebug(param1:String = "", param2:int = 0)
      {
         super();
         this.texte = param1;
         this.type = param2;
      }
   }
}

