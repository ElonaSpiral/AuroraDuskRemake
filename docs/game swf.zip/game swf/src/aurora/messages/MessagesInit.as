package aurora.messages
{
   import aurora.messages.commun.MessageEntier;
   import aurora.messages.donnee.MessageDonnee;
   import aurora.messages.effet.MessageEffetAfficher;
   import aurora.messages.infos.MessageInfosScore;
   import aurora.messages.jeu.MessageJeuDemarrer;
   import aurora.messages.jeu.MessageJeuQuitter;
   import aurora.messages.jeu.MessageJeuTerminee;
   import aurora.messages.joueur.MessageJoueur;
   import aurora.messages.joueur.MessageJoueurAllerPerso;
   import aurora.messages.joueur.MessageJoueurCible;
   import aurora.messages.joueur.MessageJoueurCreerObjet;
   import aurora.messages.joueur.MessageJoueurCreerPerso;
   import aurora.messages.joueur.MessageJoueurDeplacer;
   import aurora.messages.joueur.MessageJoueurDonnees;
   import aurora.messages.joueur.MessageJoueurDonnerOrdre;
   import aurora.messages.joueur.MessageJoueurRecupererCaracteristiquePrimaire;
   import aurora.messages.joueur.MessageJoueurUtiliserObjet;
   import aurora.messages.joueur.MessageJoueurUtiliserRessource;
   import aurora.messages.joueur.MessageJoueurValiderEmplacement;
   import aurora.messages.joueur.MessageJoueurVerifierEmplacement;
   import aurora.messages.joueur.MessageJoueurVision;
   import aurora.messages.objet.MessageObjetDonnees;
   import aurora.messages.perso.MessagePersoActualiser;
   import aurora.messages.perso.MessagePersoActualiserEntier;
   import aurora.messages.perso.MessagePersoActualiserNombre;
   import aurora.messages.perso.MessagePersoActualiserTexte;
   import aurora.messages.perso.MessagePersoApparence;
   import aurora.messages.perso.MessagePersoBooleen;
   import aurora.messages.perso.MessagePersoCreer;
   import aurora.messages.perso.MessagePersoDeplacer;
   import aurora.messages.perso.MessagePersoDetruire;
   import aurora.messages.perso.MessagePersoOrienter;
   import aurora.messages.perso.MessagePersoRotation;
   import aurora.messages.perso.MessagePersoSauvegarder;
   import flash.net.registerClassAlias;
   
   public class MessagesInit
   {
      
      public function MessagesInit()
      {
         super();
      }
      
      public static function init() : void
      {
         registerClassAlias("aurora.messages.MessageDebug",MessageDebug);
         registerClassAlias("aurora.messages.commun.MessageEntier",MessageEntier);
         registerClassAlias("aurora.messages.donnee.MessageDonnee",MessageDonnee);
         registerClassAlias("aurora.messages.jeu.MessageJeuDemarrer",MessageJeuDemarrer);
         registerClassAlias("aurora.messages.jeu.MessageJeuQuitter",MessageJeuQuitter);
         registerClassAlias("aurora.messages.jeu.MessageJeuTerminee",MessageJeuTerminee);
         registerClassAlias("aurora.messages.joueur.MessageJoueur",MessageJoueur);
         registerClassAlias("aurora.messages.joueur.MessageJoueurDeplacer",MessageJoueurDeplacer);
         registerClassAlias("aurora.messages.joueur.MessageJoueurAllerPerso",MessageJoueurAllerPerso);
         registerClassAlias("aurora.messages.joueur.MessageJoueurCreerPerso",MessageJoueurCreerPerso);
         registerClassAlias("aurora.messages.joueur.MessageJoueurCreerObjet",MessageJoueurCreerObjet);
         registerClassAlias("aurora.messages.joueur.MessageJoueurUtiliserRessource",MessageJoueurUtiliserRessource);
         registerClassAlias("aurora.messages.joueur.MessageJoueurUtiliserObjet",MessageJoueurUtiliserObjet);
         registerClassAlias("aurora.messages.joueur.MessageJoueurRecupererCaracteristiquePrimaire",MessageJoueurRecupererCaracteristiquePrimaire);
         registerClassAlias("aurora.messages.joueur.MessageJoueurDonnees",MessageJoueurDonnees);
         registerClassAlias("aurora.messages.joueur.MessageJoueurCible",MessageJoueurCible);
         registerClassAlias("aurora.messages.joueur.MessageJoueurVerifierEmplacement",MessageJoueurVerifierEmplacement);
         registerClassAlias("aurora.messages.joueur.MessageJoueurValiderEmplacement",MessageJoueurValiderEmplacement);
         registerClassAlias("aurora.messages.joueur.MessageJoueurDonnerOrdre",MessageJoueurDonnerOrdre);
         registerClassAlias("aurora.messages.joueur.MessageJoueurVision",MessageJoueurVision);
         registerClassAlias("aurora.messages.perso.MessagePersoCreer",MessagePersoCreer);
         registerClassAlias("aurora.messages.perso.MessagePersoDeplacer",MessagePersoDeplacer);
         registerClassAlias("aurora.messages.perso.MessagePersoOrienter",MessagePersoOrienter);
         registerClassAlias("aurora.messages.perso.MessagePersoRotation",MessagePersoRotation);
         registerClassAlias("aurora.messages.perso.MessagePersoActualiser",MessagePersoActualiser);
         registerClassAlias("aurora.messages.perso.MessagePersoActualiserNombre",MessagePersoActualiserNombre);
         registerClassAlias("aurora.messages.perso.MessagePersoActualiserEntier",MessagePersoActualiserEntier);
         registerClassAlias("aurora.messages.perso.MessagePersoActualiserTexte",MessagePersoActualiserTexte);
         registerClassAlias("aurora.messages.perso.MessagePersoApparence",MessagePersoApparence);
         registerClassAlias("aurora.messages.perso.MessagePersoBooleen",MessagePersoBooleen);
         registerClassAlias("aurora.messages.perso.MessagePersoDetruire",MessagePersoDetruire);
         registerClassAlias("aurora.messages.perso.MessagePersoSauvegarder",MessagePersoSauvegarder);
         registerClassAlias("aurora.messages.objet.MessageObjetDonnees",MessageObjetDonnees);
         registerClassAlias("aurora.messages.effet.MessageEffetAfficher",MessageEffetAfficher);
         registerClassAlias("aurora.messages.infos.MessageInfosScore",MessageInfosScore);
      }
   }
}

