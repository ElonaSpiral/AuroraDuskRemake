package aurora.messages.commun
{
   public class MessageEntier
   {
      
      public var entier:int;
      
      public function MessageEntier(param1:int = 0)
      {
         super();
         this.entier = param1;
      }
   }
}

