package aurora.messages.perso
{
   public class MessagePersoApparence
   {
      
      public var id:int;
      
      public var apparence:Vector.<Object>;
      
      public function MessagePersoApparence(param1:int = 0, param2:Vector.<Object> = null)
      {
         super();
         this.id = param1;
         this.apparence = param2;
      }
   }
}

