package aurora.messages.perso
{
   public class MessagePersoCreer
   {
      
      public var id:int;
      
      public var race:String;
      
      public var cliquable:Boolean;
      
      public var ennemi:Boolean;
      
      public var cliquableMort:Boolean;
      
      public var cliquableBlesse:Boolean;
      
      public var serviteur:Boolean;
      
      public var jouable:Boolean;
      
      public var x:Number;
      
      public var y:Number;
      
      public var largeur:int;
      
      public var hauteur:int;
      
      public var anim:String;
      
      public var decalageY:int;
      
      public function MessagePersoCreer(param1:int = 0, param2:String = "", param3:Boolean = false, param4:Boolean = false, param5:Boolean = false, param6:Boolean = false, param7:Boolean = false, param8:Boolean = false, param9:Number = 0, param10:Number = 0, param11:int = 0, param12:int = 0, param13:String = "", param14:int = 0)
      {
         super();
         this.id = param1;
         this.race = param2;
         this.cliquable = param3;
         this.ennemi = param4;
         this.cliquableMort = param5;
         this.cliquableBlesse = param6;
         this.serviteur = param7;
         this.jouable = param8;
         this.x = param9;
         this.y = param10;
         this.largeur = param11;
         this.hauteur = param12;
         this.anim = param13;
         this.decalageY = param14;
      }
   }
}

