package aurora.messages.perso
{
   public class MessagePersoOrienter
   {
      
      public static const DEFAUT:int = 0;
      
      public static const HAUT:int = 1;
      
      public static const BAS:int = 0;
      
      public static const GAUCHE:int = 2;
      
      public static const DROITE:int = 3;
      
      public var id:int;
      
      public var orientation:int;
      
      public function MessagePersoOrienter(param1:int = 0, param2:int = 0)
      {
         super();
         this.id = param1;
         this.orientation = param2;
      }
   }
}

