package aurora.messages.perso
{
   public class MessagePersoDetruire
   {
      
      public var id:int;
      
      public function MessagePersoDetruire(param1:int = 0)
      {
         super();
         this.id = param1;
      }
   }
}

