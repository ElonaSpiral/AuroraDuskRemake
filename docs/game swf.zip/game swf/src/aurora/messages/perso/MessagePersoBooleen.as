package aurora.messages.perso
{
   public class MessagePersoBooleen
   {
      
      public var id:int;
      
      public var booleen:Boolean;
      
      public function MessagePersoBooleen(param1:int = 0, param2:Boolean = false)
      {
         super();
         this.id = param1;
         this.booleen = param2;
      }
   }
}

