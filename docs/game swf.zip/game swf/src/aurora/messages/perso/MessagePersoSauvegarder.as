package aurora.messages.perso
{
   public class MessagePersoSauvegarder
   {
      
      public var nom:String;
      
      public var donnees:Object;
      
      public var quitter:Boolean;
      
      public function MessagePersoSauvegarder(param1:String = "", param2:Object = null, param3:Boolean = false)
      {
         super();
         this.nom = param1;
         this.donnees = param2;
         this.quitter = param3;
      }
   }
}

