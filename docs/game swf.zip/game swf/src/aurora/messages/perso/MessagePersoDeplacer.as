package aurora.messages.perso
{
   public class MessagePersoDeplacer
   {
      
      public var id:int;
      
      public var x:int;
      
      public var y:int;
      
      public var pas:int;
      
      public function MessagePersoDeplacer(param1:int = 0, param2:int = 0, param3:int = 0, param4:int = 0)
      {
         super();
         this.id = param1;
         this.x = param2;
         this.y = param3;
         this.pas = param4;
      }
   }
}

