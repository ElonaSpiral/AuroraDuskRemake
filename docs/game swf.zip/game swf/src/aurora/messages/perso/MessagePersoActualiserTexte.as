package aurora.messages.perso
{
   public class MessagePersoActualiserTexte
   {
      
      public var id:int;
      
      public var texte:String;
      
      public function MessagePersoActualiserTexte(param1:int = 0, param2:String = "")
      {
         super();
         this.id = param1;
         this.texte = param2;
      }
   }
}

