package aurora.messages.perso
{
   public class MessagePersoRotation
   {
      
      public var id:int;
      
      public var rotation:Number;
      
      public function MessagePersoRotation(param1:int = 0, param2:Number = 0)
      {
         super();
         this.id = param1;
         this.rotation = param2;
      }
   }
}

