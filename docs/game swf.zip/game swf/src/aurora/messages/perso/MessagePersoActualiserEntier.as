package aurora.messages.perso
{
   public class MessagePersoActualiserEntier
   {
      
      public var id:int;
      
      public var entier:int;
      
      public function MessagePersoActualiserEntier(param1:int = 0, param2:int = 0)
      {
         super();
         this.id = param1;
         this.entier = param2;
      }
   }
}

