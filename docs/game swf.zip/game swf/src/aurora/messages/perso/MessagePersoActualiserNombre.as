package aurora.messages.perso
{
   public class MessagePersoActualiserNombre
   {
      
      public var id:int;
      
      public var nombre:Number;
      
      public function MessagePersoActualiserNombre(param1:int = 0, param2:Number = 0)
      {
         super();
         this.id = param1;
         this.nombre = param2;
      }
   }
}

