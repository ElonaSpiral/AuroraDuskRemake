package aurora.messages.perso
{
   public class MessagePersoActualiser
   {
      
      public var id:int;
      
      public function MessagePersoActualiser(param1:int = 0)
      {
         super();
         this.id = param1;
      }
   }
}

