package aurora.messages.jeu
{
   public class MessageJeuQuitter
   {
      
      public function MessageJeuQuitter()
      {
         super();
      }
   }
}

