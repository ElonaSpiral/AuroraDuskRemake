package aurora.messages.jeu
{
   public class MessageJeuTerminee
   {
      
      public var gagne:Boolean;
      
      public function MessageJeuTerminee(param1:Boolean = false)
      {
         super();
         this.gagne = param1;
      }
   }
}

