package aurora.messages.jeu
{
   import flash.utils.ByteArray;
   
   public class MessageJeuDemarrer
   {
      
      public var config:Object;
      
      public var nbDonnees:int;
      
      public var sauvegarde:ByteArray;
      
      public function MessageJeuDemarrer(param1:Object = null, param2:int = 0, param3:ByteArray = null)
      {
         super();
         this.config = param1;
         this.nbDonnees = param2;
         this.sauvegarde = param3;
      }
   }
}

