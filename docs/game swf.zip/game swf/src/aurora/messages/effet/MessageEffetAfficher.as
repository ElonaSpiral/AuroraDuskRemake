package aurora.messages.effet
{
   public class MessageEffetAfficher
   {
      
      public var x:Number;
      
      public var y:Number;
      
      public var volume:Number;
      
      public var effet:String;
      
      public var score:int;
      
      public var echelle:Number;
      
      public function MessageEffetAfficher(param1:Number = 0, param2:Number = 0, param3:String = "", param4:Number = 1, param5:int = 0, param6:Number = 1)
      {
         super();
         this.x = param1;
         this.y = param2;
         this.effet = param3;
         this.volume = param4;
         this.score = param5;
         this.echelle = param6;
      }
   }
}

